# Elevenex design system

Elevenex is a desktop app for running and supervising coding agents. The model:

- A **project** is one or more repositories on a machine. It holds tasks; each task works in one of its repositories.
- A **task** is one piece of work: a git branch plus a workspace that Elevenex manages for it. A task moves through stages (Planned, Active, Waiting, Closed).
- A **session** is one agent conversation inside a task. A task can run many sessions at once; a session can be forked, and a side chat can branch off a message.
- A **machine** is where Elevenex runs its agents: this computer, or another one (often over SSH). A window works on one machine at a time.

This folder is the complete design system for that app: the rules, the tokens, a reference implementation of every component, and a live preview of each. It's self-contained: you don't need any other context to use it.

## Read in this order

1. `project/README.md`, the **brand book**. It's the source of truth: the product model, voice, color, type, layout, the chat, the Changes review, machines, motion (with the reasons behind each rule), the keyboard map, and, at the end, the open questions and what isn't designed yet.
2. `project/tokens.css`, every token as a CSS custom property, in light and dark. `project/tokens.json` is the same data with a usage note for each token.
3. The gallery: run `npm run gallery && npm run serve`, then open http://localhost:4321/gallery/. It shows all 83 cards, and the Dark button switches every card. Start with the **Pages** group (`AppShell`, `Chat`), which shows the whole window composed.
4. For a component: `project/components/<Name>/README.md` says what it is, its props, its states and its motion. `preview.html` is the live card, and `index.d.ts` has the types of every export.

## What's normative, and what's a reference

- **Normative** (the app must follow it): the brand book, the tokens, each component's README (behavior, states, motion, do's and don'ts), and how the cards look and move.
- **Reference implementation:** `project/components/bundle.js` and `bundle.css`. They're a working React 18 version of every component, written so the previews can run without a build step: one classic script that sets `window.Elevenex`, no JSX, no dependencies, every class prefixed `ex-`. Read them to see exactly how something is built or animated. Port them; don't ship them as they are.

## The app being built

These decisions were made for the real app. Follow them unless told otherwise.

- **Stack:** Angular (standalone components, Signals, zoneless) inside Electron.
- **Styling:** no Tailwind. Plain CSS in each component's styles, using only the variables from `tokens.css`. Copy `tokens.css` as it is, and port `bundle.css` one component at a time. Bundle the two fonts (Instrument Sans, Geist Mono) locally.
- **Motion:** no `@angular/animations` (it's deprecated). Use CSS transitions and keyframes with the duration and easing tokens, the Web Animations API for moves started from code, and Angular's `animate.enter` / `animate.leave` for things that appear and leave. The springs are already CSS `linear()` curves (`--ease-glide`, `--ease-spring`), so no spring library is needed. The motion helpers in `bundle.js` become small Angular directives:

  | In bundle.js | What it does | In Angular |
  | --- | --- | --- |
  | `Presence` / `usePresence` | keeps something mounted while it plays its exit | `animate.leave` |
  | `Fold` | opens and closes in place (grid rows 0fr ↔ 1fr) | a directive or component with the same CSS |
  | `AutoHeight` | a box that eases to its content's height | a directive with a ResizeObserver |
  | `FlipScope`, `useFlip` | things that move slide from where they were (FLIP) | a directive using the Web Animations API |
  | `EaseSwap` | swaps a label in place while its width eases | a small component |
  | `usePanelTakeover` | the Changes panel takes over the chat for a while | a directive on the main area |

- **Headless behavior** (menus, popovers, dialogs, listboxes, comboboxes, tabs, focus handling) comes from an unstyled library: Angular CDK, `@angular/aria`, or Spartan's "brain" layer. The looks always come from this design system.
- **Electron:** the renderer never touches git, files or agents directly. Those run in the main process (or worker processes), behind typed IPC. The Changes review expects each file's diff to be loaded on demand (see `DiffReview`).

## Checks

Requirements: Node 18+ and Python 3.9+. Nothing to install.

```sh
npm run smoke      # renders every preview with a tiny React stand-in; fails on any exception
npm run gallery    # writes gallery/: one page per card, plus an index
npm run serve      # http://localhost:4321/gallery/
npm run tokens:json  # rewrites tokens.json from tools/gen_tokens.py and checks contrast in both themes
```

React 18.3.1 is included in `vendor/`, so the gallery works offline. The fonts load from Google Fonts; offline, the cards fall back to system fonts.

## What's in the folder

```
README.md                  this file
AGENTS.md                  rules for an agent changing the design system itself
project/
  README.md                the brand book (start here)
  tokens.css, tokens.json  the tokens (tokens.json is written by tools/gen_tokens.py; tokens.css from it)
  design-system.json       index: title, namespace, last change
  components/
    bundle.js, bundle.css  the reference implementation of every component
    index.d.ts             types for every export
    <Name>/README.md       the component's guidelines
    <Name>/preview.html    its live card
gallery/                   generated pages (safe to delete; npm run gallery rebuilds it)
tools/                     the generators and checks (see AGENTS.md)
vendor/                    React 18.3.1 (MIT), for the gallery and the check pages
```
