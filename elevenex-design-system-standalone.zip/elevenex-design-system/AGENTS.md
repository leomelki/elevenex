# Working in this folder

Read `README.md` first. If you're **building the app**, use this folder as the spec and port from it; the rules below don't bind your app code, except the design rules (tokens, contrast, motion).

If you're **changing the design system itself**, keep these rules.

## Shape

- `project/` keeps one shape: `components/<Name>/README.md` plus `preview.html` per component, one `bundle.js`, one `bundle.css`, `index.d.ts`, `tokens.json`, `tokens.css`, `design-system.json`.
- Generated files are never edited by hand:
  - `tokens.json` comes from `tools/gen_tokens.py` (`npm run tokens:json`, which also checks contrast);
  - `tokens.css` comes from `tokens.json` (`npm run tokens`);
  - `gallery/` comes from the previews (`npm run gallery`).
- To change a token, edit `tools/gen_tokens.py`, then run `npm run tokens:json`.

## Hard constraints of the reference implementation

- `bundle.js` is one classic script (no modules, no build step) that assigns `window.Elevenex`. It must never contain the strings `</script` or `<!--`, because it's inlined into pages.
- Its first line is the `/* @ds-bundle: {…} */` header, which lists every exported component.
- React 18 only, through `React.createElement` (aliased `h`). No JSX, no dependencies.
- Every `preview.html` starts with `<!-- @dsCard group="…" height=N [width=N] [page] -->` on line 1. It renders into `#root` and assumes `tokens.css`, `bundle.css`, React and `bundle.js` are already loaded.
- Every class is prefixed `ex-`.
- Colors, spacing, radii, shadows, durations and easings always come from tokens (`var(--…)`). No raw hex in components.
- Both themes must work: check every change in light and dark.
- Text contrast is WCAG AA (4.5:1) on every surface in both themes; control borders 3:1.
- When behavior or props change, update `index.d.ts`, the component's README and the brand book. Write docs in plain, short sentences, with no em dashes.

## Motion rules (the ones that bite)

- **Nothing pops and nothing jumps.** Nothing appears or disappears in one frame, and nothing below it gets shoved. The tools:
  - `Fold`: opens and closes in place.
  - `AutoHeight`: a box that eases to its content.
  - `MotionList`: keyed rows that grow in and collapse out.
  - `Presence` / `usePresence`: exits.
  - `FlipScope`: things that move between lists, and the selection highlight gliding.
  - `EaseSwap`: a label that changes in place.
- **A wrapper added for motion lays out exactly like what it wraps.** It carries its parent's gap and direction, sizes its column `minmax(0, 1fr)`, and adds no gap when closed.
- **Sizes ease on plain easing** (`ease-in-out`), never on a spring. Springs are for small marks only (checks, counts, thumbs).
- **One change is one motion.** Parts that move together start together and take the same time. Nothing waits for another part to finish or to cross a threshold first.
- **What you're reading stays where it is** when content above it changes.
- **Closing is quicker than opening**, and content fades before the box finishes closing.
- **Motion follows stable ids**, never list positions.
- **History and first paint never animate.**
- **Honor `prefers-reduced-motion`.**

## How to check a change

1. `npm run smoke`: no preview may throw.
2. `npm run gallery && npm run serve`: look at the cards you touched, in light and dark.
3. **CSS refactors:** keep a copy of the previous `project/` and run `python3 tools/layout_diff.py ../before/project project diff.html <Comp,…>`. Run it again with `style` as the last argument. Open `diff.html`: everything not changed on purpose must say `same`.
4. **Motion:**
   - Wrap a page with `tools/probe.py` (watches the content below a component) or `tools/probe_rows.py` (every row of a list) to catch one-frame jumps.
   - To see the frames in between, pause `document.getAnimations()` at a chosen `currentTime` and look. Some preview viewers pause or throttle the animation clock, so this is the reliable way.
5. `tools/harness.py project out.html Comp,Comp [width]` puts chosen cards in light and dark on one page.

## Where to start

The last section of `project/README.md` lists the open questions (with what the system does until they're answered) and what isn't designed yet.
