# What changed since the last zip

Two changes, both about limits:

1. plan usage is always in view;
2. alerts when a limit runs low or hits, for a plan or for context.

There are also two small fixes. Everything is in the components (`bundle.js`, `bundle.css`), the types (`index.d.ts`), the READMEs and the brand book (`project/README.md`: the composer section and the status table).

The gallery now has 87 cards: `PlanMeter` is new. Its card shows everything below: the chip at five moments, the hover card, the agent menu, a narrow window, the limit hitting, and context filling up.

## 1. Plan usage, always in view

**What it measures:** what's left of a Claude or Codex plan. Unlike context, a plan isn't one session's. Every session on that account draws from it, and it comes back on a clock: a 5-hour window, and a weekly one.

**`PlanMeter`** (new) is a second small ring, beside the context ring in the agent chip.
- A 14px ring with a clock hand, the same size and weight as the context ring. The clock hand says it's a limit that comes back.
- It fills as the plan is used: a full ring means nothing left, like the context ring.
- It tracks one number, the limit that stops you first: the 5-hour one or the weekly one, whichever has less left.
- **Colors:** `ink-muted` while there's plenty, `attention` at 20% left, `danger` at the limit.
- **In the chip** (`compact`), the number only shows when it matters:
  - "12%" when running low ("18% wk" when the weekly limit is the tighter one);
  - "14:30" at the limit, meaning when it comes back.
- **API key:** with an API key there's no plan, so only the context ring shows.

**`UsageCard`** (new) is the agent chip's hover card.
- It appears after hovering or focusing the chip for 400ms.
- It shows context (ring, %, "84k of 200k"), then the plan's name and tier ("Claude plan · Max").
- Then each limit, with a thin bar of what's left and when it resets ("5-hour limit · 12% left · Resets at 14:30"). The tighter limit is in bold.
- Its footer reads "More in the agent menu ⌘J".
- The agent menu now opens on the same block, above model and thinking.

**`PlanNotice`** (new) is a line above the composer.
- At 20% left: "12% of your 5-hour limit left. Resets at 14:30." in `attention-soft`, dismissible.
- At the limit: "Claude plan limit reached. Resets at 14:30." in `danger-soft`, with two actions:
  - **Send at 14:30** (write now, it sends then; the composer's placeholder says "Write now, it sends at 14:30…");
  - **Fork to Codex** (`forkTo`).
- It renders nothing while there's plenty.

**API:**
- The `AgentPicker` value (and so `Composer`'s `agent`) takes:
  - `plan: { win, week, resetWin, resetWeek, name, tier }`, where `win` and `week` are what's LEFT, 0–1;
  - `tokens` ("84k of 200k").
- Previews only: `AgentPicker` has `cardOpen` and `Composer` has `agentCardOpen`, to show the card.

**Motion:**
- Arcs ease as usage changes, and colors ease at each threshold.
- The number fades in when it appears.
- The card rises 3px and fades in (140ms), and leaves in 120ms.

## 2. Alerts when a limit runs low or hits

**A new session status: Paused.**
- Its glyph is a circle with a pause sign, in `ink-muted`.
- It means the session stopped at a plan limit and picks up by itself when the limit resets.
- The session row says "until 14:30", and the session stays in the task's working sessions.
- It's in `StatusGlyph` and the `Status` type, and in the brand book's status table.

**When a running session hits the limit:**
- Its turn (`Turn` with `status: 'paused'` and `pause: { plan, resumes, forkTo, onFork, onStop }`) reads "Paused after 3m 12s".
- One line under it says: "**Paused at the Claude plan limit.** It picks up where it stopped at 14:30." with **Fork to Codex** and **Stop**.
- At 14:30 it carries on by itself.

**Wherever you are,** the title island shows it once, in `warn`:
- `IslandEvent` with the clock icon: "Claude plan limit reached · 3 sessions paused until 14:30 · Show".
- Show opens the first paused session.
- Like any event, it shrinks back after a few seconds.

**Context filling up: `ContextNotice`** (new), a line above the composer.
- **From 75% (`attention`):** "**Context 78% full.** Compact it to keep long work sharp." with Fork with a summary and **Compact now**. It can be dismissed.
- **From 90% (`danger`):** "**Context 94% full.** The agent may lose track of early details." It stays until there's room.
- **In the agent menu:** from 75%, a small **Compact** button sits beside the context row (`AgentPicker` `onCompact`).

**One line above the composer at a time,** the most urgent first:
1. a plan at its limit;
2. context at 90%;
3. a plan running low;
4. context at 75%.

## Fixes

- **A narrow composer no longer overflows.** It uses a container query on `.ex-composer` and gives way in this order:
  - under 600px, the agent's details (model · thinking);
  - under 520px, the Plan · Code labels (their icons stay);
  - under 440px, the permission label (the shield stays).
  - The meters, the preset's name, attach, dictate and send always stay, and nothing overlaps.
- **`PlanCard`'s step counter** read "0of 5". It now reads "0 of 5".
