# ContextMeter

How much of the agent's context window the session has used: a small ring that fills smoothly, `ink-muted` normally, `attention` from 75%, `danger` from 90%. It sits inside the agent chip (compact), beside the `PlanMeter` on a plan, and in full in the chip's usage card and at the top of the agent menu, with the token count.

**Provide:** `used` (0–1), optional `tokens` (text), `compact`.

- From 75% (`attention`), the agent menu shows **Compact** beside the context row, and `ContextNotice` puts one line above the composer with Compact now and Fork with a summary. From 90% (`danger`) the line can't be dismissed. See `PlanMeter` for the order when a plan line competes.
