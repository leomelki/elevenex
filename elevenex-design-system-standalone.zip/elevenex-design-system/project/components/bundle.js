/* @ds-bundle: {"format":4,"namespace":"Elevenex","components":[{"name":"Icon"},{"name":"Button"},{"name":"IconButton"},{"name":"Kbd"},{"name":"StatusGlyph"},{"name":"StatusBadge"},{"name":"StatusSummary"},{"name":"ProjectRail"},{"name":"ProjectMark"},{"name":"NewProject"},{"name":"TaskStage"},{"name":"LinkChip"},{"name":"TaskGroup"},{"name":"TaskList"},{"name":"SessionRow"},{"name":"TaskHeader"},{"name":"NewTask"},{"name":"BranchPicker"},{"name":"BranchChip"},{"name":"WorkspacePicker"},{"name":"TaskLine"},{"name":"CloseTask"},{"name":"PanelTabs"},{"name":"BrowserView"},{"name":"TerminalView"},{"name":"SessionStart"},{"name":"PresetPicker"},{"name":"AgentPicker"},{"name":"ModeToggle"},{"name":"PermissionPicker"},{"name":"ToolsMenu"},{"name":"ComposerQueue"},{"name":"Switch"},{"name":"Segmented"},{"name":"Mention"},{"name":"Composer"},{"name":"Message"},{"name":"Markdown"},{"name":"ChatScroll"},{"name":"SideThread"},{"name":"GitBar"},{"name":"CommitPanel"},{"name":"ChangeList"},{"name":"DiffReview"},{"name":"ApprovalCard"},{"name":"QuestionCard"},{"name":"PlanCard"},{"name":"ThinkingBlock"},{"name":"ToolStep"},{"name":"StreamText"},{"name":"MentionMenu"},{"name":"Toast"},{"name":"Tooltip"},{"name":"Skeleton"},{"name":"ContextMeter"},{"name":"PlanMeter"},{"name":"NewMessagesPill"},{"name":"ProgressLine"},{"name":"Presence"},{"name":"Turn"},{"name":"WorkTimeline"},{"name":"NowLine"},{"name":"OutcomeBar"},{"name":"FileChip"},{"name":"TurnNav"},{"name":"Fold"},{"name":"TitleIsland"},{"name":"MachinePanel"},{"name":"MachineCard"},{"name":"MachineHome"},{"name":"MachineLaunch"},{"name":"GettingReady"},{"name":"AddMachine"},{"name":"MachineMenu"},{"name":"EditMachine"},{"name":"HostField"},{"name":"HostKeyCheck"},{"name":"PairingText"},{"name":"PairPaste"}]} */
(function () {
  'use strict';
  var React = window.React;
  var h = React.createElement;
  var F = React.Fragment;
  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(' '); }

  /* ── Motion helpers ── */
  var useLayout = React.useLayoutEffect || React.useEffect;
  /* Measures the selected child of a container so a single "thumb" can glide between options. */
  function useThumb(sel, deps) {
    var ref = React.useRef(null);
    var _s = React.useState(null); var box = _s[0], setBox = _s[1];
    var _r = React.useState(false); var ready = _r[0], setReady = _r[1];
    useLayout(function () {
      var el = ref.current; if (!el || !el.querySelector) return;
      function measure() {
        var on = el.querySelector(sel);
        if (!on) { setBox(null); return; }
        setBox({ left: on.offsetLeft, top: on.offsetTop, width: on.offsetWidth, height: on.offsetHeight });
      }
      measure();
      var t = setTimeout(function () { setReady(true); }, 30);
      /* the list itself changed size (a fold opening, padding changing): the thumb follows at once, without gliding,
         so the highlight never lags behind its row; it only glides when the selection moves */
      var raf = 0;
      function resized() {
        el.classList.add('is-resizing'); measure();
        /* write it now too: the observer runs before this frame paints, a re-render may not */
        var on = el.querySelector(sel), th = el.querySelector(':scope > .ex-thumb');
        if (on && th) { th.style.transform = 'translate(' + on.offsetLeft + 'px,' + on.offsetTop + 'px)'; th.style.width = on.offsetWidth + 'px'; th.style.height = on.offsetHeight + 'px'; }
        cancelAnimationFrame(raf); raf = requestAnimationFrame(function () { raf = requestAnimationFrame(function () { el.classList.remove('is-resizing'); }); });
      }
      var ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resized) : null;
      if (ro) ro.observe(el);
      return function () { clearTimeout(t); cancelAnimationFrame(raf); if (ro) ro.disconnect(); };
    }, deps);
    return { ref: ref, style: box ? { transform: 'translate(' + box.left + 'px,' + box.top + 'px)', width: box.width, height: box.height } : { opacity: 0 }, ready: ready, has: !!box };
  }
  function reducedMotion() { try { return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } }
  function tokenOf(el, name, fallback) { try { var v = getComputedStyle(el || document.documentElement).getPropertyValue('--' + name).trim(); return v || fallback; } catch (e) { return fallback; } }
  function msOf(el, name, fallback) { var v = parseFloat(tokenOf(el, name, '')); return isNaN(v) ? fallback : v; }
  /* Web Animations with the system's spring; silently skipped where unsupported or under reduced motion. */
  function play(el, frames, opts) {
    if (!el || !el.animate || reducedMotion()) return null;
    opts = opts || {};
    var easing = tokenOf(el, opts.ease || 'ease-glide', 'cubic-bezier(0.16, 1, 0.3, 1)');
    var dur = msOf(el, opts.dur || 'dur-glide', 320);
    try { return el.animate(frames, { duration: dur, easing: easing, fill: opts.fill || 'none' }); }
    catch (e) { try { return el.animate(frames, { duration: dur, easing: 'cubic-bezier(0.16, 1, 0.3, 1)' }); } catch (e2) { return null; } }
  }
  /* FLIP: children that move because of a layout change slide from where they were. */
  function useFlip(ref, sel, deps) {
    var last = React.useRef(null);
    useLayout(function () {
      var el = ref.current; if (!el || !el.querySelectorAll) return;
      var now = {}; var nodes = el.querySelectorAll(sel);
      for (var i = 0; i < nodes.length; i++) { var k = nodes[i].getAttribute('data-key') || i; now[k] = nodes[i].offsetLeft; }
      var before = last.current; last.current = now;
      if (!before) return;
      for (var j = 0; j < nodes.length; j++) {
        var key = nodes[j].getAttribute('data-key') || j;
        var dx = (before[key] == null ? now[key] : before[key]) - now[key];
        if (Math.abs(dx) > 0.5) play(nodes[j], [{ transform: 'translateX(' + dx + 'px)' }, { transform: 'none' }]);
      }
    }, deps);
  }
  /* Keeps a child mounted while it plays its exit (.is-leaving), then removes it. */
  function Presence(props) {
    var _m = React.useState(!!props.show); var mounted = _m[0], setMounted = _m[1];
    var _l = React.useState(false); var leaving = _l[0], setLeaving = _l[1];
    React.useEffect(function () {
      if (props.show) { setMounted(true); setLeaving(false); return; }
      if (!mounted) return;
      setLeaving(true);
      var t = setTimeout(function () { setMounted(false); setLeaving(false); }, props.exit || 160);
      return function () { clearTimeout(t); };
    }, [props.show]);
    if (!mounted) return null;
    return h('div', { className: cx('ex-presence', leaving && 'is-leaving') }, props.children);
  }
  /* Presence as a hook: { m: mounted, l: leaving }. Keeps an element for `exit` ms after it should go. */
  function usePresence(show, exit) {
    var _m = React.useState(!!show); var m = _m[0], setM = _m[1];
    var _l = React.useState(false); var l = _l[0], setL = _l[1];
    React.useEffect(function () {
      if (show) { setM(true); setL(false); return; }
      if (!m) return;
      setL(true);
      var t = setTimeout(function () { setM(false); setL(false); }, exit || 140);
      return function () { clearTimeout(t); };
    }, [!!show]);
    return { m: m, l: l };
  }
  /* The last non-empty value, held for `ms` after it empties: bridges the short gaps between two actions. */
  function useHold(value, ms) {
    var last = React.useRef(value);
    var _h = React.useState(!!value); var held = _h[0], setHeld = _h[1];
    if (value) last.current = value;
    React.useEffect(function () {
      if (value) { setHeld(true); return; }
      var t = setTimeout(function () { setHeld(false); }, ms || 600);
      return function () { clearTimeout(t); };
    }, [!!value]);
    return { value: last.current, on: !!value || held };
  }
  /* A box whose height eases to its content's. Small steps (a list row growing in) are followed as they come;
     jumps (a card collapsing, a line of text, a footer appearing) ease over dur-base. Content is never delayed. */
  function AutoHeight(props) {
    var outer = React.useRef(null), inner = React.useRef(null);
    useLayout(function () {
      var o = outer.current, i = inner.current;
      if (!o || !i || typeof ResizeObserver === 'undefined') return;
      var last = i.offsetHeight, sizing = false, t = null;
      function end() { sizing = false; o.style.height = ''; o.classList.remove('is-sizing'); }
      var ro = new ResizeObserver(function () {
        var next = i.offsetHeight;
        if (next === last) return;
        if (reducedMotion()) { last = next; return; }
        if (sizing) { o.style.height = next + 'px'; }
        else if (Math.abs(next - last) < 8) { last = next; return; }
        else {
          sizing = true; o.classList.add('is-sizing');
          o.style.height = last + 'px'; void o.offsetHeight; o.style.height = next + 'px';
        }
        last = next;
        clearTimeout(t); t = setTimeout(end, props.duration || 240);
      });
      ro.observe(i);
      return function () { ro.disconnect(); clearTimeout(t); };
    }, []);
    return h('div', { ref: outer, className: cx('ex-autoh', props.className) }, h('div', { ref: inner, className: cx('ex-autoh-in', props.innerClassName) }, props.children));
  }
  /* A keyed list whose rows grow in and collapse out instead of popping. items: [{ key, node }]. */
  function MotionList(props) {
    var store = React.useRef(null);
    var _f = React.useState(0); var force = _f[1];
    var first = store.current == null;
    var prev = store.current || [];
    var next = props.items || [];
    var inNext = {}; next.forEach(function (it) { inNext[it.key] = 1; });
    var prevAt = {}; prev.forEach(function (p, i) { prevAt[p.key] = i; });
    var leaving = prev.filter(function (p) { return !inNext[p.key]; }).map(function (p) { return p.leave ? p : Object.assign({}, p, { leave: Date.now() }); });
    var out = [], li = 0;
    next.forEach(function (it) {
      var at = prevAt[it.key];
      if (at != null) while (li < leaving.length && prevAt[leaving[li].key] < at) out.push(leaving[li++]);
      var was = at != null ? prev[at] : null;
      out.push({ key: it.key, node: it.node, enter: was ? (was.leave ? true : was.enter) : !first });
    });
    while (li < leaving.length) out.push(leaving[li++]);
    store.current = out;
    var exit = props.exit || 300;
    React.useEffect(function () {
      if (!leaving.length) return;
      var t = setTimeout(function () { var now = Date.now(); store.current = store.current.filter(function (p) { return !p.leave || now - p.leave < exit - 10; }); force(function (x) { return x + 1; }); }, exit);
      return function () { clearTimeout(t); };
    });
    return h(props.as || 'div', { className: props.className, role: props.role }, out.map(function (p) {
      return h(props.itemAs || 'div', { key: p.key, className: cx('ex-ml', p.enter && 'is-enter', p.leave && 'is-leave'), 'aria-hidden': p.leave ? 'true' : undefined }, h('div', { className: 'ex-ml-in' }, p.node));
    }));
  }
  /* FLIP across a region: anything marked data-flip="key" glides from where it was to where it is after a change:
     a reorder, a move to another list (a task changing stage), a filter. The copy a list keeps while it leaves
     hides at once when the same key lives on elsewhere, so a move reads as one thing travelling.
     `selected` (a data-flip key) also glides the selection highlight from the previous row to the new one. */
  function flipSnap(root) {
    /* in the root's own CSS pixels, so a zoomed or scaled page (a preview, a thumbnail) still travels the right distance */
    var r = root.getBoundingClientRect(), k = root.offsetWidth ? r.width / root.offsetWidth : 1, out = {};
    if (!k) k = 1;
    var nodes = root.querySelectorAll('[data-flip]');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i]; if (el.closest('.is-leave')) continue;
      var b = el.getBoundingClientRect();
      out[el.getAttribute('data-flip')] = { el: el, x: (b.left - r.left) / k + root.scrollLeft, y: (b.top - r.top) / k + root.scrollTop, w: b.width / k, h: b.height / k, hidden: !!el.closest('.ex-fold.is-closed') };
    }
    return out;
  }
  function FlipScope(props) {
    var ref = React.useRef(null), before = React.useRef(null), prevSel = React.useRef(props.selected);
    /* read the DOM while it still shows the previous state (render runs before the commit) */
    if (ref.current) before.current = flipSnap(ref.current);
    useLayout(function () {
      var root = ref.current; if (!root) return;
      var prev = before.current; before.current = null;
      var sel = props.selected, was = prevSel.current; prevSel.current = sel;
      if (!prev || reducedMotion()) return;
      var now = flipSnap(root);
      var ghosts = root.querySelectorAll('.ex-ml.is-leave [data-flip]');
      /* a copy only hides when the thing lives on in view; moving into something folded, it fades and collapses as it leaves */
      for (var g = 0; g < ghosts.length; g++) { var gk = now[ghosts[g].getAttribute('data-flip')]; if (gk && !gk.hidden) ghosts[g].closest('.ex-ml').classList.add('is-moved-away'); }
      /* document order, so a parent's move is known before its children: a child only moves by what it adds */
      var moved = {};
      Object.keys(now).forEach(function (k) {
        var a = prev[k], b = now[k]; if (!a || a.hidden || b.hidden) return;
        var dx = a.x - b.x, dy = a.y - b.y;
        var up = b.el.parentElement && b.el.parentElement.closest('[data-flip]');
        var pk = up && root.contains(up) ? up.getAttribute('data-flip') : null;
        if (pk && moved[pk]) { dx -= moved[pk][0]; dy -= moved[pk][1]; }
        if (Math.abs(dx) < 1 && Math.abs(dy) < 1) return;
        moved[k] = [a.x - b.x, a.y - b.y];
        var entering = b.el.closest('.ex-ml.is-enter'); if (entering) entering.classList.add('is-moved');
        if (b.el.getAnimations) b.el.getAnimations().forEach(function (an) { if (an.id === 'ex-flip') an.cancel(); });
        var an = play(b.el, [{ transform: 'translate(' + dx + 'px,' + dy + 'px)' }, { transform: 'none' }], { fill: 'backwards' });
        if (an) { an.id = 'ex-flip'; b.el.classList.add('is-flipping'); an.onfinish = an.oncancel = function () { b.el.classList.remove('is-flipping'); }; }
      });
      if (sel != null && was != null && sel !== was && prev[was] && now[sel] && !prev[was].hidden && !now[sel].hidden) {
        var from = prev[was], to = now[sel], tgt = to.el;
        var glide = document.createElement('div'); glide.className = 'ex-sel-glide'; glide.setAttribute('aria-hidden', 'true');
        glide.style.left = to.x + 'px'; glide.style.top = to.y + 'px'; glide.style.width = to.w + 'px'; glide.style.height = to.h + 'px';
        root.insertBefore(glide, root.firstChild); tgt.classList.add('is-sel-gliding');
        var ga = play(glide, [{ transform: 'translate(' + (from.x - to.x) + 'px,' + (from.y - to.y) + 'px)', width: from.w + 'px', height: from.h + 'px' }, { transform: 'none', width: to.w + 'px', height: to.h + 'px' }], { fill: 'backwards' });
        var done = function () { if (glide.parentNode) glide.parentNode.removeChild(glide); tgt.classList.remove('is-sel-gliding'); };
        if (ga) ga.onfinish = ga.oncancel = done; else done();
      }
    });
    return h(props.as || 'div', { ref: ref, className: cx('ex-flip', props.className), style: props.style }, props.children);
  }
  /* A number that rolls when it changes. */
  function Ticker(props) {
    var prev = React.useRef(props.value);
    var dir = props.value > prev.current ? 'up' : props.value < prev.current ? 'down' : null;
    React.useEffect(function () { prev.current = props.value; });
    return h('span', { className: 'ex-tick' }, h('span', { key: String(props.value), className: cx('ex-tick-n', dir && 'is-' + dir) }, props.value));
  }

  /* ── Icon: 16px grid, 1.5 stroke, round caps ── */
  var P = {
    plus: 'M8 3v10M3 8h10',
    'arrow-up': 'M8 13V3M4 7l4-4 4 4',
    terminal: 'M3.5 3h9A1.5 1.5 0 0 1 14 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 11.5v-7A1.5 1.5 0 0 1 3.5 3zM5 6.5l2 1.5-2 1.5M8.5 10H11',
    code: 'M6 4L2.5 8 6 12M10 4l3.5 4L10 12',
    changes: 'M9.5 2.5h-5a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1v-7zM8 6v3M6.5 7.5h3M6.5 11h3',
    actions: 'M5 3.5v9l7-4.5z',
    globe: 'M8 2.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11zM2.5 8h11M8 2.5c1.6 1.5 2.4 3.4 2.4 5.5S9.6 12 8 13.5C6.4 12 5.6 10.1 5.6 8S6.4 4 8 2.5z',
    fork: 'M5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM8 11a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM5 5v1a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2V5M8 8v3',
    'side-chat': 'M2.5 4A1.5 1.5 0 0 1 4 2.5h6A1.5 1.5 0 0 1 11.5 4v3.5A1.5 1.5 0 0 1 10 9H6.5l-2.5 2V9A1.5 1.5 0 0 1 2.5 7.5zM13.5 6.5v4a1.5 1.5 0 0 1-1.5 1.5v1.5L10 12H7.5',
    chat: 'M4 2.5h8A1.5 1.5 0 0 1 13.5 4v5.5A1.5 1.5 0 0 1 12 11H7.5l-3 2.5V11H4a1.5 1.5 0 0 1-1.5-1.5V4A1.5 1.5 0 0 1 4 2.5z',
    check: 'M3.5 8.5l3 3 6-7',
    x: 'M4.5 4.5l7 7M11.5 4.5l-7 7',
    'chevron-down': 'M4.5 6.5L8 10l3.5-3.5',
    'chevron-right': 'M6.5 4.5L10 8l-3.5 3.5',
    at: 'M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0zM10.5 8v1a1.75 1.75 0 0 0 3.5 0V8A6 6 0 1 0 11.5 12.9',
    search: 'M7 2.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zM10.3 10.3L13.5 13.5',
    commit: 'M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM1.5 8h4M10.5 8h4',
    push: 'M8 11V3M4.5 6.5L8 3l3.5 3.5M3 13.5h10',
    more: 'M3.5 8h.01M8 8h.01M12.5 8h.01',
    stop: 'M5.5 4.5h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1z',
    sidebar: 'M3.5 3h9A1.5 1.5 0 0 1 14 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 11.5v-7A1.5 1.5 0 0 1 3.5 3zM6 3v10',
    panel: 'M3.5 3h9A1.5 1.5 0 0 1 14 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 11.5v-7A1.5 1.5 0 0 1 3.5 3zM10 3v10',
    attach: 'M12.5 7.5l-4.6 4.6a3 3 0 0 1-4.2-4.2L8.5 3.1a2 2 0 0 1 2.8 2.8L6.6 10.6a1 1 0 0 1-1.4-1.4L9.5 5',
    repo: 'M4.5 2.5h7.5v9H4.5a1.5 1.5 0 0 0-1.5 1.5V4a1.5 1.5 0 0 1 1.5-1.5zM3 13a1.5 1.5 0 0 0 1.5 1h7.5v-2.5',
    task: 'M3 4.5h1M6.5 4.5H13M3 8h1M6.5 8H13M3 11.5h1M6.5 11.5H10',
    copy: 'M6 5.5h6a.5.5 0 0 1 .5.5v6.5a.5.5 0 0 1-.5.5H6a.5.5 0 0 1-.5-.5V6a.5.5 0 0 1 .5-.5zM10.5 5.5V3.5a.5.5 0 0 0-.5-.5H4a.5.5 0 0 0-.5.5V10a.5.5 0 0 0 .5.5h1.5',
    expand: 'M9.5 2.5h4v4M13.5 2.5L9 7M6.5 13.5h-4v-4M2.5 13.5L7 9',
    folder: 'M2.5 4.5a1 1 0 0 1 1-1h3l1.5 1.5h4.5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1z',
    'expand-up': 'M8 10.5v-7M5 6.5l3-3 3 3M3 13h10',
    'expand-down': 'M3 3h10M8 5.5v7M5 9.5l3 3 3-3',
    unfold: 'M8 6V1.5M5.5 4L8 1.5 10.5 4M8 10v4.5M5.5 12L8 14.5 10.5 12M3 8h10',
    shrink: 'M13.5 2.5L9.5 6.5M9.5 3v3.5H13M2.5 13.5l4-4M3 9.5h3.5V13',
    wrap: 'M2.5 4h11M2.5 8h9a2 2 0 0 1 0 4H8M9.5 10.5L8 12l1.5 1.5M2.5 12h3',
    back: 'M13 8H3M7 4L3 8l4 4',
    play: 'M5 3.5l7 4.5-7 4.5z',
    cursor: 'M3.5 2l9 5.2-4 1.1 2.4 4.3-1.7 1-2.4-4.3-3.3 2.7z',
    target: 'M8 2v2.5M8 11.5V14M2 8h2.5M11.5 8H14M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z',
    phone: 'M5 1.5h6a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-11a1 1 0 0 1 1-1zM7 12.5h2',
    hand: 'M5.5 8V3.5a1 1 0 0 1 2 0V7M7.5 7V2.5a1 1 0 0 1 2 0V7M9.5 7V3.5a1 1 0 0 1 2 0V9c0 2.5-1.5 4.5-4 4.5S4 12 3.5 10.5L2.5 8a1 1 0 0 1 1.7-1z',
    bug: 'M5.5 5.5h5v5a2.5 2.5 0 0 1-5 0zM6 5.5a2 2 0 0 1 4 0M3 7.5h2.5M10.5 7.5H13M3 11h2.5M10.5 11H13M8 8v5',
    subtask: 'M4 3v6.5a1.5 1.5 0 0 0 1.5 1.5H12M9.5 8.5L12 11l-2.5 2.5',
    file: 'M9.5 2.5h-5a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1v-7zM9.5 2.5v3h3',
    pr: 'M4.5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM4.5 11a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11.5 11a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM4.5 5v6M11.5 11V6.5a2 2 0 0 0-2-2H7.5M9 3L7.5 4.5 9 6',
    merged: 'M4.5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM4.5 11a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11.5 7.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM4.5 5v6M4.5 5.5c0 2 1.5 3.5 5.5 3.5',
    ticket: 'M3.5 3.5h9a1 1 0 0 1 1 1v1.75a1.75 1.75 0 0 0 0 3.5v1.75a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1v-1.75a1.75 1.75 0 0 0 0-3.5V4.5a1 1 0 0 1 1-1zM9.5 3.5v1.5M9.5 7.25v1.5M9.5 11v1.5',
    link: 'M7 9a2.5 2.5 0 0 0 3.5 0l2-2A2.5 2.5 0 0 0 9 3.5l-.75.75M9 7a2.5 2.5 0 0 0-3.5 0l-2 2A2.5 2.5 0 0 0 7 12.5l.75-.75',
    archive: 'M2.5 3.5h11v3h-11zM3.5 6.5v5.5a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V6.5M6.5 9h3',
    'close-task': 'M4.75 2.75h6.5a2 2 0 0 1 2 2v6.5a2 2 0 0 1-2 2h-6.5a2 2 0 0 1-2-2v-6.5a2 2 0 0 1 2-2zM5.6 8.1l1.7 1.7 3.2-3.5',
    layers: 'M8 2.5l5.5 3L8 8.5 2.5 5.5zM2.5 8.25L8 11.25l5.5-3M2.5 10.75L8 13.75l5.5-3',
    focus: 'M8 2.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11zM8 6.25a1.75 1.75 0 1 0 0 3.5 1.75 1.75 0 0 0 0-3.5z',
    clock: 'M8 2.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11zM8 5v3l2 1.5',
    mic: 'M8 2.5a2 2 0 0 0-2 2v3.5a2 2 0 0 0 4 0V4.5a2 2 0 0 0-2-2zM4 7.75a4 4 0 0 0 8 0M8 11.75v1.75',
    bolt: 'M8.75 2L4 9h3.75L7.25 14 12 7H8.25z',
    shield: 'M8 2l5 2v3.5c0 3-2.2 5.3-5 6.5-2.8-1.2-5-3.5-5-6.5V4z',
    plug: 'M6 2.5v3M10 2.5v3M4.5 5.5h7v2a3.5 3.5 0 0 1-7 0zM8 11v2.5',
    steer: 'M3.5 3v4.5a2 2 0 0 0 2 2h7M10 7l2.5 2.5L10 12',
    pencil: 'M10.5 3l2.5 2.5L6 12.5 3 13l.5-3z',
    trash: 'M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.5 8.5h6l.5-8.5',
    plan: 'M2.75 4.25l1 1 2-2M2.75 9.25l1 1 2-2M8 4.5h5.25M8 9.5h5.25M8 13h3.5',
    branch: 'M5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM5 11a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11 3.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM5 5v6M11 6.5c0 2.5-2.5 3.5-6 4.5',
    workspace: 'M2.5 5L8 2.5 13.5 5v6L8 13.5 2.5 11zM2.5 5L8 7.5 13.5 5M8 7.5v6',
    reset: 'M3 8a5 5 0 1 0 1.5-3.5M3 2.5v2.5h2.5',
    'arrow-down': 'M8 3v10M4 9l4 4 4-4',
    bulb: 'M6 12.5h4M6.5 14.25h3M8 1.75a4.25 4.25 0 0 0-2.6 7.6c.5.4.85 1 .85 1.65v.25h3.5V11c0-.65.35-1.25.85-1.65A4.25 4.25 0 0 0 8 1.75z',
    laptop: 'M3.5 4.5h9a1 1 0 0 1 1 1v5.5h-11V5.5a1 1 0 0 1 1-1zM1.5 11h13l-.6 1.2a1 1 0 0 1-.9.55H3a1 1 0 0 1-.9-.55z',
    server: 'M3 2.5h10a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1zM3 8.5h10a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1zM4.5 5h1M4.5 11h1',
    peer: 'M2 4.5h5v4H2zM9 7.5h5v4H9zM4.5 8.5v2.5h4.5M11.5 7.5V5H7',
    key: 'M10 2.5a3.5 3.5 0 1 1-2.9 5.46L3 12v1.5H1.5V12l4.4-4.4A3.5 3.5 0 0 1 10 2.5zM10.5 5.2h.01',
    download: 'M8 2.5v8M4.5 7.5L8 11l3.5-3.5M3 13.5h10',
    wifi: 'M2 6.2a8.5 8.5 0 0 1 12 0M4.2 8.6a5.3 5.3 0 0 1 7.6 0M6.4 11a2.2 2.2 0 0 1 3.2 0M8 13.2h.01',
    refresh: 'M13 4.5V2M13 4.5h-2.5M12.6 4.4A5.5 5.5 0 1 0 13.5 8',
    grid: 'M3 3h4v4H3zM9 3h4v4H9zM3 9h4v4H3zM9 9h4v4H9z',
    window: 'M2.5 3.5h11v9h-11zM2.5 6h11M9.5 8.5v3M8 10h3',
    question: 'M8 14a6 6 0 1 0 0-12 6 6 0 0 0 0 12zM6.25 6.25a1.85 1.85 0 1 1 2.6 1.7c-.5.25-.85.7-.85 1.3v.25M8 11.25v.05'
  };
  function Icon(props) {
    var size = props.size || 16;
    return h('svg', { className: cx('ex-icon', props.className), width: size, height: size, viewBox: '0 0 16 16', fill: 'none', stroke: 'currentColor', strokeWidth: props.name === 'more' ? 2.4 : 1.5, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': 'true' },
      h('path', { d: P[props.name] || P.plus }));
  }

  function Kbd(props) { return h('kbd', { className: 'ex-kbd' }, props.children); }

  function Button(props) {
    var variant = props.variant || 'secondary';
    var size = props.size || 'md';
    var rest = Object.assign({}, props);
    ['variant', 'size', 'icon', 'iconRight', 'kbd', 'className', 'children'].forEach(function (k) { delete rest[k]; });
    var isz = size === 'sm' ? 14 : 16;
    return h('button', Object.assign({ type: 'button' }, rest, { className: cx('ex-btn', 'ex-btn-' + variant, size === 'sm' && 'ex-btn-sm', props.className) }),
      props.icon && h(Icon, { name: props.icon, size: isz }),
      props.children,
      props.iconRight && h(Icon, { name: props.iconRight, size: isz }),
      props.kbd && h(Kbd, null, props.kbd));
  }

  function IconButton(props) {
    var rest = Object.assign({}, props);
    ['icon', 'label', 'active', 'size', 'className'].forEach(function (k) { delete rest[k]; });
    return h('button', Object.assign({ type: 'button', 'aria-label': props.label, title: props.label }, rest, {
      className: cx('ex-iconbtn', props.size === 'sm' && 'ex-iconbtn-sm', props.className),
      'aria-pressed': props.active === undefined ? undefined : String(!!props.active)
    }), h(Icon, { name: props.icon, size: props.size === 'sm' ? 14 : 16 }));
  }

  /* ── Status ── */
  var STATUS = {
    running: 'Running', attention: 'Needs you', review: 'Review', done: 'Done', failed: 'Failed', queued: 'Queued', paused: 'Paused'
  };
  function glyphChange(from, to) {
    if (from === to) return null;
    if (from === 'running' && (to === 'done' || to === 'review')) return 'is-finish';
    if (to === 'attention') return 'is-nudge';
    if (to === 'failed') return 'is-shake';
    return 'is-swap';
  }
  function StatusGlyph(props) {
    var s = props.status || 'queued';
    var size = props.size || 14;
    var prev = React.useRef(s);
    var _c = React.useState(null); var change = _c[0], setChange = _c[1];
    useLayout(function () {
      var c = glyphChange(prev.current, s); prev.current = s;
      if (!c) return;
      setChange(c);
      var t = setTimeout(function () { setChange(null); }, 900);
      return function () { clearTimeout(t); };
    }, [s]);
    var kids;
    if (s === 'running') kids = [
      h('circle', { key: 't', cx: 7, cy: 7, r: 5, fill: 'none', stroke: 'currentColor', strokeOpacity: 0.25, strokeWidth: 2 }),
      h('path', { key: 'a', className: 'ex-spin', d: 'M7 2a5 5 0 0 1 5 5', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round' })];
    else if (s === 'attention') kids = [
      h('path', { key: 'd', d: 'M7 .9l6.1 6.1L7 13.1.9 7z', fill: 'currentColor' }),
      h('path', { key: 'e', d: 'M7 4.2v3.4M7 9.6v.1', stroke: 'var(--surface-raised)', strokeWidth: 1.6, strokeLinecap: 'round' })];
    else if (s === 'review') kids = [
      h('circle', { key: 'o', cx: 7, cy: 7, r: 5.25, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 }),
      h('path', { key: 'f', d: 'M7 3.5a3.5 3.5 0 0 1 0 7z', fill: 'currentColor' })];
    else if (s === 'done') kids = [
      h('circle', { key: 'o', cx: 7, cy: 7, r: 5.25, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 }),
      h('path', { key: 'c', d: 'M4.6 7.2l1.7 1.7 3.2-3.6', fill: 'none', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' })];
    else if (s === 'failed') kids = [
      h('circle', { key: 'o', cx: 7, cy: 7, r: 6, fill: 'currentColor' }),
      h('path', { key: 'x', d: 'M5 5l4 4M9 5l-4 4', stroke: 'var(--surface-raised)', strokeWidth: 1.5, strokeLinecap: 'round' })];
    else if (s === 'paused') kids = [
      h('circle', { key: 'o', cx: 7, cy: 7, r: 5.25, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 }),
      h('path', { key: 'p', d: 'M5.8 5v4M8.2 5v4', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round' })];
    else kids = [h('circle', { key: 'o', cx: 7, cy: 7, r: 5.25, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5, strokeDasharray: '2.2 2.2' })];
    if (change === 'is-finish') kids = kids.concat([h('circle', { key: 'burst', className: 'ex-burst', cx: 7, cy: 7, r: 6, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 })]);
    return h('svg', { className: cx('ex-glyph', 'ex-glyph-' + s, change), width: size, height: size, viewBox: '0 0 14 14', role: 'img', 'aria-label': STATUS[s] || s }, kids);
  }
  function StatusBadge(props) {
    var s = props.status || 'queued';
    return h('span', { className: 'ex-badge ex-badge-' + s }, h(StatusGlyph, { status: s, size: 12 }), props.label || STATUS[s]);
  }
  function StatusSummary(props) {
    var c = props.counts || {};
    var order = [['attention', 'Needs you'], ['running', 'Running'], ['review', 'Review'], ['done', 'Done']];
    return h('div', { className: 'ex-sum', role: 'group', 'aria-label': 'Session status' }, order.map(function (o) {
      var n = c[o[0]] || 0;
      return h('button', { key: o[0], type: 'button', className: cx('ex-sum-item', n === 0 && 'is-zero'), 'aria-pressed': String(props.active === o[0]), onClick: props.onSelect && function () { props.onSelect(o[0]); } },
        h('span', { className: 'ex-sum-n' }, h(StatusGlyph, { status: o[0], size: 12 }), h(Ticker, { value: n })),
        h('span', { className: 'ex-sum-l' }, o[1]));
    }));
  }

  /* ── Project rail ── */
  /* A project's face: its logo when it has one, else a monogram on its hue. */
  function ProjectMark(props) {
    var size = props.size || 36;
    var r = size >= 28 ? 'var(--radius-md)' : size >= 20 ? '6px' : '4px';
    var style = { width: size, height: size, borderRadius: r, fontSize: Math.round(size * 0.36) };
    if (props.logo) return h('span', { className: 'ex-pmark ex-pmark-logo', style: style, 'aria-hidden': props.decorative ? 'true' : undefined }, h('img', { src: props.logo, alt: props.decorative ? '' : props.name }));
    /* a face: an emoji, an icon, or letters, on the project's hue */
    var inner = props.emoji ? h('span', { className: 'ex-pmark-emoji' }, props.emoji) : props.icon ? h(Icon, { name: props.icon, size: Math.round(size * 0.5) }) : props.initials || (props.name || '').slice(0, 2);
    return h('span', { className: cx('ex-pmark ex-tile-' + (props.hue || 'steel'), props.emoji && 'is-emoji'), style: style, 'aria-hidden': props.decorative ? 'true' : undefined }, inner);
  }
  function RailPips(p) {
    if (p.muted) return null;
    if (p.attention) return h('span', { className: 'ex-tile-pip', 'aria-hidden': 'true' }, p.attention);
    if (p.running) return h('span', { className: 'ex-tile-run', 'aria-hidden': 'true' }, h(StatusGlyph, { status: 'running', size: 14 }));
    return null;
  }
  function railLabel(name, p) {
    if (p.muted) return name + ', muted';
    return name + (p.attention ? ', ' + p.attention + ' need you' : '') + (p.running ? ', ' + p.running + ' running' : '');
  }
  function ProjectRail(props) {
    var projects = props.projects || [];
    var all = props.all || {};
    var sel = props.onSelect;
    var ind = useThumb('[aria-current="true"]', [props.activeId, projects.length]);
    var bar = React.useRef(null), firstRail = React.useRef(true);
    React.useEffect(function () {
      if (firstRail.current) { firstRail.current = false; return; }
      play(bar.current, [{ transform: 'scaleY(1)' }, { transform: 'scaleY(1.7)', offset: 0.35 }, { transform: 'scaleY(1)' }], { ease: 'ease-out', dur: 'dur-glide' });
    }, [props.activeId]);
    /* a project added later pops into its place: the tiles below slide down to make room, the new tile springs in
       (it's a mark: it may overshoot a little) and one ring in its color goes out. First paint never animates. */
    var before = React.useRef(null);
    if (ind.ref.current) { var snap = {}; Array.prototype.forEach.call(ind.ref.current.querySelectorAll('[data-key]'), function (n) { snap[n.getAttribute('data-key')] = n.offsetTop; }); before.current = snap; }
    useLayout(function () {
      var root = ind.ref.current, prev = before.current; before.current = null;
      if (!root || !prev || reducedMotion()) return;
      Array.prototype.forEach.call(root.querySelectorAll('[data-key]'), function (n) {
        var k = n.getAttribute('data-key'), was = prev[k];
        if (was == null) {
          if (!n.animate) return;
          var p = projects.filter(function (x) { return x.id === k; })[0];
          n.animate([{ transform: 'scale(.3)', opacity: 0 }, { transform: 'scale(1.1)', opacity: 1, offset: 0.55 }, { transform: 'scale(.97)', offset: 0.8 }, { transform: 'none', opacity: 1 }], { duration: 520, delay: 140, easing: 'cubic-bezier(0.2, 0.7, 0.3, 1)', fill: 'backwards' });
          markRing(root, n, p && p.hue, 380);
          return;
        }
        var dy = was - n.offsetTop;
        if (Math.abs(dy) > 0.5) play(n, [{ transform: 'translateY(' + dy + 'px)' }, { transform: 'none' }], { ease: 'ease-in-out', dur: 'dur-glide' });
      });
    });
    return h('nav', { ref: ind.ref, className: cx('ex-rail ex-glass', ind.has && 'has-ind', ind.ready && 'is-ready'), 'aria-label': 'Projects' },
      h('span', { className: 'ex-rail-ind', 'aria-hidden': 'true', style: ind.style }, h('i', { ref: bar })),
      props.all !== false && h('button', { type: 'button', className: 'ex-tile ex-tile-all', 'aria-label': railLabel('All projects', all), title: 'All projects  ⌘0', 'aria-current': String(props.activeId === 'all'), onClick: sel && function () { sel('all'); } },
        h(Icon, { name: 'layers' }), h(RailPips, all)),
      props.all !== false && h('span', { className: 'ex-rail-sep', 'aria-hidden': 'true' }),
      projects.map(function (p, i) {
        return h('button', { key: p.id, 'data-key': p.id, type: 'button', className: cx('ex-tile ex-tile-proj', p.muted && 'is-muted'), 'aria-label': railLabel(p.name, p), title: p.name + (i < 9 ? '  ⌘' + (i + 1) : ''), 'aria-current': String(p.id === props.activeId), onClick: sel && function () { sel(p.id); } },
          h(ProjectMark, Object.assign({}, p, { size: 36, decorative: true })), h(RailPips, p));
      }),
      h('span', { className: 'ex-rail-sep', 'data-key': 'sep-end', 'aria-hidden': 'true' }),
      h('button', { type: 'button', 'data-key': 'add', className: 'ex-tile ex-tile-add', 'aria-label': 'Add project', title: 'Add project', onClick: props.onAdd ? function (e) { props.onAdd(e.currentTarget); } : undefined }, h(Icon, { name: 'plus' })));
  }

  /* ── Task lifecycle ── */
  var STAGE = { planned: 'Planned', active: 'In progress', waiting: 'Waiting', closed: 'Closed' };
  function StageGlyph(props) {
    var s = props.stage || 'planned';
    var size = props.size || 14;
    var box = { x: 1.75, y: 1.75, width: 10.5, height: 10.5, rx: 3, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 };
    var kids;
    if (s === 'planned') kids = [h('rect', Object.assign({ key: 'b' }, box, { strokeDasharray: '2.4 2' }))];
    else if (s === 'active') kids = [h('rect', Object.assign({ key: 'b' }, box)), h('rect', { key: 'f', x: 4, y: 7, width: 6, height: 3, rx: 1, fill: 'currentColor' })];
    else if (s === 'waiting') kids = [h('rect', Object.assign({ key: 'b' }, box)), h('path', { key: 'p', d: 'M5.75 5v4M8.25 5v4', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round' })];
    else kids = [h('rect', { key: 'b', x: 1, y: 1, width: 12, height: 12, rx: 3.5, fill: 'currentColor' }), h('path', { key: 'c', d: 'M4.4 7.2l1.7 1.7 3.5-3.8', fill: 'none', stroke: 'var(--surface-raised)', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' })];
    return h('svg', { className: 'ex-glyph ex-stage-' + s, width: size, height: size, viewBox: '0 0 14 14', role: 'img', 'aria-label': STAGE[s] }, kids);
  }
  function TaskStage(props) {
    var s = props.stage || 'planned';
    return h('button', { type: 'button', className: 'ex-stage ex-stage-pill-' + s, 'aria-haspopup': 'menu', title: 'Change stage' },
      h(StageGlyph, { stage: s, size: 12 }), STAGE[s], h(Icon, { name: 'chevron-down', size: 12 }));
  }
  var PR_STATE = { draft: 'Draft', open: 'Open', approved: 'Approved', failing: 'Checks failing', merged: 'Merged', closed: 'Closed' };
  function LinkChip(props) {
    var kind = props.kind || 'pr';
    var st = props.state;
    var icon = kind === 'ticket' ? 'ticket' : st === 'merged' ? 'merged' : 'pr';
    var word = kind === 'pr' ? PR_STATE[st] : st;
    return h(props.href ? 'a' : 'span', { href: props.href, className: cx('ex-link', 'ex-link-' + kind, st && 'is-' + st, props.compact && 'is-compact'), title: (kind === 'pr' ? 'Pull request ' : 'Ticket ') + props.label + (word ? ' · ' + word : '') },
      h(Icon, { name: icon, size: 12 }), h('span', { className: 'ex-link-label' }, props.label),
      !props.compact && word ? h('span', { className: 'ex-link-state' }, word) : null);
  }
  function TaskHeader(props) {
    var links = props.links || [];
    return h('header', { className: cx('ex-taskhead', props.parent && 'is-sub') },
      props.parent ? h('button', { type: 'button', className: 'ex-taskhead-parent', onClick: props.parent.onOpen, title: 'Open ' + props.parent.title }, h(Icon, { name: 'subtask', size: 12 }), 'Sub-task of ', h('b', null, props.parent.title), props.parent.branch ? h('span', { className: 'ex-mono' }, props.parent.branch) : null) : null,
      h('div', { className: 'ex-taskhead-row' },
        h('div', { className: 'ex-shell-title' }, props.project ? h(ProjectMark, Object.assign({}, props.project, { size: 20, decorative: true })) : null, h('span', { className: 'ex-taskhead-name' }, props.title), h(TaskStage, { stage: props.stage })),
        h('span', { className: 'ex-grow' }),
        /* Close task: always there, a quiet word (a ticked square, not an archive box); accent once the work looks finished */
        h('button', { type: 'button', className: cx('ex-taskhead-close', props.closeSuggested && 'is-due'), onClick: props.onClose, title: props.closeSuggested ? 'The work looks finished: close the task' : 'Close the task: stops its sessions and archives it' },
          h(Icon, { name: 'close-task', size: 14 }), 'Close task'),
        h('span', { className: 'ex-taskhead-vsep', 'aria-hidden': 'true' }),
        h(IconButton, { icon: 'panel', label: 'Toggle side panel', active: !!props.panelOpen })),
      h('div', { className: 'ex-taskhead-row' },
        h('div', { className: 'ex-shell-meta' },
          props.repo ? h(RepoTag, { repo: props.repo, size: 'md' }) : null,
          props.branch ? h(BranchChip, { name: props.branch, compact: true }) : null,
          links.map(function (l, i) { return h(LinkChip, Object.assign({ key: i }, l)); }),
          links.length ? null : h('button', { type: 'button', className: 'ex-link-add' }, h(Icon, { name: 'link', size: 12 }), 'Link PR or ticket'),
          props.meta ? h('span', { className: 'ex-taskhead-meta' }, props.meta) : null),
        h('span', { className: 'ex-grow' }),
        !props.git ? null
          : h(GitBar, Object.assign({ compact: true }, props.git))));
  }
  function CloseTask(props) {
    var unpushed = props.unpushed || 0;
    var running = props.running || 0;
    var ticket = props.ticket;
    var _c = React.useState(true); var moveTicket = _c[0], setMove = _c[1];
    return h('section', { className: 'ex-dialog', role: 'dialog', 'aria-label': 'Close task' },
      h('div', { className: 'ex-dialog-title' }, 'Close “' + props.title + '”?'),
      h('ul', { className: 'ex-dialog-list' },
        running ? h('li', null, h(StatusGlyph, { status: 'running', size: 14 }), 'Stops ' + running + (running === 1 ? ' running session' : ' running sessions')) : null,
        h('li', null, h(Icon, { name: 'archive', size: 14 }), 'Archives ' + (props.sessions || 0) + ' sessions. Reopen them any time from Closed.'),
        h('li', null, h(Icon, { name: 'check', size: 14 }), 'Cleans up the task’s files on disk.'),
        unpushed ? h('li', { className: 'is-warn' }, h(StatusGlyph, { status: 'attention', size: 14 }), unpushed + (unpushed === 1 ? ' commit is' : ' commits are') + ' not pushed yet.') : null),
      ticket ? h('label', { className: 'ex-check-row' }, h('input', { type: 'checkbox', checked: moveTicket, onChange: function () { setMove(!moveTicket); } }), 'Move ', h(LinkChip, { kind: 'ticket', label: ticket, compact: true }), ' to Done') : null,
      h('div', { className: 'ex-dialog-foot' },
        h(Button, { variant: 'ghost' }, 'Cancel'),
        h('span', { style: { flex: 1 } }),
        unpushed ? h(Button, { variant: 'secondary' }, 'Close without pushing') : null,
        h(Button, { variant: 'primary', icon: unpushed ? 'push' : 'close-task' }, unpushed ? 'Push and close' : 'Close task')));
  }
  /* ── Branch and workspace ── */
  function branchFromTitle(title, prefix) {
    var slug = String(title || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    if (slug.length > 48) slug = slug.slice(0, 48).replace(/-[^-]*$/, '');
    return slug ? (prefix || '') + slug : '';
  }
  var BAD_BRANCH = /(\s|\.\.|[~^:?*\[\\]|@\{|\/\/|\/$|\.lock$|^-|\.$)/;
  function BranchChip(props) {
    var _c = React.useState(false); var copied = _c[0], setCopied = _c[1];
    function copy() { try { if (navigator.clipboard) navigator.clipboard.writeText(props.name); } catch (e) {} setCopied(true); setTimeout(function () { setCopied(false); }, 1200); }
    return h('span', { className: cx('ex-branch', props.compact && 'is-compact', copied && 'is-copied') },
      h('button', { type: 'button', className: 'ex-branch-name', title: 'Branch · rename' }, h(Icon, { name: 'branch', size: 12 }), h('span', null, props.name)),
      props.base && !props.compact ? h('span', { className: 'ex-branch-base' }, 'from ', h('span', { className: 'ex-mono' }, props.base)) : null,
      h('button', { type: 'button', className: 'ex-branch-copy', 'aria-label': copied ? 'Copied' : 'Copy branch name', title: copied ? 'Copied' : 'Copy branch name', onClick: copy }, h(Icon, { key: copied ? 'c' : 'k', name: copied ? 'check' : 'copy', size: 12 })));
  }
  function WorkspacePicker(props) {
    var pm = usePresence(props.open);
    var v = props.value || 'auto';
    var items = props.items || [];
    var free = items.filter(function (w) { return w.state === 'free'; });
    var auto = free[0];
    var label = v === 'auto' ? 'Automatic' : v;
    var sub = v === 'auto' ? (auto ? 'reuses ' + auto.name + (auto.note ? ', ' + auto.note : '') : 'creates a new one') : '';
    return h('div', { className: 'ex-agent-wrap' },
      h('button', { type: 'button', className: 'ex-agent ex-ws', 'aria-haspopup': 'listbox', 'aria-expanded': String(!!props.open) },
        h(Icon, { name: 'workspace', size: 14 }), label, sub ? h('span', { className: 'ex-agent-sub' }, sub) : null, h(Icon, { name: 'chevron-down', size: 13 })),
      pm.m && h('div', { className: 'ex-menu' + (pm.l ? ' is-leaving' : ''), role: 'listbox', style: { top: 32, left: 0, minWidth: 340 } },
        h('div', { className: 'ex-menu-item', role: 'option', 'aria-selected': String(v === 'auto') },
          h('span', { className: 'ex-grow' }, h('span', null, 'Automatic'), h('span', { className: 'ex-muted', style: { fontSize: 12, lineHeight: '16px' } }, 'Reuse a free workspace from the pool, or add one')),
          v === 'auto' ? h(Icon, { name: 'check', size: 14, className: 'ex-check' }) : null),
        h('div', { className: 'ex-menu-sep' }),
        h('div', { className: 'ex-overline ex-menu-label', style: { display: 'flex' } }, h('span', { style: { flex: 1 } }, 'Pool'), h('span', { style: { letterSpacing: 0, textTransform: 'none', fontWeight: 500 } }, free.length + ' free of ' + items.length)),
        items.map(function (w, i) {
          var used = w.state === 'used';
          return h('div', { key: i, role: 'option', className: cx('ex-menu-item', used && 'is-used'), 'aria-selected': String(v === w.name), 'aria-disabled': used ? 'true' : undefined },
            h('span', { className: cx('ex-dot', used ? 'is-off' : 'is-ok') }),
            h('span', { className: 'ex-grow' }, h('span', { className: 'ex-mono' }, w.name), h('span', { className: 'ex-muted', style: { fontSize: 12, lineHeight: '16px' } }, used ? 'In use · ' + w.task : 'Free' + (w.note ? ' · ' + w.note : ''))),
            v === w.name ? h(Icon, { name: 'check', size: 14, className: 'ex-check' }) : null);
        }),
        h('div', { className: 'ex-menu-item' }, h(Icon, { name: 'plus', size: 14 }), h('span', { className: 'ex-grow' }, 'New workspace')),
        h('div', { className: 'ex-menu-sep' }),
        h('div', { className: 'ex-menu-item ex-muted' }, h(Icon, { name: 'workspace', size: 14 }), h('span', { className: 'ex-grow' }, 'Manage workspaces…'))));
  }
  function WorkspaceStatus(props) {
    var s = props.state || 'ready';
    if (s === 'ready') return h('span', { className: 'ex-wsstat' }, h(Icon, { name: 'check', size: 12 }), 'Workspace ready');
    return h('span', { className: 'ex-wsstat is-setup' }, h(StatusGlyph, { status: 'running', size: 12 }), 'Setting up workspace', props.step ? h('span', { className: 'ex-muted' }, '· ' + props.step) : null);
  }

  /* Branch combobox list: matches for what you typed, plus "Create" when it doesn't exist yet. */
  function tokensOf(q) { return String(q || '').toLowerCase().split(/[\s\/_-]+/).filter(Boolean); }
  function branchItems(query, branches, allowCreate) {
    var q = String(query || '').trim();
    var toks = tokensOf(q);
    var list = (branches || []).filter(function (b) {
      if (!toks.length) return true;
      var n = b.name.toLowerCase();
      return toks.every(function (t) { return n.indexOf(t) !== -1; });
    }).map(function (b) {
      var n = b.name.toLowerCase(), ql = q.toLowerCase();
      var score = n === ql ? 0 : (b.isDefault ? 1 : 2) + (n.indexOf(ql) === 0 ? 0 : 2);
      return { kind: 'branch', name: b.name, meta: b.meta, when: b.when, remote: b.remote, task: b.task, isDefault: b.isDefault, score: score };
    }).sort(function (a, b) { return a.score - b.score; });
    var exact = list.some(function (b) { return b.name === q; });
    if (allowCreate && q && !exact) {
      var bad = BAD_BRANCH.test(q);
      list.unshift({ kind: bad ? 'invalid' : 'create', name: q });
    }
    return list.slice(0, 7);
  }
  function Highlight(props) {
    var toks = tokensOf(props.query);
    if (!toks.length) return h(F, null, props.text);
    var re = new RegExp('(' + toks.map(function (t) { return t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('|') + ')', 'ig');
    return h(F, null, String(props.text).split(re).map(function (part, i) { return i % 2 ? h('mark', { key: i }, part) : part; }));
  }
  function BranchPicker(props) {
    var items = props.items || branchItems(props.query, props.branches, props.allowCreate);
    var hi = props.hi || 0;
    var th = useThumb('[aria-selected="true"]', [hi, props.query, items.length]);
    return h('div', { ref: th.ref, className: cx('ex-combo-list', th.has && 'has-thumb', th.ready && 'is-ready'), role: 'listbox', 'aria-label': props.label || 'Branches' },
      h('span', { className: 'ex-thumb ex-list-thumb', 'aria-hidden': 'true', style: th.style }),
      items.length ? items.map(function (it, i) {
        var used = !!it.task;
        var cls = cx('ex-combo-item', 'is-' + it.kind, used && 'is-used');
        var sel = i === hi && !used && it.kind !== 'invalid';
        if (it.kind === 'invalid') return h('div', { key: i, className: cls, role: 'option', 'aria-disabled': 'true' },
          h(Icon, { name: 'x', size: 13 }), h('span', { className: 'ex-grow' }, 'Not a valid branch name: no spaces, “..”, or ~ ^ : ? * [ \\'));
        if (it.kind === 'create') return h('div', { key: i, className: cls, role: 'option', 'aria-selected': String(sel), onClick: props.onPick && function () { props.onPick(it); } },
          h(Icon, { name: 'plus', size: 13 }), h('span', { className: 'ex-combo-verb' }, 'Create'), h('span', { className: 'ex-mono ex-grow' }, it.name),
          props.base ? h('span', { className: 'ex-combo-meta' }, 'from ' + props.base) : null, sel ? h(Kbd, null, '↵') : null);
        return h('div', { key: i, className: cls, role: 'option', 'aria-selected': String(sel), 'aria-disabled': used ? 'true' : undefined, onClick: !used && props.onPick ? function () { props.onPick(it); } : undefined },
          h(Icon, { name: 'branch', size: 13 }), h('span', { className: 'ex-mono ex-grow' }, h(Highlight, { text: it.name, query: props.query })),
          it.isDefault ? h('span', { className: 'ex-bf-tag' }, 'default') : null,
          h('span', { className: 'ex-combo-meta' }, used ? 'In use · ' + it.task : [it.remote ? 'remote' : null, it.when].filter(Boolean).join(' · ')),
          sel ? h(Kbd, null, '↵') : null);
      }) : h('div', { className: 'ex-combo-empty' }, 'No branch matches “' + props.query + '”'));
  }

  /* ── New task: 1 Name ↵ 2 Branch ↵ 3 From ↵ (numbered rows, all visible) ── */
  var NT_ORDER = { name: 0, repo: 0.5, branch: 1, base: 2, created: 3 };
  /* Which repository a task works in: its short tag (else its name), quiet, cut short when long. A size up, with the repo icon. */
  function RepoTag(props) {
    var r = typeof props.repo === 'string' ? { name: props.repo } : (props.repo || {});
    return h('span', { className: cx('ex-repotag', props.size === 'md' && 'is-md', props.className), title: r.name + (r.path ? ' · ' + r.path : '') },
      props.size === 'md' ? h(Icon, { name: 'repo', size: 12 }) : null, h('span', { className: 'ex-repotag-t' }, r.short || r.name));
  }
  function StepNum(props) {
    var st = props.state;
    return h('span', { className: 'ex-nt-num is-' + st, 'aria-hidden': 'true' }, st === 'done' ? h(Icon, { name: 'check', size: 11 }) : st === 'skip' ? '–' : props.n);
  }
  function NewTask(props) {
    var p = props.project || { name: 'Project', hue: 'steel' };
    var prefix = props.branchPrefix || '';
    var branches = props.branches || [];
    var bases = props.bases || branches.filter(function (b) { return !b.task; });
    var defBase = props.base || 'main';
    var _st = React.useState(props.step || 'name'); var step = _st[0], setStep = _st[1];
    var _t = React.useState(props.title || ''); var title = _t[0], setTitle = _t[1];
    var _bq = React.useState(props.branchQuery === undefined ? null : props.branchQuery); var bq = _bq[0], setBq = _bq[1];
    var _bp = React.useState(null); var bPick = _bp[0], setBPick = _bp[1];
    var _oq = React.useState(props.baseQuery || ''); var oq = _oq[0], setOq = _oq[1];
    var _ob = React.useState(defBase); var base = _ob[0], setBase = _ob[1];
    var _hi = React.useState(props.hi != null ? props.hi : props.step === 'repo' && props.repos ? Math.max(0, props.repos.map(function (r) { return r.id; }).indexOf(props.repo)) : 0); var hi = _hi[0], setHi = _hi[1];
    var rn = React.useRef(null), rb = React.useRef(null), ro = React.useRef(null), rr = React.useRef(null), rf = React.useRef(null), mounted = React.useRef(false);
    /* several repositories: which one the task works in (preselected: the one you're in, else the last used) */
    var repos = props.repos || [], multi = repos.length > 1, asStep = multi;
    var _rp = React.useState(props.repo || (repos[0] && repos[0].id)), repo = _rp[0], setRepo = _rp[1];
    var curRepo = repos.filter(function (r) { return r.id === repo; })[0] || repos[0];
    if (props.branchesFor && curRepo) { branches = props.branchesFor(curRepo.id) || branches; bases = branches.filter(function (b) { return !b.task; }); }
    var inferred = branchFromTitle(title, prefix);
    var bQuery = bq === null ? inferred : bq;
    var bItems = branchItems(bQuery, branches, true);
    var oItems = branchItems(oq, bases, false);
    var first = null; for (var i = 0; i < bItems.length; i++) if (bItems[i].kind !== 'invalid' && !bItems[i].task) { first = bItems[i]; break; }
    var branch = bPick || (String(bQuery).trim() && first ? { name: first.name, existing: first.kind === 'branch' } : null);
    var skipBase = !!(branch && branch.existing);
    React.useEffect(function () {
      if (!mounted.current) { mounted.current = true; return; }
      var r = step === 'name' ? rn : step === 'repo' ? rr : step === 'branch' ? rb : step === 'base' ? ro : null;
      if (r && r.current) r.current.focus();
      else if (step === 'base' && rf.current && rf.current.querySelector('button')) rf.current.querySelector('button').focus();   /* From isn't needed: rest on Create task, so ↵ creates */
    }, [step]);
    function go(s) { setStep(s); setHi(0); }
    function create(b, o) {
      var res = { repo: multi ? repo : undefined, title: title, branch: (b || branch || {}).name, existing: !!(b || branch || {}).existing, base: (b || branch || {}).existing ? null : (o || base) };
      if (props.onCreate) props.onCreate(res); else go('created');
    }
    function pickBranch(it) { var b = { name: it.name, existing: it.kind === 'branch' }; setBPick(b); go('base'); }   /* always on to From, the last step; an existing branch shows it isn't needed */
    function pickBase(it) { setBase(it.name); setOq(''); create(null, it.name); }
    function reset() { setStep('name'); setTitle(''); setBq(null); setBPick(null); setOq(''); setBase(defBase); setHi(0); }
    function back() { if (step === 'repo') go('name'); else if (step === 'branch') go(asStep ? 'repo' : 'name'); else if (step === 'base') go('branch'); }
    function pickRepo(id) { setRepo(id); setBPick(null); go('branch'); }
    function onKey(e) {
      if (e.key === 'Escape') { e.preventDefault(); if (props.onCancel) props.onCancel(); else reset(); return; }
      if (e.key === 'Tab' && e.shiftKey && (step === 'repo' || step === 'branch' || step === 'base')) { e.preventDefault(); back(); return; }
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); if (title.trim() && branch) create(); return; }
      if (e.key === 'Enter' && e.altKey) { e.preventDefault(); if (props.onPlan) props.onPlan({ title: title, branch: branch && branch.name, base: base }); return; }
      var items = step === 'repo' ? repos : step === 'branch' ? bItems : step === 'base' ? oItems : null;
      if (items && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) { e.preventDefault(); setHi(Math.max(0, Math.min(items.length - 1, hi + (e.key === 'ArrowDown' ? 1 : -1)))); return; }
      if (e.key !== 'Enter') return;
      if (e.target.closest && e.target.closest('.ex-newtask-foot')) return;   /* a focused footer button takes its own ↵ */
      e.preventDefault();
      nextStep();
    }
    function state(id) {
      if (id === 'base' && skipBase && step !== 'base') return 'skip';
      if (step === id) return 'active';
      return NT_ORDER[step] > NT_ORDER[id] ? 'done' : 'todo';
    }
    function Row(n, id, label, value, body) {
      var st = state(id);
      return h('div', { className: cx('ex-nt-row', 'is-' + st) },
        h('button', { type: 'button', className: 'ex-nt-row-head', disabled: st === 'skip' || st === 'active', onClick: function () { go(id); } },
          h(StepNum, { n: n, state: st }), h('span', { className: 'ex-nt-row-l' }, label), st === 'active' ? null : h('span', { className: 'ex-nt-row-v' }, value)),
        h(Fold, { open: st === 'active' }, h('div', { className: 'ex-nt-body' }, body)));
    }
    /* the main button does what ↵ does: Next on every step, Create task on the last one (From) */
    var hiB = step === 'branch' ? bItems[hi] : null;
    var lastStep = step === 'base';
    var canNext = step === 'name' ? !!title.trim() : step === 'repo' ? !!repos[hi] : step === 'branch' ? !!hiB && hiB.kind !== 'invalid' && !hiB.task : step === 'base' ? (skipBase || !!oItems[hi]) : false;
    function nextStep() {
      if (step === 'name') { if (title.trim()) { if (asStep) { go('repo'); setHi(Math.max(0, repos.indexOf(curRepo))); } else go('branch'); } }
      else if (step === 'repo') { if (repos[hi]) pickRepo(repos[hi].id); }
      else if (step === 'branch') { if (canNext) pickBranch(hiB); }
      else if (step === 'base') { if (skipBase) create(); else if (oItems[hi]) pickBase(oItems[hi]); }
    }
    var links = props.links || [];
    return h('section', { className: 'ex-newtask ex-nt', 'aria-label': 'New task', onKeyDown: onKey },
      h('div', { className: 'ex-newtask-head' },
        h('button', { type: 'button', className: 'ex-agent', 'aria-haspopup': 'listbox' }, h(ProjectMark, Object.assign({}, p, { size: 18, decorative: true })), p.name, h(Icon, { name: 'chevron-down', size: 13 })),
        h('span', { className: 'ex-muted', style: { fontSize: 12 } }, '/'),
        h('span', { className: 'ex-muted', style: { fontSize: 12.5, fontWeight: 500 } }, 'New task'),
        h('span', { style: { flex: 1 } }), h(Kbd, null, 'Esc')),
      h(AutoHeight, { innerClassName: 'ex-nt-stack' }, step === 'created'
        ? h('div', { className: 'ex-nt-created' }, h(StatusGlyph, { status: 'done', size: 16 }),
            h('span', null, 'Created ', h('b', null, title), multi && curRepo ? h(F, null, ' in ', h(RepoTag, { repo: curRepo })) : null, ' on ', h('span', { className: 'ex-mono' }, branch ? branch.name : ''), skipBase ? '' : ' from ' + base),
            h('span', { style: { flex: 1 } }), h(Button, { variant: 'ghost', size: 'sm', icon: 'reset', onClick: reset }, 'Again'))
        : h(F, null,
          h('div', { className: 'ex-nt-rows' },
            Row(1, 'name', 'Name', title ? h('span', { className: 'ex-nt-title-v' }, title) : h('span', { className: 'ex-muted' }, 'Task name'),
              h('input', { ref: rn, className: 'ex-newtask-title ex-nt-name', value: title, placeholder: 'What are you working on?', 'aria-label': 'Task name', autoFocus: !!props.autoFocus && step === 'name', onChange: function (e) { setTitle(e.target.value); setBPick(null); } })),
            asStep ? Row(2, 'repo', 'Repository', curRepo ? h(RepoTag, { repo: curRepo, size: 'md' }) : null,
              h('div', { className: 'ex-nt-repos', role: 'listbox', 'aria-label': 'Repository', ref: rr, tabIndex: -1 }, repos.map(function (r, i) {
                return h('button', { key: r.id, type: 'button', role: 'option', 'aria-selected': String(i === hi), className: cx('ex-nt-repo', i === hi && 'is-hi'), onMouseEnter: function () { setHi(i); }, onClick: function () { pickRepo(r.id); } },
                  h(Icon, { name: 'repo', size: 14, className: 'ex-nt-repo-ic' }), h('span', { className: 'ex-repo-n' }, r.name), r.path ? h('span', { className: 'ex-muted ex-mono ex-repo-p' }, r.path) : null,
                  r.id === repo ? h('span', { className: 'ex-bf-tag' }, 'last used') : null, i === hi ? h(Kbd, null, '↵') : null);
              }), h('button', { type: 'button', className: 'ex-nt-repo is-add', onClick: props.onAddRepo }, h(Icon, { name: 'plus', size: 13 }), 'Add a repository\u2026'))) : null,
            Row(asStep ? 3 : 2, 'branch', 'Branch',
              branch ? h(F, null, h(Icon, { name: 'branch', size: 13 }), h('span', { className: 'ex-mono' }, branch.name), h('span', { className: 'ex-bf-tag' }, branch.existing ? 'existing' : 'new')) : h('span', { className: 'ex-muted' }, 'from the task name'),
              h(F, null,
                h('label', { className: 'ex-bf-input ex-nt-input' }, h(Icon, { name: 'branch', size: 14 }),
                  h('input', { ref: rb, value: bQuery, spellCheck: false, placeholder: 'Search or create a branch', 'aria-label': 'Branch: type to search or create', autoFocus: !!props.autoFocus && step === 'branch', onChange: function (e) { setBq(e.target.value); setBPick(null); setHi(0); } }),
                  bq !== null ? h('button', { type: 'button', className: 'ex-bf-reset', title: 'Back to the name from the task', onClick: function () { setBq(null); setBPick(null); } }, h(Icon, { name: 'reset', size: 12 })) : h('span', { className: 'ex-bf-tag' }, 'from the name')),
                h(BranchPicker, { items: bItems, query: bQuery, base: base, hi: hi, onPick: pickBranch }))),
            Row(asStep ? 4 : 3, 'base', 'From',
              skipBase ? h('span', { className: 'ex-muted' }, 'not needed: an existing branch keeps its history')
                       : h(F, null, h(Icon, { name: 'branch', size: 13 }), h('span', { className: 'ex-mono' }, base), base === defBase ? h('span', { className: 'ex-bf-tag' }, 'default') : null),
              skipBase ? h('div', { className: 'ex-nt-skipnote' }, 'Not needed: ', h('span', { className: 'ex-mono' }, branch.name), ' already exists and keeps its history.') : h(F, null,
                h('label', { className: 'ex-bf-input ex-nt-input' }, h(Icon, { name: 'search', size: 14 }),
                  h('input', { ref: ro, value: oq, spellCheck: false, placeholder: 'Search branches to start from', 'aria-label': 'Start from', autoFocus: !!props.autoFocus && step === 'base', onChange: function (e) { setOq(e.target.value); setHi(0); } })),
                h(BranchPicker, { items: oItems, query: oq, hi: hi, onPick: pickBase, label: 'Start from' })))),
          h('div', { className: 'ex-nt-extras' },
            h('span', { className: 'ex-nt-extra-l' }, 'Workspace'), h(WorkspacePicker, { value: props.workspace, items: props.workspaces, open: props.workspaceOpen }),
            h('span', { className: 'ex-nt-extra-l' }, 'Link'),
            h('span', { className: 'ex-nt-links' }, links.map(function (l, i) { return h(LinkChip, Object.assign({ key: i }, l)); }),
              h('button', { type: 'button', className: 'ex-link-add' }, h(Icon, { name: 'link', size: 12 }), links.length ? 'Link another' : 'Paste a ticket or PR (optional)'))),
          h('div', { className: 'ex-newtask-foot' },
            h(Button, { variant: 'ghost', onClick: function () { if (props.onPlan) props.onPlan({ title: title, branch: branch && branch.name, base: base }); } }, 'Save as planned'),
            h('span', { style: { flex: 1 } }),
            h('span', { ref: rf, className: 'ex-nt-mainwrap' }, h(Button, { variant: 'primary', className: 'ex-np-next', disabled: !canNext, onClick: nextStep },
              h(EaseSwap, { k: lastStep ? 'create' : 'next' }, h('span', { className: 'ex-np-next-in' }, lastStep ? 'Create task' : 'Next', h(Kbd, null, '↵')))))))));
  }

  /* The task line atop a new session: name, branch, workspace progress. */
  function TaskLine(props) {
    var t = props.task || {};
    return h('div', { className: 'ex-taskline' },
      t.project ? h(ProjectMark, Object.assign({}, t.project, { size: 16, decorative: true })) : null,
      h('button', { type: 'button', className: 'ex-taskline-name', title: 'Rename task' }, t.title),
      t.branch ? h(BranchChip, { name: t.branch, base: t.base }) : null,
      t.workspace ? h(WorkspaceStatus, t.workspace) : null);
  }

  /* ── Sessions and tasks ── */
  function Diff(props) {
    if (!props.add && !props.del) return null;
    return h('span', { className: 'ex-diff', 'aria-label': props.add + ' lines added, ' + props.del + ' removed' },
      props.add ? h('span', { className: 'ex-diff-add' }, '+', h(Ticker, { value: props.add })) : null, props.del ? h('span', { className: 'ex-diff-del' }, '\u2212', h(Ticker, { value: props.del })) : null);
  }
  function SessionRow(props) {
    var s = props.status || 'queued';
    var kindIcon = props.kind === 'fork' ? 'fork' : props.kind === 'side' ? 'side-chat' : props.kind === 'auto' ? 'bolt' : null;
    return h('button', {
      type: 'button', className: cx('ex-session', s === 'attention' && !props.selected && 'is-attention', s === 'done' && 'is-done', props.fresh && 'is-fresh'),
      'aria-current': props.selected ? 'true' : undefined, style: { '--ex-indent': ((props.depth || 0) * 16) + 'px', '--i': props.index || 0 }, onClick: props.onClick
    },
      h(StatusGlyph, { status: s, size: 14 }),
      kindIcon && h('span', { className: cx('ex-session-kind', props.kind === 'auto' && 'is-auto'), title: props.kind === 'fork' ? 'Fork' : props.kind === 'auto' ? 'Started by Elevenex for a git job' : 'Side chat' }, h(Icon, { name: kindIcon, size: 13 })),
      h('span', { className: 'ex-session-title' }, props.title),
      props.diff ? h(Diff, props.diff) : props.meta ? h('span', { className: 'ex-session-meta' }, props.meta) : null,
      props.unread && h('span', { className: 'ex-session-unread', 'aria-label': 'Unread' }));
  }
  /* ── Tasks in the sidebar: an outline ──
     A task is a strong header row (chevron, project, 13.5 semibold title, link, signal, + new session) that stays
     pinned while you scroll its sessions. Its sessions hang under a guide line, lighter: working ones first, the
     finished ones folded into one “N finished” row. A session that needs you is marked, never moved. */
  var SESSION_ACTIVE = { attention: 1, running: 1, review: 1, queued: 1, failed: 1, paused: 1 };
  var NEW_SESSION_KEY = '⌥⌘N';
  function sessionKey(s, i) { return s.id || s.title || String(i); }
  function TaskSignal(props) {
    var asks = props.asks, running = props.running, quiet = !asks && !running;
    return h('span', { className: 'ex-task-signal', title: asks ? asks + (asks === 1 ? ' session needs you' : ' sessions need you') : running ? running + ' working' : undefined },
      h('span', { className: cx('ex-task-ask', !asks && 'is-hidden') }, h(StatusGlyph, { status: 'attention', size: 12 }), h(Ticker, { value: asks || 1 })),
      h('span', { className: cx('ex-task-run', (!running || asks) && 'is-hidden') }, h(StatusGlyph, { status: 'running', size: 12 }), h(Ticker, { value: running || 1 })),
      h('span', { className: cx('ex-task-count', !(quiet && props.collapsed && props.total) && 'is-hidden') }, h(Ticker, { value: props.total || 0 })));
  }
  /* Archiving a session from its row: on hover (or focus) an archive button takes the place of its diff or time. One
     click archives it. A running one asks first, in place: the button stretches left into a red “Stop and archive” (its
     name stays readable beside it); a second click confirms, Esc or a click anywhere else puts it back. The task's
     `onArchive` reaches every row of its tree through this context. */
  var SessionArchiveCtx = React.createContext(null);
  function TaskSession(props) {
    var s = props.s, arch = React.useContext(SessionArchiveCtx), running = s.status === 'running', ref = React.useRef(null);
    var _a = React.useState(false), armed = _a[0], setArmed = _a[1];
    React.useEffect(function () {
      if (!armed) return;
      function d(e) { if (ref.current && !ref.current.contains(e.target)) setArmed(false); }
      function k(e) { if (e.key === 'Escape') { e.stopPropagation(); setArmed(false); } }
      document.addEventListener('mousedown', d); document.addEventListener('keydown', k);
      return function () { document.removeEventListener('mousedown', d); document.removeEventListener('keydown', k); };
    }, [armed]);
    var isSel = !!(s.selected || (props.selected != null && props.selected === s.id));
    return h('div', { ref: ref, 'data-flip': s.id || undefined, className: cx('ex-task-srow', arch && 'has-act', arch && !s.diff && !s.meta && 'no-trail', armed && 'is-armed', props.dim && !isSel && s.status !== 'attention' && 'is-dim') },
      h(SessionRow, Object.assign({}, s, { depth: 0, selected: !!(s.selected || (props.selected != null && props.selected === s.id)) })),
      arch ? h('button', { type: 'button', className: cx('ex-srow-arch', armed && 'is-armed'),
        'aria-label': armed ? 'Stop and archive ' + s.title + ': press again to confirm' : (running ? 'Stop and archive ' : 'Archive ') + s.title, title: armed ? null : running ? 'Stop and archive' : 'Archive',
        onBlur: function (e) { if (armed && !(ref.current && ref.current.contains(e.relatedTarget))) setArmed(false); },
        onClick: function () { if (running && !armed) setArmed(true); else { setArmed(false); arch(s); } } },
        h('span', { className: 'ex-srow-arch-ic' }, h(Icon, { name: 'archive', size: 14 })),
        h('span', { className: 'ex-srow-arch-l', 'aria-hidden': 'true' }, h('span', null, 'Stop and archive'))) : null);
  }
  /* Too many working sessions: a task shows its latest `cap` (5); a session that needs you, the open one and one just
     started always show too. The earlier ones wait above one quiet row, shaped like “N finished”: “› 9 older”. The
     first row under it turns muted, so the list reads as going on above. Each click brings back the next `step` (5):
     they scroll into view from under that row, nearest first, pushing the rest down; the count rolls. “Show fewer”
     scrolls them back up. Hidden is never finished: they keep running. */
  var SESSION_CAP = 5, SESSION_STEP = 5;
  function earlierState(H, n, step, closing) { var shownN = closing ? 0 : Math.min(H.length, n * step); return { shownN: shownN, rem: H.length - shownN }; }
  function TaskEarlier(props) {
    var H = props.hidden, n = props.batches, step = props.step, closing = props.closing, st = earlierState(H, n, step, closing), rem = st.rem;
    var blocks = [];
    for (var i = n; i >= 1; i--) { var a = Math.max(0, H.length - i * step), b = H.length - (i - 1) * step; if (b > a) blocks.push({ k: i, list: H.slice(a, b) }); }
    if (!H.length) return null;
    return h('div', { className: 'ex-earlier' },
      h('div', { className: 'ex-earlier-top' },
        h('button', { type: 'button', className: 'ex-task-finrow ex-earlier-more', 'aria-expanded': String(!rem), 'aria-label': rem ? 'Show ' + Math.min(step, rem) + ' older sessions (' + rem + ' hidden)' : 'Show fewer sessions', title: rem ? 'Show ' + Math.min(step, rem) + ' more' : 'Show fewer', onClick: rem ? props.onMore : props.onFewer },
          h(Icon, { name: 'chevron-down', size: 12, className: cx('ex-chev', rem && 'is-closed') }),
          h(EaseSwap, { k: rem ? 'more' : 'fewer' }, rem ? h('span', null, h(Ticker, { value: rem }), ' older') : h('span', null, 'Show fewer'))),
        n && rem && !closing ? h('button', { type: 'button', className: 'ex-earlier-fewer', onClick: props.onFewer }, 'Show fewer') : null),
      blocks.map(function (bk) {
        return h(EarlierBatch, { key: 'b' + bk.k, closing: closing }, h(MotionList, { className: 'ex-task-sessions', items: bk.list.map(function (x, j) { return { key: sessionKey(x, j), node: h(TaskSession, { s: x, selected: props.selected, dim: props.dimId === x.id }) }; }) }));
      }));
  }
  /* A batch of earlier sessions. Its height animates in pixels (0 → its rows, on the launch curve) with its rows pinned
     to its bottom edge, so they scroll into view from under the row above, nearest first; closing runs it back. */
  var SCROLL_EASE = 'cubic-bezier(0.33, 0, 0.15, 1)';
  function EarlierBatch(props) {
    var ref = React.useRef(null), anim = React.useRef(null);
    /* like a smooth scroll: a soft start, a long settle; the longer the way, the longer it takes (440–760ms) */
    function run(from, to) {
      var el = ref.current; if (!el || !el.animate || reducedMotion()) return;
      if (anim.current) anim.current.cancel();
      el.classList.add('is-moving'); el.style.height = from + 'px'; /* holds the start until the animation is running */
      var ms = Math.max(440, Math.min(760, 320 + 1.3 * Math.abs(to - from)));
      var a = el.animate([{ height: from + 'px' }, { height: to + 'px' }], { duration: ms, easing: SCROLL_EASE, fill: 'forwards' });
      a.onfinish = function () { if (to) { el.style.height = ''; el.classList.remove('is-moving'); a.cancel(); } else el.style.height = '0px'; };
      anim.current = a;
    }
    useLayout(function () { var el = ref.current; if (el) run(0, el.scrollHeight); }, []);
    useLayout(function () { var el = ref.current; if (el && props.closing) run(el.offsetHeight, 0); }, [props.closing]);
    return h('div', { ref: ref, className: 'ex-earlier-batch' }, props.children);
  }
  function TaskSessions(props) {
    return h(MotionList, { className: 'ex-task-sessions', items: props.sessions.map(function (s, i) { return { key: sessionKey(s, i), node: h(TaskSession, { s: s, selected: props.selected, dim: props.dimId != null && props.dimId === s.id }) }; }) });
  }
  function TaskFinished(props) {
    var fin = props.sessions, merged = props.merged || [];
    var _o = React.useState(false); var open = _o[0], setOpen = _o[1];
    var holdsSel = fin.some(function (s) { return s.selected || (props.selected != null && s.id === props.selected); });
    var isOpen = open || holdsSel;
    return h(Fold, { open: fin.length + merged.length > 0, className: 'ex-task-finfold' }, h('div', { className: 'ex-task-fin' },
      h('button', { type: 'button', className: 'ex-task-finrow', 'aria-expanded': String(isOpen), onClick: function () { setOpen(!open); } },
        h(Icon, { name: 'chevron-down', size: 12, className: cx('ex-chev', !isOpen && 'is-closed') }),
        fin.length ? h(F, null, h(Ticker, { value: fin.length }), ' finished') : null,
        h('span', { className: cx('ex-task-merged-n', !merged.length && 'is-hidden') }, fin.length ? ' · ' : '', h(Ticker, { value: merged.length || 1 }), ' merged')),
      h(Fold, { open: isOpen }, h('div', null, h(TaskSessions, { sessions: fin, selected: props.selected }),
        h(MotionList, { className: 'ex-task-sessions', items: merged.map(function (m) { return { key: 'm' + m.id, node: h('div', { className: 'ex-subtask-merged', title: 'Merged ' + (m.branch || m.title) },
          h(Icon, { name: 'merged', size: 12 }), h('span', { className: 'ex-subtask-merged-t' }, m.title), m.diff ? h(Diff, m.diff) : null) }; }) })))));
  }
  /* Sub-tasks: open ones in the task's tree, children right under their parent, all at one indent. A child of a sub-task
     says where it came from with a small tag. Past three, the rest fold into one row. Merged ones leave for the finished row. */
  function subtaskOrder(subs) {
    var open = subs.filter(function (s) { return !s.merged; }), byParent = {}, out = [];
    open.forEach(function (s) { var p = s.parent && open.some(function (o) { return o.id === s.parent; }) ? s.parent : ''; (byParent[p] = byParent[p] || []).push(s); });
    (function walk(p) { (byParent[p] || []).forEach(function (s) { out.push(s); walk(s.id); }); })('');
    return out;
  }
  /* The sub-task mark: a staircase, one step per level (1 = in the task), capped at three. Drawn for 14px, in a 16px slot. */
  var SUB_STAIRS = { 1: 'M3 1.5V7.5Q3 9.5 5 9.5H12.5', 2: 'M2.5 1.5V5H6.5V9.5H13', 3: 'M2 1.5V4H5V6.75H8.5V9.5H14' };
  function SubtaskGlyph(props) {
    var d = Math.max(1, Math.min(3, props.depth || 1)), end = d === 1 ? 12.5 : d === 2 ? 13 : 14;
    return h('span', { className: cx('ex-subtask-glyph', props.className), 'aria-hidden': 'true' },
      h('svg', { width: 16, height: 14, viewBox: '0 0 16 14', fill: 'none', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' },
        h('path', { d: SUB_STAIRS[d] }), h('path', { d: 'M' + (end - 2.5) + ' 7L' + end + ' 9.5L' + (end - 2.5) + ' 12' })));
  }
  function SubTask(props) {
    var t = props.t, ss = t.sessions || [], from = props.from;
    var act = ss.filter(function (x) { return SESSION_ACTIVE[x.status || 'queued']; }), fin = ss.filter(function (x) { return !SESSION_ACTIVE[x.status || 'queued']; });
    var asks = ss.filter(function (x) { return x.status === 'attention'; }).length, running = ss.filter(function (x) { return x.status === 'running'; }).length;
    var _o = React.useState(true), open = _o[0], setOpen = _o[1];
    /* the hint names where it lives: its parent sub-tasks (earlier ones shortened), or the task for a first-level one */
    var path = props.path || [], up = path.length > 1 ? path.slice(1) : path;
    var tip = up.map(function (p, i) { return i < up.length - 1 && p.length > 12 ? p.slice(0, 11).trim() + '…' : p; });
    return h('div', { className: cx('ex-subtask', props.lit && 'is-lit'), 'data-flip': 'st-' + t.id },
      h('div', { className: 'ex-subtask-head', onMouseEnter: props.onHover, onMouseLeave: props.onLeave, onFocus: props.onHover, onBlur: props.onLeave },
        h('button', { type: 'button', className: 'ex-subtask-toggle', 'aria-expanded': String(open), 'aria-label': t.title + ', in ' + path.join(', in '), onClick: function () { setOpen(!open); } },
          h(SubtaskGlyph, { depth: props.depth }), h('span', { className: 'ex-subtask-title' }, t.title)),
        props.tip ? h('span', { className: 'ex-tip ex-subtask-tip', role: 'tooltip' }, h('span', { className: 'ex-subtask-tip-b' }, 'In '), tip.join(' › ')) : null,
        t.ready && !asks ? h('span', { className: 'ex-subtask-ready', title: 'Committed and checked: ready to merge into ' + (from ? from.title : 'the task') }, 'Ready')
          : h(TaskSignal, { asks: asks, running: running, total: ss.length, collapsed: !open }),
        props.onAdd ? h(IconButton, { icon: 'plus', label: 'New session in this sub-task', size: 'sm', className: 'ex-task-add', onClick: props.onAdd }) : null),
      h(Fold, { open: open }, h('div', { className: 'ex-subtask-tree' }, h(TaskSessions, { sessions: act, selected: props.selected }), h(TaskFinished, { sessions: fin, selected: props.selected }))));
  }
  function TaskSubtasks(props) {
    var all = props.subtasks || [], list = subtaskOrder(all), _m = React.useState(false), more = _m[0], setMore = _m[1];
    var byId = {}; all.forEach(function (s) { byId[s.id] = s; });
    /* depth and path come from open parents only: a merged parent's children now belong to its parent */
    var up = function (s) { var p = s.parent && byId[s.parent]; return p && !p.merged ? p : null; };
    var chain = function (s) { var out = []; for (var p = up(s); p; p = up(p)) out.unshift(p); return out; };
    var _h = React.useState(null), hover = _h[0], setHover = _h[1], _t = React.useState(null), tipId = _t[0], setTip = _t[1], timer = React.useRef(0);
    React.useEffect(function () { return function () { clearTimeout(timer.current); }; }, []);
    var enter = function (id) { setHover(id); clearTimeout(timer.current); timer.current = setTimeout(function () { setTip(id); }, 500); };
    var leave = function () { setHover(null); setTip(null); clearTimeout(timer.current); };
    /* the lit path: the sub-task you hover, else the one holding the selected session, and every sub-task above it */
    var at = hover ? byId[hover] : all.filter(function (s) { return !s.merged && (s.sessions || []).some(function (x) { return x.id === props.selected; }); })[0];
    var lit = {}; if (at) { lit[at.id] = true; chain(at).forEach(function (p) { lit[p.id] = true; }); }
    var holdsSel = function (s) { return (s.sessions || []).some(function (x) { return x.id === props.selected; }); };
    var cut = list.length > 4 && !more ? 3 : list.length, shown = list.slice(0, cut).concat(list.slice(cut).filter(holdsSel)), hidden = list.length - shown.length;
    return h('div', { className: 'ex-subtasks' },
      h(MotionList, { items: shown.map(function (s) { return { key: s.id, node: h(SubTask, { t: s, from: up(s), depth: chain(s).length + 1, path: [props.taskTitle || 'the task'].concat(chain(s).map(function (p) { return p.title; })), lit: !!lit[s.id], tip: tipId === s.id,
          onHover: function () { enter(s.id); }, onLeave: leave, selected: props.selected, onAdd: props.onAdd ? function () { props.onAdd(s); } : null }) }; }) }),
      h(Fold, { open: hidden > 0 }, h('button', { type: 'button', className: 'ex-task-finrow', onClick: function () { setMore(true); } }, h(SubtaskGlyph, { depth: 1 }), h(Ticker, { value: hidden || 1 }), ' more sub-tasks')));
  }
  function TaskGroup(props) {
    var sessions = props.sessions || [], subs = props.subtasks || [];
    var folded = props.collapsed != null ? !!props.collapsed : (props.stage === 'waiting' || props.stage === 'planned' || props.stage === 'closed');
    /* a task that arrives in a folded stage arrives open, then folds: you see its sessions go away */
    var _s = React.useState(props.startOpen ? false : folded); var collapsedState = _s[0], setCollapsed = _s[1];
    React.useEffect(function () { if (props.startOpen && folded) { var t = setTimeout(function () { setCollapsed(true); }, 360); return function () { clearTimeout(t); }; } }, []);
    var filter = props.filter;
    var collapsed = filter ? false : collapsedState;
    var links = props.links || (props.link ? [props.link] : []);
    var lead = links.filter(function (l) { return l.kind === 'pr'; })[0] || links[0];
    var act = sessions.filter(function (x) { return SESSION_ACTIVE[x.status || 'queued'] && (!filter || x.status === filter); });
    /* the cap: the latest `cap` working sessions show, plus any that need you, the open one and a fresh one; the rest wait above */
    var cap = props.cap == null ? SESSION_CAP : props.cap, step = props.capStep || SESSION_STEP, early = [];
    var _bt = React.useState(0), batches = _bt[0], setBatches = _bt[1], _cl = React.useState(false), closingEarly = _cl[0], setClosingEarly = _cl[1];
    if (!filter && cap > 0 && act.length > cap) {
      /* everything before the latest `cap` waits above; a session that needs you, the open one or a fresh one comes
         out only while it's still hidden (one already brought back stays where it is, so nothing jumps) */
      var older = act.slice(0, act.length - cap), back = closingEarly ? 0 : Math.min(older.length, batches * step), hiddenPart = older.slice(0, older.length - back);
      early = older.filter(function (x) { return !(hiddenPart.indexOf(x) >= 0 && (x.status === 'attention' || x.id === props.selected || x.fresh)); });
    }
    var actShown = act.filter(function (x) { return early.indexOf(x) < 0; });
    React.useEffect(function () { if (!early.length && batches) setBatches(0); }, [early.length]);
    function fewer() { setClosingEarly(true); setTimeout(function () { setBatches(0); setClosingEarly(false); }, 780); }
    /* the first row under “N older” turns muted while some are still hidden: the list reads as going on above */
    var est = earlierState(early, batches, step, closingEarly), dimId = null;
    if (est.rem) { var topRow = est.shownN ? early[early.length - Math.min(early.length, batches * step)] : actShown[0]; dimId = topRow ? topRow.id : null; }
    var fin = filter ? [] : sessions.filter(function (x) { return !SESSION_ACTIVE[x.status || 'queued']; });
    /* the task's signal counts its sub-tasks' sessions too: a sub-task that needs you shows on the task */
    var everyone = sessions.concat.apply(sessions, subs.filter(function (s) { return !s.merged; }).map(function (s) { return s.sessions || []; }));
    var asks = everyone.filter(function (x) { return x.status === 'attention'; }).length;
    var running = everyone.filter(function (x) { return x.status === 'running'; }).length;
    var merged = filter ? [] : subs.filter(function (s) { return s.merged; });
    /* the task you're in (it holds the selected session, maybe in a sub-task): its “+” stays shown, and it ends with “+ New session” */
    var here = props.selected != null && everyone.some(function (x) { return x.id === props.selected; }), canAdd = props.onAdd !== false;
    return h(SessionArchiveCtx.Provider, { value: props.onArchive || null }, h('div', { className: cx('ex-task', collapsed && 'is-collapsed', props.fresh && 'is-fresh', here && 'is-here'), 'data-flip': props.id || undefined },
      h('div', { className: 'ex-task-head' },
        h('button', { type: 'button', className: 'ex-task-toggle', 'aria-expanded': String(!collapsed), onClick: function () { setCollapsed(!collapsedState); } },
          h(Icon, { name: 'chevron-down', size: 12, className: cx('ex-chev', collapsed && 'is-closed') }),
          props.project ? h(ProjectMark, Object.assign({}, props.project, { size: 18, decorative: true })) : null,
          h('span', { className: 'ex-task-title' }, props.title),
          props.repo ? h(RepoTag, { repo: props.repo }) : null),
        props.showLink && lead ? h(LinkChip, Object.assign({}, lead, { compact: true })) : null,
        h(TaskSignal, { asks: asks, running: running, total: everyone.length, collapsed: collapsed }),
        canAdd ? h(IconButton, { icon: 'plus', label: 'New session in this task  ' + NEW_SESSION_KEY, size: 'sm', className: 'ex-task-add', onClick: props.onAdd }) : null),
      h(Fold, { open: !collapsed, className: 'ex-task-fold' },
        h('div', { className: 'ex-task-tree' },
          h(TaskEarlier, { hidden: early, batches: batches, step: step, closing: closingEarly, selected: props.selected, dimId: dimId, onMore: function () { setBatches(Math.min(batches + 1, Math.ceil(early.length / step))); }, onFewer: fewer }),
          h(TaskSessions, { sessions: actShown, selected: props.selected, dimId: dimId }),
          subs.length ? h(TaskSubtasks, { taskTitle: props.title, subtasks: filter ? subs.filter(function (s) { return (s.sessions || []).some(function (x) { return x.status === filter; }); }) : subs, selected: props.selected, onAdd: props.onAddSub }) : null,
          h(TaskFinished, { sessions: fin, merged: merged, selected: props.selected }),
          h(Fold, { open: here && canAdd && !filter, className: 'ex-task-newfold' },
            h('button', { type: 'button', className: 'ex-task-new', onClick: props.onAdd, title: 'New session in this task  ' + NEW_SESSION_KEY },
              h(Icon, { name: 'plus', size: 14 }), h('span', { className: 'ex-task-new-t' }, 'New session'), h('span', { className: 'ex-task-new-k' }, NEW_SESSION_KEY)))))));
  }
  /* The sidebar's body: tasks by stage (In progress, Waiting, Planned), each group counted. Tasks keep their place
     when a session needs you; a filter (a status) folds away everything else. Anything that changes stage travels. */
  var TASK_STAGES = [['active', 'In progress'], ['waiting', 'Waiting'], ['planned', 'Planned']];
  function TaskList(props) {
    var tasks = props.tasks || [], filter = props.filter;
    var seen = React.useRef({}), first = React.useRef(true);
    var shown = tasks.filter(function (t) { return !filter || (t.sessions || []).some(function (x) { return x.status === filter; }); });
    var groups = TASK_STAGES.map(function (g) { return { id: g[0], label: g[1], tasks: shown.filter(function (t) { return (t.stage || 'active') === g[0]; }) }; }).filter(function (g) { return g.tasks.length; });
    var moved = {};
    tasks.forEach(function (t) { var was = seen.current[t.id]; if (!first.current && was && was !== (t.stage || 'active')) moved[t.id] = true; });
    React.useEffect(function () { first.current = false; var m = {}; tasks.forEach(function (t) { m[t.id] = t.stage || 'active'; }); seen.current = m; });
    return h(FlipScope, { className: cx('ex-tasklist', props.className), selected: props.selected },
      h(MotionList, { items: groups.map(function (g) {
        return { key: g.id, node: h('div', { className: 'ex-tasklist-group' },
          h('div', { className: 'ex-overline ex-tasklist-over' }, g.label, h('span', { className: 'ex-tasklist-n' }, h(Ticker, { value: g.tasks.length }))),
          h(MotionList, { className: 'ex-tasklist-tasks', items: g.tasks.map(function (t) {
            return { key: t.id, node: h(TaskGroup, Object.assign({}, t, { selected: props.selected, filter: filter, startOpen: !!moved[t.id], project: props.showProjects === false ? null : t.project,
              onAdd: props.onAdd ? function () { props.onAdd(t); } : t.onAdd, onArchive: props.onArchive ? function (x) { props.onArchive(t, x); } : t.onArchive, cap: props.sessionCap != null ? props.sessionCap : t.cap })) };
          }) })) };
      }) }));
  }


  /* ── Side-view tabs ── */
  function PanelTabs(props) {
    var tabs = props.tabs || [];
    var th = useThumb('[aria-selected="true"]', [props.active, props.labelled, tabs.length]);
    useFlip(th.ref, '.ex-tab', [props.active, props.labelled]);
    return h('div', { ref: th.ref, className: cx('ex-tabs', props.labelled && 'is-labelled', th.has && 'has-thumb', th.ready && 'is-ready'), role: 'tablist', 'aria-label': props.label || 'Side views' }, h('span', { className: 'ex-thumb', 'aria-hidden': 'true', style: th.style }), tabs.map(function (t) {
      var on = t.id === props.active;
      return h('button', { key: t.id, 'data-key': t.id, type: 'button', role: 'tab', className: 'ex-tab', 'aria-selected': String(on), title: t.label, onClick: props.onSelect && function () { props.onSelect(t.id); } },
        h(Icon, { name: t.icon, size: 15 }), h('span', { className: 'ex-tab-label' }, t.label),
        t.badge ? h('span', { className: 'ex-tab-dot', 'aria-label': 'Has updates' }) : null);
    }));
  }

  /* ── Small controls: Switch, Segmented ── */
  function Switch(props) {
    var on = !!props.on;
    return h('button', { type: 'button', role: 'switch', 'aria-checked': String(on), 'aria-label': props.label, className: cx('ex-switch', on && 'is-on'), onClick: props.onChange && function () { props.onChange(!on); } }, h('span', { className: 'ex-switch-thumb' }));
  }
  function Segmented(props) {
    var opts = props.options || [];
    var th = useThumb('[aria-checked="true"]', [props.value, opts.length]);
    return h('div', { ref: th.ref, className: cx('ex-seg', props.size === 'sm' && 'ex-seg-sm', th.has && 'has-thumb', th.ready && 'is-ready', props.className), role: 'radiogroup', 'aria-label': props.label },
      h('span', { className: 'ex-thumb', 'aria-hidden': 'true', style: th.style }),
      opts.map(function (o) {
        var on = o.id === props.value;
        return h('button', { key: o.id, type: 'button', role: 'radio', 'aria-checked': String(on), className: 'ex-seg-opt', title: o.title || o.label, onClick: props.onChange && function () { props.onChange(o.id); } },
          o.icon ? h(Icon, { name: o.icon, size: 13 }) : null, o.label ? h('span', null, o.label) : null);
      }));
  }

  /* ── Mode: plan or code ── */
  function ModeToggle(props) {
    return h(Segmented, { label: 'Mode', size: 'sm', className: 'ex-mode', value: props.value || 'code', onChange: props.onChange, options: [
      { id: 'plan', label: 'Plan', icon: 'plan', title: 'Plan: read and propose, no edits  ⇧Tab' },
      { id: 'code', label: 'Code', icon: 'code', title: 'Code: make changes  ⇧Tab' }] });
  }

  /* ── Agent picker: presets in one click, custom below ── */
  var THINKING = ['Off', 'Low', 'Medium', 'High', 'Max'];
  function AgentMark(props) { return h('span', { className: 'ex-agent-mark', 'aria-hidden': 'true' }, props.mark); }
  function agentSub(a) { return [a.preset ? a.model : a.harness, a.thinking || a.effort].filter(Boolean).join(' · '); }
  /* ── Plan usage: what's left of a Claude or Codex plan ──
     Unlike context, it isn't one session's: every session on that account draws from it, and it comes back on a clock
     (a 5-hour window and a weekly one). One number: the limit that stops you first. `plan`: { win, week } as fractions
     LEFT (0–1), { resetWin: '14:30', resetWeek: 'Monday' }, optional { name: 'Claude plan', tier: 'Max' }. */
  function planBind(p) { var w = p.win == null ? 1 : p.win; return p.week != null && p.week < w ? { left: p.week, which: 'week', reset: p.resetWeek || '' } : { left: w, which: 'win', reset: p.resetWin || '' }; }
  function planTone(left) { return left <= 0 ? 'danger' : left <= 0.2 ? 'attention' : 'ok'; }
  function pctOf(x) { return Math.round(Math.max(0, x) * 100) + '%'; }
  /* A small ring with a clock hand, beside the context ring: it fills as the plan is used (a full ring, nothing left).
     Grey while there's plenty, `attention` at 20% left, `danger` at the limit. When low it says how much is left
     (“12%”, “18% wk” when the weekly one is tighter); at the limit, when it comes back (“14:30”). */
  function PlanMeter(props) {
    var p = props.plan || {}, b = planBind(p), t = planTone(b.left), r = 5.25, c = 2 * Math.PI * r, used = 1 - Math.max(0, Math.min(1, b.left));
    var say = !props.compact || t !== 'ok';
    return h('span', { className: cx('ex-pmeter', 'is-' + t), role: 'img', 'aria-label': (b.left <= 0 ? 'Plan limit reached, resets ' + b.reset : pctOf(b.left) + ' of the ' + (b.which === 'week' ? 'weekly' : '5-hour') + ' limit left') },
      h('svg', { width: 14, height: 14, viewBox: '0 0 14 14', 'aria-hidden': 'true' },
        h('circle', { cx: 7, cy: 7, r: r, fill: 'none', stroke: 'currentColor', strokeOpacity: 0.22, strokeWidth: 1.75 }),
        h('circle', { className: 'ex-pmeter-arc', cx: 7, cy: 7, r: r, fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeDasharray: c, strokeDashoffset: c * (1 - used), transform: 'rotate(-90 7 7)' }),
        h('path', { d: 'M7 4.6v2.6l1.6 1', fill: 'none', stroke: 'currentColor', strokeWidth: 1.2, strokeLinecap: 'round', strokeLinejoin: 'round' })),
      say ? h('span', { className: 'ex-pmeter-n' }, b.left <= 0 ? b.reset : pctOf(b.left), b.which === 'week' && b.left > 0 ? h('span', { className: 'ex-pmeter-wk' }, ' wk') : null) : null);
  }
  function PlanLimit(props) {
    var t = planTone(props.left);
    return h('div', { className: cx('ex-plim', 'is-' + t, props.tight && 'is-tight') },
      h('span', { className: 'ex-plim-l' }, props.label), h('span', { className: 'ex-plim-v' }, props.left <= 0 ? 'Used up' : pctOf(props.left) + ' left'),
      h('span', { className: 'ex-plim-bar' }, h('i', { style: { width: Math.max(0, props.left) * 100 + '%' } })),
      h('span', { className: 'ex-plim-r' }, props.reset ? 'Resets ' + (/^\d/.test(props.reset) ? 'at ' : '') + props.reset : null));
  }
  /* Context and the plan, in full: the hover card on the agent chip, and the top of the agent menu. */
  function UsageBlock(props) {
    var p = props.plan, b = p ? planBind(p) : null;
    return h('div', { className: 'ex-usage' },
      props.context != null ? h('div', { className: 'ex-usage-ctx' }, h(ContextMeter, { used: props.context }), h('span', null, 'Context'), props.tokens ? h('span', { className: 'ex-usage-dim' }, props.tokens) : null,
        props.actions && props.context >= 0.75 ? h('button', { type: 'button', className: 'ex-usage-act', onClick: props.onCompact }, 'Compact') : null) : null,
      p ? h(F, null,
        h('div', { className: 'ex-usage-h' }, h('span', { className: 'ex-overline' }, p.name || 'Plan'), p.tier ? h('span', { className: 'ex-usage-dim' }, p.tier) : null),
        h(PlanLimit, { label: '5-hour limit', left: p.win == null ? 1 : p.win, reset: p.resetWin, tight: b.which === 'win' }),
        p.week != null ? h(PlanLimit, { label: 'Weekly limit', left: p.week, reset: p.resetWeek, tight: b.which === 'week' }) : null) : null);
  }
  function UsageCard(props) {
    return h('div', { className: cx('ex-usage-card', props.leaving && 'is-leaving'), role: 'tooltip' }, h(UsageBlock, props),
      h('div', { className: 'ex-usage-f' }, h('span', null, 'More in the agent menu'), h(Kbd, null, '⌘J')));
  }
  /* The line above the composer when the context fills up (75%, then 90%), with a way to make room. Show one line at a
     time, the most urgent: a plan at its limit, then context at 90%, then a plan running low, then context at 75%. */
  function ContextNotice(props) {
    var u = props.used || 0; if (u < 0.75) return null;
    var full = u >= 0.9;
    return h('div', { className: cx('ex-plan-note ex-ctx-note', full ? 'is-danger' : 'is-attention'), role: 'status' }, h(ContextMeter, { used: u, compact: true }),
      h('span', { className: 'ex-plan-note-t' }, h('b', null, 'Context ' + Math.round(u * 100) + '% full.'), full ? ' The agent may lose track of early details.' : ' Compact it to keep long work sharp.'),
      props.onFork ? h('button', { type: 'button', className: 'ex-plan-note-b', onClick: props.onFork }, 'Fork with a summary') : null,
      props.onCompact ? h('button', { type: 'button', className: 'ex-plan-note-b is-main', onClick: props.onCompact }, 'Compact now') : null,
      !full && props.onDismiss ? h(IconButton, { icon: 'x', label: 'Dismiss', size: 'sm', onClick: props.onDismiss }) : null);
  }
  /* The line above the composer when a plan runs low (20% left) or out; at the limit, a way on. */
  function PlanNotice(props) {
    var p = props.plan; if (!p) return null;
    var b = planBind(p), out = b.left <= 0; if (b.left > 0.2) return null;
    var when = b.which === 'week' ? (b.reset || 'next week') : b.reset, at = /^\d/.test(when) ? 'at ' + when : when;
    return h('div', { className: cx('ex-plan-note', out ? 'is-danger' : 'is-attention'), role: 'status' }, h(Icon, { name: 'clock', size: 14 }),
      h('span', { className: 'ex-plan-note-t' }, out ? h(F, null, h('b', null, (p.name || 'Plan') + ' limit reached.'), ' Resets ' + at + '.') : h(F, null, h('b', null, pctOf(b.left) + ' of your ' + (b.which === 'week' ? 'weekly' : '5-hour') + ' limit left.'), ' Resets ' + at + '.')),
      out && props.onSendLater ? h('button', { type: 'button', className: 'ex-plan-note-b', onClick: props.onSendLater }, 'Send ' + at) : null,
      out && props.forkTo ? h('button', { type: 'button', className: 'ex-plan-note-b is-main', onClick: props.onFork }, h(Icon, { name: 'fork', size: 13 }), 'Fork to ' + props.forkTo) : null,
      !out && props.onDismiss ? h(IconButton, { icon: 'x', label: 'Dismiss', size: 'sm', onClick: props.onDismiss }) : null);
  }
  function AgentPicker(props) {
    var pm = usePresence(props.open);
    var cur = props.value || { mark: 'Cl', harness: 'Claude Code', model: 'Opus 5.5', thinking: 'High' };
    var harnesses = props.harnesses || ['Claude Code', 'Codex', 'Local'];
    var locked = props.locked !== false, usage = cur.context != null || !!cur.plan;
    /* hover (or focus) the chip for a moment: context and the plan in full */
    var _hv = React.useState(false), hover = _hv[0], setHover = _hv[1], ht = React.useRef(null);
    function enter() { clearTimeout(ht.current); ht.current = setTimeout(function () { setHover(true); }, 400); }
    function leave() { clearTimeout(ht.current); setHover(false); }
    React.useEffect(function () { return function () { clearTimeout(ht.current); }; }, []);
    var pc = usePresence(usage && !props.open && (hover || !!props.cardOpen), 140);
    return h('div', { className: 'ex-agent-wrap', onMouseEnter: enter, onMouseLeave: leave, onFocus: enter, onBlur: leave },
      h('button', { type: 'button', className: 'ex-agent', 'aria-haspopup': 'dialog', 'aria-expanded': String(!!props.open), title: usage ? undefined : 'Agent  ⌘J' },
        h(AgentMark, cur), h('span', { className: 'ex-agent-name' }, cur.preset || cur.model), h('span', { className: 'ex-agent-sub' }, agentSub(cur)),
        cur.fast ? h('span', { className: 'ex-fast', title: 'Fast mode on' }, h(Icon, { name: 'bolt', size: 12 })) : null,
        usage ? h('span', { className: 'ex-agent-meters' }, cur.context != null ? h(ContextMeter, { used: cur.context, compact: true }) : null, cur.plan ? h(PlanMeter, { plan: cur.plan, compact: true }) : null) : null,
        h(Icon, { name: 'chevron-down', size: 13 })),
      pc.m ? h('div', { className: 'ex-usage-at', style: props.placement === 'top' ? { bottom: 34, left: 0 } : { top: 34, left: 0 } }, h(UsageCard, { context: cur.context, tokens: cur.tokens, plan: cur.plan, leaving: pc.l })) : null,
      pm.m && h('div', { className: 'ex-menu ex-agent-menu' + (pm.l ? ' is-leaving' : ''), role: 'dialog', 'aria-label': 'Agent', style: props.placement === 'top' ? { bottom: 32, left: 0 } : { top: 32, left: 0 } },
        usage ? h(F, null, h('div', { className: 'ex-agent-usage' }, h(UsageBlock, { context: cur.context, tokens: cur.tokens, plan: cur.plan, actions: true, onCompact: props.onCompact })), h('div', { className: 'ex-menu-sep' })) : null,
        h('div', { className: 'ex-overline ex-menu-label' }, cur.preset ? 'Adjust “' + cur.preset + '”' : 'Agent'),
        h('div', { className: 'ex-field' }, h('span', { className: 'ex-field-l' }, 'Harness'),
          locked
            ? h(F, null, h('span', { className: 'ex-field-v' }, h(AgentMark, cur), cur.harness), h('span', { style: { flex: 1 } }), h(Button, { variant: 'ghost', size: 'sm', icon: 'fork', title: 'Fork this session into another harness' }, 'Fork to…'))
            : h(Segmented, { size: 'sm', label: 'Harness', value: cur.harness, options: harnesses.map(function (x) { return { id: x, label: x }; }) })),
        h('div', { className: 'ex-field' }, h('span', { className: 'ex-field-l' }, 'Model'), h('button', { type: 'button', className: 'ex-select' }, h('span', null, cur.model), h(Icon, { name: 'chevron-down', size: 13 }))),
        h('div', { className: 'ex-field' }, h('span', { className: 'ex-field-l' }, 'Thinking'), h(Segmented, { size: 'sm', label: 'Thinking level', value: cur.thinking || cur.effort, options: THINKING.map(function (x) { return { id: x, label: x === 'Medium' ? 'Med' : x, title: x }; }) })),
        h('div', { className: 'ex-field' }, h('span', { className: 'ex-field-l' }, h(Icon, { name: 'bolt', size: 13 }), 'Fast mode'), h('span', { className: 'ex-muted', style: { fontSize: 12, flex: 1 } }, 'Quicker replies'), h(Switch, { on: !!cur.fast, label: 'Fast mode' })),
        h('div', { className: 'ex-menu-sep' }),
        h('div', { className: 'ex-menu-foot' }, h(Button, { variant: 'ghost', size: 'sm', icon: 'plus' }, 'Save as preset'), h('span', { style: { flex: 1 } }), h('span', { className: 'ex-muted', style: { fontSize: 12, paddingRight: 6 } }, 'Applies from the next message'))));
  }

  /* ── Presets: chosen when a session starts ── */
  function PresetCard(props) {
    var p = props.preset || {};
    var on = !!props.selected;
    return h('button', { type: 'button', role: 'radio', 'aria-checked': String(on), className: cx('ex-preset', on && 'is-on', props.custom && 'is-custom'), onClick: props.onSelect, title: props.kbd ? (p.preset || 'Custom') + '  ' + props.kbd : undefined },
      props.custom
        ? h(F, null, h('span', { className: 'ex-preset-top' }, h('span', { className: 'ex-preset-plus' }, h(Icon, { name: 'plus', size: 14 })), h('span', { style: { flex: 1 } })),
            h('span', { className: 'ex-preset-name' }, 'Custom'), h('span', { className: 'ex-preset-sub' }, 'Pick harness, model, thinking'))
        : h(F, null,
            h('span', { className: 'ex-preset-top' }, h(AgentMark, p), h('span', { style: { flex: 1 } }),
              on ? h('span', { className: 'ex-preset-check' }, h(Icon, { name: 'check', size: 12 })) : props.kbd ? h(Kbd, null, props.kbd) : null),
            h('span', { className: 'ex-preset-name' }, p.preset, p.fast ? h('span', { className: 'ex-fast', title: 'Fast mode' }, h(Icon, { name: 'bolt', size: 12 })) : null),
            h('span', { className: 'ex-preset-sub' }, [p.model, p.thinking].filter(Boolean).join(' · ')),
            h('span', { className: 'ex-preset-harness' }, p.harness)));
  }
  function PresetPicker(props) {
    var presets = props.presets || [];
    var sel = props.value;
    return h('div', { className: cx('ex-presets', props.compact && 'is-compact'), role: 'radiogroup', 'aria-label': 'Start with' },
      presets.map(function (p, i) { return h(PresetCard, { key: i, preset: p, selected: sel === p.preset, kbd: i < 9 ? '⌥' + (i + 1) : null, onSelect: props.onSelect && function () { props.onSelect(p.preset); } }); }),
      props.custom !== false ? h(PresetCard, { custom: true, selected: sel === 'custom' }) : null);
  }
  function SessionStart(props) {
    var presets = props.presets || [];
    var _s = React.useState(props.value || (presets[0] && presets[0].preset)); var sel = _s[0], setSel = _s[1];
    var agent = presets.filter(function (p) { return p.preset === sel; })[0] || presets[0];
    return h('div', { className: 'ex-start' },
      h('div', { className: 'ex-start-inner' },
        props.task ? h(TaskLine, { task: props.task }) : props.context ? h('div', { className: 'ex-start-ctx' }, props.context) : null,
        h('h2', { className: 'ex-start-title' }, props.title || 'What should we work on?'),
        h(PresetPicker, { presets: presets, value: sel, onSelect: setSel }),
        h(Composer, Object.assign({ agent: agent, mode: 'code', permission: 'edits' }, props.composer || {}, { hideAgent: true }))));
  }

  /* ── Permissions ── */
  var PERMS = [
    { id: 'ask', label: 'Ask first', short: 'Ask', note: 'Approve every edit and command' },
    { id: 'edits', label: 'Auto-edit', short: 'Auto-edit', note: 'Edits apply, commands ask' },
    { id: 'auto', label: 'Full auto', short: 'Full auto', note: 'Nothing asks; runs sandboxed' }];
  function PermissionPicker(props) {
    var pm = usePresence(props.open);
    var v = props.value || 'ask';
    var cur = PERMS.filter(function (p) { return p.id === v; })[0] || PERMS[0];
    return h('div', { className: 'ex-agent-wrap' },
      h('button', { type: 'button', className: cx('ex-agent ex-perm', 'is-' + v), 'aria-haspopup': 'listbox', 'aria-expanded': String(!!props.open), title: 'Permissions: ' + cur.label },
        h(Icon, { name: 'shield', size: 14 }), h('span', { className: 'ex-perm-l' }, cur.short)),
      pm.m && h('div', { className: 'ex-menu' + (pm.l ? ' is-leaving' : ''), role: 'listbox', style: { bottom: 32, left: 0, minWidth: 248 } },
        h('div', { className: 'ex-overline ex-menu-label' }, 'Permissions'),
        PERMS.map(function (p) {
          var sel = p.id === v;
          return h('div', { key: p.id, role: 'option', className: 'ex-menu-item', 'aria-selected': String(sel) },
            h('span', { className: 'ex-grow' }, h('span', null, p.label), h('span', { className: 'ex-muted', style: { fontSize: 12, lineHeight: '16px' } }, p.note)),
            sel ? h(Icon, { name: 'check', size: 14, className: 'ex-check' }) : null);
        })));
  }

  /* ── Tools: attach, mention, MCP servers ── */
  function ToolsMenu(props) {
    var pm = usePresence(props.open);
    var servers = props.servers || [];
    var onCount = servers.filter(function (s) { return s.on; }).length;
    return h('div', { className: 'ex-agent-wrap' },
      h('button', { type: 'button', className: 'ex-iconbtn', 'aria-label': 'Add files, mentions and tools', title: 'Add  ⌘U', 'aria-expanded': String(!!props.open) }, h(Icon, { name: 'plus' })),
      pm.m && h('div', { className: 'ex-menu' + (pm.l ? ' is-leaving' : ''), style: { bottom: 34, right: 0, minWidth: 280 } },
        h('div', { className: 'ex-menu-item' }, h(Icon, { name: 'attach', size: 14 }), h('span', { className: 'ex-grow' }, 'Attach files'), h(Kbd, null, '⌘U')),
        h('div', { className: 'ex-menu-item' }, h(Icon, { name: 'at', size: 14 }), h('span', { className: 'ex-grow' }, 'Mention a session, task or file'), h(Kbd, null, '@')),
        h('div', { className: 'ex-menu-sep' }),
        h('div', { className: 'ex-overline ex-menu-label', style: { display: 'flex' } }, h('span', { style: { flex: 1 } }, 'MCP servers'), h('span', { style: { letterSpacing: 0, textTransform: 'none', fontWeight: 500 } }, onCount + ' on')),
        servers.map(function (s, i) {
          return h('div', { key: i, className: 'ex-menu-item' },
            h('span', { className: cx('ex-dot', 'is-' + (s.on ? (s.error ? 'error' : 'ok') : 'off')), 'aria-hidden': 'true' }),
            h('span', { className: 'ex-grow' }, h('span', null, s.name), h('span', { className: cx('ex-muted', s.error && 'ex-err'), style: { fontSize: 12, lineHeight: '16px' } }, s.error ? s.error : s.tools + ' tools')),
            h(Switch, { on: !!s.on, label: s.name }));
        }),
        h('div', { className: 'ex-menu-sep' }),
        h('div', { className: 'ex-menu-item ex-muted' }, h(Icon, { name: 'plug', size: 14 }), h('span', { className: 'ex-grow' }, 'Manage MCP servers…'))));
  }

  /* ── Mention ── */
  function Mention(props) {
    var kind = props.kind || 'session';
    return h('span', { className: 'ex-mention ex-mention-' + kind },
      kind === 'session' ? h(StatusGlyph, { status: props.status || 'done', size: 12 }) : h(Icon, { name: kind === 'task' ? 'task' : 'file', size: 12 }),
      props.children,
      props.removable ? h('button', { type: 'button', className: 'ex-mention-x', 'aria-label': 'Remove' }, h(Icon, { name: 'x', size: 11 })) : null);
  }

  /* ── Queue: messages waiting for the agent's turn to end ── */
  function ComposerQueue(props) {
    var items = props.items || [];
    if (!items.length) return null;
    return h('div', { className: 'ex-queue', role: 'list', 'aria-label': 'Queued messages' },
      h('div', { className: 'ex-queue-head' }, h(StatusGlyph, { status: 'queued', size: 12 }), items.length + (items.length === 1 ? ' queued message' : ' queued messages'), h('span', { style: { flex: 1 } }), h('span', { className: 'ex-muted' }, 'Sent when this turn ends')),
      items.map(function (q, i) {
        return h('div', { key: i, role: 'listitem', className: 'ex-queue-item' },
          h('span', { className: 'ex-queue-n' }, i + 1),
          h('span', { className: 'ex-queue-text' }, q.text),
          h('span', { className: 'ex-queue-acts' },
            h(IconButton, { icon: 'pencil', label: 'Edit', size: 'sm' }),
            h(IconButton, { icon: 'trash', label: 'Remove', size: 'sm' })),
          h(Button, { variant: 'ghost', size: 'sm', icon: 'steer', title: 'Send now: the agent reads it at its next step, without stopping  ⌥↵' }, 'Steer'));
      }));
  }

  /* ── Dictation ── */
  function Waveform(props) {
    var bars = props.levels || [3, 6, 10, 7, 12, 5, 9, 14, 8, 4, 11, 6, 3, 8, 12, 7, 5, 9, 4, 3];
    return h('span', { className: 'ex-wave', 'aria-hidden': 'true' }, bars.map(function (b, i) { return h('i', { key: i, style: { height: b } }); }));
  }

  /* ── Composer ── */
  function Composer(props) {
    var running = !!props.running;
    var mode = props.mode || 'code';
    var hasText = props.hasText !== undefined ? props.hasText : !!props.children;
    var rec = props.recording;
    var context = (props.context || []);
    var send;
    if (running && !hasText) send = null;
    else if (running) send = h(Button, { variant: 'primary', className: 'ex-send-q', title: 'Queue  ↵ · Steer now  ⌥↵' }, 'Queue');
    else send = h(Button, { variant: 'primary', className: 'ex-send', 'aria-label': 'Send', title: 'Send  ↵', disabled: !hasText }, h(Icon, { name: 'arrow-up' }));
    return h('div', { className: cx('ex-composer', mode === 'plan' && 'is-plan', props.dropping && 'is-drop', props.className) },
      props.dropping ? h('div', { className: 'ex-drop', 'aria-hidden': 'true' }, h(Icon, { name: 'attach', size: 16 }), 'Drop to attach') : null,
      h(ComposerQueue, { items: props.queue }),
      context.length ? h('div', { className: 'ex-composer-context' }, context.map(function (c, i) { return h(Mention, Object.assign({ key: i, removable: true }, c), c.label); })) : null,
      h('div', { className: 'ex-composer-input', contentEditable: true, suppressContentEditableWarning: true, role: 'textbox', 'aria-multiline': 'true', 'aria-label': 'Message', 'data-placeholder': props.placeholder || (running ? 'Queue a message, or steer…' : mode === 'plan' ? 'Describe what to plan…' : 'Ask, or @mention a session…') },
        props.children, rec && rec.interim ? h('span', { className: 'ex-interim' }, ' ' + rec.interim) : null),
      h('div', { className: 'ex-composer-bar' },
        h(ModeToggle, { value: mode }),
        props.hideAgent ? null : h(AgentPicker, { value: props.agent, open: props.agentOpen, cardOpen: props.agentCardOpen, locked: !props.agentUnlocked, placement: 'top' }),
        mode === 'code' ? h(PermissionPicker, { value: props.permission, open: props.permissionOpen }) : null,
        h('span', { className: 'ex-grow' }),
        rec
          ? h('span', { className: 'ex-rec' }, h('span', { className: 'ex-rec-dot', 'aria-hidden': 'true' }), h(Waveform, null), h('span', { className: 'ex-mono' }, rec.time || '0:00'),
              h(IconButton, { icon: 'x', label: 'Cancel dictation', size: 'sm' }), h(IconButton, { icon: 'check', label: 'Finish dictation', size: 'sm' }))
          : h(F, null,
              h(ToolsMenu, { servers: props.servers, open: props.toolsOpen }),
              h(IconButton, { icon: 'mic', label: 'Dictate  ⌘D' })),
        running ? h(Button, { variant: 'secondary', className: 'ex-send', 'aria-label': 'Stop', title: 'Stop  ⌘.' }, h(Icon, { name: 'stop' })) : null,
        send));
  }


  /* ── ChatScroll: the chat's scrolling area. While you read a reply whose message has scrolled away above,
     that message stays pinned at the top as a reminder: two lines, Back to it, Hide. ── */
  function ChatScroll(props) {
    var sc = React.useRef(null), stick = React.useRef(props.startAtEnd !== false), measured = React.useRef(false), instantKey = React.useRef(null), last = React.useRef(null), raf = React.useRef(0), flashT = React.useRef(0);
    var st = React.useState(null), pin = st[0], setPin = st[1];
    var hs = React.useState({}), hidden = hs[0], setHidden = hs[1];
    function measure() {
      raf.current = 0;
      var el = sc.current; if (!el) return;
      if (stick.current && el.scrollHeight - el.scrollTop - el.clientHeight > 1) el.scrollTop = el.scrollHeight; /* at the bottom, the chat follows what arrives */
      var top = el.getBoundingClientRect().top, hgt = el.clientHeight, ms = el.querySelectorAll('.ex-you'), chosen = null, ci = -1;
      for (var i = 0; i < ms.length; i++) { if (ms[i].getBoundingClientRect().bottom < top + 8) { chosen = ms[i]; ci = i; } else break; }
      var next = ci >= 0 ? ms[ci + 1] : null;
      /* once the next message reaches the upper part of the view, the reply below it is the one you're reading: no reminder */
      if (chosen && next && next.getBoundingClientRect().top < top + hgt * 0.4) chosen = null;
      var p = null;
      if (chosen) { var b = chosen.querySelector('.ex-msg-user'); p = { key: chosen.getAttribute('data-msg') || 'm' + ci, text: (b ? b.textContent : '').trim() }; }
      if (!measured.current) { measured.current = true; instantKey.current = p ? p.key : null; }
      setPin(function (o) { return (!o && !p) || (o && p && o.key === p.key && o.text === p.text) ? o : p; });
    }
    function soon() { if (!raf.current) raf.current = requestAnimationFrame(measure); }
    function onScroll() { var el = sc.current; if (el) stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 24; soon(); }
    useLayout(function () {
      var el = sc.current; if (!el) return;
      if (props.startAtEnd !== false) el.scrollTop = el.scrollHeight; /* a chat opens on its latest message */
      measure();
      el.addEventListener('scroll', onScroll, { passive: true });
      var mo = window.MutationObserver ? new MutationObserver(soon) : null; if (mo) mo.observe(el, { childList: true, subtree: true, characterData: true });
      var ro = window.ResizeObserver ? new ResizeObserver(soon) : null; if (ro) ro.observe(el);
      return function () { el.removeEventListener('scroll', onScroll); if (mo) mo.disconnect(); if (ro) ro.disconnect(); if (raf.current) cancelAnimationFrame(raf.current); clearTimeout(flashT.current); };
    }, []);
    function back() {
      var el = sc.current; if (!el || !pin) return;
      var ms = el.querySelectorAll('.ex-you'), target = null;
      for (var i = 0; i < ms.length; i++) if ((ms[i].getAttribute('data-msg') || 'm' + i) === pin.key) target = ms[i];
      if (!target) return;
      var d = target.getBoundingClientRect().top - el.getBoundingClientRect().top - 12;
      el.scrollTo({ top: el.scrollTop + d, behavior: reducedMotion() ? 'auto' : 'smooth' });
      var bubble = target.querySelector('.ex-msg-user');
      if (bubble) { bubble.classList.remove('is-flash'); void bubble.offsetWidth; bubble.classList.add('is-flash'); clearTimeout(flashT.current); flashT.current = setTimeout(function () { bubble.classList.remove('is-flash'); }, 1400); }
    }
    var show = !!pin && !hidden[pin.key] && props.reminder !== false;
    if (show) last.current = pin;
    var shown = show ? pin : last.current;
    return h('div', { className: cx('ex-chatscroll', props.className), style: props.style },
      h('div', { ref: sc, className: cx('ex-chatscroll-in', props.innerClassName) }, props.children),
      h(Presence, { show: show, exit: 160 }, shown ? h('div', { className: cx('ex-pin', shown.key === instantKey.current && 'is-instant'), role: 'region', 'aria-label': 'Your message' },
        h('button', { type: 'button', className: 'ex-pin-body', onClick: back, title: 'Back to your message' },
          h('span', { className: 'ex-pin-label' }, 'You asked'), h('span', { key: shown.key, className: 'ex-pin-text' }, shown.text)),
        h(IconButton, { icon: 'arrow-up', label: 'Back to your message', size: 'sm', onClick: back }),
        h(IconButton, { icon: 'x', label: 'Hide', size: 'sm', onClick: function () { var o = Object.assign({}, hidden); o[shown.key] = true; setHidden(o); } })) : null));
  }
  /* ── Message ── */
  function Message(props) {
    var role = props.role || 'agent';
    if (role === 'user') return h('div', { className: cx('ex-you', props.isNew && 'is-new'), 'data-msg': props.id },
      h('div', { className: cx('ex-msg ex-msg-user', props.isNew && 'is-new') }, h('div', null, props.children)),
      props.time ? h('span', { className: 'ex-you-time' }, props.time) : null);
    return h('section', { className: cx('ex-msg ex-msg-agent', props.pinned && 'is-pinned') },
      h('div', { className: 'ex-turn-gutter', 'aria-hidden': 'true' }, h('span', { className: 'ex-turn-avatar', title: (props.author || 'Opus 5.5') + (props.time ? ' · ' + props.time : '') }, h(AgentMark, { mark: props.mark || 'Cl' }))),
      h('div', { className: 'ex-msg-body' },
        h('div', { className: 'ex-turn-answer' }, props.children),
        props.sideChats ? h('button', { type: 'button', className: 'ex-msg-branches' }, h(Icon, { name: 'side-chat', size: 13 }), props.sideChats + (props.sideChats === 1 ? ' side chat' : ' side chats')) : null,
        h('div', { className: 'ex-turn-foot' }, h('span', { style: { flex: 1 } }), h(TurnActs))));
  }
  /* Side chat, fork, copy: on hover or focus, at the end of the reply's footer. */
  function TurnActs() {
    return h('span', { className: 'ex-msg-acts' },
      h(IconButton, { icon: 'side-chat', label: 'Side chat from here', size: 'sm' }),
      h(IconButton, { icon: 'fork', label: 'Fork from here', size: 'sm' }),
      h(IconButton, { icon: 'copy', label: 'Copy', size: 'sm' }));
  }

  /* ── Side thread ── */
  function SideThread(props) {
    return h('section', { className: cx('ex-side', props.className), 'aria-label': 'Side chat' },
      h('div', { className: 'ex-side-head' }, h(Icon, { name: 'side-chat', size: 15 }), h('span', { className: 'ex-grow' }, props.title || 'Side chat'),
        h(IconButton, { icon: 'expand', label: 'Promote to fork', size: 'sm' }), h(IconButton, { icon: 'x', label: 'Close', size: 'sm' })),
      props.anchor && h('div', { className: 'ex-side-anchor' }, props.anchor),
      h('div', { className: 'ex-side-body' }, props.children),
      h('div', { className: 'ex-side-note' }, h(Icon, { name: 'check', size: 13 }), 'Not added to the main session’s context'),
      h('div', { className: 'ex-side-foot' }, h('div', { className: 'ex-composer' },
        h('div', { className: 'ex-composer-input', contentEditable: true, suppressContentEditableWarning: true, role: 'textbox', 'aria-label': 'Reply in side chat', 'data-placeholder': 'Ask a follow-up…' }),
        h('div', { className: 'ex-composer-bar' }, h('span', { className: 'ex-grow' }), h(Button, { variant: 'primary', size: 'sm', className: 'ex-send', style: { width: 24, height: 24 }, 'aria-label': 'Send' }, h(Icon, { name: 'arrow-up', size: 14 }))))));
  }

  /* ── Git ── */
  /* Swaps inline content without a jump: the old content fades out where it was, the new one fades in over it,
     and the box's width eases from one to the other. Content with the same key updates in place (its width still eases). */
  function EaseSwap(props) {
    var outer = React.useRef(null), mounted = React.useRef(false), ids = React.useRef(1), timers = React.useRef([]), shown = React.useRef(props.children);
    var st = React.useState([{ id: 0, k: props.k, node: null }]), layers = st[0], setLayers = st[1];
    useLayout(function () {
      var top = layers[layers.length - 1];
      if (top.k === props.k) return;
      var id = ids.current++, prevNode = shown.current; /* what the last render showed */
      setLayers(function (ls) { return ls.map(function (l) { return l.leaving ? l : Object.assign({}, l, { leaving: true, node: l === ls[ls.length - 1] ? prevNode : l.node }); }).concat([{ id: id, k: props.k, node: null }]); });
      timers.current.push(setTimeout(function () { setLayers(function (ls) { return ls.filter(function (l) { return !l.leaving || l.id > id; }); }); }, 260));
    }, [props.k]);
    useLayout(function () {
      shown.current = props.children;
      var o = outer.current; if (!o) return;
      var t = o.querySelector('.ex-eswap-l.is-top'); if (!t) return;
      var w = t.offsetWidth + 'px', hh = t.offsetHeight + 'px';
      if (!mounted.current) { mounted.current = true; requestAnimationFrame(function () { if (outer.current) outer.current.classList.add('is-live'); }); }
      if (o.style.width === w && o.style.height === hh) return;
      /* inside a slot that's hidden (or growing in this very frame), take the new size at once: the slot is what moves */
      if (o.closest('[data-still]') && o.classList.contains('is-live')) { o.classList.remove('is-live'); o.style.width = w; o.style.height = hh; void o.offsetWidth; o.classList.add('is-live'); }
      else { o.style.width = w; o.style.height = hh; }
    });
    React.useEffect(function () { return function () { timers.current.forEach(clearTimeout); }; }, []);
    return h('span', { ref: outer, className: cx('ex-eswap', props.className) }, layers.map(function (l, n) {
      var top = n === layers.length - 1;
      return h('span', { key: l.id, className: cx('ex-eswap-l', top && 'is-top', l.leaving && 'is-out', top && l.id > 0 && 'is-in'), 'aria-hidden': top ? null : 'true' }, top ? props.children : l.node);
    }));
  }

  /* One button for the next git step: Commit while there are uncommitted changes, Push once commits are waiting, nothing when
     the task is up to date. The chevron holds the combinations. The button is one element throughout: its icon and label
     crossfade in place and its width eases; it only grows in or leaves when there's a step to show or none. */
  function GitBar(props) {
    var files = props.files || 0, ahead = props.ahead || 0, busy = props.busy;
    var into = props.mergeInto, intoShort = into ? String(into).split('/').pop() : '';
    /* a job (merge, sync, push) that Elevenex runs: the button says its step, its menu lists the steps */
    var job = props.job, lastJob = React.useRef(job); if (job) lastJob.current = job;
    var _jo = React.useState(!!(job && job.open)), jobOpen = _jo[0], setJobOpen = _jo[1];
    var jm = usePresence(!!job && jobOpen);
    var jsteps = job ? job.steps || [] : [], jdone = jsteps.filter(function (s) { return s.status === 'done'; }).length;
    var jcur = jsteps.filter(function (s) { return s.status !== 'done'; })[0];
    var step = job ? 'job' : busy === 'commit' || (!busy && files) ? 'commit' : busy === 'merge' || (into && ahead) ? 'merge' : busy === 'push' || ahead ? 'push' : null;
    var statKind = job ? null : files ? 'diff' : step ? null : 'quiet';
    var stat = statKind === 'diff'
      ? h('span', { className: 'ex-git-stat', role: 'button', tabIndex: 0, title: files + (files === 1 ? ' changed file' : ' changed files') + ', open changes' }, h(Icon, { name: 'changes', size: 15 }), h(Diff, { add: props.add || 0, del: props.del || 0 }))
      : statKind === 'quiet' ? h('span', { className: 'ex-git-stat is-quiet' }, 'Up to date') : null;
    var label = job ? (job.waiting ? (job.noun || 'Merge') + ' waiting on you' : (job.verb || 'Merging') + ' · ' + (jcur && jcur.short ? jcur.short : Math.min(jdone + 1, jsteps.length) + ' of ' + jsteps.length))
      : props.busyLabel && busy ? props.busyLabel : busy === 'commit' ? 'Committing…' : busy === 'push' ? 'Pushing…' : busy === 'merge' ? 'Merging…' : step === 'commit' ? 'Commit' : step === 'merge' ? 'Merge into ' + intoShort : 'Push';
    var count = job || busy || step === 'merge' ? 0 : step === 'push' ? ahead : files;
    var kbd = !props.compact && step === 'commit' && !busy;
    var menu = job ? 'Steps and Cancel' : step === 'commit'
      ? (into ? 'Commit and merge into ' + intoShort + ' · Sync with ' + intoShort : ahead ? 'Commit and push · Push the ' + ahead + ' waiting · Commit and open PR · Sync with main' : 'Commit and push · Commit and open PR · Sync with main')
      : step === 'merge' ? 'Squash and merge (default) · Merge commit · Rebase on ' + intoShort + ' · Push this branch'
      : 'Push and open PR · Push to a new name · Sync with main';
    var variant = props.compact ? 'secondary' : 'primary';
    return h('div', { className: 'ex-git' },
      h(GitAction, { show: !!statKind, className: 'is-stat' }, h(EaseSwap, { k: statKind || 'none', className: 'ex-git-statswap' }, stat)),
      h(GitAction, { show: !!step },
        h('span', { className: cx('ex-split', job && 'is-job', job && job.waiting && 'is-wait') },
          h(Button, { variant: job ? 'secondary' : variant, disabled: !!busy, 'aria-busy': busy || (job && !job.waiting) ? 'true' : null, 'aria-expanded': job && !job.waiting ? String(jobOpen) : undefined,
            title: job ? (job.waiting ? 'Open the session that needs you' : 'Show the steps') : step === 'merge' ? 'Merge ' + ahead + (ahead === 1 ? ' commit' : ' commits') + ' into ' + into : undefined,
            onClick: job ? (job.waiting && job.onOpen ? job.onOpen : function () { setJobOpen(!jobOpen); }) : step === 'commit' ? props.onCommit : step === 'merge' ? props.onMerge : props.onPush },
            h(EaseSwap, { k: job ? (job.waiting ? 'wait' : 'job') : busy ? 'busy' : step || 'none', className: 'ex-git-ic' }, job ? h(StatusGlyph, { status: job.waiting ? 'attention' : 'running', size: 13 }) : busy ? h(StatusGlyph, { status: 'running', size: 13 }) : h(Icon, { name: step === 'commit' ? 'commit' : step === 'merge' ? 'merged' : 'push', size: 14 })),
            h(EaseSwap, { k: label + (count ? '#' : '') + (kbd ? 'k' : '') },
              h('span', { className: 'ex-git-label' }, label),
              count ? h('span', { className: 'ex-git-ahead', title: step === 'push' ? count + ' to push' : count + (count === 1 ? ' changed file' : ' changed files') }, h(Ticker, { value: count })) : null,
              kbd ? h(Kbd, null, '⌘↵') : null)),
          h(Button, { variant: job ? 'secondary' : variant, disabled: !!busy, 'aria-label': 'More: ' + menu, title: menu, 'aria-expanded': job ? String(jobOpen) : undefined, onClick: job ? function () { setJobOpen(!jobOpen); } : undefined }, h(Icon, { name: 'chevron-down', size: 14 })))),
      jm.m && lastJob.current ? h(GitJobMenu, { job: lastJob.current, leaving: jm.l }) : null,
      props.panel || null);
  }
  /* The job's steps: what's done, what runs now, what's next, and who does each (Elevenex, or the session it started). */
  function GitJobMenu(props) {
    var J = props.job, steps = J.steps || [];
    return h('div', { className: cx('ex-menu ex-git-job', props.leaving && 'is-leaving'), role: 'dialog', 'aria-label': J.title || 'Job' },
      h('div', { className: 'ex-overline ex-menu-label' }, J.title || 'Merge'),
      steps.map(function (s, i) {
        return h('div', { key: i, className: cx('ex-git-jobstep', 'is-' + (s.status || 'queued')) }, h(StatusGlyph, { status: s.status || 'queued', size: 13 }),
          h('span', { className: 'ex-grow' }, h('span', null, s.label), s.detail ? h('span', { className: 'ex-git-jobd' }, s.detail) : null),
          s.session ? h('button', { type: 'button', className: 'ex-git-jobby', title: 'Open the session Elevenex started for this', onClick: J.onOpen }, h(Icon, { name: 'bolt', size: 12 }), s.session) : null);
      }),
      h('div', { className: 'ex-git-jobfoot' }, h('span', { className: 'ex-muted' }, J.note || 'Elevenex runs these itself'), h(Button, { size: 'sm', variant: 'ghost', onClick: J.onCancel }, J.cancel || 'Cancel')));
  }
  /* The first message of a session Elevenex started for a job: what happened, what to do, when to stop. Neither your
     bubble nor the agent's: a quiet well with the ⚡ mark. */
  function JobBrief(props) {
    return h('div', { className: 'ex-brief', 'data-msg': props.id },
      h('div', { className: 'ex-brief-h' }, h(Icon, { name: 'bolt', size: 13 }), h('b', null, 'Elevenex'), h('span', null, props.title || 'started this session for a git job'), props.time ? h('span', { className: 'ex-brief-t' }, props.time) : null),
      h('div', { className: 'ex-brief-b' }, props.children));
  }
  /* A slot that grows in or closes. While it's shown its width is auto (the content eases itself). Growing in, the pill
     opens from the right with its rounded edge while the space for it opens, and its label fades in once there's room;
     closing is the reverse. It keeps its last content while it closes. It sets is-gone itself, so neither way snaps. */
  function GitAction(props) {
    var outer = React.useRef(null), inner = React.useRef(null), prev = React.useRef(null), last = React.useRef(props.children), t = React.useRef(0);
    if (props.show) last.current = props.children;
    useLayout(function () {
      var o = outer.current, i = inner.current; if (!o || !i) return;
      var was = prev.current; prev.current = props.show;
      /* while hidden, the content inside doesn't ease (EaseSwap reads this): when the slot grows in, its content is already at its final size */
      if (props.show) o.removeAttribute('data-still'); else o.setAttribute('data-still', '');
      if (was === null) { if (!props.show) { o.classList.add('is-gone'); o.style.width = '0px'; } return; } /* first paint: no motion */
      if (was === props.show) return;
      clearTimeout(t.current);
      o.style.width = (props.show ? 0 : o.offsetWidth) + 'px'; void o.offsetWidth;
      o.classList.add('is-moving');
      o.classList.toggle('is-gone', !props.show);
      o.style.width = (props.show ? i.offsetWidth : 0) + 'px';
      t.current = setTimeout(function () { o.classList.remove('is-moving'); if (props.show) o.style.width = ''; }, 360);
    }, [props.show]);
    React.useEffect(function () { return function () { clearTimeout(t.current); }; }, []);
    return h('span', { ref: outer, className: cx('ex-git-act', props.className), 'aria-hidden': props.show ? null : 'true', inert: props.show ? null : '' },
      h('span', { ref: inner, className: 'ex-git-act-in' }, props.show ? props.children : last.current));
  }
  /* Commit, opened from its button: a panel grows out of the button, under it. The message first (optional: an empty one
     is written after Commit), what goes in on one line, the files folded under it (a filter, what needs a look, the
     biggest changes, the rest one click away in a short scroll), the unstaged files in or out, a note only when something
     deserves one, and Commit. Commit folds it back into the button, which says what it's doing. */
  var CP_ROW = 28, CP_ROWS = 6, CP_TOP = 4; /* what needs a look + the 4 biggest + “Show the other N” fill the 6 rows the scroll keeps later */
  function CommitPanel(props) {
    var files = props.files || [], morph = !reducedMotion();
    var pm = usePresence(!!props.open, morph ? 520 : 200), layer = React.useRef(null), msgRef = React.useRef(null), scrollRef = React.useRef(null);
    var _m = React.useState(''), msg = _m[0], setMsg = _m[1], _u = React.useState(true), withUn = _u[0], setWithUn = _u[1];
    var _l = React.useState(false), list = _l[0], setList = _l[1], _q = React.useState(''), q = _q[0], setQ = _q[1], _a = React.useState(false), all = _a[0], setAll = _a[1];
    var init = React.useMemo(function () { var o = {}; files.forEach(function (f) { o[f.path] = !f.flag; }); return o; }, [files.length]);
    var _p = React.useState(init), pick = _p[0], setPick = _p[1], _mo = React.useState(false), more = _mo[0], setMore = _mo[1];
    /* the button it opens from, and closes back into: the main button of the GitBar it sits in */
    function fromEl() { var w = layer.current, git = w && w.parentNode; return git && git.querySelector('.ex-split > .ex-btn'); }
    /* a fresh start each time it opens; as wide as the header lets it (at most 460) */
    var wasOpen = React.useRef(false);
    useLayout(function () {
      if (props.open && !wasOpen.current) {
        setMsg(''); setList(false); setQ(''); setAll(false); setWithUn(true); setPick(init);
        var w = layer.current, head = w && w.closest('.ex-taskhead');
        if (head) w.style.setProperty('--cp-w', Math.min(460, head.offsetWidth - 24) + 'px');
        setTimeout(function () { msgRef.current && msgRef.current.focus({ preventScroll: true }); }, morph ? 280 : 0);
      }
      /* closed with the focus inside: it goes back to the button */
      if (!props.open && wasOpen.current && layer.current && layer.current.contains(document.activeElement)) { var b = fromEl(); b && b.focus({ preventScroll: true }); }
      wasOpen.current = !!props.open;
    }, [props.open]);
    useMorphFrom(layer, pm, morph, fromEl, { noFace: true, fadeIn: 0.3 });
    /* Esc, or a press outside (not on its own button), closes it untouched */
    React.useEffect(function () {
      if (!props.open) return;
      function k(e) { if (e.key === 'Escape') { e.stopPropagation(); props.onClose && props.onClose(); } }
      function d(e) { var w = layer.current, git = w && w.parentNode; if (!git || git.contains(e.target)) return; props.onClose && props.onClose(); }
      document.addEventListener('keydown', k); document.addEventListener('mousedown', d);
      return function () { document.removeEventListener('keydown', k); document.removeEventListener('mousedown', d); };
    }, [props.open]);
    /* the list fades at its bottom edge while there's more below */
    function edge(e) { var el = e && (e.currentTarget || e); if (!el || !el.clientHeight) return; setMore(el.scrollTop + el.clientHeight < el.scrollHeight - 2); }
    useLayout(function () { edge(scrollRef.current); }, [list, q, all, withUn, pm.m]);

    function can(f) { return withUn || !!f.staged; }
    function on(f) { return !!pick[f.path] && can(f); }
    function flip(path, v) { var o = Object.assign({}, pick); o[path] = v; setPick(o); }
    var chosen = files.filter(on), unstaged = files.filter(function (f) { return !f.staged; }).length;
    var stagedIn = chosen.filter(function (f) { return f.staged; }).length, unIn = chosen.length - stagedIn;
    var tot = chosen.reduce(function (a, f) { return { add: a.add + (f.add || 0), del: a.del + (f.del || 0) }; }, { add: 0, del: 0 });
    var flagged = files.filter(function (f) { return f.flag; }), running = props.running || [];
    /* the list: what needs a look, then the biggest changes; what can't go in (staged only) last; the rest one click away */
    var match = files.filter(function (f) { return !q || f.path.toLowerCase().indexOf(q.toLowerCase()) >= 0; });
    var size = function (f) { return (f.add || 0) + (f.del || 0); };
    var rest = match.filter(function (f) { return !f.flag; }).sort(function (a, b) { return (can(b) - can(a)) || (size(b) - size(a)) || (a.path < b.path ? -1 : 1); });
    var lead = match.filter(function (f) { return f.flag && can(f); }), tail = match.filter(function (f) { return f.flag && !can(f); });
    var full = lead.concat(rest.filter(can), tail, rest.filter(function (f) { return !can(f); }));
    var cut = q || all ? full.length : lead.length + Math.min(CP_TOP, rest.filter(can).length), shown = full.slice(0, cut), hidden = full.length - shown.length;
    function commit() { if (!chosen.length) return; props.onCommit && props.onCommit({ message: msg.trim(), files: chosen.map(function (f) { return f.path; }), push: !!props.push }); }

    var kept = React.useRef(null);
    var box = props.open ? h('div', { className: 'ex-cp-box', role: 'dialog', 'aria-label': 'Commit', onKeyDown: function (e) { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); commit(); } } },
      h('label', { className: 'ex-cp-msg' }, h(Icon, { name: 'commit', size: 14 }),
        h('input', { ref: msgRef, value: msg, placeholder: 'Describe the change, or leave it to Elevenex', spellCheck: true, 'aria-label': 'Commit message (optional: Elevenex writes one from the changes if you leave it empty)',
          onChange: function (e) { setMsg(e.target.value); }, onKeyDown: function (e) { if (e.key === 'Enter') { e.preventDefault(); commit(); } } })),
      h('button', { type: 'button', className: cx('ex-cp-sum', list && 'is-open'), 'aria-expanded': String(list), onClick: function () { setList(!list); } },
        h('b', null, h(Ticker, { value: chosen.length }), chosen.length === 1 ? ' file' : ' files'), h(Diff, { add: tot.add, del: tot.del }),
        h('span', { className: 'ex-cp-sum-d' }, unIn ? stagedIn + ' staged · ' + unIn + ' unstaged' : stagedIn === files.length ? 'all staged' : stagedIn + ' staged'),
        h(Icon, { name: 'chevron-down', size: 13, className: cx('ex-ps-chev', list && 'is-open') })),
      h(Fold, { open: list }, h('div', { className: 'ex-cp-list' },
        h('label', { className: 'ex-cp-find' }, h(Icon, { name: 'search', size: 13 }),
          h('input', { value: q, placeholder: 'Filter ' + files.length + ' files', 'aria-label': 'Filter files', onChange: function (e) { setQ(e.target.value); } }),
          q ? h('span', { className: 'ex-cp-find-n' }, match.length === 1 ? '1 file' : match.length + ' files') : null),
        h(AutoHeight, null, h('div', { ref: scrollRef, className: cx('ex-cp-scroll', more && 'is-more'), style: { maxHeight: CP_ROW * CP_ROWS + 'px' }, onScroll: edge },
          shown.map(function (f) {
            var ok = can(f), isOn = on(f), i = f.path.lastIndexOf('/');
            return h('label', { key: f.path, className: cx('ex-cp-file', !isOn && 'is-off', !ok && 'is-dis'), title: f.path + (f.staged ? ' · staged' : ok ? ' · unstaged' : ' · unstaged: include unstaged files to pick it') },
              h('input', { type: 'checkbox', checked: isOn, disabled: !ok, onChange: function () { flip(f.path, !pick[f.path]); } }),
              h('span', { className: cx('ex-cp-st', 'is-' + (f.status || 'M')) }, f.status || 'M'),
              h('span', { className: 'ex-cp-path ex-mono' }, i >= 0 ? h('span', { className: 'ex-cp-dir' }, f.path.slice(0, i + 1)) : null, f.path.slice(i + 1)),
              /* no “unstaged” tag on every row: the summary counts them, and staged only sets them apart */
              f.flag ? h('span', { className: 'ex-cp-tag is-warn' }, h(Icon, { name: 'shield', size: 11 }), 'may hold secrets') : null,
              h(Diff, { add: f.add || 0, del: f.del || 0 }));
          }),
          !shown.length ? h('div', { className: 'ex-cp-none' }, 'No file matches “' + q + '”') : null,
          hidden ? h('button', { type: 'button', className: 'ex-cp-more', onClick: function () { setAll(true); setTimeout(function () { var n = scrollRef.current && scrollRef.current.querySelectorAll('input')[cut]; n && n.focus({ preventScroll: true }); }, 0); } }, 'Show the other ' + hidden) : null)))),
      unstaged ? h('label', { className: 'ex-cp-opt' }, h('input', { type: 'checkbox', checked: withUn, onChange: function () { setWithUn(!withUn); } }),
        h('span', null, 'Include ', h('b', null, unstaged + ' unstaged'), unstaged === 1 ? ' file' : ' files')) : null,
      flagged.map(function (f) { var inn = !!pick[f.path]; return h(Fold, { key: f.path, open: can(f) }, h('div', { className: 'ex-cp-note' }, h(Icon, { name: 'shield', size: 13, className: 'is-warn' }),
        h('span', { className: 'ex-cp-note-t' }, h('b', { className: 'ex-mono' }, f.path.split('/').pop()), inn ? ' is included, though it may hold secrets.' : ' may hold secrets, so it’s left out.'),
        h('button', { type: 'button', className: 'ex-cp-link', onClick: function () { flip(f.path, !inn); } }, inn ? 'Leave it out' : 'Include it'))); }),
      running.length ? h('div', { className: 'ex-cp-note' }, h(StatusGlyph, { status: 'running', size: 13 }),
        h('span', { className: 'ex-cp-note-t' }, running.length === 1 ? h(F, null, h('b', null, running[0]), ' is still running. What it changes from now on won’t be in this commit.') : h(F, null, h('b', null, running.length + ' sessions'), ' are still running. What they change from now on won’t be in this commit.'))) : null,
      h('div', { className: 'ex-cp-foot' },
        h('label', { className: 'ex-cp-push' }, h(Switch, { on: !!props.push, label: 'Push after', onChange: props.onPush }), h('span', null, 'Push after')),
        h('span', { className: 'ex-mgrow' }),
        h(Button, { variant: 'primary', size: 'sm', className: 'ex-np-next ex-cp-go', disabled: !chosen.length, onClick: commit },
          h(EaseSwap, { k: props.push ? 'p' : 'c' }, h('span', { className: 'ex-np-next-in' }, props.push ? 'Commit and push' : 'Commit', h('span', { className: 'ex-cp-n' }, h(Ticker, { value: chosen.length })), h(Kbd, null, '↵')))))) : null;
    /* while it leaves, it keeps showing what it showed (the files change as the commit starts) */
    if (props.open) kept.current = box;
    /* the layer is always there (empty when closed), so it knows its GitBar before it opens */
    return h('div', { ref: layer, className: cx('ex-cp', pm.l && 'is-leaving', morph && 'has-from') }, pm.m ? (props.open ? box : kept.current) : null);
  }
  /* The changed files: status letter (M modified, A added, D deleted, R renamed), name in bold with its folder muted, line
     counts, and a check once viewed. Grouped, files sit under their folder. The current file has the raised highlight,
     which glides when it changes. */
  function ChangeList(props) {
    var items = props.items || [];
    var th = useThumb('[aria-current="true"]', [items.map(function (f) { return f.path + (f.current || f.selected ? '*' : ''); }).join('|'), !!props.grouped]);
    var rows = [], lastDir = null;
    items.forEach(function (f, i) {
      var parts = f.path.split('/'), name = parts.pop(), dir = parts.join('/');
      if (props.grouped && dir !== lastDir) { lastDir = dir; if (dir) rows.push(h('div', { key: 'd' + i, className: 'ex-change-dir', role: 'presentation' }, h(Icon, { name: 'folder', size: 13 }), h('bdi', null, dir + '/'))); }
      var nested = props.grouped && dir;
      rows.push(h(props.onSelect ? 'button' : 'div', { key: i, type: props.onSelect ? 'button' : undefined, role: 'listitem', className: cx('ex-change', nested && 'is-nested', f.viewed && 'is-viewed'), 'data-key': f.path,
        'aria-current': f.current || f.selected ? 'true' : undefined, onClick: props.onSelect && function () { props.onSelect(f.path); } },
        h('span', { className: 'ex-change-st st-' + f.status, title: { M: 'Modified', A: 'Added', D: 'Deleted', R: 'Renamed' }[f.status] }, f.status),
        h('span', { className: 'ex-change-path' }, h('bdi', null, h('b', null, name), !nested && dir ? h('span', null, '  ' + dir) : null)),
        f.changed ? h('span', { className: 'ex-change-again', title: 'Changed since you viewed it' }) : null,
        h(Diff, { add: f.add || 0, del: f.del || 0 }),
        f.viewed !== undefined ? h('span', { className: cx('ex-change-v', f.viewed && 'is-on'), 'aria-label': f.viewed ? 'Viewed' : null }, h(Icon, { name: 'check', size: 12 })) : null));
    });
    return h('div', { ref: th.ref, className: cx('ex-changes', th.has && 'has-thumb', th.ready && 'is-ready'), role: 'list' },
      h('span', { className: 'ex-thumb', 'aria-hidden': 'true', style: th.style }), rows);
  }

  /* ════ Changes review (DiffReview) ════
     A pull-request-style review of a task's changes: one long scroll of every changed file, each with its hunks and a few
     lines around them; expand above or below a hunk; mark a file Viewed to fold it away; jump between files from the list.
     Full files shows each file whole with its changes marked in place (like an editor's inline diff). */

  function splitLines(s) { if (s == null || s === '') return []; var a = String(s).split('\n'); if (a[a.length - 1] === '') a.pop(); return a; }
  /* Line diff (longest common subsequence after trimming the shared head and tail): fine for files of a few thousand lines. */
  function diffLines(a, b) {
    var n = a.length, m = b.length, pre = 0, suf = 0;
    while (pre < n && pre < m && a[pre] === b[pre]) pre++;
    while (suf < n - pre && suf < m - pre && a[n - 1 - suf] === b[m - 1 - suf]) suf++;
    var A = a.slice(pre, n - suf), B = b.slice(pre, m - suf), N = A.length, M = B.length, W = M + 1;
    var L = new Uint32Array((N + 1) * W), i, j;
    for (i = N - 1; i >= 0; i--) for (j = M - 1; j >= 0; j--) L[i * W + j] = A[i] === B[j] ? L[(i + 1) * W + j + 1] + 1 : Math.max(L[(i + 1) * W + j], L[i * W + j + 1]);
    var ops = [], k;
    for (k = 0; k < pre; k++) ops.push({ t: ' ', o: k, n: k, s: a[k] });
    var x = 0, y = 0;
    while (x < N || y < M) {
      if (x < N && y < M && A[x] === B[y]) { ops.push({ t: ' ', o: pre + x, n: pre + y, s: A[x] }); x++; y++; }
      else if (x < N && (y >= M || L[(x + 1) * W + y] >= L[x * W + y + 1])) { ops.push({ t: '-', o: pre + x, n: null, s: A[x] }); x++; }
      else { ops.push({ t: '+', o: null, n: pre + y, s: B[y] }); y++; }
    }
    for (k = suf; k > 0; k--) ops.push({ t: ' ', o: n - k, n: m - k, s: a[n - k] });
    /* in each run of changes, removed lines come before added ones; pair them up for word-level highlights */
    var out = [], r = 0;
    while (r < ops.length) {
      if (ops[r].t === ' ') { out.push(ops[r]); r++; continue; }
      var s0 = r; while (r < ops.length && ops[r].t !== ' ') r++;
      var run = ops.slice(s0, r), dels = run.filter(function (o) { return o.t === '-'; }), adds = run.filter(function (o) { return o.t === '+'; });
      for (var p = 0; p < Math.min(dels.length, adds.length); p++) wordPair(dels[p], adds[p]);
      var kind = dels.length && adds.length ? 'mod' : dels.length ? 'del' : 'add', all = dels.concat(adds);
      all[0].blk = kind; all[all.length - 1].blkEnd = true;
      out.push.apply(out, all);
    }
    return out;
  }
  /* Word-level change inside a removed/added pair: the span between their shared start and shared end. */
  function wordPair(d, a) {
    var x = d.s, y = a.s, p = 0, q = 0;
    while (p < x.length && p < y.length && x[p] === y[p]) p++;
    while (q < x.length - p && q < y.length - p && x[x.length - 1 - q] === y[y.length - 1 - q]) q++;
    var same = p + q, len = Math.max(x.length, y.length);
    if (!len || same < len * 0.3) return; /* too different: the whole line is the change */
    while (p > 0 && /\w/.test(x[p - 1] || '') && /\w/.test(x[p] || y[p] || '')) p--; /* widen to whole words */
    if (x.length - q > p) d.x = [p, x.length - q];
    if (y.length - q > p) a.x = [p, y.length - q];
  }

  /* A small syntax colouring for JS/TS: keywords, strings, numbers, comments, called functions. */
  var TK_RE = /(\/\/.*$|\/\*.*?\*\/)|("(?:[^"\\]|\\.)*"?|'(?:[^'\\]|\\.)*'?|`(?:[^`\\]|\\.)*`?)|(\b\d[\d_.]*\b|\b(?:true|false|null|undefined)\b)|(\b(?:const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|delete|typeof|instanceof|in|of|async|await|export|import|from|default|class|extends|implements|interface|type|enum|public|private|protected|readonly|static|try|catch|finally|throw|this|super|yield|as|void)\b)|([A-Za-z_$][\w$]*)(?=\s*\()/g;
  var TK_CLS = [null, 'c', 's', 'n', 'k', 'f'];
  function codeTokens(text, lang) {
    if (!lang) return [{ c: null, s: text }];
    var out = [], last = 0, m; TK_RE.lastIndex = 0;
    while ((m = TK_RE.exec(text))) {
      if (!m[0]) { TK_RE.lastIndex++; continue; }
      if (m.index > last) out.push({ c: null, s: text.slice(last, m.index) });
      for (var g = 1; g < 6; g++) if (m[g] != null) { out.push({ c: TK_CLS[g], s: m[0] }); break; }
      last = m.index + m[0].length;
    }
    if (last < text.length) out.push({ c: null, s: text.slice(last) });
    return out;
  }
  function codeNodes(text, lang, x) {
    var toks = codeTokens(text, lang), nodes = [], pos = 0;
    toks.forEach(function (t, i) {
      var a = pos, b = pos + t.s.length; pos = b;
      var cuts = [a]; if (x) { if (x[0] > a && x[0] < b) cuts.push(x[0]); if (x[1] > a && x[1] < b) cuts.push(x[1]); } cuts.push(b);
      for (var c = 0; c < cuts.length - 1; c++) {
        var s = cuts[c], e = cuts[c + 1], inX = x && s >= x[0] && e <= x[1];
        var cls = cx(t.c && 'ex-tk-' + t.c, inX && 'ex-dr-x', inX && s === x[0] && 'is-s', inX && e === x[1] && 'is-e');
        nodes.push(cls ? h('span', { key: i + '.' + c, className: cls }, text.slice(s, e)) : text.slice(s, e));
      }
    });
    return nodes.length ? nodes : ['​'];
  }
  function langOf(path) { return /\.(m?[jt]sx?|cjs)$/.test(path || '') ? 'js' : null; }
  var SCOPE_RE = /^\s*(export\s+)?(default\s+)?(async\s+)?(function\b|class\b|interface\b|type\s+\w+\s*=|(const|let)\s+\w+\s*=\s*(async\s*)?(\(|function))/;

  function prepFile(f) {
    var parts = (f.path || '').split('/'), name = parts.pop();
    var base = { path: f.path, name: name, dir: parts.join('/'), status: f.status || 'M', oldPath: f.oldPath, binary: !!f.binary, lang: langOf(f.path) };
    if (f.binary) return Object.assign(base, { ops: [], add: 0, del: 0, sig: 'bin' });
    if (f.old === undefined && f['new'] === undefined) return Object.assign(base, { pending: true, ops: [], add: f.add || 0, del: f.del || 0, sig: 'p' });
    var a = f.status === 'A' ? [] : splitLines(f.old), b = f.status === 'D' ? [] : splitLines(f['new']);
    var ops = diffLines(a, b), add = 0, del = 0;
    ops.forEach(function (o) { if (o.t === '+') add++; else if (o.t === '-') del++; });
    return Object.assign(base, { ops: ops, add: add, del: del, newLines: b, sig: add + ':' + del + ':' + (f['new'] || '').length + ':' + (f.old || '').length });
  }
  /* How tall a file will be before its lines arrive, so the scroll, the ruler and jumps hold still while it loads. */
  function estRows(f, ctx) { var ch = f.add + f.del, hunks = Math.max(1, Math.min(10, Math.ceil(ch / 14))); return { rows: Math.min(ch, 400) + hunks * ctx * 2, gaps: hunks }; }
  function hashOf(s) { var x = 7; for (var i = 0; i < s.length; i++) x = (x * 31 + s.charCodeAt(i)) | 0; return Math.abs(x); }

  /* Rows and gaps for the changes view: every change plus `ctx` lines around it; the rest are gaps you can open. */
  function diffSegments(ops, ctx, exp) {
    var n = ops.length, vis = new Uint8Array(n), i, j;
    for (i = 0; i < n; i++) if (ops[i].t !== ' ') for (j = Math.max(0, i - ctx); j <= Math.min(n - 1, i + ctx); j++) vis[j] = 1;
    var segs = []; i = 0;
    while (i < n) {
      var s = i, v = vis[i]; while (i < n && vis[i] === v) i++;
      if (v || i - s <= 2) { if (segs.length && segs[segs.length - 1].k === 'rows') segs[segs.length - 1].to = i; else segs.push({ k: 'rows', from: s, to: i }); continue; }
      var e = exp[s] || { d: [], u: [] }, dn = e.d.reduce(function (x, y) { return x + y; }, 0), up = e.u.reduce(function (x, y) { return x + y; }, 0);
      segs.push({ k: 'gap', id: s, from: s, to: i, d: e.d, u: e.u, left: Math.max(0, i - s - dn - up), first: s === 0, last: i === n });
    }
    return segs;
  }
  function hunkHead(f, ops, from, to) {
    var o0 = null, n0 = null, oc = 0, nc = 0;
    for (var i = from; i < to; i++) { var op = ops[i]; if (op.o != null) { if (o0 == null) o0 = op.o; oc++; } if (op.n != null) { if (n0 == null) n0 = op.n; nc++; } }
    var scope = '';
    var startN = n0 == null ? 0 : n0;
    for (var k = startN - 1; k >= 0 && f.newLines && k > startN - 400; k--) if (SCOPE_RE.test(f.newLines[k])) { scope = f.newLines[k].trim().replace(/\s*\{\s*$/, ''); break; }
    return { text: '@@ −' + ((o0 == null ? 0 : o0) + 1) + ',' + oc + ' +' + (startN + 1) + ',' + nc + ' @@', scope: scope };
  }

  /* Grows in on mount (an opened gap, a comment box). With `keepBelow`, the review pins what's under it, so that stays
     where it is on screen and the new lines grow upward. */
  /* A file's body before and after its lines arrive: in view, the skeleton eases to the real height while the lines fade
     in; out of view it simply changes (the review's anchoring keeps what you're reading still). */
  function DrSwap(props) {
    var ref = React.useRef(null), was = React.useRef(props.state), last = React.useRef(0), t = React.useRef(0);
    useLayout(function () {
      var el = ref.current; if (!el) return;
      var from = last.current, to = el.offsetHeight; last.current = to;
      if (was.current === props.state) return;
      was.current = props.state;
      var sc = el.closest('.ex-dr-scroll'); if (!sc || reducedMotion() || !from) return;
      var r = el.getBoundingClientRect(), b = sc.getBoundingClientRect();
      if (r.bottom <= b.top || r.top >= b.bottom) return;
      clearTimeout(t.current);
      el.style.height = from + 'px'; void el.offsetHeight; el.classList.add('is-arriving'); el.style.height = to + 'px';
      t.current = setTimeout(function () { el.classList.remove('is-arriving'); el.style.height = ''; }, 320);
    });
    React.useEffect(function () { return function () { clearTimeout(t.current); }; }, []);
    return h('div', { ref: ref, className: cx('ex-dr-swap', 'is-' + props.state) }, props.children);
  }
  function DrGrow(props) {
    var ref = React.useRef(null);
    useLayout(function () {
      var el = ref.current; if (!el || reducedMotion()) return;
      /* what you were looking at stays put: the hunk under it (opening context above), else what's just before it */
      var still = props.keepBelow ? el.nextElementSibling : el.previousElementSibling;
      if (props.pin && still) props.pin(still, 420);
      var full = el.offsetHeight, dur = Math.round(Math.min(320, 180 + full * 0.25));
      el.style.setProperty('--dr-grow', dur + 'ms'); el.style.height = '0px'; void el.offsetHeight;
      el.classList.add('is-growing'); el.style.height = full + 'px';
      var t = setTimeout(function () { el.classList.remove('is-growing'); el.style.height = ''; }, dur + 20);
      return function () { clearTimeout(t); };
    }, []);
    return h('div', { ref: ref, className: cx('ex-dr-grow', props.className) }, props.children);
  }

  /* A file's body opening and closing. Only what you can see moves: the part below the view is trimmed (or added) at once,
     so a long file folds over the same short distance as a short one, and the time follows that distance. Closing, the
     lines lift 8px and fade first, then the box closes and the header's corners round; opening is the reverse. */
  function DrFold(props) {
    var ref = React.useRef(null), was = React.useRef(null), t = React.useRef(0);
    useLayout(function () {
      var el = ref.current; if (!el) return;
      var open = !!props.open, first = was.current === null;
      if (!first && was.current === open) return;
      was.current = open; clearTimeout(t.current); el.classList.remove('is-closing', 'is-opening');
      if (first || reducedMotion()) { if (open) { el.removeAttribute('data-shut'); el.style.height = ''; } else { el.setAttribute('data-shut', ''); el.style.height = '0px'; } return; }
      var sc = el.closest('.ex-dr-scroll'), bottom = sc ? sc.getBoundingClientRect().bottom : window.innerHeight, top = el.getBoundingClientRect().top, dur;
      if (!open) {
        var vis = Math.max(0, Math.min(el.offsetHeight, bottom - top));
        el.style.height = vis + 'px'; void el.offsetHeight;
        dur = Math.round(Math.min(260, 150 + vis * 0.18));
        el.style.setProperty('--dr-fold', dur + 'ms'); el.classList.add('is-closing'); el.style.height = '0px';
        t.current = setTimeout(function () { el.classList.remove('is-closing'); el.setAttribute('data-shut', ''); }, dur);
      } else {
        el.removeAttribute('data-shut'); el.style.height = ''; var full = el.offsetHeight, target = Math.max(0, Math.min(full, bottom - top));
        el.style.height = '0px'; void el.offsetHeight;
        dur = Math.round(Math.min(340, 200 + target * 0.2));
        el.style.setProperty('--dr-fold', dur + 'ms'); el.classList.add('is-opening'); el.style.height = target + 'px';
        t.current = setTimeout(function () { el.classList.remove('is-opening'); el.style.height = ''; }, dur);
      }
    }, [!!props.open]);
    React.useEffect(function () { return function () { clearTimeout(t.current); }; }, []);
    return h('div', { ref: ref, className: 'ex-dr-foldbox', 'aria-hidden': props.open ? null : 'true', inert: props.open ? null : '' }, h('div', { className: 'ex-dr-fold-in' }, props.children));
  }

  function ViewedBox(props) {
    return h('button', { type: 'button', role: 'checkbox', 'aria-checked': String(!!props.on), className: cx('ex-dr-viewed', props.on && 'is-on'), title: (props.on ? 'Viewed' : 'Mark as viewed') + '  V', onClick: props.onClick },
      h('span', { className: 'ex-dr-box', 'aria-hidden': 'true' }, h(Icon, { name: 'check', size: 12 })), h('span', { className: 'ex-dr-viewed-l' }, 'Viewed'));
  }
  function ViewedRing(props) {
    var r = 6, c = 2 * Math.PI * r, p = props.total ? props.done / props.total : 0;
    return h('span', { className: cx('ex-dr-ring', p === 1 && 'is-all'), title: props.done + ' of ' + props.total + ' files viewed' },
      h('svg', { width: 16, height: 16, viewBox: '0 0 16 16', 'aria-hidden': 'true' },
        h('circle', { cx: 8, cy: 8, r: r, className: 'ex-dr-ring-bg' }),
        h('circle', { cx: 8, cy: 8, r: r, className: 'ex-dr-ring-fg', style: { strokeDasharray: c, strokeDashoffset: c * (1 - p) } })),
      h('span', { className: 'ex-dr-ring-n' }, h(Ticker, { value: props.done }), '/' + props.total));
  }

  function DiffReview(props) {
    var files = props.files || [], ctx = props.context == null ? 3 : props.context;
    var _ct = React.useState({}), content = _ct[0], setContent = _ct[1];
    var _ld = React.useState({}), loading = _ld[0], setLoading = _ld[1];
    var _er = React.useState({}), failed = _er[0], setFailed = _er[1];
    var prepped = React.useMemo(function () { return files.map(function (f) { var c = content[f.path]; var p = prepFile(c && c.rev === f.rev ? Object.assign({}, f, { old: c.old, 'new': c['new'] }) : f); if (f.rev != null) p.sig = 'r' + f.rev; return p; }); }, [files, content]);
    var root = React.useRef(null), scroll = React.useRef(null), stream = React.useRef(null), anchor = React.useRef(null), sigs = React.useRef({});
    function useS(v) { return React.useState(v); }
    var _m = useS(props.mode || 'changes'), mode = _m[0], setMode = _m[1];
    var _w = useS(props.wrap !== false), wrap = _w[0], setWrap = _w[1];
    var _v = useS(function () { var o = {}; files.forEach(function (f) { if (f.viewed && !f.changedSinceViewed) o[f.path] = true; }); return o; }), viewed = _v[0], setViewed = _v[1];
    var _c = useS(function () { var o = {}; files.forEach(function (f) { if (f.changedSinceViewed) o[f.path] = true; }); return o; }), changed = _c[0], setChanged = _c[1];
    var _o = useS(function () { var o = {}; files.forEach(function (f) { o[f.path] = !(f.viewed && !f.changedSinceViewed); }); return o; }), open = _o[0], setOpen = _o[1];
    var _l = useS({}), loaded = _l[0], setLoaded = _l[1];
    var _e = useS({}), exp = _e[0], setExp = _e[1];
    var _f = useS({}), fullOf = _f[0], setFullOf = _f[1];
    var _cur = useS(files[0] ? files[0].path : null), cur = _cur[0], setCur = _cur[1];
    var _j = useS(false), jump = _j[0], setJump = _j[1];
    var _mn = useS(null), menu = _mn[0], setMenu = _mn[1];
    var _d = useS(null), draft = _d[0], setDraft = _d[1];
    var _s = useS([]), sent = _s[0], setSent = _s[1];
    var _wd = useS(false), autoWide = _wd[0], setAutoWide = _wd[1];
    var _mk = useS({ marks: [], ticks: [], thumb: null }), ruler = _mk[0], setRuler = _mk[1];
    var wide = props.wide == null ? autoWide : !!props.wide, showList = true;
    var prevWide = React.useRef(wide); if (prevWide.current !== wide) { prevWide.current = wide; if (!anchor.current) anchor.current = grabAnchor(); }
    var largeAt = props.largeAt || 400;
    var jp = usePresence(jump, 140), mp = usePresence(!!menu, 140);
    var menuFile = React.useRef(null); if (menu) menuFile.current = menu;
    /* a click anywhere else closes the file list and the file menu */
    React.useEffect(function () {
      if (!jump && !menu) return;
      function away(e) { var el = root.current; if (!el) return; if (!e.target.closest || !e.target.closest('.ex-agent-wrap')) { setJump(false); setMenu(null); } }
      document.addEventListener('mousedown', away);
      return function () { document.removeEventListener('mousedown', away); };
    }, [jump, menu]);

    /* a file the agent changes again after you viewed it opens back up, marked */
    React.useEffect(function () {
      var was = sigs.current, now = {}, again = [];
      prepped.forEach(function (f) { now[f.path] = f.sig === 'p' ? was[f.path] : f.sig; if (was[f.path] && f.sig !== 'p' && was[f.path] !== f.sig && viewed[f.path]) again.push(f.path); });
      sigs.current = now;
      if (!again.length) return;
      setViewed(function (v) { var o = Object.assign({}, v); again.forEach(function (p) { delete o[p]; }); return o; });
      setChanged(function (v) { var o = Object.assign({}, v); again.forEach(function (p) { o[p] = true; }); return o; });
      setOpen(function (v) { var o = Object.assign({}, v); again.forEach(function (p) { o[p] = true; }); return o; });
    }, [prepped]);

    /* width decides the layout when `wide` isn't given */
    useLayout(function () {
      var el = root.current; if (!el || props.wide != null || typeof ResizeObserver === 'undefined') return;
      var ro = new ResizeObserver(function () { setAutoWide(el.offsetWidth >= 720); }); ro.observe(el);
      return function () { ro.disconnect(); };
    }, [props.wide]);

    /* Anchoring: whatever changes above what you're reading (files loading, folding, context opening), it stays where it is
       on screen. A pin (a jump to a file, context opened above a hunk) holds a chosen element instead, for a while. */
    var keep = React.useRef(null), pinUntil = React.useRef(0);
    function record() {
      if (Date.now() < pinUntil.current) return;
      var sc = scroll.current; if (!sc) return;
      var top = sc.getBoundingClientRect().top + 40, secs = sc.querySelectorAll('.ex-dr-file'), el = null;
      for (var i = 0; i < secs.length && !el; i++) {
        var r = secs[i].getBoundingClientRect(); if (r.bottom <= top) continue;
        var rows = secs[i].querySelectorAll('.ex-dr-ln, .ex-dr-skrow, .ex-dr-exp, .ex-dr-msg');
        for (var j = 0; j < rows.length; j++) { var rr = rows[j].getBoundingClientRect(); if (rr.bottom > top && rr.height) { el = rows[j]; break; } }
        if (!el) el = secs[i];
      }
      keep.current = el ? { el: el, top: el.getBoundingClientRect().top } : null;
    }
    function pin(el, ms) { if (!el) return; keep.current = { el: el, top: el.getBoundingClientRect().top }; pinUntil.current = Date.now() + (ms || 400); }
    function hold() {
      var k = keep.current, sc = scroll.current; if (!k || !sc || !k.el.isConnected) return;
      var d = k.el.getBoundingClientRect().top - k.top; if (Math.abs(d) > 0.5) sc.scrollTop += d;
    }
    function unpin() { pinUntil.current = 0; record(); }

    /* lines load as their file comes near: the visible ones first, then two screens ahead, three at a time */
    var queue = React.useRef([]), active = React.useRef(0), state = React.useRef({}); state.current = { content: content, loading: loading, failed: failed, open: open };
    function need(path, first) {
      var f = files.find(function (x) { return x.path === path; }), st = state.current;
      if (!f || !props.loadFile || f.binary || f.old !== undefined || f['new'] !== undefined || (st.content[path] && st.content[path].rev === f.rev) || st.loading[path] || st.failed[path] || !st.open[path]) return;
      if (queue.current.indexOf(path) < 0) { if (first) queue.current.unshift(path); else queue.current.push(path); }
      pump();
    }
    function pump() {
      var sc = scroll.current;
      while (active.current < 3 && queue.current.length) {
        if (sc) { var mid = sc.getBoundingClientRect().top + sc.clientHeight / 2; queue.current.sort(function (a, b) { var A = secOf(a), B = secOf(b); return (A ? Math.abs(A.getBoundingClientRect().top - mid) : 1e9) - (B ? Math.abs(B.getBoundingClientRect().top - mid) : 1e9); }); }
        var path = queue.current.shift(), rev = (files.find(function (x) { return x.path === path; }) || {}).rev; active.current++;
        setLoading(function (l) { var o = Object.assign({}, l); o[path] = true; return o; });
        (function (path, rev) {
          Promise.resolve().then(function () { return props.loadFile(path); }).then(function (res) {
            setContent(function (c) { var o = Object.assign({}, c); o[path] = { rev: rev, old: res && res.old != null ? res.old : '', 'new': res && res['new'] != null ? res['new'] : '' }; return o; });
          }, function (err) { setFailed(function (x) { var o = Object.assign({}, x); o[path] = (err && err.message) || 'Couldn’t load it'; return o; }); })
          .then(function () { active.current--; setLoading(function (l) { var o = Object.assign({}, l); delete o[path]; return o; }); pump(); });
        })(path, rev);
      }
    }
    function retry(path) { setFailed(function (x) { var o = Object.assign({}, x); delete o[path]; return o; }); setTimeout(function () { need(path, true); }, 0); }
    useLayout(function () {
      var sc = scroll.current; if (!sc || !props.loadFile || typeof IntersectionObserver === 'undefined') return;
      var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) need(e.target.getAttribute('data-path')); }); }, { root: sc, rootMargin: '1400px 0px' });
      [].forEach.call(sc.querySelectorAll('.ex-dr-file[data-pending]'), function (el) { io.observe(el); });
      return function () { io.disconnect(); };
    }, [prepped, open]);

    /* which file you're in, and the overview ruler */
    var raf = React.useRef(0);
    var marksDirty = React.useRef(true);
    function measure() {
      raf.current = 0;
      var sc = scroll.current; if (!sc) return;
      var full = marksDirty.current; marksDirty.current = false;
      var top = sc.getBoundingClientRect().top, secs = sc.querySelectorAll('.ex-dr-file'), c = secs.length ? secs[0].getAttribute('data-path') : null;
      for (var i = 0; i < secs.length; i++) { if (secs[i].getBoundingClientRect().top - top <= 2) c = secs[i].getAttribute('data-path'); else break; }
      setCur(function (p) { return p === c ? p : c; });
      var H = sc.scrollHeight, vh = sc.clientHeight; if (!H || !vh) return;
      var thumb0 = H > vh + 1 ? { top: sc.scrollTop / H * vh, h: Math.max(12, vh * vh / H) } : null;
      if (!full) { setRuler(function (r) { return Object.assign({}, r, { thumb: thumb0 }); }); return; }
      var marks = [], starts = sc.querySelectorAll('[data-blk]');
      for (var k = 0; k < starts.length; k++) {
        var s = starts[k], e = s; while (e && !e.hasAttribute('data-blk-end')) e = e.nextElementSibling;
        if (!s.offsetHeight) continue;
        var t0 = s.getBoundingClientRect().top - top + sc.scrollTop, t1 = (e || s).getBoundingClientRect().bottom - top + sc.scrollTop;
        marks.push({ k: s.getAttribute('data-blk'), top: t0 / H * vh, h: Math.max(2, (t1 - t0) / H * vh) });
      }
      var ticks = []; for (var q = 1; q < secs.length; q++) ticks.push((secs[q].getBoundingClientRect().top - top + sc.scrollTop) / H * vh);
      setRuler({ marks: marks, ticks: ticks, thumb: thumb0 });
    }
    function soon() { if (!raf.current) raf.current = requestAnimationFrame(measure); }
    function remeasure() { marksDirty.current = true; soon(); }
    useLayout(function () {
      var sc = scroll.current; if (!sc) return;
      measure(); record();
      function onScroll() { record(); soon(); }
      function onInput() { if (pinUntil.current) unpin(); }
      sc.addEventListener('scroll', onScroll, { passive: true });
      sc.addEventListener('wheel', onInput, { passive: true }); sc.addEventListener('touchstart', onInput, { passive: true });
      var ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(function () { hold(); record(); remeasure(); }) : null; if (ro && stream.current) { ro.observe(stream.current); ro.observe(sc); }
      return function () { sc.removeEventListener('scroll', onScroll); sc.removeEventListener('wheel', onInput); sc.removeEventListener('touchstart', onInput); if (ro) ro.disconnect(); if (raf.current) cancelAnimationFrame(raf.current); };
    }, []);

    /* switching Changes ↔ Full files keeps the line you were looking at where it was */
    function grabAnchor() {
      var sc = scroll.current; if (!sc) return null;
      /* the change you're reading if one is in the upper part of the view, else the first line in view */
      var box = sc.getBoundingClientRect(), top = box.top + 40, rows = sc.querySelectorAll('.ex-dr-ln'), first = null, pick = null;
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i].getBoundingClientRect(); if (r.bottom <= top || !rows[i].offsetHeight) continue;
        if (r.top > box.top + box.height * 0.6) break;
        if (!first) first = rows[i];
        if (/is-(add|del)/.test(rows[i].className)) { pick = rows[i]; break; }
      }
      var el = pick || first; if (!el) return null;
      var sec = el.closest('.ex-dr-file');
      return { path: sec && sec.getAttribute('data-path'), n: el.getAttribute('data-n'), o: el.getAttribute('data-o'), dy: el.getBoundingClientRect().top - box.top };
    }
    useLayout(function () {
      var a = anchor.current; anchor.current = null;
      var sc = scroll.current; if (!a || !sc) return;
      var sec = null; [].forEach.call(sc.querySelectorAll('.ex-dr-file'), function (s) { if (s.getAttribute('data-path') === a.path) sec = s; });
      if (!sec) return;
      var row = (a.n && sec.querySelector('.ex-dr-ln[data-n="' + a.n + '"]')) || (a.o && sec.querySelector('.ex-dr-ln[data-o="' + a.o + '"]'));
      if (!row && a.n) { var all = sec.querySelectorAll('.ex-dr-ln[data-n]'); for (var i = 0; i < all.length; i++) if (+all[i].getAttribute('data-n') >= +a.n) { row = all[i]; break; } }
      var el = row || sec;
      sc.scrollTop += el.getBoundingClientRect().top - sc.getBoundingClientRect().top - (row ? a.dy : 0);
      pin(el, 420);
      if (stream.current && !reducedMotion()) { stream.current.classList.remove('is-swapping'); void stream.current.offsetWidth; stream.current.classList.add('is-swapping'); }
    });
    function changeMode(m) { if (m === mode) return; anchor.current = grabAnchor(); setMode(m); setFullOf({}); if (props.onMode) props.onMode(m); }
    function toggleWrap() { anchor.current = grabAnchor(); setWrap(!wrap); }

    function secOf(path) { var sc = scroll.current, out = null; if (sc) [].forEach.call(sc.querySelectorAll('.ex-dr-file'), function (s) { if (s.getAttribute('data-path') === path) out = s; }); return out; }
    function goTo(path) {
      var sc = scroll.current, sec = secOf(path); setJump(false); if (!sc || !sec) return;
      setCur(path); need(path, true);
      var d = sec.getBoundingClientRect().top - sc.getBoundingClientRect().top;
      if (Math.abs(d) > sc.clientHeight * 1.5 || reducedMotion()) {
        /* far: go at once, hold the file at the top while what's above it loads, and let it fade in */
        sc.scrollTop += d; pin(sec, 2500);
        if (!reducedMotion()) { sec.classList.remove('is-landing'); void sec.offsetWidth; sec.classList.add('is-landing'); }
      } else sc.scrollTo({ top: sc.scrollTop + d, behavior: 'smooth' });
    }
    if (props.controller) props.controller.current = { goTo: goTo, step: function (d) { step(d); } };
    function step(d) { var i = prepped.findIndex(function (f) { return f.path === cur; }); var n = prepped[Math.max(0, Math.min(prepped.length - 1, i + d))]; if (n) goTo(n.path); }
    function nextChange(d) {
      var sc = scroll.current; if (!sc) return;
      var top = sc.getBoundingClientRect().top, starts = [].filter.call(sc.querySelectorAll('[data-blk]'), function (s) { return s.offsetHeight; });
      var ys = starts.map(function (s) { return s.getBoundingClientRect().top - top; }), pick = null;
      for (var i = 0; i < ys.length; i++) { if (d > 0 && ys[i] > 60) { pick = ys[i]; break; } if (d < 0 && ys[i] < 40) pick = ys[i]; }
      if (pick != null) sc.scrollTo({ top: sc.scrollTop + pick - 48, behavior: reducedMotion() ? 'auto' : 'smooth' });
    }

    function setViewedOf(path, on) {
      setViewed(function (v) { var o = Object.assign({}, v); if (on) o[path] = true; else delete o[path]; return o; });
      if (on) setChanged(function (v) { if (!v[path]) return v; var o = Object.assign({}, v); delete o[path]; return o; });
      if (props.onViewed) props.onViewed(path, on);
      if (on) closeFile(path); else openFile(path);
    }
    /* the header you clicked stays where it is; what's under it moves */
    function pinHead(path) { var sec = secOf(path); if (sec) pin(sec.querySelector('.ex-dr-fh') || sec, 480); }
    function openFile(path) { pinHead(path); setOpen(function (o) { var x = Object.assign({}, o); x[path] = true; state.current.open = x; return x; }); need(path, true); }
    function closeFile(path) {
      var sc = scroll.current, sec = secOf(path), shut = function () { setOpen(function (o) { var x = Object.assign({}, o); x[path] = false; return x; }); };
      if (sc && sec && sec.getBoundingClientRect().top - sc.getBoundingClientRect().top < -1 && !reducedMotion()) {
        /* its header is stuck at the top while you're inside the file: the lines fade, the scroll moves to the file's start
           (the header looks the same there), then the body folds into the header and the next file rises under it */
        sec.classList.add('is-leaving');
        setTimeout(function () { sec.classList.remove('is-leaving'); sc.scrollTop += sec.getBoundingClientRect().top - sc.getBoundingClientRect().top; pin(sec, 400); shut(); }, 110);
        return;
      }
      pinHead(path); shut();
    }
    function expand(path, gap, dir, n) {
      setExp(function (e) {
        var fe = Object.assign({}, e[path] || {}), g = fe[gap] ? { d: fe[gap].d.slice(), u: fe[gap].u.slice() } : { d: [], u: [] };
        g[dir].push(n); fe[gap] = g; var o = Object.assign({}, e); o[path] = fe; return o;
      });
    }

    function onKey(e) {
      var t = e.target; if (t && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT')) return;
      if (e.altKey && e.key === 'ArrowDown') { e.preventDefault(); step(1); }
      else if (e.altKey && e.key === 'ArrowUp') { e.preventDefault(); step(-1); }
      else if (e.key === 'F7') { e.preventDefault(); nextChange(e.shiftKey ? -1 : 1); }
      else if ((e.key === 'v' || e.key === 'V') && !e.metaKey && !e.ctrlKey && !e.altKey && cur) { e.preventDefault(); setViewedOf(cur, !viewed[cur]); }
      else if (e.key === 'Escape') { if (jump || menu || draft) { setJump(false); setMenu(null); } else if (props.onExit) props.onExit(); }
    }

    var total = prepped.length, done = prepped.filter(function (f) { return viewed[f.path]; }).length;
    var sumAdd = prepped.reduce(function (s, f) { return s + f.add; }, 0), sumDel = prepped.reduce(function (s, f) { return s + f.del; }, 0);
    var curIdx = Math.max(0, prepped.findIndex(function (f) { return f.path === cur; })), curF = prepped[curIdx];
    var listItems = prepped.map(function (f) { return { path: f.path, status: f.status, add: f.add, del: f.del, viewed: !!viewed[f.path], changed: !!changed[f.path], current: f.path === cur }; });


    function lineRow(f, op, i) {
      var kind = op.t === '+' ? 'add' : op.t === '-' ? 'del' : 'ctx';
      var key = f.path + ':' + (op.n != null ? 'n' + op.n : 'o' + op.o), line = op.n != null ? op.n + 1 : op.o + 1, side = op.n != null ? 'new' : 'old';
      /* both gutters are always there; the old-number one opens and closes with the layout, in the same motion */
      var nums = [h('span', { key: 'o', className: 'ex-dr-no is-o' }, op.o != null ? op.o + 1 : ''),
        h('span', { key: 'n', className: cx('ex-dr-no', 'is-n', !wide && op.t === '-' && 'is-old') }, wide ? (op.n != null ? op.n + 1 : '') : line)];
      var rows = [h('div', { key: 'l' + i, className: cx('ex-dr-ln', 'is-' + kind), 'data-n': op.n != null ? op.n + 1 : null, 'data-o': op.o != null ? op.o + 1 : null, 'data-blk': op.blk || null, 'data-blk-end': op.blkEnd ? '' : null },
        h('span', { className: 'ex-dr-gut' }, nums),
        h('span', { className: 'ex-dr-sign', 'aria-label': kind === 'add' ? 'added' : kind === 'del' ? 'removed' : null }, kind === 'add' ? '+' : kind === 'del' ? '−' : ' ',
          props.onComment !== false ? h('button', { type: 'button', className: 'ex-dr-say', 'aria-label': 'Ask the agent about line ' + line, title: 'Ask the agent about this line', onClick: function () { setDraft({ key: key, path: f.path, line: line, side: side, text: '' }); } }, h(Icon, { name: 'plus', size: 12 })) : null),
        h('span', { className: 'ex-dr-code' }, codeNodes(op.s, f.lang, op.x)))];
      sent.forEach(function (c, ci) { if (c.key === key) rows.push(h(DrGrow, { key: 'c' + ci, className: 'ex-dr-note', pin: pin }, h('div', { className: 'ex-dr-note-in' }, h(Icon, { name: 'chat', size: 13 }), h('span', { className: 'ex-dr-note-t' }, c.text), h('span', { className: 'ex-muted' }, 'Sent to the session')))); });
      if (draft && draft.key === key) rows.push(h(DrGrow, { key: 'd', className: 'ex-dr-ask', pin: pin }, h(DraftBox, { draft: draft, onCancel: function () { setDraft(null); }, onSend: function (text) {
        setSent(sent.concat([{ key: key, text: text }])); setDraft(null);
        if (typeof props.onComment === 'function') props.onComment({ path: f.path, line: line, side: side, text: text });
      } })));
      return rows;
    }
    function gapRow(f, g, segs, si) {
      var next = segs[si + 1], left = g.left, head = next ? hunkHead(f, f.ops, next.from, next.to) : null;
      var btn = function (dir, icon, label, n) { return h('button', { key: dir + icon, type: 'button', className: 'ex-dr-exp-b', 'aria-label': label, title: label, onClick: function () { expand(f.path, g.id, dir, n); } }, h(Icon, { name: icon, size: 14 })); };
      var btns = g.last ? [btn('d', 'expand-down', 'Show ' + Math.min(20, left) + ' more lines', Math.min(20, left))]
        : g.first ? [btn('u', 'expand-up', 'Show ' + Math.min(20, left) + ' lines above', Math.min(20, left))]
        : left <= 20 ? [btn('u', 'unfold', 'Show the ' + left + ' hidden lines', left)]
        : [btn('u', 'expand-up', 'Show 20 lines above', 20), btn('d', 'expand-down', 'Show 20 lines below', 20)];
      return h(Fold, { key: 'g' + g.id, open: left > 0, className: 'ex-dr-expf' },
        h('div', { className: 'ex-dr-exp' }, h('span', { className: 'ex-dr-exp-bs' }, btns),
          head && !g.last ? h('span', { className: 'ex-dr-exp-t' }, h('span', { className: 'ex-dr-exp-h' }, head.text), head.scope ? h('span', { className: 'ex-dr-exp-s' }, head.scope) : null)
            : h('span', { className: 'ex-dr-exp-t ex-muted' }, left + (left === 1 ? ' more line' : ' more lines'))));
    }
    function skeleton(f) {
      var e = estRows(f, ctx), rows = [], seed = hashOf(f.path), n = Math.min(e.rows, 60), perGap = Math.max(1, Math.round(n / e.gaps));
      for (var i = 0; i < n; i++) {
        if (i && i % perGap === 0) rows.push(h('div', { key: 'g' + i, className: 'ex-dr-skrow is-gap' }));
        var w = 18 + ((seed >> (i % 13)) + i * 37) % 62, ind = ((seed >> (i % 7)) + i) % 4;
        rows.push(h('div', { key: i, className: 'ex-dr-skrow' }, h('span', { className: 'ex-dr-skno' }), h('span', { className: 'ex-skel', style: { width: w + '%', marginLeft: ind * 2 + 'ch' } })));
      }
      return h('div', { className: 'ex-dr-body is-pending', 'aria-busy': 'true', 'aria-label': 'Loading the changes of ' + f.name, style: { height: e.rows * 20 + e.gaps * 28 } }, rows);
    }
    function fileBody(f) {
      if (f.binary) return h('div', { className: 'ex-dr-msg' }, 'Binary file, not shown.');
      if (failed[f.path]) return h('div', { className: 'ex-dr-msg' }, h('span', null, 'Couldn’t load these changes.'), h(Button, { size: 'sm', icon: 'refresh', onClick: function () { retry(f.path); } }, 'Try again'));
      if (f.pending) return skeleton(f);
      var big = f.add + f.del > largeAt;
      if ((f.status === 'D' || big) && !loaded[f.path]) return h('div', { className: 'ex-dr-msg' },
        h('span', null, f.status === 'D' ? 'This file was deleted · ' + f.del + ' lines' : 'Large change · ' + (f.add + f.del).toLocaleString() + ' lines'),
        h(Button, { size: 'sm', onClick: function () { var o = Object.assign({}, loaded); o[f.path] = true; setLoaded(o); } }, f.status === 'D' ? 'Show' : 'Load the diff'));
      var full = mode === 'full' || fullOf[f.path] || f.status === 'A' || f.status === 'D';
      var out = [];
      if (full) f.ops.forEach(function (op, i) { out.push.apply(out, lineRow(f, op, i)); });
      else {
        var segs = diffSegments(f.ops, ctx, exp[f.path] || {});
        segs.forEach(function (sg, si) {
          if (sg.k === 'rows') { for (var i = sg.from; i < sg.to; i++) out.push.apply(out, lineRow(f, f.ops[i], i)); return; }
          var at = sg.from;
          sg.d.forEach(function (n, k) { var rows = []; for (var i = at; i < at + n && i < sg.to; i++) rows.push.apply(rows, lineRow(f, f.ops[i], i)); at += n; out.push(h(DrGrow, { key: 'gd' + sg.id + '.' + k, pin: pin }, rows)); });
          out.push(gapRow(f, sg, segs, si));
          /* "above" steps stack upward from the hunk below: the latest sits highest. While one grows, the hunk under it stays put. */
          var end = sg.to, ups = [];
          sg.u.forEach(function (n, k) { var s0 = Math.max(at, end - n), rows = []; for (var i = s0; i < end; i++) rows.push.apply(rows, lineRow(f, f.ops[i], i)); end = s0; ups.push(h(DrGrow, { key: 'gu' + sg.id + '.' + k, keepBelow: true, pin: pin }, rows)); });
          out.push.apply(out, ups.reverse());
        });
      }
      return h('div', { className: 'ex-dr-body' }, h('div', { className: 'ex-dr-lines' }, out));
    }
    function fileHead(f) {
      var isOpen = !!open[f.path], v = !!viewed[f.path], st = { M: 'Modified', A: 'Added', D: 'Deleted', R: 'Renamed' }[f.status];
      return h('div', { className: 'ex-dr-fh' },
        h('button', { type: 'button', className: 'ex-dr-fold', 'aria-expanded': String(isOpen), 'aria-label': (isOpen ? 'Collapse ' : 'Expand ') + f.name, onClick: function () { if (isOpen) closeFile(f.path); else openFile(f.path); } },
          h(Icon, { name: 'chevron-down', size: 14, className: cx('ex-chev', !isOpen && 'is-closed') }),
          h('span', { className: 'ex-change-st st-' + f.status, title: st }, f.status),
          h('span', { className: 'ex-dr-path' }, h('bdi', null, h('b', null, f.name), f.status === 'R' && f.oldPath ? h('span', null, '  from ' + f.oldPath) : f.dir ? h('span', null, '  ' + f.dir) : null)),
          f.binary ? null : h(Diff, { add: f.add, del: f.del }), loading[f.path] ? h('span', { className: 'ex-dr-loading', 'aria-label': 'Loading' }, h(StatusGlyph, { status: 'running', size: 12 })) : null),
        changed[f.path] ? h('span', { className: 'ex-dr-again', title: 'The agent changed this file after you marked it viewed' }, wide ? 'Changed since viewed' : 'Changed') : null,
        h(ViewedBox, { on: v, onClick: function () { setViewedOf(f.path, !v); } }),
        h('span', { className: 'ex-agent-wrap' }, h(IconButton, { icon: 'more', label: 'More for ' + f.name, size: 'sm', 'aria-expanded': String(menu === f.path), onClick: function () { setMenu(menu === f.path ? null : f.path); } }),
          mp.m && menuFile.current === f.path ? h('div', { className: cx('ex-menu', 'ex-dr-menu', mp.l && 'is-leaving'), role: 'menu' },
            mode !== 'full' && f.status === 'M' ? h('div', { className: 'ex-menu-item', role: 'menuitem', onClick: function () { anchor.current = grabAnchor(); var o = Object.assign({}, fullOf); o[f.path] = !o[f.path]; setFullOf(o); setMenu(null); } }, h(Icon, { name: 'file', size: 14 }), fullOf[f.path] ? 'Show changes only' : 'Show the full file') : null,
            h('div', { className: 'ex-menu-item', role: 'menuitem', onClick: function () { try { navigator.clipboard.writeText(f.path); } catch (e) {} setMenu(null); } }, h(Icon, { name: 'copy', size: 14 }), 'Copy path'),
            h('div', { className: 'ex-menu-item', role: 'menuitem', onClick: function () { setMenu(null); if (props.onOpenFile) props.onOpenFile(f.path); } }, h(Icon, { name: 'code', size: 14 }), 'Open in Code')) : null));
    }

    return h('div', { ref: root, className: cx('ex-dr', wide && 'is-wide', wide && showList && 'has-list', !wrap && 'is-nowrap', props.className), style: props.style, tabIndex: -1, onKeyDown: onKey, 'aria-label': 'Changes' },
      h('div', { className: 'ex-dr-bar' },
        h('div', { className: 'ex-dr-bar-tree', 'aria-hidden': wide && showList ? null : 'true' }, h('b', null, total + (total === 1 ? ' file' : ' files')), h(Diff, { add: sumAdd, del: sumDel })),
        h('div', { className: 'ex-dr-bar-main' },
          h('div', { className: 'ex-dr-jumpw ex-agent-wrap', 'aria-hidden': wide ? 'true' : null },
            h('button', { type: 'button', className: 'ex-dr-jump', 'aria-haspopup': 'listbox', 'aria-expanded': String(jump), title: 'Go to a file', onClick: function () { setJump(!jump); } },
              h(EaseSwap, { k: curF ? curF.path : 'none', className: 'ex-dr-jump-name' }, h('b', null, curF ? curF.name : 'No changes')),
              h('span', { className: 'ex-dr-jump-n' }, total ? h(F, null, h(Ticker, { value: curIdx + 1 }), ' of ' + total) : null),
              h(Icon, { name: 'chevron-down', size: 13 })),
            jp.m ? h('div', { className: cx('ex-menu', 'ex-dr-jumpmenu', jp.l && 'is-leaving'), role: 'listbox', 'aria-label': 'Changed files' },
              h('div', { className: 'ex-dr-jumphead' }, h('span', null, total + ' files'), h(Diff, { add: sumAdd, del: sumDel }), h('span', { style: { flex: 1 } }), h('span', { className: 'ex-muted' }, done + ' of ' + total + ' viewed')),
              h(ChangeList, { items: listItems, grouped: true, onSelect: goTo })) : null),
          h(IconButton, { icon: 'arrow-up', size: 'sm', label: 'Previous file  ⌥↑', disabled: curIdx <= 0, onClick: function () { step(-1); } }),
          h(IconButton, { icon: 'arrow-down', size: 'sm', label: 'Next file  ⌥↓', disabled: curIdx >= total - 1, onClick: function () { step(1); } }),
          h('span', { style: { flex: 1, minWidth: 4 } }),
          h(ViewedRing, { done: done, total: total }),
          h(Segmented, { size: 'sm', label: 'Show', value: mode, onChange: changeMode, options: [{ id: 'changes', label: 'Changes', title: 'Each file’s changes with a few lines around them' }, { id: 'full', label: wide ? 'Full files' : 'Full', title: 'Each file whole, with its changes marked in place' }] }),
          h(IconButton, { icon: 'wrap', size: 'sm', label: wrap ? 'Don’t wrap lines' : 'Wrap long lines', active: wrap, onClick: toggleWrap }),
          props.toolbarEnd || null)),
      h('div', { className: 'ex-dr-main' },
        h('aside', { className: 'ex-dr-tree', 'aria-label': 'Changed files', 'aria-hidden': wide && showList ? null : 'true', inert: wide && showList ? null : '' },
          h(ChangeList, { items: listItems, grouped: true, onSelect: goTo }),
          h('div', { className: 'ex-dr-tree-foot ex-muted' }, done + ' of ' + total + ' viewed')),
        h('div', { className: 'ex-dr-view' },
          h('div', { ref: scroll, className: 'ex-dr-scroll' },
            h('div', { ref: stream, className: 'ex-dr-stream' },
              total ? prepped.map(function (f) {
                var st = failed[f.path] ? 'failed' : f.pending ? 'pending' : 'ready';
                return h('section', { key: f.path, className: cx('ex-dr-file', viewed[f.path] && 'is-viewed', changed[f.path] && 'is-again'), 'data-path': f.path, 'data-pending': f.pending ? '' : null, 'aria-label': f.path },
                  fileHead(f), h(DrFold, { open: !!open[f.path] }, h(DrSwap, { state: st }, fileBody(f))));
              }) : h('div', { className: 'ex-dr-empty ex-muted' }, 'No changes yet.'))),
          h('div', { className: 'ex-dr-ruler', 'aria-hidden': 'true', onMouseDown: function (e) {
            var sc = scroll.current; if (!sc) return; var r = e.currentTarget.getBoundingClientRect();
            sc.scrollTo({ top: (e.clientY - r.top) / r.height * sc.scrollHeight - sc.clientHeight / 2, behavior: reducedMotion() ? 'auto' : 'smooth' });
          } },
            ruler.ticks.map(function (t, i) { return h('span', { key: 't' + i, className: 'ex-dr-tick', style: { top: t } }); }),
            ruler.marks.map(function (m, i) { return h('span', { key: i, className: 'ex-dr-mark is-' + m.k, style: { top: m.top, height: m.h } }); }),
            ruler.thumb ? h('span', { className: 'ex-dr-thumb', style: { transform: 'translateY(' + ruler.thumb.top + 'px)', height: ruler.thumb.h } }) : null))));
  }
  /* The Changes panel takes over the chat for a while (the expand icon in the panel header): the panel eases wide over
     the chat's place while the chat fades, laid out at its own width so nothing in it reflows; back is the reverse.
     Put the returned ref on the main area; the shell (.ex-shell) gets is-takeover. */
  function usePanelTakeover(on) {
    var ref = React.useRef(null), was = React.useRef(null), w = React.useRef(0), t = React.useRef(0);
    useLayout(function () {
      var m = ref.current; if (!m) return; var sh = m.closest('.ex-shell');
      var first = was.current === null; was.current = !!on;
      if (on) m.setAttribute('inert', ''); else m.removeAttribute('inert');
      if (!first) {
        clearTimeout(t.current);
        if (on) w.current = m.offsetWidth;
        m.style.setProperty('--freeze-w', (w.current || m.offsetWidth) + 'px'); m.classList.add('is-frozen');
        if (!on) t.current = setTimeout(function () { m.classList.remove('is-frozen'); }, 340);
      }
      if (sh) sh.classList.toggle('is-takeover', !!on);
    }, [!!on]);
    React.useEffect(function () { return function () { clearTimeout(t.current); }; }, []);
    return ref;
  }
  function DraftBox(props) {
    var _t = React.useState(props.draft.text || ''), text = _t[0], setText = _t[1], ta = React.useRef(null);
    React.useEffect(function () { if (ta.current) ta.current.focus(); }, []);
    function send() { if (text.trim()) props.onSend(text.trim()); }
    return h('div', { className: 'ex-dr-ask-in' },
      h('textarea', { ref: ta, rows: 2, className: 'ex-dr-ask-ta', value: text, placeholder: 'Ask the agent about line ' + props.draft.line + '…', 'aria-label': 'Message about line ' + props.draft.line,
        onChange: function (e) { setText(e.target.value); },
        onKeyDown: function (e) { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); send(); } else if (e.key === 'Escape') { e.preventDefault(); props.onCancel(); } } }),
      h('div', { className: 'ex-dr-ask-bar' }, h('span', { className: 'ex-muted' }, 'Goes to the chat with line ' + props.draft.line + ' attached'), h('span', { style: { flex: 1 } }),
        h(Button, { size: 'sm', onClick: props.onCancel }, 'Cancel'), h(Button, { size: 'sm', variant: 'primary', disabled: !text.trim(), kbd: '⌘↵', onClick: send }, 'Send')));
  }

  /* ════ Rich replies: the agent's Markdown, and the files it embeds ════
     `Markdown` renders what the agent wrote. An image line, ![caption](path), embeds the file by its kind (a picture, a
     recording, an HTML page); a link, [text](path), stays a link (files in the task open in Code, web links in the browser). */
  var MD_LANG = { ts: 'js', tsx: 'js', js: 'js', jsx: 'js', mjs: 'js', cjs: 'js', json: 'js', javascript: 'js', typescript: 'js' };
  var MD_EMBED = /^!\[([^\]]*)\]\(([^)\s]+)\)\s*$/;
  function mdInline(s, k, ctx) {
    var out = [], re = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\*[^*\s][^*]*\*|_[^_\s][^_]*_)|(~~[^~]+~~)|(\[[^\]]+\]\([^)\s]+\))/g, last = 0, m, i = 0;
    while ((m = re.exec(s))) {
      if (m.index > last) out.push(s.slice(last, m.index));
      var t = m[0], key = k + '.' + i++;
      if (m[1]) out.push(h('code', { key: key }, t.slice(1, -1)));
      else if (m[2]) out.push(h('strong', { key: key }, mdInline(t.slice(2, -2), key, ctx)));
      else if (m[3]) out.push(h('em', { key: key }, mdInline(t.slice(1, -1), key, ctx)));
      else if (m[4]) out.push(h('del', { key: key }, t.slice(2, -2)));
      else {
        var lm = /\[([^\]]+)\]\(([^)\s]+)\)/.exec(t), href = lm[2], web = /^(https?:|mailto:)/.test(href);
        out.push(web
          ? h('a', { key: key, className: 'ex-md-a', href: href, target: '_blank', rel: 'noopener noreferrer', title: href, onClick: ctx.onOpenLink ? function (e) { e.preventDefault(); ctx.onOpenLink(href); } : undefined }, mdInline(lm[1], key, ctx), h(Icon, { name: 'link', size: 11 }))
          : h('a', { key: key, className: 'ex-md-a is-file', href: '#', title: 'Open ' + href + ' in Code', onClick: function (e) { e.preventDefault(); if (ctx.onOpenFile) ctx.onOpenFile(href); } }, h(Icon, { name: 'file', size: 12 }), lm[1]));
      }
      last = m.index + t.length;
    }
    if (last < s.length) out.push(s.slice(last));
    return out;
  }
  function mdBlocks(src, ctx, kp) {
    var L = String(src || '').split('\n'), out = [], i = 0, key = 0, buf = [];
    if (ctx.streaming && L.length && /^!\[/.test(L[L.length - 1])) L.pop(); /* an embed shows once its line is complete */
    function para() { if (buf.length) out.push(h('p', { key: kp + key++ }, mdInline(buf.join(' '), kp + 'p' + key, ctx))); buf = []; }
    while (i < L.length) {
      var l = L[i], m;
      if (/^\s*```/.test(l)) {
        para(); var lang = l.trim().slice(3).trim(), code = []; i++;
        while (i < L.length && !/^\s*```/.test(L[i])) code.push(L[i++]);
        var open = i >= L.length; i++;
        out.push(lang === 'mermaid' && ctx.renderDiagram && !open ? h('div', { key: kp + key++, className: 'ex-md-diagram' }, ctx.renderDiagram(code.join('\n'))) : h(MdCode, { key: kp + key++, lang: lang, code: code.join('\n'), writing: open && ctx.streaming }));
        continue;
      }
      if ((m = /^(#{1,6})\s+(.*)/.exec(l))) { para(); var lv = Math.min(m[1].length, 4); out.push(h('h' + (lv + 1), { key: kp + key++, className: 'ex-md-h ex-md-h' + lv }, mdInline(m[2], kp + 'h' + key, ctx))); i++; continue; }
      if (/^\s*(---+|\*\*\*+)\s*$/.test(l)) { para(); out.push(h('hr', { key: kp + key++ })); i++; continue; }
      if (MD_EMBED.test(l)) {
        para(); var group = [];
        while (i < L.length && MD_EMBED.test(L[i])) { var g = MD_EMBED.exec(L[i]); group.push({ alt: g[1], path: g[2] }); i++; }
        out.push(h(MdEmbeds, { key: kp + key++, items: group, ctx: ctx })); continue;
      }
      if (/^>\s?/.test(l)) {
        para(); var q = []; while (i < L.length && /^>\s?/.test(L[i])) q.push(L[i++].replace(/^>\s?/, ''));
        var cm = /^\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]\s*$/.exec(q[0] || '');
        if (cm) {
          var kind = cm[1].toLowerCase(), icon = { note: 'question', tip: 'bulb', important: 'bolt', warning: 'shield', caution: 'shield' }[kind];
          out.push(h('div', { key: kp + key++, className: 'ex-md-callout is-' + kind, role: 'note' }, h('div', { className: 'ex-md-callout-t' }, h(Icon, { name: icon, size: 14 }), kind[0].toUpperCase() + kind.slice(1)), mdBlocks(q.slice(1).join('\n'), ctx, kp + key + 'c')));
        } else out.push(h('blockquote', { key: kp + key++ }, mdBlocks(q.join('\n'), ctx, kp + key + 'q')));
        continue;
      }
      if (/^\s*\|/.test(l) && i + 1 < L.length && /^\s*\|?\s*:?-{2,}/.test(L[i + 1])) {
        para(); var rows = []; while (i < L.length && /^\s*\|/.test(L[i])) rows.push(L[i++]);
        out.push(h(MdTable, { key: kp + key++, rows: rows, ctx: ctx })); continue;
      }
      if (/^\s*([-*+]|\d+[.)])\s/.test(l)) {
        para(); var items = [], ordered = /^\s*\d/.test(l), start = ordered ? parseInt(l, 10) : 1;
        while (i < L.length && (/^\s*([-*+]|\d+[.)])\s/.test(L[i]) || (/^\s{2,}\S/.test(L[i]) && items.length))) {
          if (/^\s*([-*+]|\d+[.)])\s/.test(L[i])) items.push({ lv: /^(\s*)/.exec(L[i])[1].length >> 1, txt: L[i].replace(/^\s*([-*+]|\d+[.)])\s/, '') });
          else items[items.length - 1].txt += ' ' + L[i].trim();
          i++;
        }
        out.push(mdList(items, ordered, start, kp + key++, ctx)); continue;
      }
      if (!l.trim()) { para(); i++; continue; }
      buf.push(l.trim()); i++;
    }
    para();
    return out;
  }
  function mdList(items, ordered, start, k, ctx) {
    var root = [], stack = [{ lv: -1, kids: root }];
    items.forEach(function (it) { while (stack[stack.length - 1].lv >= it.lv) stack.pop(); var node = { txt: it.txt, kids: [] }; stack[stack.length - 1].kids.push(node); stack.push({ lv: it.lv, kids: node.kids }); });
    function render(nodes, ord, kk, first) {
      var tasks = nodes.some(function (n) { return /^\[[ xX]\]\s/.test(n.txt); });
      return h(ord ? 'ol' : 'ul', { key: kk, className: cx(tasks && 'ex-md-tasks'), start: ord && first !== 1 ? first : undefined }, nodes.map(function (n, j) {
        var tm = /^\[([ xX])\]\s(.*)/.exec(n.txt), done = tm && tm[1] !== ' ';
        return h('li', { key: j, className: tm ? (done ? 'is-done' : 'is-todo') : null },
          tm ? h('span', { className: 'ex-md-check', role: 'img', 'aria-label': done ? 'Done' : 'Not done' }, done ? h(Icon, { name: 'check', size: 11 }) : null) : null,
          h('span', { className: 'ex-md-li' }, mdInline(tm ? tm[2] : n.txt, kk + '.' + j, ctx)),
          n.kids.length ? render(n.kids, false, kk + '.' + j + 'k', 1) : null);
      }));
    }
    return render(root, ordered, 'l' + k, start);
  }
  function MdTable(props) {
    function cells(r) { return r.trim().replace(/^\||\|$/g, '').split('|').map(function (c) { return c.trim(); }); }
    var head = cells(props.rows[0]), align = cells(props.rows[1]).map(function (c) { return /^:-+:$/.test(c) ? 'center' : /-:$/.test(c) ? 'right' : 'left'; }), body = props.rows.slice(2).map(cells);
    return h('div', { className: 'ex-md-table', tabIndex: 0, role: 'region', 'aria-label': 'Table' }, h('table', null,
      h('thead', null, h('tr', null, head.map(function (c, j) { return h('th', { key: j, style: { textAlign: align[j] } }, mdInline(c, 'th' + j, props.ctx)); }))),
      h('tbody', null, body.map(function (r, ri) { return h('tr', { key: ri }, head.map(function (_, j) { return h('td', { key: j, style: { textAlign: align[j] } }, mdInline(r[j] || '', 'td' + ri + '.' + j, props.ctx)); })); }))));
  }
  /* A code block: a bare well; the language and Copy sit in its corner on hover (always on touch and with focus). */
  function MdCode(props) {
    var _c = React.useState(false), copied = _c[0], setCopied = _c[1], t = React.useRef(0), lang = MD_LANG[(props.lang || '').toLowerCase()] || null;
    React.useEffect(function () { return function () { clearTimeout(t.current); }; }, []);
    function copy() { try { navigator.clipboard.writeText(props.code); } catch (e) {} setCopied(true); clearTimeout(t.current); t.current = setTimeout(function () { setCopied(false); }, 1400); }
    var lines = props.code.split('\n');
    return h('div', { className: cx('ex-md-code', props.writing && 'is-writing') },
      h('div', { className: 'ex-md-code-tools' }, props.lang ? h('span', { className: 'ex-md-code-lang' }, props.lang) : null,
        h('button', { type: 'button', className: 'ex-md-code-copy', onClick: copy, 'aria-label': copied ? 'Copied' : 'Copy code', title: copied ? 'Copied' : 'Copy' }, h(EaseSwap, { k: copied ? 'y' : 'n' }, h(Icon, { name: copied ? 'check' : 'copy', size: 13 })))),
      h('pre', { className: 'ex-md-pre' }, h('code', null, lines.map(function (ln, i) { return h(F, { key: i }, codeNodes(ln, lang), i < lines.length - 1 ? '\n' : null); }))));
  }

  /* ── embeds: consecutive image lines become one group; pictures sit together, recordings and pages stand alone ── */
  function MdEmbeds(props) {
    var ctx = props.ctx, items = props.items.map(function (it) { return Object.assign({}, it, { file: ctx.resolve ? ctx.resolve(it.path) : null }); });
    var out = [], run = [];
    function flush() { if (run.length) out.push(h(MdFigures, { key: 'f' + out.length, items: run, ctx: ctx })); run = []; }
    items.forEach(function (it, i) {
      var kind = it.file ? it.file.kind || 'image' : 'missing';
      if (kind === 'image') { run.push(it); return; }
      flush();
      out.push(kind === 'video' ? h(MdVideo, { key: i, item: it, ctx: ctx }) : kind === 'page' ? h(MdPage, { key: i, item: it, ctx: ctx })
        : h('span', { key: i, className: 'ex-md-missing' }, h(Icon, { name: 'file', size: 13 }), it.path, h('span', null, ' isn’t in the workspace')));
    });
    flush();
    return out.length === 1 ? out[0] : h('div', { className: 'ex-md-embeds' }, out);
  }
  function MdFigures(props) {
    var items = props.items, _l = React.useState(null), lb = _l[0], setLb = _l[1];
    var pair = items.length === 2 && /before/i.test(items[0].path + items[0].alt) && /after/i.test(items[1].path + items[1].alt);
    if (pair) return h(MdCompare, { items: items });
    function open(i, el) { setLb({ i: i, from: el }); }
    var layout = items.length === 1 ? 'is-one' : items.length === 2 ? 'is-two' : 'is-strip';
    return h('div', { className: cx('ex-md-figs', layout) }, items.map(function (it, i) { return h(MdFigure, { key: it.path + i, item: it, onOpen: function (el) { open(i, el); } }); }),
      lb ? h(MdLightbox, { items: items, index: lb.i, from: lb.from, onClose: function () { setLb(null); } }) : null);
  }
  function MdFigure(props) {
    var it = props.item, f = it.file, _r = React.useState(false), ready = _r[0], setReady = _r[1];
    return h('figure', { className: 'ex-md-fig' },
      h('button', { type: 'button', className: cx('ex-md-fig-img', ready && 'is-ready'), 'aria-label': 'View ' + (it.alt || it.path) + ' large', onClick: function (e) { props.onOpen(e.currentTarget.querySelector('img')); } },
        h('img', { src: f.src, alt: it.alt, width: f.w, height: f.h, loading: 'lazy', decoding: 'async', onLoad: function () { setReady(true); }, ref: function (el) { if (el && el.complete && el.naturalWidth && !ready) setReady(true); } })),
      it.alt ? h('figcaption', null, it.alt) : null);
  }
  /* the viewer grows from the picture you clicked and shrinks back into it; ← → step through the group */
  function MdLightbox(props) {
    var ref = React.useRef(null), _i = React.useState(props.index), i = _i[0], setI = _i[1], closing = React.useRef(false);
    var it = props.items[i], f = it.file, ease = 'cubic-bezier(0.32, 0.72, 0, 1)';
    function fromBox() { var el = props.from; return el && el.isConnected ? el.getBoundingClientRect() : null; }
    function morph(img, a, back) {
      var b = img.getBoundingClientRect(); if (!a || !b.width || !img.animate) return null;
      var start = { transform: 'translate(' + (a.left - b.left) + 'px,' + (a.top - b.top) + 'px) scale(' + a.width / b.width + ',' + a.height / b.height + ')', borderRadius: '10px' }, end = { transform: 'none', borderRadius: '12px' };
      return img.animate(back ? [end, start] : [start, end], { duration: back ? 300 : 380, easing: ease, fill: 'both' });
    }
    useLayout(function () {
      var el = ref.current; if (!el || reducedMotion()) return;
      if (i === props.index) morph(el.querySelector('img'), fromBox(), false);
      el.animate && el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 200, easing: 'ease-out' });
      el.focus();
    }, []);
    function close() {
      if (closing.current) return; closing.current = true; var el = ref.current;
      if (!el || reducedMotion()) { props.onClose(); return; }
      var a = i === props.index ? fromBox() : null, an = a ? morph(el.querySelector('img'), a, true) : null;
      el.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 260, easing: 'ease-in', fill: 'forwards', delay: an ? 60 : 0 }).onfinish = props.onClose;
    }
    function step(d) { var n = Math.max(0, Math.min(props.items.length - 1, i + d)); if (n !== i) setI(n); }
    return h('div', { ref: ref, className: 'ex-md-lb', role: 'dialog', 'aria-modal': 'true', 'aria-label': it.alt || it.path, tabIndex: -1, onClick: close,
      onKeyDown: function (e) { if (e.key === 'Escape') { e.preventDefault(); close(); } else if (e.key === 'ArrowRight') step(1); else if (e.key === 'ArrowLeft') step(-1); } },
      h('div', { className: 'ex-md-lb-bar', onClick: function (e) { e.stopPropagation(); } },
        h('span', { className: 'ex-md-lb-t' }, it.alt || it.path.split('/').pop()), h('span', { className: 'ex-md-lb-p' }, it.path), h('span', { style: { flex: 1 } }),
        props.items.length > 1 ? h('span', { className: 'ex-md-lb-n' }, (i + 1) + ' of ' + props.items.length) : null,
        props.items.length > 1 ? h(IconButton, { icon: 'chevron-right', label: 'Previous  ←', size: 'sm', className: 'ex-md-lb-prev', disabled: i === 0, onClick: function () { step(-1); } }) : null,
        props.items.length > 1 ? h(IconButton, { icon: 'chevron-right', label: 'Next  →', size: 'sm', className: 'ex-md-lb-next', disabled: i === props.items.length - 1, onClick: function () { step(1); } }) : null,
        h(IconButton, { icon: 'x', label: 'Close  Esc', size: 'sm', onClick: close })),
      h('img', { key: it.path, src: f.src, alt: it.alt, width: f.w, height: f.h, className: i === props.index ? null : 'is-step', onClick: function (e) { e.stopPropagation(); } }));
  }
  /* two shots of one screen, named before and after: one picture you wipe across */
  function MdCompare(props) {
    var a = props.items[0], b = props.items[1], _p = React.useState(50), pos = _p[0], setPos = _p[1], drag = React.useRef(false);
    function at(e) { var r = e.currentTarget.getBoundingClientRect(); setPos(Math.max(0, Math.min(100, (e.clientX - r.left) / r.width * 100))); }
    return h('figure', { className: 'ex-md-fig' },
      h('div', { className: 'ex-md-cmp', role: 'slider', tabIndex: 0, 'aria-label': 'Before and after', 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-valuenow': Math.round(pos), style: { aspectRatio: a.file.w + ' / ' + a.file.h },
        onPointerDown: function (e) { drag.current = true; e.currentTarget.setPointerCapture && e.currentTarget.setPointerCapture(e.pointerId); at(e); },
        onPointerMove: function (e) { if (drag.current || e.pointerType === 'mouse') at(e); }, onPointerUp: function () { drag.current = false; },
        onKeyDown: function (e) { if (e.key === 'ArrowLeft') setPos(Math.max(0, pos - 5)); else if (e.key === 'ArrowRight') setPos(Math.min(100, pos + 5)); } },
        h('img', { src: b.file.src, alt: b.alt }), h('div', { className: 'ex-md-cmp-a', style: { clipPath: 'inset(0 ' + (100 - pos) + '% 0 0)' } }, h('img', { src: a.file.src, alt: a.alt })),
        h('span', { className: 'ex-md-cmp-line', style: { left: pos + '%' } }, h('span', { className: 'ex-md-cmp-knob' }, h(Icon, { name: 'chevron-right', size: 12 }))),
        h('span', { className: 'ex-md-cmp-tag is-a' }, a.alt || 'Before'), h('span', { className: 'ex-md-cmp-tag is-b' }, b.alt || 'After')),
      h('figcaption', null, 'Move across to compare'));
  }

  /* ── a recording: poster at its size, one play button, quiet controls; marks on the track (a test's steps) ── */
  function mdTime(s) { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ':' + ('0' + s % 60).slice(-2); }
  function MdVideo(props) {
    var it = props.item, f = it.file, v = React.useRef(null), box = React.useRef(null), tick = React.useRef(0);
    var _s = React.useState({ on: false, t: 0, started: false }), st = _s[0], setSt = _s[1], _r = React.useState(1), rate = _r[0], setRate = _r[1];
    var dur = f.dur || 0, fake = !f.src; /* without a source (a preview), time is simulated */
    React.useEffect(function () {
      if (!fake || !st.on) return;
      var t0 = performance.now() - st.t * 1000 / rate;
      tick.current = setInterval(function () { var t = (performance.now() - t0) / 1000 * rate; if (t >= dur) setSt({ on: false, t: 0, started: true }); else setSt(function (s) { return Object.assign({}, s, { t: t }); }); }, 120);
      return function () { clearInterval(tick.current); };
    }, [st.on, rate]);
    function toggle() { if (!fake && v.current) { if (v.current.paused) v.current.play(); else v.current.pause(); } setSt(function (s) { return Object.assign({}, s, { on: !s.on, started: true }); }); }
    function seek(t) { if (!fake && v.current) v.current.currentTime = t; setSt(function (s) { return Object.assign({}, s, { t: t, started: true }); }); }
    function cycle() { var r = rate === 1 ? 1.5 : rate === 1.5 ? 2 : 1; setRate(r); if (v.current) v.current.playbackRate = r; }
    function full() { var b = box.current; if (b && b.requestFullscreen) b.requestFullscreen(); }
    var p = dur ? st.t / dur : 0;
    return h('figure', { className: 'ex-md-fig' },
      h('div', { ref: box, className: cx('ex-md-vid', st.on && 'is-on', st.started && 'is-started'), style: { aspectRatio: (f.w || 16) + ' / ' + (f.h || 9) }, tabIndex: 0, 'aria-label': (it.alt || 'Video') + ', ' + mdTime(dur),
        onKeyDown: function (e) { if (e.key === ' ' || e.key === 'k') { e.preventDefault(); toggle(); } else if (e.key === 'ArrowRight') seek(Math.min(dur, st.t + 5)); else if (e.key === 'ArrowLeft') seek(Math.max(0, st.t - 5)); } },
        fake ? h('img', { src: f.poster, alt: '', className: 'ex-md-vid-media' })
          : h('video', { ref: v, className: 'ex-md-vid-media', src: f.src, poster: f.poster, preload: 'metadata', playsInline: true, onClick: toggle, onTimeUpdate: function (e) { var t = e.currentTarget.currentTime; setSt(function (s) { return Object.assign({}, s, { t: t }); }); }, onEnded: function () { setSt({ on: false, t: 0, started: true }); } }),
        !st.on ? h('button', { type: 'button', className: 'ex-md-vid-play', onClick: toggle, 'aria-label': 'Play' }, h('span', { className: 'ex-md-tri' })) : null,
        h('div', { className: 'ex-md-vid-bar' },
          h('button', { type: 'button', className: 'ex-md-vid-b', onClick: toggle, 'aria-label': st.on ? 'Pause' : 'Play' }, h('span', { className: st.on ? 'ex-md-pause' : 'ex-md-tri is-sm' })),
          h('span', { className: 'ex-md-vid-t' }, mdTime(st.t) + ' / ' + mdTime(dur)),
          h('span', { className: 'ex-md-vid-track', onClick: function (e) { var r = e.currentTarget.getBoundingClientRect(); seek((e.clientX - r.left) / r.width * dur); } },
            h('span', { className: 'ex-md-vid-fill', style: { transform: 'scaleX(' + p + ')' } }),
            (f.marks || []).map(function (mk, i) { return h('button', { key: i, type: 'button', className: 'ex-md-vid-mark', style: { left: (mk.t / dur * 100) + '%' }, title: mk.label + ' · ' + mdTime(mk.t), 'aria-label': 'Go to ' + mk.label, onClick: function (e) { e.stopPropagation(); seek(mk.t); } }); })),
          h('button', { type: 'button', className: 'ex-md-vid-b is-txt', onClick: cycle, 'aria-label': 'Speed ' + rate + '×' }, rate + '×'),
          h('button', { type: 'button', className: 'ex-md-vid-b', onClick: full, 'aria-label': 'Full screen' }, h(Icon, { name: 'expand', size: 13 })))),
      h('figcaption', null, (it.alt || it.path.split('/').pop()) + ' · ' + mdTime(dur)));
  }

  /* ── an HTML page the agent made: live, sandboxed, as tall as the page up to a limit ── */
  var MD_PAGE_CAP = 480;
  function mdPageDoc(src) {
    var csp = '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src data: blob:; media-src data: blob:; style-src \'unsafe-inline\'; script-src \'unsafe-inline\'; font-src data:">';
    var report = '<script>(function(){function s(){parent.postMessage({exPageHeight:Math.ceil(document.documentElement.scrollHeight)},"*")}addEventListener("load",s);new ResizeObserver(s).observe(document.documentElement);s()})()<' + '/script>';
    var d = String(src || '');
    d = /<head[^>]*>/i.test(d) ? d.replace(/<head[^>]*>/i, function (m) { return m + csp; }) : csp + d;
    return /<\/body>/i.test(d) ? d.replace(/<\/body>/i, report + '</body>') : d + report;
  }
  function MdPage(props) {
    var it = props.item, f = it.file, ctx = props.ctx, frame = React.useRef(null), boxRef = React.useRef(null);
    var _v = React.useState('desktop'), vp = _v[0], setVp = _v[1], _w = React.useState(false), whole = _w[0], setWhole = _w[1];
    var _h = React.useState(0), ch = _h[0], setCh = _h[1], _k = React.useState(0), rk = _k[0], setRk = _k[1], _live = React.useState(true), live = _live[0], setLive = _live[1];
    var _u = React.useState(false), updated = _u[0], setUpdated = _u[1], firstDoc = React.useRef(f.srcdoc);
    var doc = React.useMemo(function () { return f.srcdoc != null ? mdPageDoc(f.srcdoc) : null; }, [f.srcdoc]);
    React.useEffect(function () {
      function on(e) { if (frame.current && e.source === frame.current.contentWindow && e.data && typeof e.data.exPageHeight === 'number') setCh(e.data.exPageHeight); }
      window.addEventListener('message', on); return function () { window.removeEventListener('message', on); };
    }, []);
    /* the agent changed the page: it reloads in place and says so for a moment */
    React.useEffect(function () { if (f.srcdoc === firstDoc.current) return; firstDoc.current = f.srcdoc; setUpdated(true); var t = setTimeout(function () { setUpdated(false); }, 2600); return function () { clearTimeout(t); }; }, [f.srcdoc]);
    /* only what's near the view stays alive; a page far away is unloaded (its box keeps its size) and reloads when it comes back */
    React.useEffect(function () {
      var el = boxRef.current; if (!el || typeof IntersectionObserver === 'undefined') return;
      var io = new IntersectionObserver(function (es) { setLive(es[0].isIntersecting); }, { rootMargin: '900px 0px' }); io.observe(el);
      return function () { io.disconnect(); };
    }, []);
    var fixed = f.srcdoc == null, long = !fixed && ch > MD_PAGE_CAP + 40;
    var height = fixed ? MD_PAGE_CAP : !ch ? (f.h || 320) : whole ? Math.min(ch, 4000) : Math.min(ch, MD_PAGE_CAP);
    return h('div', { ref: boxRef, className: cx('ex-md-page', updated && 'is-updated') },
      h('div', { className: 'ex-md-pbar' },
        h('span', { className: 'ex-md-pfav' }, h(Icon, { name: 'globe', size: 12 })), h('b', null, f.title || it.alt || 'Page'), h('span', { className: 'ex-md-pbar-p' }, f.url || it.path),
        h('span', { className: 'ex-md-updated', 'aria-live': 'polite' }, updated ? 'Updated' : ''), h('span', { style: { flex: 1, minWidth: 4 } }),
        h(Segmented, { size: 'sm', label: 'Width', value: vp, onChange: setVp, options: [{ id: 'desktop', icon: 'laptop', title: 'Full width' }, { id: 'phone', icon: 'window', title: 'Phone width (390)' }] }),
        h(IconButton, { icon: 'refresh', label: 'Reload', size: 'sm', onClick: function () { setRk(rk + 1); } }),
        h(IconButton, { icon: 'panel', label: 'Open in the Browser view', size: 'sm', onClick: function () { if (ctx.onOpenPage) ctx.onOpenPage(it.path); } })),
      h('div', { className: cx('ex-md-page-view', long && !whole && 'is-cut'), style: { height: height } },
        h('div', { className: cx('ex-md-page-vp', vp === 'phone' && 'is-phone') },
          live ? h('iframe', { key: rk + ':' + vp, ref: frame, className: 'ex-md-frame', title: f.title || it.alt || it.path, sandbox: 'allow-scripts', referrerPolicy: 'no-referrer', srcDoc: doc || undefined, src: fixed ? f.url : undefined, scrolling: fixed || whole && ch > 4000 ? 'auto' : 'no', style: { height: fixed ? '100%' : Math.max(ch, height) } }) : null),
        long && !whole ? h('button', { type: 'button', className: 'ex-md-page-more', onClick: function () { setWhole(true); } }, 'Show the whole page') : null),
      h('div', { className: 'ex-md-page-foot' }, h(Icon, { name: 'shield', size: 12 }), h('span', null, fixed ? 'Live from ' + f.url : 'Runs sandboxed: no network, no access to your files'), h('span', { style: { flex: 1 } }),
        long && whole ? h('button', { type: 'button', className: 'ex-md-page-less', onClick: function () { setWhole(false); } }, 'Show less') : null));
  }

  function Markdown(props) {
    var ctx = { resolve: props.resolve, onOpenFile: props.onOpenFile, onOpenLink: props.onOpenLink, onOpenPage: props.onOpenPage, renderDiagram: props.renderDiagram, streaming: !!props.streaming };
    return h('div', { className: cx('ex-md', props.className) }, mdBlocks(props.source || props.children || '', ctx, 'b'));
  }

  /* ════ Side views: Browser and Terminal ════ */

  /* A row of tabs that grow in and close away (never pop); keeps a closing tab for its exit. */
  function ViewTabs(props) {
    var items = props.items || [], prev = React.useRef(null), _g = React.useState([]), gone = _g[0], setGone = _g[1], first = prev.current === null;
    var ids = items.map(function (t) { return t.id; }).join('|');
    React.useEffect(function () {
      var was = prev.current || [], now = items.map(function (t) { return t.id; });
      var left = was.filter(function (t) { return now.indexOf(t.id) < 0; }).map(function (t) { return Object.assign({}, t, { leaving: true, at: was.indexOf(t) }); });
      prev.current = items.slice();
      if (!left.length) return;
      setGone(function (g) { return g.concat(left); });
      var t = setTimeout(function () { setGone(function (g) { return g.filter(function (x) { return left.indexOf(x) < 0; }); }); }, 200);
      return function () { clearTimeout(t); };
    }, [ids]);
    var seen = React.useRef({}); if (first) items.forEach(function (t) { seen.current[t.id] = true; });
    var list = items.slice(); gone.forEach(function (g) { list.splice(Math.min(g.at, list.length), 0, g); });
    return h('div', { className: cx('ex-vtabs-row', props.className) }, h('div', { className: 'ex-vtabs', role: 'tablist', 'aria-label': props.label },
      list.map(function (t) {
        var fresh = !seen.current[t.id]; seen.current[t.id] = true;
        var on = t.id === props.active && !t.leaving;
        return h('div', { key: t.id, role: 'tab', 'aria-selected': String(on), tabIndex: on ? 0 : -1, className: cx('ex-vtab', on && 'is-on', fresh && 'is-new', t.leaving && 'is-leaving'), title: t.tip || t.title,
          onClick: function () { if (!t.leaving && props.onSelect) props.onSelect(t.id); },
          onAuxClick: function (e) { if (e.button === 1 && props.onClose) props.onClose(t.id); } },
          props.lead ? props.lead(t) : null, h('span', { className: 'ex-vtab-t' }, t.title), props.trail ? props.trail(t) : null,
          props.onClose ? h('button', { type: 'button', className: 'ex-vtab-x', 'aria-label': 'Close ' + t.title, onClick: function (e) { e.stopPropagation(); props.onClose(t.id); } }, h(Icon, { name: 'x', size: 11 })) : null);
      }),
      props.onNew ? h('button', { type: 'button', className: 'ex-vtab-new', 'aria-label': props.newLabel || 'New tab', title: props.newLabel || 'New tab', onClick: props.onNew }, h(Icon, { name: 'plus', size: 13 })) : null),
      props.after || null);
  }
  function AgentMark(props) { return h('span', { className: cx('ex-amark', props.live && 'is-live'), 'aria-label': props.live ? 'The agent is using this tab' : 'Opened by the agent' }, props.mark || 'Cl'); }

  /* ── Browser: tabs the agent and you share. One driver per tab; your click takes over, Hand back returns it. ── */
  function BrowserView(props) {
    var tabs = props.tabs || [], active = props.active || (tabs[0] && tabs[0].id), tab = tabs.filter(function (t) { return t.id === active; })[0] || {};
    var driver = props.driver || 'you', agent = driver === 'agent', needs = driver === 'needs';
    var _a = React.useState(''), ask = _a[0], setAsk = _a[1];
    var view = React.useRef(null);
    var pill = agent ? { k: 'agent', node: h(F, null, h(AgentMark, { live: true }), 'Driving') } : needs ? { k: 'needs', node: h(F, null, h(Icon, { name: 'hand', size: 12 }), 'Your turn') } : { k: 'you', node: h(F, null, h(Icon, { name: 'cursor', size: 12 }), 'You') };
    var act = props.action, pick = props.picked, errs = props.errors || 0, step = props.step;
    return h('div', { className: cx('ex-bv', agent && 'is-agent', props.className), style: props.style },
      h(ViewTabs, { label: 'Browser tabs', items: tabs.map(function (t) { return { id: t.id, title: t.title, tip: t.url }; }), active: active, onSelect: props.onSelect, onClose: props.onClose, onNew: props.onNew, newLabel: 'New tab  ⌘T',
        lead: function (t) { var full = tabs.filter(function (x) { return x.id === t.id; })[0] || {}; return full.by === 'agent' ? h(AgentMark, { live: agent && t.id === active }) : h('span', { className: 'ex-bv-fav', style: full.color ? { background: full.color } : null }); } }),
      h('div', { className: 'ex-bv-bar' },
        h(IconButton, { icon: 'back', label: 'Back', size: 'sm', onClick: props.onBack }), h(IconButton, { icon: 'refresh', label: 'Reload', size: 'sm', onClick: props.onReload }),
        h('label', { className: 'ex-bv-url' }, tab.server ? h('span', { className: 'ex-bv-srv', title: tab.server + ' · this task’s dev server' }, tab.server) : null, h('span', { className: 'ex-bv-url-t' }, tab.url || 'about:blank')),
        h('span', { className: cx('ex-bv-driver', 'is-' + driver), role: 'status' }, h(EaseSwap, { k: pill.k }, pill.node)),
        h(IconButton, { icon: 'target', label: 'Point at something to ask about it  ⇧⌘C', size: 'sm', active: !!props.picking, onClick: props.onPick }),
        h(IconButton, { icon: 'phone', label: props.width === 'phone' ? 'Full width' : 'Phone width (390)', size: 'sm', active: props.width === 'phone', onClick: props.onWidth }),
        h(IconButton, { icon: 'more', label: 'More: screenshot to the chat, light or dark, slow network, open outside', size: 'sm' })),
      h(Fold, { open: needs }, h('div', { className: 'ex-bv-needs', role: 'alert' }, h('span', { className: 'ex-bv-needs-ic' }, h(Icon, { name: 'hand', size: 14 })),
        h('span', { className: 'ex-grow' }, h('b', null, props.needsTitle || 'The agent needs you here'), h('span', null, props.needsText || 'It pauses until you’re done, and can’t see what you type in password and card fields.')),
        h(Button, { size: 'sm', variant: 'primary', onClick: props.onHandBack }, 'I’m done'))),
      h('div', { ref: view, className: 'ex-bv-view', onMouseDown: agent && props.onTakeOver ? function () { props.onTakeOver(); } : undefined },
        h('div', { className: cx('ex-bv-page', props.width === 'phone' && 'is-phone') }, props.children,
          act && agent ? h('span', { className: 'ex-bv-hl', style: { left: act.x - 4, top: act.y - 4, width: act.w + 8, height: act.h + 8 } }, act.label ? h('span', { className: 'ex-bv-hl-l' }, act.label) : null) : null,
          act && agent ? h('span', { className: 'ex-bv-cursor', style: { transform: 'translate(' + (act.x + act.w * 0.62) + 'px,' + (act.y + act.h * 0.55) + 'px)' } }, h('svg', { width: 18, height: 18, viewBox: '0 0 16 16', 'aria-hidden': 'true' }, h('path', { d: 'M3.5 2l9 5.2-4 1.1 2.4 4.3-1.7 1-2.4-4.3-3.3 2.7z', fill: '#fff', stroke: '#0e1621', strokeWidth: 1.2, strokeLinejoin: 'round' })), h('span', { className: 'ex-bv-ripple', key: act.label })) : null,
          pick ? h('span', { className: 'ex-bv-hl is-pick', style: { left: pick.x - 4, top: pick.y - 4, width: pick.w + 8, height: pick.h + 8 } }, h('span', { className: 'ex-bv-hl-l' }, pick.label + (pick.file ? ' · ' + pick.file : ''))) : null),
        agent ? h('span', { className: 'ex-bv-veil', 'aria-hidden': 'true' }, h('span', null, 'Click anywhere to take over')) : null,
        pick ? h('div', { className: 'ex-bv-ask', onMouseDown: function (e) { e.stopPropagation(); } },
          h('span', { className: 'ex-bv-ask-chip' }, h(Icon, { name: 'target', size: 12 }), pick.label, pick.file ? h('span', null, pick.file) : null),
          h('textarea', { className: 'ex-bv-ask-in', rows: 2, value: ask, placeholder: 'What should change here?', onChange: function (e) { setAsk(e.target.value); },
            onKeyDown: function (e) { if (e.key === 'Enter' && !e.shiftKey && ask.trim()) { e.preventDefault(); if (props.onAsk) props.onAsk(ask.trim()); setAsk(''); } else if (e.key === 'Escape' && props.onPick) props.onPick(); } }),
          h('span', { className: 'ex-bv-ask-bar' }, h('span', { className: 'ex-muted' }, 'Sent with a screenshot of the element'), h('span', { style: { flex: 1 } }), h(Button, { size: 'sm', variant: 'primary', kbd: '↵', disabled: !ask.trim(), onClick: function () { if (props.onAsk) props.onAsk(ask.trim()); setAsk(''); } }, 'Ask'))) : null),
      h(Fold, { open: agent && !!step }, step ? h('div', { className: 'ex-bv-foot' }, h(AgentMark, { live: true }), h('span', { className: 'ex-bv-foot-t' }, h('b', null, 'Step ' + step.n + (step.total ? ' of ' + step.total : '')), h('span', { className: 'ex-bv-sep', 'aria-hidden': 'true' }, '·'), h(EaseSwap, { k: String(step.n), className: 'ex-bv-step' }, step.text)),
        step.total ? h('span', { className: 'ex-bv-dots', 'aria-hidden': 'true' }, Array.apply(null, Array(Math.min(step.total, 12))).map(function (_, i) { return h('i', { key: i, className: i < step.n - 1 ? 'is-done' : i === step.n - 1 ? 'is-now' : null }); })) : null,
        h(Button, { size: 'sm', onClick: props.onTakeOver }, 'Take over')) : null),
      h(Fold, { open: !agent && errs > 0 }, h('div', { className: 'ex-bv-foot is-err' }, h(Icon, { name: 'bug', size: 14 }), h('span', { className: 'ex-bv-foot-t' }, h('b', null, errs + (errs === 1 ? ' error' : ' errors')), props.errorText ? h(F, null, h('span', { className: 'ex-bv-sep', 'aria-hidden': 'true' }, '·'), h('span', { className: 'ex-bv-step' }, props.errorText)) : null), h(Button, { size: 'sm', variant: 'primary', onClick: props.onSendErrors }, 'Send to agent'))),
      h(Fold, { open: driver === 'you' && !!props.agentWaiting }, h('div', { className: 'ex-bv-foot' }, h(Icon, { name: 'cursor', size: 14 }), h('span', { className: 'ex-bv-foot-t' }, 'You’re driving; the agent waits'), h(Button, { size: 'sm', onClick: props.onHandBack }, 'Hand back'))));
  }

  /* ── Terminal: your shells, in the task's workspace. The agent's commands are tool calls in the chat, never here. ── */
  function TermStatus(props) {
    var s = props.status;
    if (s === 'running') return h(StatusGlyph, { status: 'running', size: 12 });
    return h('span', { className: cx('ex-tv-dot', 'is-' + (s || 'idle')), 'aria-label': s === 'failed' ? 'Last command failed' : s === 'serving' ? 'Serving' : null });
  }
  function TerminalView(props) {
    var tabs = props.tabs || [], active = props.active || (tabs[0] && tabs[0].id), tab = tabs.filter(function (t) { return t.id === active; })[0] || {};
    var _m = React.useState(false), menu = _m[0], setMenu = _m[1], mp = usePresence(menu, 140), fail = props.failure;
    React.useEffect(function () {
      if (!menu) return; function away(e) { if (!e.target.closest || !e.target.closest('.ex-tv-newwrap')) setMenu(false); }
      document.addEventListener('mousedown', away); return function () { document.removeEventListener('mousedown', away); };
    }, [menu]);
    var scripts = props.scripts || [];
    return h('div', { className: cx('ex-tv', props.className), style: props.style },
      h(ViewTabs, { label: 'Terminals', items: tabs.map(function (t) { return { id: t.id, title: t.title, tip: (t.cmd || t.title) + (t.cwd ? ' · ' + t.cwd : '') }; }), active: active, onSelect: props.onSelect, onClose: props.onClose,
        lead: function (t) { var full = tabs.filter(function (x) { return x.id === t.id; })[0] || {}; return h(TermStatus, { status: full.status }); },
        trail: function (t) { var full = tabs.filter(function (x) { return x.id === t.id; })[0] || {}; return full.unread && t.id !== active ? h('span', { className: 'ex-tv-unread', 'aria-label': 'New output' }) : full.port ? h('span', { className: 'ex-tv-port' }, ':' + full.port) : null; },
        after: h('span', { className: 'ex-tv-newwrap ex-agent-wrap' },
          h('button', { type: 'button', className: 'ex-vtab-new', 'aria-label': 'New terminal', title: 'New terminal  ⌘T · or run a script', 'aria-expanded': String(menu), onClick: function () { setMenu(!menu); } }, h(Icon, { name: 'plus', size: 13 })),
          mp.m ? h('div', { className: cx('ex-menu', 'ex-tv-menu', mp.l && 'is-leaving'), role: 'menu' },
            h('div', { className: 'ex-menu-item', role: 'menuitem', onClick: function () { setMenu(false); if (props.onNew) props.onNew(); } }, h(Icon, { name: 'terminal', size: 14 }), h('span', { className: 'ex-grow' }, 'New shell'), h(Kbd, null, '⌘T')),
            scripts.length ? h('div', { className: 'ex-menu-sep' }) : null,
            scripts.length ? h('div', { className: 'ex-overline ex-menu-label' }, 'Run a script') : null,
            scripts.map(function (s, i) { return h('div', { key: i, className: 'ex-menu-item', role: 'menuitem', onClick: function () { setMenu(false); if (props.onRun) props.onRun(s); } }, h(Icon, { name: 'play', size: 14 }), h('span', { className: 'ex-grow' }, h('span', null, s.name), h('span', { className: 'ex-muted ex-mono' }, s.cmd))); })) : null) }),
      h('div', { className: 'ex-tv-sub' }, h(Icon, { name: 'workspace', size: 12 }), h('span', { className: 'ex-tv-cwd' }, tab.cwd || '~'), tab.branch ? h('span', { className: 'ex-tv-branch' }, h(Icon, { name: 'branch', size: 11 }), tab.branch) : null, h('span', { style: { flex: 1 } }),
        tab.port ? h('button', { type: 'button', className: 'ex-tv-open', onClick: function () { if (props.onOpenPort) props.onOpenPort(tab.port); } }, h(Icon, { name: 'globe', size: 12 }), 'Open :' + tab.port) : null,
        tab.status === 'running' || tab.status === 'serving' ? h(IconButton, { icon: 'stop', label: 'Stop  ⌃C', size: 'sm', onClick: props.onStop }) : null,
        h(IconButton, { icon: 'search', label: 'Find  ⌘F', size: 'sm' })),
      h('div', { className: 'ex-tv-out', tabIndex: 0, 'aria-label': 'Terminal output' }, props.children || (props.output || []).map(function (l, i) { return h('div', { key: i, className: cx('ex-tv-l', l[0] && 'is-' + l[0]) }, l[1]); }),
        props.children ? null : h('div', { className: 'ex-tv-l is-prompt' }, h('span', { className: 'ex-tv-ps' }, (tab.cwd || '~').split('/').pop() + ' $'), h('span', { className: 'ex-tv-caret' }))),
      h(Fold, { open: !!fail }, fail ? h('div', { className: 'ex-tv-fail' }, h('span', { className: 'ex-tv-dot is-failed' }), h('span', { className: 'ex-grow' }, h('b', null, 'Exited ' + fail.code), h('span', { className: 'ex-mono' }, fail.cmd)),
        h(Button, { size: 'sm', variant: 'primary', onClick: props.onAsk }, 'Ask the agent'), h(Button, { size: 'sm', onClick: props.onRerun }, 'Run again')) : null));
  }

  /* ════ Live agent moments ════ */

  /* The agent waits for a yes: run a command, apply an edit, call a tool. */
  /* The card eases between its states (pending ↔ resolved) instead of snapping. */
  function ApprovalCard(props) { return h(AutoHeight, { className: 'ex-card-autoh' }, h(ApprovalCardInner, props)); }
  function ApprovalCardInner(props) {
    var _s = React.useState(props.status || 'pending'); var status = _s[0], setStatus = _s[1];
    var kind = props.kind || 'command';
    var verb = { command: 'Run a command', edit: 'Apply an edit', tool: 'Use a tool' }[kind];
    if (status !== 'pending') {
      var ok = status !== 'denied';
      return h('div', { className: cx('ex-approval is-resolved', ok ? 'is-ok' : 'is-no') },
        h(Icon, { name: ok ? 'check' : 'x', size: 13 }),
        h('span', null, status === 'always' ? 'Always allowed' : ok ? 'Approved' : 'Denied'),
        h('span', { className: 'ex-mono ex-approval-sum' }, props.command || props.file || props.tool),
        props.onUndo !== false ? h('button', { type: 'button', className: 'ex-link-add', onClick: function () { setStatus('pending'); } }, 'Undo') : null);
    }
    function act(s) { setStatus(s); if (props.onResolve) props.onResolve(s); }
    return h('section', { className: 'ex-approval', role: 'group', 'aria-label': 'Needs you: ' + verb },
      h('div', { className: 'ex-approval-head' }, h(StatusGlyph, { status: 'attention', size: 14 }), h('span', { className: 'ex-approval-verb' }, verb), props.reason ? h('span', { className: 'ex-approval-why' }, props.reason) : null),
      kind === 'edit'
        ? h('div', { className: 'ex-approval-body' }, h(Icon, { name: 'file', size: 13 }), h('span', { className: 'ex-mono ex-grow' }, props.file), props.diff ? h(Diff, props.diff) : null)
        : h('div', { className: 'ex-approval-body is-code' }, h('span', { className: 'ex-approval-prompt', 'aria-hidden': 'true' }, kind === 'tool' ? '→' : '$'), h('span', { className: 'ex-mono ex-grow' }, props.command || props.tool), props.where ? h('span', { className: 'ex-approval-where' }, props.where) : null),
      h('div', { className: 'ex-approval-acts' },
        h(Button, { variant: 'primary', size: 'sm', kbd: '↵', onClick: function () { act('approved'); } }, 'Approve'),
        h(Button, { variant: 'secondary', size: 'sm', onClick: function () { act('always'); } }, kind === 'command' ? 'Always allow this command' : 'Always allow'),
        h('span', { style: { flex: 1 } }),
        h(Button, { variant: 'ghost', size: 'sm', kbd: 'Esc', onClick: function () { act('denied'); } }, 'Deny')));
  }

  /* The agent asks you to choose. Number keys pick; or type your own answer. */
  /* The card eases between its states (pending ↔ resolved) instead of snapping. */
  function QuestionCard(props) { return h(AutoHeight, { className: 'ex-card-autoh' }, h(QuestionCardInner, props)); }
  function questionList(props) {
    if (props.questions && props.questions.length) return props.questions.map(function (q, i) { return Object.assign({}, q, { id: q.id || 'q' + i, kind: q.kind || 'single', options: q.options || [] }); });
    return [{ id: 'q0', question: props.question, header: props.header, kind: props.kind || 'single', options: props.options || [] }];
  }
  function QuestionCardInner(props) {
    var qs = questionList(props), many = qs.length > 1;
    var init = props.answers || (props.answer != null ? { q0: [].concat(props.answer) } : null);
    var _i = React.useState(0), idx = _i[0], setIdx = _i[1];
    var _d = React.useState(1), dir = _d[0], setDir = _d[1];
    var _a = React.useState(init || {}), answers = _a[0], setAnswers = _a[1];
    var _o = React.useState({}), others = _o[0], setOthers = _o[1];   /* your own answer per question */
    var _e = React.useState(null), editing = _e[0], setEditing = _e[1];
    var _s = React.useState(!!init), sent = _s[0], setSent = _s[1];
    var _dr = React.useState(''), draft = _dr[0], setDraft = _dr[1];
    var timer = React.useRef(0), committed = React.useRef(false);
    /* writing your own answer selects it at once (pick one: the other options let go); nothing is sent until you say so */
    function edit(q) { committed.current = false; clearTimeout(timer.current); setDraft(others[q.id] || ''); setEditing(q.id); if (q.kind !== 'multi') setFor(q, [], false); }
    React.useEffect(function () { return function () { clearTimeout(timer.current); }; }, []);
    function picked(q) { return answers[q.id] || []; }
    function answered(q) { return picked(q).length > 0; }
    function go(n) { if (n < 0 || n >= qs.length) return; setDir(n > idx ? 1 : -1); setIdx(n); setEditing(null); }
    function send(a) { setSent(true); setEditing(null); if (props.onSubmit) props.onSubmit(a || answers); }
    function setFor(q, list, after) {
      /* list is a value or a function of the current answers for q (so quick successive picks never drop one) */
      var o = null;
      setAnswers(function (prev) { o = Object.assign({}, prev); o[q.id] = typeof list === 'function' ? list(prev[q.id] || []) : list; return o; });
      if (after && q.kind !== 'multi') {
        clearTimeout(timer.current);
        if (!many) timer.current = setTimeout(function () { send(o); }, 180);        /* one question, one pick: that's the answer */
        else if (idx < qs.length - 1) timer.current = setTimeout(function () { setDir(1); setIdx(idx + 1); }, 220); /* in a run, move on */
      }
    }
    function choose(q, label) {
      if (q.kind === 'multi') setFor(q, function (cur) { return cur.indexOf(label) >= 0 ? cur.filter(function (x) { return x !== label; }) : cur.concat([label]); }, false);
      else setFor(q, [label], true);
    }
    function commitOther(q, text, then) {
      text = (text || '').trim(); var prev = others[q.id];
      var oo = Object.assign({}, others); if (text) oo[q.id] = text; else delete oo[q.id]; setOthers(oo); setEditing(null);
      var cur = (answers[q.id] || []).filter(function (x) { return x !== prev; });
      var list = !text ? cur : q.kind === 'multi' ? cur.concat([text]) : [text];
      var next = Object.assign({}, answers); next[q.id] = list; setAnswers(next);
      if (!text) return;
      if (then === 'send') send(next);
      else if (then === 'next' && idx < qs.length - 1) { setDir(1); setIdx(idx + 1); }
    }
    var allDone = qs.every(answered);

    if (sent) {
      if (!many) return h('div', { className: 'ex-approval is-resolved is-ok' }, h(Icon, { name: 'check', size: 13 }), h('span', null, 'You chose'), h('b', { className: 'ex-approval-sum' }, picked(qs[0]).join(', ')),
        h('button', { type: 'button', className: 'ex-link-add', onClick: function () { setSent(false); } }, 'Change'));
      return h('div', { className: 'ex-approval is-resolved is-ok ex-q-sent' },
        h('div', { className: 'ex-q-sent-h' }, h(Icon, { name: 'check', size: 13 }), h('span', null, 'You answered ' + qs.length + ' questions'), h('button', { type: 'button', className: 'ex-link-add', onClick: function () { setSent(false); setIdx(0); } }, 'Change')),
        h('ul', { className: 'ex-q-sent-list' }, qs.map(function (q, i) { return h('li', { key: q.id }, h('span', null, q.header || 'Question ' + (i + 1)), h('b', null, picked(q).join(', '))); })));
    }

    var q = qs[idx], cur = picked(q), mine = others[q.id], multi = q.kind === 'multi';
    function onKey(e) {
      if (e.target && e.target.tagName === 'INPUT') return;
      var n = parseInt(e.key, 10);
      if (n >= 1 && n <= q.options.length) { e.preventDefault(); choose(q, q.options[n - 1].label); return; }
      if (e.key === 'Enter') { e.preventDefault(); if (idx < qs.length - 1 && answered(q)) go(idx + 1); else if (allDone && (many || multi)) send(); }
      if (e.key === 'ArrowLeft' && many) go(idx - 1);
      if (e.key === 'ArrowRight' && many && answered(q)) go(idx + 1);
    }
    function row(o, i) {
      var on = cur.indexOf(o.label) >= 0;
      return h('button', { key: o.label, type: 'button', role: multi ? 'checkbox' : 'radio', 'aria-checked': String(on), className: cx('ex-q-opt', on && 'is-picked'), style: { '--i': i }, onClick: function () { choose(q, o.label); } },
        h('span', { className: cx('ex-q-ind', multi ? 'is-check' : 'is-radio') }, multi ? h('svg', { viewBox: '0 0 16 16', width: 12, height: 12, 'aria-hidden': 'true' }, h('path', { d: 'M3.5 8.5l3 3 6-7' })) : h('span')),
        h('span', { className: 'ex-grow' }, h('span', { className: 'ex-q-label' }, o.label), o.detail ? h('span', { className: 'ex-q-detail' }, o.detail) : null),
        o.recommended ? h('span', { className: 'ex-bf-tag' }, 'suggested') : null,
        i < 9 ? h(Kbd, null, String(i + 1)) : null);
    }
    var otherRow = editing === q.id
      ? h('div', { key: 'other-edit', className: 'ex-q-opt ex-q-other is-editing is-picked' },
          h('span', { className: cx('ex-q-ind', multi ? 'is-check' : 'is-radio') }, multi ? h('svg', { viewBox: '0 0 16 16', width: 12, height: 12, 'aria-hidden': 'true' }, h('path', { d: 'M3.5 8.5l3 3 6-7' })) : h('span')),
          h('input', { autoFocus: true, value: draft, onChange: function (e) { setDraft(e.target.value); }, placeholder: 'Write your own answer', 'aria-label': 'Your own answer',
            onKeyDown: function (e) {
              if (e.key === 'Enter') { e.preventDefault(); if (!draft.trim()) return; committed.current = true; commitOther(q, draft, multi ? null : many ? 'next' : 'send'); }
              if (e.key === 'Escape') { e.preventDefault(); committed.current = true; setEditing(null); }
            },
            onBlur: function () { if (committed.current) return; committed.current = true; if (draft.trim()) commitOther(q, draft, null); else setEditing(null); } }),
          h(Kbd, null, '↵'))
      : mine
        ? h('button', { key: 'other-mine', type: 'button', role: multi ? 'checkbox' : 'radio', 'aria-checked': String(cur.indexOf(mine) >= 0), className: cx('ex-q-opt ex-q-other is-mine', cur.indexOf(mine) >= 0 && 'is-picked'), onClick: function () { choose(q, mine); } },
            h('span', { className: cx('ex-q-ind', multi ? 'is-check' : 'is-radio') }, multi ? h('svg', { viewBox: '0 0 16 16', width: 12, height: 12, 'aria-hidden': 'true' }, h('path', { d: 'M3.5 8.5l3 3 6-7' })) : h('span')),
            h('span', { className: 'ex-grow' }, h('span', { className: 'ex-q-label' }, mine), h('span', { className: 'ex-q-detail' }, 'Your answer')),
            h('span', { className: 'ex-q-edit', role: 'button', tabIndex: 0, onClick: function (e) { e.stopPropagation(); edit(q); } }, 'Edit'))
        : h('button', { key: 'other-add', type: 'button', className: 'ex-q-opt ex-q-other', onClick: function () { edit(q); } },
            h('span', { className: 'ex-q-ind is-pen' }, h(Icon, { name: 'pencil', size: 12 })), h('span', { className: 'ex-grow' }, h('span', { className: 'ex-q-label' }, 'Something else…')));
    var writing = editing === q.id, ownPicked = writing || (!!mine && cur.indexOf(mine) >= 0);
    var hint = writing ? (multi ? '↵ adds it' : many ? '↵ keeps it and goes on' : '↵ sends it') : multi ? (cur.length ? cur.length + ' picked' : 'Pick any') : (many ? 'Pick one' : ownPicked ? 'Your own answer' : null);
    var canGo = writing ? !!draft.trim() || (multi && cur.length > 0) : answered(q);
    function goOn(then) { if (writing && draft.trim()) { committed.current = true; commitOther(q, draft, then); } else if (then === 'send') send(); else go(idx + 1); }
    var nextBtn = idx < qs.length - 1
      ? h(Button, { size: 'sm', variant: canGo ? 'primary' : 'secondary', kbd: canGo && !writing ? '↵' : null, disabled: !canGo, onMouseDown: function (e) { e.preventDefault(); }, onClick: function () { goOn('next'); } }, 'Next')
      : (function () { var ready = qs.every(function (qq) { return qq.id === q.id ? canGo : answered(qq); });
          return h(Button, { size: 'sm', variant: 'primary', kbd: ready && !writing ? '↵' : null, disabled: !ready, onMouseDown: function (e) { e.preventDefault(); }, onClick: function () { goOn('send'); } }, many ? 'Send answers' : 'Send'); })();
    /* one question, pick one: no footer unless your own answer is the choice (then you send it yourself) */
    var foot = many || multi || ownPicked;
    return h('section', { className: cx('ex-approval ex-question', many && 'is-many'), role: 'group', 'aria-label': 'Needs you: ' + (many ? qs.length + ' questions' : 'a question'), onKeyDown: onKey },
      many ? h('div', { className: 'ex-q-steps', role: 'tablist' },
        qs.map(function (qq, i) { var ok = answered(qq);
          return h('button', { key: qq.id, type: 'button', role: 'tab', 'aria-selected': String(i === idx), className: cx('ex-q-step', i === idx && 'is-on', ok && 'is-done'), onClick: function () { go(i); } },
            h('span', { className: 'ex-q-step-n' }, ok && i !== idx ? h(Icon, { name: 'check', size: 10 }) : i + 1), h('span', { className: 'ex-q-step-l' }, qq.header || 'Question ' + (i + 1))); }),
        h('span', { style: { flex: 1 } }), h('span', { className: 'ex-q-count' }, h(Ticker, { value: qs.filter(answered).length }), '\u00a0of ' + qs.length)) : null,
      h('div', { key: q.id, className: cx('ex-q-pane', many && (dir > 0 ? 'is-fwd' : 'is-back')) },
        h('div', { className: 'ex-approval-head' }, h(StatusGlyph, { status: 'attention', size: 14 }), h('span', { className: 'ex-approval-verb' }, q.question)),
        h('div', { className: 'ex-q-opts', role: multi ? 'group' : 'radiogroup', 'aria-label': q.question }, q.options.map(row), otherRow)),
      foot ? h('div', { className: 'ex-q-foot' },
        many && idx > 0 ? h(Button, { size: 'sm', variant: 'ghost', onClick: function () { go(idx - 1); } }, 'Back') : null,
        hint ? h('span', { className: 'ex-q-hint' }, hint) : null, h('span', { style: { flex: 1 } }), nextBtn) : null);
  }

  /* A proposed plan: steps that tick off as the agent works. */
  /* The card eases between its states (pending ↔ resolved) instead of snapping. */
  function PlanCard(props) { return h(AutoHeight, { className: 'ex-card-autoh' }, h(PlanCardInner, props)); }
  function PlanCardInner(props) {
    var steps = props.steps || [];
    var status = props.status || 'proposed';
    var done = steps.filter(function (s) { return s.state === 'done'; }).length;
    return h('section', { className: cx('ex-plan', 'is-' + status), 'aria-label': 'Plan' },
      h('div', { className: 'ex-plan-head' },
        h(Icon, { name: 'plan', size: 14 }), h('span', { className: 'ex-plan-title' }, props.title || 'Plan'),
        h('span', { style: { flex: 1 } }),
        status === 'proposed' ? h('span', { className: 'ex-plan-meta' }, steps.length + ' steps') : h('span', { className: 'ex-plan-meta' }, h('span', null, h(Ticker, { value: done }), ' of ' + steps.length))),
      status !== 'proposed' ? h(ProgressLine, { value: steps.length ? done / steps.length : 0 }) : null,
      h('ol', { className: 'ex-plan-steps' }, steps.map(function (s, i) {
        var st = s.state || 'todo';
        return h('li', { key: i, className: 'ex-plan-step is-' + st, style: { '--i': i } },
          h('span', { className: 'ex-plan-mark' }, st === 'running' ? h(StatusGlyph, { status: 'running', size: 14 }) : st === 'done' ? h(StatusGlyph, { status: 'done', size: 14 }) : h('span', { className: 'ex-plan-n' }, i + 1)),
          h('span', { className: 'ex-plan-text' }, s.text));
      })),
      status === 'proposed' ? h('div', { className: 'ex-plan-acts' },
        h(Button, { variant: 'primary', size: 'sm', icon: 'code', kbd: '⇧⇥', onClick: props.onStart }, 'Start coding'),
        h(Button, { variant: 'ghost', size: 'sm', icon: 'pencil' }, 'Refine'),
        h('span', { style: { flex: 1 } }), h('span', { className: 'ex-plan-meta' }, 'Switches to Code and follows these steps')) : null);
  }

  /* The model thinking: a live shimmer and timer, collapsed to one line when done. */
  function ThinkingBlock(props) {
    var _o = React.useState(!!props.open); var open = _o[0], setOpen = _o[1];
    var active = !!props.active;
    return h('div', { className: cx('ex-think', active && 'is-active', open && 'is-open') },
      h('button', { type: 'button', className: 'ex-think-head', 'aria-expanded': String(open), onClick: function () { setOpen(!open); } },
        h(Icon, { name: 'bulb', size: 13 }),
        h('span', { className: active ? 'ex-shimmer-text' : null }, active ? 'Thinking' : 'Thought for ' + (props.seconds || 0) + 's'),
        active && props.seconds != null ? h('span', { className: 'ex-think-time' }, props.seconds + 's') : null,
        h(Icon, { name: 'chevron-right', size: 12, className: 'ex-think-chev' })),
      h(Fold, { open: open }, h('div', { className: 'ex-think-body' }, props.children)));
  }

  /* One tool call: shimmer while running, a check (and its duration) when done, output on demand. */
  function ToolStep(props) {
    var _o = React.useState(!!props.open); var open = _o[0], setOpen = _o[1];
    var st = props.status || 'done';
    var hasOut = !!props.output;
    return h('div', { className: cx('ex-step2', 'is-' + st, open && 'is-open') },
      h('button', { type: 'button', className: 'ex-step2-head', 'aria-expanded': hasOut ? String(open) : undefined, onClick: hasOut ? function () { setOpen(!open); } : undefined, tabIndex: hasOut ? 0 : -1 },
        h(Icon, { name: props.icon || 'terminal', size: 14 }),
        props.verb ? h('span', { className: 'ex-step2-verb' }, props.verb) : null,
        h('span', { className: 'ex-mono ex-step2-detail' }, props.detail),
        h('span', { style: { flex: 1 } }),
        props.meta ? h('span', { className: 'ex-step2-meta' }, props.meta) : null,
        st === 'running' ? h(StatusGlyph, { status: 'running', size: 13 }) : st === 'failed' ? h(StatusGlyph, { status: 'failed', size: 13 }) : h('span', { className: 'ex-step2-done' }, h(StatusGlyph, { status: 'done', size: 13 })),
        hasOut ? h(Icon, { name: 'chevron-right', size: 12, className: 'ex-step2-chev' }) : null),
      hasOut ? h(Fold, { open: open }, h('pre', { className: 'ex-step2-out' }, props.output)) : null);
  }

  /* Streaming text: new words fade in, a caret blinks until the turn ends. `demo` types it out. */
  function StreamText(props) {
    var full = String(props.text || '');
    var _n = React.useState(props.demo ? 0 : full.length); var n = _n[0], setN = _n[1];
    var prev = React.useRef(0);
    React.useEffect(function () {
      if (!props.demo) { setN(full.length); return; }
      setN(0); prev.current = 0;
      var t = setInterval(function () { setN(function (x) { if (x >= full.length) { clearInterval(t); return x; } var next = full.indexOf(' ', x + 3); return next === -1 ? full.length : next; }); }, props.speed || 55);
      return function () { clearInterval(t); };
    }, [full, props.demo, props.run]);
    var cut = Math.min(n, full.length);
    var stable = Math.min(prev.current, cut);
    React.useEffect(function () { prev.current = cut; });
    var streaming = props.streaming != null ? props.streaming : cut < full.length;
    return h('p', { className: 'ex-stream' }, full.slice(0, stable), h('span', { key: stable, className: 'ex-chunk' }, full.slice(stable, cut)), streaming ? h('span', { className: 'ex-caret', 'aria-hidden': 'true' }) : null);
  }

  /* The @ menu: sessions (with live status), tasks and files that match. */
  function MentionMenu(props) {
    var q = props.query || '';
    var groups = [
      { id: 'sessions', label: 'Sessions', items: (props.sessions || []) },
      { id: 'tasks', label: 'Tasks', items: (props.tasks || []) },
      { id: 'files', label: 'Files', items: (props.files || []) }];
    var idx = -1, hi = props.hi || 0;
    var th = useThumb('[aria-selected="true"]', [hi, q]);
    return h('div', { ref: th.ref, className: cx('ex-menu ex-mention-menu', th.has && 'has-thumb', th.ready && 'is-ready'), role: 'listbox', 'aria-label': 'Mention', style: props.inline ? { position: 'relative' } : { bottom: 36, left: 0 } },
      h('span', { className: 'ex-thumb ex-list-thumb', 'aria-hidden': 'true', style: th.style }),
      h('div', { className: 'ex-mm-q' }, h('span', { className: 'ex-mm-at' }, '@'), h('span', { className: 'ex-mono' }, q), h('span', { className: 'ex-caret', 'aria-hidden': 'true' })),
      groups.map(function (g) {
        if (!g.items.length) return null;
        return h(F, { key: g.id }, h('div', { className: 'ex-overline ex-menu-label' }, g.label),
          g.items.map(function (it, i) {
            idx++;
            var sel = idx === hi;
            return h('div', { key: i, role: 'option', 'aria-selected': String(sel), className: 'ex-menu-item ex-mm-item' },
              g.id === 'sessions' ? h(StatusGlyph, { status: it.status || 'done', size: 13 }) : g.id === 'tasks' ? h(StageGlyph, { stage: it.stage || 'active', size: 13 }) : h(Icon, { name: 'file', size: 13 }),
              h('span', { className: cx('ex-grow', g.id === 'files' && 'ex-mono') }, h(Highlight, { text: it.label, query: q })),
              it.meta ? h('span', { className: 'ex-combo-meta' }, it.meta) : null,
              sel ? h(Kbd, null, '↵') : null);
          }));
      }),
      h('div', { className: 'ex-mm-foot' }, h(Kbd, null, '↑↓'), ' choose', h('span', { className: 'ex-keys-sep' }), h(Kbd, null, '↵'), ' insert', h('span', { className: 'ex-keys-sep' }), h(Kbd, null, '⇥'), ' next group'));
  }

  /* Toast: brief confirmation with Undo; a thin bar shows the time left and pauses on hover. */
  function Toast(props) {
    return h('div', { className: cx('ex-toast', props.tone && 'is-' + props.tone), role: 'status', style: { '--ex-toast-time': (props.duration || 5000) + 'ms' } },
      props.tone === 'danger' ? h(StatusGlyph, { status: 'failed', size: 14 }) : h(StatusGlyph, { status: props.glyph || 'done', size: 14 }),
      h('span', { className: 'ex-toast-text' }, h('span', null, props.title), props.detail ? h('span', { className: 'ex-toast-detail' }, props.detail) : null),
      props.action ? h('button', { type: 'button', className: 'ex-toast-act', onClick: props.onAction }, props.action) : null,
      h('button', { type: 'button', className: 'ex-toast-x', 'aria-label': 'Dismiss', onClick: props.onClose }, h(Icon, { name: 'x', size: 12 })),
      props.duration !== 0 ? h('span', { className: 'ex-toast-bar', 'aria-hidden': 'true' }) : null);
  }

  /* Tooltip bubble: name plus shortcut. Shown after 400ms, then instantly for 600ms while you move along a toolbar. */
  function Tooltip(props) {
    return h('span', { className: cx('ex-tip', 'is-' + (props.side || 'top')), role: 'tooltip' }, props.label, props.kbd ? h('span', { className: 'ex-tip-kbd' }, props.kbd) : null);
  }

  /* Skeletons: only after 150ms of waiting, shimmering, replaced in place. */
  function Skeleton(props) {
    var v = props.variant || 'rows';
    var n = props.count || 3;
    if (v === 'message') return h('div', { className: 'ex-skel-msg', 'aria-busy': 'true', 'aria-label': 'Loading' },
      h('span', { className: 'ex-skel', style: { width: 120, height: 12 } }),
      h('span', { className: 'ex-skel', style: { width: '92%', height: 12 } }), h('span', { className: 'ex-skel', style: { width: '78%', height: 12 } }), h('span', { className: 'ex-skel', style: { width: '54%', height: 12 } }));
    return h('div', { className: 'ex-skel-rows', 'aria-busy': 'true', 'aria-label': 'Loading' }, Array.apply(null, Array(n)).map(function (_, i) {
      return h('div', { key: i, className: 'ex-skel-row' }, h('span', { className: 'ex-skel', style: { width: 14, height: 14, borderRadius: 7 } }), h('span', { className: 'ex-skel', style: { width: (52 + (i * 17) % 38) + '%', height: 10 } }));
    }));
  }

  /* How full the agent's context is: a ring that turns attention near the limit. */
  function ContextMeter(props) {
    var u = Math.max(0, Math.min(1, props.used || 0));
    var tone = u >= 0.9 ? 'danger' : u >= 0.75 ? 'attention' : 'ok';
    var r = 5.25, c = 2 * Math.PI * r;
    return h('span', { className: cx('ex-ctx', 'is-' + tone, props.compact && 'is-compact'), title: 'Context ' + Math.round(u * 100) + '% used' + (props.tokens ? ' · ' + props.tokens : '') },
      h('svg', { width: 14, height: 14, viewBox: '0 0 14 14', 'aria-hidden': 'true' },
        h('circle', { cx: 7, cy: 7, r: r, fill: 'none', stroke: 'currentColor', strokeOpacity: 0.22, strokeWidth: 1.75 }),
        h('circle', { className: 'ex-ctx-arc', cx: 7, cy: 7, r: r, fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeDasharray: c, strokeDashoffset: c * (1 - u), transform: 'rotate(-90 7 7)' })),
      props.compact ? null : h('span', { className: 'ex-ctx-pct' }, Math.round(u * 100) + '%'));
  }

  /* Pill that appears when new messages arrive below what you're reading. */
  function NewMessagesPill(props) {
    return h('button', { type: 'button', className: 'ex-newmsg' }, h(Icon, { name: 'arrow-down', size: 13 }), (props.count || 1) + (props.count === 1 ? ' new message' : ' new messages'));
  }

  /* Progress: determinate (value 0–1) or indeterminate (no value). */
  function ProgressLine(props) {
    var det = props.value != null;
    return h('span', { className: cx('ex-progress', !det && 'is-indeterminate'), role: 'progressbar', 'aria-valuenow': det ? Math.round(props.value * 100) : undefined, 'aria-valuemin': 0, 'aria-valuemax': 100 },
      h('span', { className: 'ex-progress-fill', style: det ? { transform: 'scaleX(' + props.value + ')' } : undefined }));
  }

  /* ════ Agent turns: the work, condensed ════ */

  /* Height that animates to and from auto (CSS grid 1fr ↔ 0fr). Content stays mounted. */
  function Fold(props) {
    /* Clipped only while it moves or is closed: once open and settled, focus rings and hover fills can spill out. */
    var open = !!props.open;
    var _s = React.useState(open); var settled = _s[0], setSettled = _s[1];
    var was = React.useRef(open);
    if (was.current !== open) { was.current = open; if (settled) setSettled(false); }
    React.useEffect(function () {
      if (!open || settled) return;
      var t = setTimeout(function () { setSettled(true); }, 420);
      return function () { clearTimeout(t); };
    }, [open, settled]);
    return h('div', { className: cx('ex-fold', open ? 'is-open' : 'is-closed', open && settled && 'is-settled', props.className), 'aria-hidden': open ? undefined : 'true', inert: open ? undefined : 'true',
      onTransitionEnd: function (e) { if (e.target === e.currentTarget && open && e.propertyName === 'grid-template-rows') setSettled(true); } }, h('div', { className: 'ex-fold-in' }, props.children));
  }

  var STEP_META = {
    think: { icon: 'bulb', verb: 'Thought' }, read: { icon: 'file', verb: 'Read' }, search: { icon: 'search', verb: 'Searched' },
    list: { icon: 'search', verb: 'Listed' }, edit: { icon: 'changes', verb: 'Edited' }, create: { icon: 'plus', verb: 'Created' },
    run: { icon: 'terminal', verb: 'Ran' }, test: { icon: 'terminal', verb: 'Tested' }, tool: { icon: 'plug', verb: 'Used' },
    web: { icon: 'globe', verb: 'Opened' }, ask: { icon: 'question', verb: 'You answered' }, note: { icon: null, verb: '' } };
  var GATHER = { read: 1, search: 1, list: 1, think: 1 };

  function fmtDur(sec) {
    sec = Math.max(0, Math.round(sec || 0));
    if (sec < 60) return sec + 's';
    var m = Math.floor(sec / 60), s = sec % 60;
    if (m < 60) return m + 'm' + (s ? ' ' + s + 's' : '');
    return Math.floor(m / 60) + 'h ' + (m % 60) + 'm';
  }
  /* Consecutive look-around steps (reads, searches, thinking) collapse into one row. */
  function groupSteps(steps) {
    var out = [], run = [];
    function flush() {
      if (run.length >= 2) {
        var c = {}; run.forEach(function (s) { c[s.kind] = (c[s.kind] || 0) + 1; });
        var parts = [];
        if (c.think) parts.push('thought');
        if (c.read) parts.push('read ' + c.read + (c.read === 1 ? ' file' : ' files'));
        if (c.search) parts.push('searched ' + c.search + (c.search === 1 ? ' time' : ' times'));
        if (c.list) parts.push('listed ' + c.list + (c.list === 1 ? ' folder' : ' folders'));
        var label = parts.join(', '); label = label.charAt(0).toUpperCase() + label.slice(1);
        out.push({ kind: 'group', label: label, items: run.slice(), status: run.some(function (s) { return s.status === 'running'; }) ? 'running' : 'done' });
      } else out.push.apply(out, run);
      run = [];
    }
    (steps || []).forEach(function (s) { if (GATHER[s.kind] && !(s.kind === 'think' && (s.text || s.title))) run.push(s); else { flush(); out.push(s); } });
    flush();
    return out;
  }
  /* A failure is history once the agent got past it: a later success of the same kind supersedes it, and a
     failure the agent caused on purpose (reproducing a bug) is marked expected. Only what still fails stays loud. */
  function settle(steps) {
    steps = steps || [];
    return steps.map(function (s, i) {
      if (s.status !== 'failed' || s.recovered || s.expected) return s;
      if (s.kind === 'run' || s.kind === 'test') {
        for (var j = i + 1; j < steps.length; j++) if ((steps[j].kind === 'run' || steps[j].kind === 'test') && steps[j].status !== 'failed' && steps[j].status !== 'running') return Object.assign({}, s, { recovered: 'passed later' });
      }
      return s;
    });
  }
  /* What a finished turn did, in a few facts, most important first. */
  function summarize(steps) {
    var files = {}, add = 0, del = 0, runs = 0, reads = 0, fails = 0, test = null, asks = 0;
    steps = settle(steps);
    (steps || []).forEach(function (s) {
      if (s.kind === 'edit' || s.kind === 'create') { files[s.detail] = 1; add += (s.diff && s.diff.add) || 0; del += (s.diff && s.diff.del) || 0; }
      if (s.kind === 'run') runs++;
      if (s.kind === 'read') reads++;
      if (s.kind === 'test') test = s;
      if (s.kind === 'ask') asks++;
      if (s.status === 'failed' && !s.recovered && !s.expected) fails++;
    });
    var facts = [];
    if (fails) facts.push({ tone: 'danger', icon: 'x', text: fails + (fails === 1 ? ' step failed' : ' steps failed') });
    var nf = Object.keys(files).length;
    if (nf) facts.push({ icon: 'changes', text: 'Edited ' + nf + (nf === 1 ? ' file' : ' files'), diff: { add: add, del: del } });
    if (test) facts.push({ tone: test.status === 'failed' && !test.recovered ? 'danger' : 'ok', icon: test.status === 'failed' && !test.recovered ? 'x' : 'check', text: test.result || test.meta || 'Tests' });
    if (runs) facts.push({ icon: 'terminal', text: 'Ran ' + runs + (runs === 1 ? ' command' : ' commands') });
    if (reads && facts.length < 4) facts.push({ icon: 'file', text: 'Read ' + reads + (reads === 1 ? ' file' : ' files') });
    if (asks && facts.length < 4) facts.push({ icon: 'question', text: asks === 1 ? '1 decision' : asks + ' decisions' });
    return facts.slice(0, 4);
  }

  function Fact(props) {
    var f = props.fact;
    return h('span', { className: cx('ex-fact', f.tone && 'is-' + f.tone), style: { '--i': props.index || 0 } },
      h(Icon, { name: f.icon, size: 12 }), f.text, f.diff ? h(Diff, f.diff) : null);
  }

  /* Interim messages: what the agent says while it works (kind 'say'; 'note' is the older name). */
  function isSay(s) { return s && (s.kind === 'say' || s.kind === 'note'); }

  function TimelineStep(props) {
    var s = props.step;
    var _o = React.useState(!!s.open); var open = _o[0], setOpen = _o[1];
    if (isSay(s)) return h('div', { className: 'ex-tl-say', style: { '--i': props.index } }, s.text);
    var meta = STEP_META[s.kind] || STEP_META.tool;
    var isGroup = s.kind === 'group', isThink = s.kind === 'think';
    var expandable = isGroup || !!s.output || !!s.hunk || (isThink && !!s.text);
    var st = s.status || 'done';
    var calm = s.recovered || s.expected;
    return h('div', { className: cx('ex-tl-step', 'is-' + st, isThink && 'is-think', s.recovered && 'is-recovered', s.expected && 'is-expected', open && 'is-open'), style: { '--i': props.index } },
      h('span', { className: 'ex-tl-dot', 'aria-hidden': 'true' }, st === 'running' ? h(StatusGlyph, { status: 'running', size: 12 }) : st === 'failed' && !calm ? h(StatusGlyph, { status: 'failed', size: 12 }) : h(Icon, { name: isGroup ? 'search' : meta.icon || 'check', size: 12 })),
      h('div', { className: 'ex-tl-body' },
        h('button', { type: 'button', className: 'ex-tl-head', onClick: expandable ? function () { setOpen(!open); } : undefined, 'aria-expanded': expandable ? String(open) : undefined, tabIndex: expandable ? 0 : -1 },
          h('span', { className: 'ex-tl-verb' }, isGroup ? s.label : (s.verb || meta.verb)),
          isThink && s.title ? h('span', { className: 'ex-tl-title' }, s.title) : null,
          !isGroup && !isThink && s.detail ? h('span', { className: 'ex-mono ex-tl-detail' }, s.detail) : null,
          s.diff ? h(Diff, s.diff) : null,
          s.recovered ? h('span', { className: 'ex-tl-tag' }, s.recovered === true ? 'fixed' : s.recovered) : s.expected ? h('span', { className: 'ex-tl-tag' }, s.expected === true ? 'reproduced' : s.expected) : null,
          h('span', { style: { flex: 1 } }),
          s.meta ? h('span', { className: cx('ex-tl-meta', st === 'failed' && !calm && 'is-bad') }, s.meta) : null,
          s.dur ? h('span', { className: 'ex-tl-dur' }, s.dur) : null,
          expandable ? h(Icon, { name: 'chevron-right', size: 12, className: 'ex-tl-chev' }) : null),
        expandable ? h(Fold, { open: open },
          isGroup ? h('div', { className: 'ex-tl-files' }, s.items.map(function (it, i) { return h('span', { key: i, className: 'ex-tl-file' }, h(Icon, { name: (STEP_META[it.kind] || {}).icon || 'file', size: 11 }), h('span', { className: 'ex-mono' }, it.detail || (STEP_META[it.kind] || {}).verb)); }))
            : isThink ? h('div', { className: 'ex-tl-think' }, s.text)
            : s.hunk ? h('div', { className: 'ex-hunk ex-tl-out' }, s.hunk.map(function (l, i) { return h('div', { key: i, className: l[0] === '+' ? 'add' : l[0] === '-' ? 'del' : null }, h('i', null, l[0] === '+' || l[0] === '-' ? (l[0] === '-' ? '−' : '+') : ''), l.slice(1)); }))
            : h('pre', { className: 'ex-tl-out ex-step2-out' }, s.output)) : null));
  }

  /* The thread of a turn: what the agent said, and the steps under it.
     Live, it keeps the latest thing the agent said plus the last few steps; the rest folds into “N earlier steps”. */
  function WorkTimeline(props) {
    var rows = groupSteps(settle((props.steps || []).map(function (st, i) { return Object.assign({}, st, { _i: i }); })));
    var max = props.maxVisible || 4;
    var _a = React.useState(false); var all = _a[0], setAll = _a[1];
    var parts = rows.map(function (s, i) { return { s: s, i: i }; });
    if (props.live && !all) {
      var lastSay = -1; rows.forEach(function (s, i) { if (isSay(s)) lastSay = i; });
      var tail = parts.slice(lastSay + 1), keepTail = tail.slice(-max);
      var head = lastSay >= 0 ? parts.slice(0, lastSay) : parts.slice(0, parts.length - keepTail.length);
      var mid = lastSay >= 0 ? tail.slice(0, tail.length - keepTail.length) : [];
      /* folding a single row saves nothing: show it */
      function fold(list, k) { return list.length >= 2 ? [{ more: list.length, k: k }] : list; }
      parts = fold(head, 'b').concat(lastSay >= 0 ? [{ s: rows[lastSay], i: lastSay }] : [], fold(mid, 'm'), keepTail);
    }
    var n = 0;
    return h(MotionList, { as: 'ol', itemAs: 'li', className: cx('ex-timeline', props.live && 'is-live'), items: parts.map(function (p) {
      if (p.more) return { key: 'more-' + p.k, node: h('div', { className: 'ex-tl-step is-more' }, h('span', { className: 'ex-tl-dot', 'aria-hidden': 'true' }, h(Icon, { name: 'more', size: 12 })),
        h('button', { type: 'button', className: 'ex-tl-head ex-tl-more', onClick: function () { setAll(true); } }, h(Ticker, { value: p.more }), p.more === 1 ? ' earlier step' : ' earlier steps')) };
      var k = p.s.kind === 'group' ? p.s.items[0]._i : p.s._i;
      return { key: 's' + k, node: h(TimelineStep, { step: p.s, index: n++ }) };
    }) });
  }

  /* What the agent is doing right now: one line that rolls to the next action.
     While it thinks, the line also shows the last lines of its reasoning, fading at the top. */
  function NowLine(props) {
    var meta = STEP_META[props.kind] || {};
    var think = props.kind === 'think' && !!props.text;
    var lastText = React.useRef(props.text); if (think) lastText.current = props.text;
    return h('div', { className: cx('ex-now', think && 'is-think'), 'aria-live': 'polite' },
      h('div', { className: 'ex-now-row' },
        h(StatusGlyph, { status: 'running', size: 14 }),
        h('span', { key: (props.verb || '') + (props.detail || '') + (props.title || ''), className: 'ex-now-text' },
          h('span', { className: 'ex-now-verb' }, props.verb || meta.verb || 'Working'),
          props.title ? h('span', { className: 'ex-now-title' }, props.title) : props.detail ? h('span', { className: 'ex-mono ex-now-detail' }, props.detail) : null),
        h('span', { style: { flex: 1 } }),
        props.meta ? h('span', { className: 'ex-now-meta' }, props.meta) : null,
        props.elapsed != null ? h('span', { className: 'ex-now-time' }, fmtDur(props.elapsed)) : null),
      lastText.current ? h(Fold, { open: think, className: 'ex-now-think-fold' }, h('div', { className: 'ex-now-think' }, props.stream && think ? h(StreamText, { demo: true, text: props.text, speed: 45, streaming: false }) : h('p', { className: 'ex-stream' }, lastText.current))) : null,
      props.progress != null ? h('span', { className: 'ex-now-bar' }, h(ProgressLine, { value: props.progress })) : null);
  }

  /* A file the turn changed: name first, folder muted, diff; opens it in Changes. */
  function FileChip(props) {
    var parts = String(props.path || '').split('/'); var name = parts.pop();
    return h('button', { type: 'button', className: 'ex-filechip', style: { '--i': props.index || 0 }, title: props.path },
      h(Icon, { name: props.status === 'A' ? 'plus' : 'file', size: 12 }), h('span', { className: 'ex-filechip-name' }, name),
      parts.length ? h('span', { className: 'ex-filechip-dir' }, parts.join('/')) : null, h(Diff, { add: props.add || 0, del: props.del || 0 }));
  }
  /* What a finished turn left behind: files to review, and the one next action. */
  function OutcomeBar(props) {
    var files = props.files || [];
    var max = props.max || 3;
    return h('div', { className: 'ex-outcome' },
      files.slice(0, max).map(function (f, i) { return h(FileChip, Object.assign({ key: f.path, index: i }, f)); }),
      files.length > max ? h('button', { type: 'button', className: 'ex-filechip is-more', style: { '--i': max } }, '+' + (files.length - max) + ' more') : null,
      h('span', { style: { flex: 1 } }),
      props.action ? h(Button, { variant: 'ghost', size: 'sm', icon: props.actionIcon || 'changes' }, props.action) : null);
  }



  /* One agent turn, in the chat's reply column: the agent's mark in a narrow gutter, the work line, the answer.
     Live: “Working” with a thread of what it says and does, the current action, the reply streaming; a line runs
     down the gutter beside the thread. Finished: “Worked 4m 12s”; its facts appear on hover, failures always show. */
  var NOW_VERB = { run: 'Running', test: 'Testing', read: 'Reading', search: 'Searching', list: 'Listing', edit: 'Editing', create: 'Creating', tool: 'Using', web: 'Opening', think: 'Thinking' };
  function Turn(props) {
    var status = props.status || 'done';
    var live = status === 'live';
    var steps = props.steps || [];
    var _o = React.useState(!!props.open); var open = _o[0], setOpen = _o[1];
    var prev = React.useRef(status);
    var _f = React.useState(false); var folding = _f[0], setFolding = _f[1];
    useLayout(function () {
      if (prev.current === 'live' && status !== 'live') { setFolding(true); setOpen(false); var t = setTimeout(function () { setFolding(false); }, 900); prev.current = status; return function () { clearTimeout(t); }; }
      prev.current = status;
    }, [status]);
    /* the render that sees the turn finish already counts as folding, so the thread never flashes its full list */
    var foldingNow = folding || (prev.current === 'live' && !live);
    var facts = live ? [] : summarize(steps);
    var nowStep = live ? steps.filter(function (s) { return s.status === 'running'; }).slice(-1)[0] : null;
    var now = useHold(nowStep, 700);
    var doneSteps = live ? steps.filter(function (s) { return s.status !== 'running'; }) : steps;
    var count = doneSteps.filter(function (s) { return !isSay(s); }).length;
    var thread = live || open;
    var label = live ? 'Working' : status === 'paused' ? 'Paused after ' + fmtDur(props.duration) : status === 'stopped' ? 'Stopped after ' + fmtDur(props.duration) : status === 'failed' ? 'Failed after ' + fmtDur(props.duration) : 'Worked ' + fmtDur(props.duration);
    var outcome = props.outcome || {}, files = outcome.files || [], max = outcome.max || 3;
    var who = (props.author || 'Opus 5.5') + (props.time ? ' · ' + props.time : '');
    var workKids = live ? [
        h(StatusGlyph, { key: 'g', status: 'running', size: 13 }),
        h('span', { key: 'w', className: 'ex-work-label ex-shimmer-text' }, label),
        props.elapsed != null ? h('span', { key: 't', className: 'ex-work-time' }, fmtDur(props.elapsed)) : null,
        count ? h('span', { key: 'c', className: 'ex-work-count' }, '· ', h(Ticker, { value: count }), count === 1 ? ' step' : ' steps') : null,
        props.onStop !== false ? h('button', { key: 's', type: 'button', className: 'ex-work-stop', title: 'Stop  ⌘.', onClick: props.onStop }, h(Icon, { name: 'stop', size: 10 }), 'Stop') : null]
      : [
        h('span', { key: 'd', className: cx('ex-work-label', status === 'failed' && 'is-bad') }, label),
        h('span', { key: 'f', className: 'ex-work-facts', ref: function (el) { if (el) requestAnimationFrame(function () { el.classList.toggle('is-clipped', el.scrollWidth > el.clientWidth + 1); }); } },
          facts.map(function (f, i) { return h('span', { key: i, className: cx('ex-work-item', f.tone === 'danger' && 'is-pinned'), style: { '--i': i } }, h(Fact, { fact: f, index: i })); })),
        h('span', { key: 'chev', className: 'ex-work-item ex-work-chevitem', style: { '--i': facts.length } }, h(Icon, { name: 'chevron-right', size: 12, className: 'ex-work-chev' }))];
    var ns = now.value;
    return h('section', { className: cx('ex-turn', 'is-' + status, foldingNow && 'is-folding', thread && steps.length && 'is-thread'), 'aria-label': 'Agent turn' }, h(AutoHeight, { innerClassName: 'ex-turn-grid' },
      h('div', { className: 'ex-turn-gutter', 'aria-hidden': 'true' },
        h('span', { className: cx('ex-turn-avatar', live && 'is-live'), title: who }, h(AgentMark, { mark: props.mark || 'Cl' })),
        h('span', { className: 'ex-turn-line' })),
      h('div', { className: 'ex-turn-body' },
        steps.length ? (live
          ? h('div', { className: 'ex-work' }, workKids)
          : h('button', { type: 'button', className: 'ex-work', 'aria-expanded': String(open), onClick: function () { setOpen(!open); } }, workKids)) : null,
        steps.length ? h(Fold, { open: thread, className: 'ex-thread-fold' }, h(WorkTimeline, { steps: doneSteps, live: live || foldingNow, maxVisible: props.maxVisible })) : null,
        ns ? h(Fold, { open: live && now.on, className: 'ex-now-fold' }, h(NowLine, { kind: ns.kind, verb: ns.verb || NOW_VERB[ns.kind], detail: ns.detail, title: ns.title, text: ns.text, stream: ns.stream, meta: ns.meta, elapsed: ns.elapsed, progress: ns.progress })) : null,
        props.error ? h('div', { className: 'ex-turn-error' }, h(StatusGlyph, { status: 'failed', size: 14 }), h('span', { className: 'ex-grow' }, props.error), h(Button, { variant: 'secondary', size: 'sm', icon: 'reset' }, 'Retry')) : null,
        /* paused at a plan limit: it picks up by itself where it stopped when the limit resets; or continue elsewhere */
        status === 'paused' ? h('div', { className: 'ex-turn-paused' }, h(StatusGlyph, { status: 'paused', size: 14 }),
          h('span', { className: 'ex-grow' }, h('b', null, 'Paused at the ' + ((props.pause && props.pause.plan) || 'plan') + ' limit.'), ' It picks up where it stopped ' + (props.pause && props.pause.resumes ? 'at ' + props.pause.resumes : 'when the limit resets') + '.'),
          props.pause && props.pause.forkTo ? h(Button, { variant: 'secondary', size: 'sm', icon: 'fork', onClick: props.pause.onFork }, 'Fork to ' + props.pause.forkTo) : null,
          h(Button, { variant: 'ghost', size: 'sm', onClick: props.pause && props.pause.onStop }, 'Stop')) : null,
        status === 'stopped' ? h('div', { className: 'ex-turn-stopped' }, h('span', { className: 'ex-grow' }, 'You stopped this turn. Nothing after the last step ran.'), h(Button, { variant: 'secondary', size: 'sm', icon: 'arrow-up' }, 'Continue')) : null,
        props.children ? h('div', { className: 'ex-turn-answer' }, props.children) : null,
        h(Fold, { open: !live, className: 'ex-turn-foot-fold' }, h('div', { className: 'ex-turn-foot' },
          h('span', { className: 'ex-turn-files' },
            files.slice(0, max).map(function (f, i) { return h(FileChip, Object.assign({ key: f.path, index: i }, f)); }),
            files.length > max ? h('button', { type: 'button', className: 'ex-filechip is-more', style: { '--i': max } }, '+' + (files.length - max)) : null),
          h(TurnActs),
          files.length || outcome.action ? h(Button, { variant: 'ghost', size: 'sm', icon: outcome.actionIcon || 'changes' }, outcome.action || 'Review') : null)))));
  }

  /* A slim map of the session's turns at the chat's edge: jump to any; changes and needs-you stand out. */
  function TurnNav(props) {
    var turns = props.turns || [];
    return h('nav', { className: 'ex-turnnav', 'aria-label': 'Turns' }, turns.map(function (t, i) {
      return h('button', { key: i, type: 'button', className: cx('ex-turnnav-item', t.id === props.active && 'is-active', t.state && 'is-' + t.state), 'aria-label': t.label, 'aria-current': t.id === props.active ? 'true' : undefined },
        h('span', { className: 'ex-turnnav-bar' }), h('span', { className: 'ex-turnnav-tip' }, h('span', { className: 'ex-turnnav-label' }, t.label), t.meta ? h('span', { className: 'ex-turnnav-meta' }, t.meta) : null));
    }));
  }


  /* ═════ Machines: where Elevenex runs ═════
     One machine per window. A window is Home (no machine), getting ready (connecting, installing, updating), or on a machine.
     Home connects to nothing; opening a machine connects to it; a connection lives while a window uses it. */
  var MACHINE_ICON = { local: 'laptop', ssh: 'server', peer: 'peer' };
  function machineLive(m) { return m.conn === 'live' || m.conn === 'kept'; }

  /* The title-bar island: one pill that names the window's machine and grows to say something, then shrinks back. */
  function TitleIsland(props) {
    var outer = React.useRef(null), inner = React.useRef(null);
    useLayout(function () { var o = outer.current, i = inner.current; if (!o || !i) return; o.style.width = i.offsetWidth + 'px'; o.style.height = i.offsetHeight + 'px'; });
    var tone = props.tone || 'rest';
    return h(props.onClick ? 'button' : 'div', { ref: outer, type: props.onClick ? 'button' : undefined, onClick: props.onClick, 'aria-expanded': props.onClick ? String(!!props.open) : undefined,
        className: cx('ex-island', 'is-' + tone, props.tall && 'is-tall', props.open && 'is-open', props.className), role: props.onClick ? undefined : 'status', 'aria-live': 'polite' },
      h('div', { key: props.contentKey, ref: inner, className: 'ex-island-in' }, props.children),
      props.progress != null ? h('span', { className: 'ex-island-p', style: { transform: 'scaleX(' + Math.max(0, Math.min(1, props.progress)) + ')' } }) : null);
  }
  /* The window's own title bar: the window controls on the left and the island centered. Window chrome, not an app bar: no actions, no tabs. */
  function TitleBar(props) {
    return h('div', { className: cx('ex-titlebar', props.className) }, h('span', { className: 'ex-titlebar-lights', 'aria-hidden': 'true' }, h('i'), h('i'), h('i')),
      h('div', { className: 'ex-titlebar-island' }, props.children));
  }
  /* The island's resting content: color dot, kind icon, name, and a mark per connected computer. */
  function IslandName(props) {
    var m = props.machine || {};
    /* `back`: on Home after Change, the machine this window just left; clicking the island opens it again */
    return h(F, null, props.back ? h(Icon, { name: 'back', size: 12, className: 'ex-island-back' }) : null, h('span', { className: 'ex-island-dot', style: { background: m.color || 'var(--accent)' } }), h(Icon, { name: MACHINE_ICON[m.kind] || 'laptop', size: 13 }), h('span', { className: 'ex-island-name' }, props.back ? 'Back to ' + m.name : m.name),
      props.guests ? h('span', { className: 'ex-island-mark' }, h(Icon, { name: 'peer', size: 11 }), props.guests) : null);
  }
  /* A moment the island grows for (someone connected, back online): an icon, two lines, one action. Shrinks back on its own. */
  function IslandEvent(props) {
    return h('span', { className: 'ex-island-ev' }, h('span', { className: 'ex-island-ev-i' }, h(Icon, { name: props.icon || 'peer', size: 15 })),
      h('span', null, h('span', { className: 'ex-island-ev-t' }, props.title), props.sub ? h('span', { className: 'ex-island-ev-s' }, props.sub) : null),
      props.action ? h('button', { type: 'button', className: 'ex-island-ev-a ex-mpanel-chip', onClick: props.onAction }, props.action) : null);
  }
  /* The island open: the machine (and changing it) on top, its connection and who else is on it, other windows at the foot. */
  function MachinePanel(props) {
    var m = props.machine || {}, guests = props.guests || [], hi = props.highlight;
    return h('div', { className: 'ex-mpanel' },
      h('div', { className: 'ex-mpanel-head' }, h('span', { className: 'ex-mpanel-ic' }, h(Icon, { name: MACHINE_ICON[m.kind] || 'laptop', size: 16 }), h('span', { className: 'ex-island-dot', style: { background: m.color || 'var(--accent)' } })),
        h('span', { className: 'ex-mgrow ex-mpanel-id' }, h('span', { className: 'ex-mpanel-name' }, m.name), h('span', { className: 'ex-mpanel-sub' }, m.address || m.sub)),
        h('button', { type: 'button', className: cx('ex-mpanel-chip', hi === 'change' && 'is-hi'), onClick: props.onChange }, 'Change')),
      m.kind === 'ssh' ? h('div', { className: 'ex-mpanel-sec' }, h('div', { className: 'ex-mpanel-label' }, 'Connection'),
        h('div', { className: 'ex-mpanel-row' }, h('span', { className: 'ex-mpanel-av' }, h(Icon, { name: 'server', size: 13 })),
          h('span', { className: 'ex-mgrow ex-mpanel-id' }, h('span', { className: 'ex-mpanel-strong' }, 'Connected over SSH'), h('span', { className: 'ex-mpanel-sub' }, 'Shared by its windows; drops when none uses it')),
          h('button', { type: 'button', className: 'ex-mpanel-chip is-quiet', onClick: props.onDisconnect }, 'Disconnect'))) : null,
      guests.length ? h('div', { className: 'ex-mpanel-sec' }, h('div', { className: 'ex-mpanel-label' }, 'Also using ' + (m.kind === 'local' ? 'this Mac' : m.name)),
        guests.map(function (g) {
          return h('div', { key: g.name, className: 'ex-mpanel-row' }, h('span', { className: 'ex-mpanel-av is-guest' }, h(Icon, { name: 'peer', size: 13 })),
            h('span', { className: 'ex-mgrow ex-mpanel-id' }, h('span', { className: 'ex-mpanel-strong' }, g.name), h('span', { className: 'ex-mpanel-sub' }, 'Connected since ' + g.since)),
            h('button', { type: 'button', className: 'ex-mpanel-chip is-quiet', onClick: function () { props.onDisconnectGuest && props.onDisconnectGuest(g); } }, 'Disconnect'));
        })) : null,
      h('button', { type: 'button', className: cx('ex-mpanel-new', hi === 'new' && 'is-hi'), onClick: props.onNewWindow }, h(Icon, { name: 'window', size: 14 }), h('span', { className: 'ex-mpanel-strong' }, 'New window'), h('span', { className: 'ex-mpanel-sub' }, 'on any machine'), h('span', { className: 'ex-mgrow' }), h('kbd', { className: 'ex-kbd' }, '⇧⌘N')));
  }

  /* A machine on Home. Connected ones say what's happening now; the others say what we knew last, dated. */
  function MachineCard(props) {
    var m = props.machine, err = !m.busy && m.error, busy = m.busy, live = !busy && !err && machineLive(m);
    /* getting ready → ready: the dot settles once (never on first paint) */
    var was = React.useRef(!!busy), done = React.useRef(false), failed = React.useRef(false);
    var nudge = !!err && was.current; /* getting ready → failed: one small shake, never on first paint */
    if (busy) done.current = false; else if (was.current && !err) done.current = true; was.current = !!busy; var settle = done.current && !err;
    if (!err) failed.current = false; else if (nudge) failed.current = true;
    var bar = usePresence(!!busy, 240);
    var danger = err && err.tone === 'danger', action = err ? (err.action || 'Try again') : null;
    var dot = busy ? 'is-busy' : err ? (danger ? 'is-danger' : 'is-fail') : m.update ? 'is-info' : live ? 'is-on' : m.conn === 'fail' ? 'is-fail' : 'is-idle';
    var tag = busy ? (props.pending ? h('span', { key: 'p', className: 'ex-mcard-tag is-accent ex-mswap' }, 'Will open') : null)
      : err ? h('span', { key: 'e', className: 'ex-mcard-act ex-mswap', 'aria-hidden': 'true' }, action === 'Try again' ? h(Icon, { name: 'refresh', size: 11 }) : null, action)
      : m.update ? h('span', { className: 'ex-mcard-tag is-info' }, 'Update') : m.windows ? h('span', { className: 'ex-mcard-tag' }, m.windows + (m.windows > 1 ? ' windows' : ' window')) : m.conn === 'kept' ? h('span', { className: 'ex-mcard-tag' }, 'until you pick') : null;
    var line = busy ? h('span', { key: 'b-' + busy.step, className: 'ex-mswap' }, busy.step, busy.meta ? h('span', { className: 'ex-mcard-meta' }, ' · ' + busy.meta) : null)
      : err ? h('span', { key: 'e-' + err.step, className: 'ex-mswap' }, err.step)
      : h('span', { key: 'r-' + (settle ? 's' : 'n'), className: settle ? 'ex-mswap' : undefined }, m.update ? 'Had ' + m.update + ' · updates when opened' : live ? m.status : m.last);
    /* one control: the card is the action, and says so to a screen reader */
    var label = err ? m.name + '. ' + err.step + '. ' + action : undefined;
    function click() { if (err && props.onAction) props.onAction(m); else if (props.onOpen) props.onOpen(m); }
    var menuOn = !!props.onMenu;
    function menuAt(e) { if (!menuOn) return; e.preventDefault(); props.onMenu(m, { x: e.clientX, y: e.clientY, card: e.currentTarget }); }
    var card = h('button', { type: 'button', 'data-machine': m.id, 'data-key': menuOn ? undefined : m.id, 'aria-busy': busy ? 'true' : undefined, 'aria-label': label, onClick: click, onContextMenu: menuOn ? menuAt : undefined,
        className: cx('ex-mcard', props.highlighted && 'is-hi', props.pressed && 'is-press', !live && !busy && !err && 'is-idle', busy && 'is-busy', err && 'is-error', danger && 'is-danger', failed.current && 'is-nudge', props.leaving && !menuOn && 'is-leaving'), style: { '--mc': m.color || 'var(--ink)' } },
      h('span', { className: 'ex-mcard-top' }, h('span', { className: 'ex-mcard-ic' }, h(Icon, { name: MACHINE_ICON[m.kind] || 'laptop', size: 15 }), h('span', { className: cx('ex-mpres', dot, settle && 'is-settle') })),
        h('span', { className: 'ex-mgrow' }), tag, props.highlighted ? h('kbd', { className: 'ex-kbd' }, '↵') : null),
      h('span', { className: 'ex-mcard-name' }, m.name),
      h('span', { className: 'ex-mcard-line' }, line),
      bar.m ? h('span', { className: cx('ex-mcard-prog', bar.l && 'is-leaving') }, h(ProgressLine, { value: busy ? busy.progress : 1 }))
        : err && err.progress != null ? h('span', { className: 'ex-mcard-prog is-stopped' }, h(ProgressLine, { value: err.progress })) : null);
    if (!menuOn) return card;
    /* ⋯ on hover or focus, in the tag's place (the tag steps aside); a sibling of the card, never a button in a button */
    return h('div', { className: cx('ex-mcard-wrap', props.menuOpen && 'is-menu', props.leaving && 'is-leaving'), 'data-key': m.id }, card,
      h('button', { type: 'button', className: 'ex-mcard-more', 'aria-label': 'More for ' + m.name, 'aria-haspopup': 'menu', 'aria-expanded': String(!!props.menuOpen),
        onClick: function (e) { var r = e.currentTarget.getBoundingClientRect(); props.onMenu(m, { x: r.right, y: r.bottom + 6, card: e.currentTarget.parentNode.firstChild, fromButton: true }); } }, h(Icon, { name: 'more', size: 14 })));
  }
  /* An empty card that adds a machine: dashed, with what it adds. */
  function MachineAdd(props) {
    return h('button', { type: 'button', 'data-key': 'add-' + props.kind, className: 'ex-mcard is-add', onClick: function (e) { props.onClick && props.onClick(e.currentTarget); } },
      h('span', { className: 'ex-mcard-top' }, h('span', { className: 'ex-mcard-ic' }, h(Icon, { name: props.kind === 'peer' ? 'peer' : 'server', size: 15 }))),
      h('span', { className: 'ex-mcard-name' }, props.kind === 'peer' ? 'Another computer' : 'A server'),
      h('span', { className: 'ex-mcard-line' }, props.kind === 'peer' ? 'A Mac or PC running Elevenex. Pair it once.' : 'Over SSH. Elevenex installs itself there.'));
  }
  /* Cards that move when one is added or removed slide from where they were; a new one grows in where it lands. */
  function useGridFlip(ref, still) {
    var before = React.useRef(null);
    if (ref.current && !still) { var snap = {}; Array.prototype.forEach.call(ref.current.querySelectorAll('[data-key]'), function (n) { snap[n.getAttribute('data-key')] = { x: n.offsetLeft, y: n.offsetTop }; }); before.current = snap; }
    useLayout(function () {
      var root = ref.current, prev = before.current; before.current = null;
      if (!root || !prev || still || reducedMotion()) return;
      Array.prototype.forEach.call(root.querySelectorAll('[data-key]'), function (n) {
        var k = n.getAttribute('data-key'), b = prev[k];
        if (!b) { /* above the ones sliding away, a beat after they start */
          if (!n.animate) return; n.style.zIndex = '1';
          var a = n.animate([{ opacity: 0, transform: 'scale(.9)' }, { opacity: 1, transform: 'none' }], { duration: 320, delay: 60, easing: 'cubic-bezier(0.32, 0.72, 0, 1)', fill: 'backwards' });
          a.onfinish = a.oncancel = function () { n.style.zIndex = ''; }; return; }
        var dx = b.x - n.offsetLeft, dy = b.y - n.offsetTop;
        if (Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5) play(n, [{ transform: 'translate(' + dx + 'px,' + dy + 'px)' }, { transform: 'none' }], { ease: 'ease-in-out', dur: 'dur-glide' });
      });
    });
  }
  /* Home: what a window shows before it has a machine. */
  /* The island on Home points at a card: the window scrolls to it, and it springs a little and sends one ring in its state's
     color (amber failed, red for safety, running getting ready, accent otherwise). */
  function pingCard(card) {
    if (!card) return;
    try { card.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: reducedMotion() ? 'auto' : 'smooth' }); } catch (e) { card.scrollIntoView(false); }
    if (reducedMotion() || !card.animate) return;
    card.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.035)', offset: 0.35 }, { transform: 'scale(1)' }], { duration: 420, easing: 'cubic-bezier(0.2, 0.7, 0.3, 1)' });
    var root = card.parentNode, c = card.classList.contains('is-danger') ? 'var(--danger)' : card.classList.contains('is-error') ? 'var(--attention)' : card.classList.contains('is-busy') ? 'var(--running)' : 'var(--accent)';
    var r = document.createElement('span'); r.className = 'ex-mcard-ring';
    r.style.cssText = 'left:' + (card.offsetLeft - 4) + 'px;top:' + (card.offsetTop - 4) + 'px;width:' + (card.offsetWidth + 8) + 'px;height:' + (card.offsetHeight + 8) + 'px;color:' + c + ';';
    root.appendChild(r);
    r.animate([{ transform: 'scale(.97)', opacity: 0 }, { transform: 'scale(1)', opacity: 0.9, offset: 0.15 }, { transform: 'scale(1.08)', opacity: 0 }], { duration: 700, easing: 'cubic-bezier(0.2, 0.7, 0.3, 1)', fill: 'both' }).onfinish = function () { r.remove(); };
  }
  /* a machine that leaves Home (removed) stays a moment, collapsing out, before the others slide over */
  function useLeaving(list, ms) {
    var prev = React.useRef(list), _t = React.useState(0), tick = _t[1], going = React.useRef({});
    var ids = {}; list.forEach(function (m) { ids[m.id] = 1; });
    prev.current.forEach(function (m, i) { if (!ids[m.id] && !going.current[m.id]) { going.current[m.id] = { m: m, at: i }; setTimeout(function () { delete going.current[m.id]; tick(function (x) { return x + 1; }); }, ms); } });
    Object.keys(going.current).forEach(function (id) { if (ids[id]) delete going.current[id]; });
    prev.current = list;
    var out = list.slice(); Object.keys(going.current).forEach(function (id) { var g = going.current[id]; out.splice(Math.min(g.at, out.length), 0, Object.assign({}, g.m, { __leaving: true })); });
    return out;
  }
  function MachineHome(props) {
    var ms = useLeaving(props.machines || [], reducedMotion() ? 0 : 260), grid = React.useRef(null), launched = React.useContext(LaunchCtx), groups = React.useRef({}), wrap = React.useRef(null);
    useGridFlip(grid, launched);
    /* `ping`: { id, at } from the island's click; each new `at` points at that card */
    React.useEffect(function () { var p = props.ping; if (!p || !p.id || !wrap.current) return; pingCard(wrap.current.querySelector('[data-machine="' + p.id + '"]')); }, [props.ping && props.ping.at]);
    function pend(m) { var p = props.pending; return !!p && (p === m.id || (p.indexOf && p.indexOf(m.id) >= 0)); }
    function card(m) { return h(MachineCard, { key: m.id, machine: m, highlighted: props.highlighted === m.id, pressed: props.pressed === m.id, pending: pend(m), onOpen: props.onOpen, onAction: props.onAction, onMenu: props.onMenu, menuOpen: props.menuOpen === m.id, leaving: !!m.__leaving }); }
    function add(e) { if (props.onAdd) props.onAdd(e.currentTarget); }
    function pair(e) { if (props.onPair) props.onPair(e.currentTarget); }
    /* first run: the question as the title, every machine in one grid, then the two ways to add one, as cards */
    if (props.firstRun) return h('div', { ref: wrap, className: 'ex-mhome is-first' }, h('div', { className: 'ex-mhome-col' },
      h('div', { className: 'ex-mhome-head' }, h('div', { className: 'ex-mgrow' }, h('div', { className: 'ex-mhome-title' }, props.title || 'Where should your agents run?'), h('div', { className: 'ex-mhome-sub' }, props.subtitle || 'Open a machine to work on it. Add more any time: they all wait here.'))),
      h('div', { ref: grid, className: 'ex-mhome-grid' }, ms.map(card), h(MachineAdd, { kind: 'ssh', onClick: props.onAdd }), h(MachineAdd, { kind: 'peer', onClick: props.onPair }))));
    /* a card getting ready stays in its group, so it doesn't move away as you click it */
    /* while a machine is open (or opening) nothing on Home moves: a machine that just connected keeps its group until Home shows again */
    /* the same for the card being opened: getting ready or about to launch, it stays where you clicked it */
    function held(m) { return launched || !!m.busy || pend(m); }
    var g = {}; ms.forEach(function (m) { var was = groups.current[m.id]; g[m.id] = held(m) && was != null ? was : machineLive(m); }); groups.current = g;
    function isOn(m) { return g[m.id]; }
    var on = ms.filter(isOn), off = ms.filter(function (m) { return !isOn(m); });
    return h('div', { ref: wrap, className: 'ex-mhome' }, h('div', { ref: grid, className: 'ex-mhome-col' },
      h('div', { className: 'ex-mhome-head' }, h('div', { className: 'ex-mgrow' }, h('div', { className: 'ex-mhome-title' }, props.title || 'Machines'), h('div', { className: 'ex-mhome-sub' }, props.subtitle || 'Pick where this window runs')),
        h(props.onFind ? 'button' : 'span', { type: props.onFind ? 'button' : undefined, className: cx('ex-mhome-search', props.findOpen && 'is-on'), onClick: props.onFind }, h(Icon, { name: 'search', size: 13 }), h('span', { className: 'ex-mgrow' }, 'Find a machine'), h('kbd', { className: 'ex-kbd' }, '⌘O'))),
      on.length ? h(F, null, h('div', { className: 'ex-mhome-label' }, 'Connected'), h('div', { className: 'ex-mhome-grid' }, on.map(card))) : null,
      off.length ? h(F, null, h('div', { className: 'ex-mhome-label' }, 'Not connected', h('span', null, 'opening one connects to it')), h('div', { className: 'ex-mhome-grid' }, off.map(card))) : null,
      h('div', { className: 'ex-mhome-foot' }, h(Button, { size: 'sm', variant: 'ghost', icon: 'plus', onClick: add }, 'Add a server'), h(Button, { size: 'sm', variant: 'ghost', onClick: pair }, 'Pair a computer'))));
  }

  /* Opening a machine launches it like an app on a phone: its card becomes a box that grows to the window, the card's face
     fades as it grows, and the machine's view scales up inside the box (cover-fit, never stretched). Closing runs it backwards. */
  var LAUNCH_EASE = 'cubic-bezier(0.32, 0.72, 0, 1)';
  /* Home knows when its window has a machine open (or opening), so it holds still meanwhile */
  var LaunchCtx = React.createContext(false);
  /* Where a card is on screen, in the launch's own units (zoom-proof). Read before the commit that opens, so a card
     that's about to move (a regroup, a list reflow) still launches from where you saw it. */
  function launchRect(body, card) {
    var b = body.getBoundingClientRect(), c = card.getBoundingClientRect(), z = (body.offsetWidth && b.width / body.offsetWidth) || 1;
    return { l: (c.left - b.left) / z, t: (c.top - b.top) / z, w: c.width / z, h: c.height / z };
  }
  function runLaunch(body, pane, zoom, host, home, card, opening, from) {
    var r = from || launchRect(body, card), l = r.l, t = r.t, cw = r.w, ch = r.h;
    var W = body.offsetWidth, H = body.offsetHeight, R = parseFloat(getComputedStyle(card).borderTopLeftRadius) || 14;
    /* Home zooms around the card, so the card stays put while everything else grows past it */
    home.style.transformOrigin = (l + cw / 2) + 'px ' + (t + ch / 2 + home.scrollTop) + 'px';
    var cardBg = getComputedStyle(card).backgroundColor, appBg = getComputedStyle(pane).backgroundColor, N = 14, kp = [], kz = [], kf = [];
    for (var i = 0; i <= N; i++) {
      var q = i / N, p = opening ? q : 1 - q, x = l * (1 - p), y = t * (1 - p), w = cw + (W - cw) * p, hh = ch + (H - ch) * p;
      var sc = Math.max(w / W, hh / H), sf = Math.min(w / cw, hh / ch);
      kp.push({ offset: q, clipPath: 'inset(' + y + 'px ' + (W - x - w) + 'px ' + (H - y - hh) + 'px ' + x + 'px round ' + (R * sf * Math.min(1, 2 * (1 - p)) + 0.01) + 'px)', backgroundColor: p < 0.35 ? cardBg : appBg, opacity: (!opening && i === N) ? 0 : 1 });
      kz.push({ offset: q, transform: 'translate(' + (x + w / 2 - W * sc / 2) + 'px,' + (y + hh / 2 - H * sc / 2) + 'px) scale(' + sc + ')', opacity: Math.max(0, Math.min(1, (p - 0.18) / 0.4)) });
      kf.push({ offset: q, transform: 'translate(' + (x - l) + 'px,' + (y - t) + 'px) scale(' + (w / cw) + ',' + (hh / ch) + ')', opacity: Math.max(0, Math.min(1, 1 - (p - 0.12) / 0.38)) });
    }
    var face = card.cloneNode(true); face.classList.remove('is-hi', 'is-press'); face.classList.add('ex-launch-face'); face.removeAttribute('data-machine'); face.setAttribute('tabindex', '-1');
    face.style.left = l + 'px'; face.style.top = t + 'px'; face.style.width = cw + 'px'; face.style.height = ch + 'px';
    host.appendChild(face); card.classList.add('is-launching');
    var opt = { duration: opening ? 560 : 500, easing: LAUNCH_EASE, fill: 'both' };
    var a = [pane.animate(kp, opt), zoom.animate(kz, opt), face.animate(kf, opt)];
    a[0].onfinish = function () { if (face.parentNode) face.parentNode.removeChild(face); card.classList.remove('is-launching'); if (opening) { a[0].cancel(); a[1].cancel(); } };
    return a;
  }
  function MachineLaunch(props) {
    var body = React.useRef(null), pane = React.useRef(null), zoom = React.useRef(null), host = React.useRef(null), homeRef = React.useRef(null), prev = React.useRef(null), anims = React.useRef([]);
    var last = React.useRef(props.machine); if (props.machine) last.current = props.machine;
    var open = !!props.open, seen = React.useRef(open), from = React.useRef(null);
    /* opening: read the card where it is now, before this commit can move it */
    if (open && !seen.current && body.current && props.machine) {
      var c0 = body.current.querySelector('[data-machine="' + props.machine + '"]');
      from.current = c0 ? launchRect(body.current, c0) : null;
    }
    seen.current = open;
    useLayout(function () {
      var was = prev.current; prev.current = open;
      if (was === null || was === open || !pane.current || !pane.current.animate || reducedMotion()) return;
      anims.current.forEach(function (x) { x.cancel(); }); host.current.innerHTML = '';
      Array.prototype.forEach.call(body.current.querySelectorAll('.is-launching'), function (c) { c.classList.remove('is-launching'); });
      var card = body.current.querySelector('[data-machine="' + last.current + '"]'); if (!card) return;
      anims.current = runLaunch(body.current, pane.current, zoom.current, host.current, homeRef.current, card, open, open ? from.current : null);
      from.current = null;
    });
    return h('div', { ref: body, className: cx('ex-launch', open ? 'is-in' : 'is-home', props.className), style: props.style },
      h('div', { ref: homeRef, className: 'ex-launch-home', 'aria-hidden': open ? 'true' : null }, h(LaunchCtx.Provider, { value: open }, props.home)),
      h('div', { ref: pane, className: cx('ex-launch-pane', open && 'is-on'), 'aria-hidden': open ? null : 'true' }, h('div', { ref: zoom, className: 'ex-launch-zoom' }, props.children)),
      h('div', { ref: host, className: 'ex-launch-host', 'aria-hidden': 'true' }));
  }

  /* Getting ready: connecting, installing or updating, outside the app. Nothing from the machine shows until it's done. */
  function stagedSteps(t, marks) { return marks.map(function (m, i) { var s0 = i ? marks[i - 1] : 0; return t >= m ? 'done' : t >= s0 ? 'active' : 'todo'; }); }
  function GettingReady(props) {
    return h('div', { className: cx('ex-ready', props.className) },
      h('div', { className: 'ex-ready-head' }, h('span', { className: 'ex-ready-ic' }, h(Icon, { name: props.icon || 'server', size: 18 })),
        h('div', { className: 'ex-mgrow' }, h('div', { className: 'ex-ready-title' }, props.title), props.sub ? h('div', { className: 'ex-ready-sub' }, props.sub) : null)),
      h('ol', { className: 'ex-ready-steps' }, (props.steps || []).map(function (r, i) {
        return h('li', { key: i, className: cx('ex-ready-step', 'is-' + (r.state || 'todo')) },
          h('span', { className: 'ex-ready-g' }, r.state === 'done' ? h(StatusGlyph, { status: 'done', size: 14 }) : r.state === 'active' ? h(StatusGlyph, { status: 'running', size: 14 }) : r.state === 'failed' ? h(StatusGlyph, { status: 'failed', size: 14 }) : h('span', { className: 'ex-ready-dot' })),
          h('span', { className: 'ex-ready-b' }, h('span', { className: 'ex-ready-l' }, r.label, r.detail ? h('span', { className: 'ex-ready-d' }, r.detail) : null),
            r.state === 'active' && r.progress != null ? h(ProgressLine, { value: r.progress }) : null),
          r.meta ? h('span', { className: 'ex-ready-m' }, r.meta) : null);
      })),
      props.actions || props.note ? h('div', { className: 'ex-ready-foot' }, props.actions || null, h('span', { className: 'ex-mgrow' }), props.note ? h('span', { className: 'ex-ready-note' }, props.note) : null) : null);
  }

  /* A machine's menu (its card's ⋯, or right-click): edit, a new window, disconnect, remove. */
  function MachineMenu(props) {
    var m = props.machine || {}, live = machineLive(m), peer = m.kind === 'peer';
    function item(icon, label, on, danger, right) { return h('button', { type: 'button', role: 'menuitem', className: cx('ex-menu-item ex-pmenu-i', danger && 'is-danger'), onClick: on }, h(Icon, { name: icon, size: 15 }), h('span', { className: 'ex-grow' }, label), right || null); }
    return h('div', { className: cx('ex-menu ex-pmenu ex-mmenu', props.leaving && 'is-leaving'), role: 'menu', 'aria-label': m.name, style: props.style },
      item('pencil', 'Edit…', props.onEdit),
      item('window', 'Open in a new window', props.onNewWindow, false, h(Kbd, null, '⌘↵')),
      live && m.kind !== 'local' ? item('plug', 'Disconnect', props.onDisconnect) : null,
      m.kind !== 'local' ? h(F, null, h('div', { className: 'ex-menu-sep' }), item('trash', (peer ? 'Unpair' : 'Remove') + (m.windows ? '…' : ''), props.onRemove, true)) : null);
  }
  var MACHINE_HUES = ['ocean', 'pine', 'plum', 'rust', 'steel', 'rose'];
  /* Editing a machine: name and color, and for a server where and how to reach it. Opened from its card (ModalLayer `from`).
     `step: 'remove'` asks before removing a machine that has windows open. */
  function EditMachine(props) {
    var m = props.machine || {}, _v = React.useState(Object.assign({}, m)), v = _v[0], setV = _v[1], _st = React.useState(props.step || 'edit'), step = _st[0], setStep = _st[1];
    function set(k) { return function (x) { var o = {}; o[k] = x; setV(function (cur) { return Object.assign({}, cur, o); }); }; }
    var ssh = m.kind === 'ssh', peer = m.kind === 'peer', local = m.kind === 'local';
    var moved = ssh && (v.host !== m.host || v.user !== m.user || String(v.port) !== String(m.port));
    function row(label, ctl) { return h('div', { className: 'ex-emach-row' }, h('span', { className: 'ex-emach-l' }, label), h('div', { className: 'ex-emach-c' }, ctl)); }
    if (step === 'remove') return h('div', { className: 'ex-ready ex-emach', role: 'dialog', 'aria-label': (peer ? 'Unpair ' : 'Remove ') + m.name },
      h('div', { className: 'ex-ready-head' }, h('span', { className: 'ex-ready-ic is-danger' }, h(Icon, { name: 'trash', size: 18 })),
        h('div', { className: 'ex-mgrow' }, h('div', { className: 'ex-ready-title' }, (peer ? 'Unpair ' : 'Remove ') + m.name + '?'), h('div', { className: 'ex-ready-sub' }, (m.windows || 1) + ((m.windows || 1) > 1 ? ' windows are' : ' window is') + ' on it. They go back to Home.'))),
      h('ul', { className: 'ex-emach-list' },
        h('li', null, h(Icon, { name: 'x', size: 12 }), h('span', null, h('b', null, 'Goes: '), 'its card, its connection and the host key we pinned.')),
        h('li', null, h(Icon, { name: 'check', size: 12 }), h('span', null, h('b', null, 'Stays: '), 'everything on ' + m.name + '. Add it again and it all comes back.'))),
      h('div', { className: 'ex-ready-foot' }, h(Button, { size: 'sm', variant: 'ghost', onClick: props.step === 'remove' ? props.onCancel : function () { setStep('edit'); } }, props.step === 'remove' ? 'Cancel' : 'Back'), h('span', { className: 'ex-mgrow' }),
        h(Button, { size: 'sm', variant: 'danger', icon: 'trash', onClick: props.onRemove }, peer ? 'Unpair' : 'Remove')));
    return h('div', { className: 'ex-ready ex-emach', role: 'dialog', 'aria-label': 'Edit ' + m.name },
      h('div', { className: 'ex-ready-head' }, h('span', { className: 'ex-ready-ic', style: { background: 'color-mix(in oklab, var(--project-' + (v.hue || 'steel') + ') 18%, var(--surface-sunken))', color: 'var(--ink)' } }, h(Icon, { name: MACHINE_ICON[m.kind] || 'laptop', size: 18 })),
        h('div', { className: 'ex-mgrow' }, h('div', { className: 'ex-ready-title' }, 'Edit ' + m.name), h('div', { className: 'ex-ready-sub' }, m.address || ''))),
      h('div', { className: 'ex-emach-form' },
        row('Name', h(SetValue, { field: true, value: v.name, label: 'Name', onInput: set('name') })),
        row('Color', h('span', { className: 'ex-ps-sw' }, MACHINE_HUES.map(function (hu) { return h('button', { key: hu, type: 'button', 'aria-label': hu, 'aria-pressed': String(v.hue === hu), className: cx('ex-ps-swatch', 'ex-tile-' + hu, v.hue === hu && 'is-on'), onClick: function () { set('hue')(hu); } }); }))),
        ssh ? h(F, null,
          row('Host', h(SetValue, { field: true, mono: true, value: v.host, label: 'Host', onInput: set('host') })),
          row('User · port', h('span', { className: 'ex-emach-pair' }, h(SetValue, { field: true, mono: true, value: v.user, label: 'User', onInput: set('user'), className: 'is-user' }), h(SetValue, { field: true, mono: true, value: String(v.port || 22), label: 'Port', onInput: set('port'), className: 'is-port' }))),
          row('Sign in with', h('button', { type: 'button', className: 'ex-set-choice' }, h(Icon, { name: 'key', size: 12 }), v.key || 'SSH agent', h(Icon, { name: 'chevron-down', size: 11 })))) : null,
        peer ? row('Pairing', h('span', { className: 'ex-set-sub' }, m.paired || 'Paired')) : null,
        local ? h('p', { className: 'ex-emach-note' }, 'This Mac is always here: rename it, change its color.') : null,
        moved ? h('p', { className: 'ex-emach-note is-on' }, h(Icon, { name: 'refresh', size: 12 }), 'Saving reconnects to check it, on its card.') : null),
      h('div', { className: 'ex-ready-foot' },
        local ? null : h(Button, { size: 'sm', variant: 'ghost', className: 'ex-emach-rm', onClick: m.windows ? function () { setStep('remove'); } : props.onRemove }, (peer ? 'Unpair' : 'Remove') + (m.windows ? '…' : '')),
        h('span', { className: 'ex-mgrow' }), h(Button, { size: 'sm', variant: 'ghost', onClick: props.onCancel }, 'Cancel'),
        h(Button, { size: 'sm', variant: 'primary', className: 'ex-np-next', onClick: function () { props.onSave && props.onSave({ name: v.name, hue: v.hue, host: v.host, user: v.user, port: v.port, key: v.key }); } }, h('span', { className: 'ex-np-next-in' }, 'Save', h(Kbd, null, '↵')))));
  }
  /* Adding a machine, in a dialog over Home: a server (its host, then its key) or another computer (its pairing text).
     It only asks; the new card then gets ready on Home. */
  function AddMachine(props) {
    var ssh = props.kind !== 'peer', step = ssh ? (props.step || 'host') : 'paste';
    var can = ssh ? (step === 'key' || !!props.picked) : !!props.found;
    var label = ssh ? (step === 'key' ? 'Trust and connect' : 'Connect') : 'Pair';
    var body = ssh ? (step === 'key' ? h(HostKeyCheck, { host: (props.picked && props.picked.name) || props.host, fingerprint: props.fingerprint, type: props.keyType })
      : h(HostField, { query: props.query, hosts: props.hosts, picked: props.picked })) : h(PairPaste, { text: props.text, found: props.found });
    return h('div', { className: 'ex-ready ex-addm', role: 'dialog', 'aria-label': ssh ? 'Add a server' : 'Pair another computer' },
      h('div', { className: 'ex-ready-head' }, h('span', { className: 'ex-ready-ic' }, h(Icon, { name: ssh ? 'server' : 'peer', size: 18 })),
        h('div', { className: 'ex-mgrow' }, h('div', { className: 'ex-ready-title' }, ssh ? 'Add a server' : 'Pair another computer'),
          h('div', { className: 'ex-ready-sub' }, ssh ? 'Elevenex uses your SSH setup and installs itself in ~/.elevenex, without root.' : 'It runs Elevenex already. Its agents and files stay there; this window drives them.'))),
      h(AutoHeight, null, h('div', { key: step, className: 'ex-addm-body' }, body)),
      h('div', { className: 'ex-ready-foot' },
        h(Button, { size: 'sm', variant: 'ghost', onClick: step === 'key' ? props.onBack : props.onCancel }, step === 'key' ? 'Back' : 'Cancel'), h('span', { className: 'ex-mgrow' }),
        h(Button, { size: 'sm', variant: 'primary', className: 'ex-np-next', disabled: !can, onClick: props.onNext }, h(EaseSwap, { k: label }, h('span', { className: 'ex-np-next-in' }, label, h(Kbd, null, '↵'))))));
  }
  /* Add a server: hosts from ~/.ssh/config come first; once one is picked, its user, port and key show. */
  function HostField(props) {
    var q = props.query || '', hosts = (props.hosts || []).filter(function (x) { return !q || x.name.indexOf(q) === 0 || x.detail.indexOf(q) !== -1; }), picked = props.picked;
    return h('div', { className: 'ex-host' },
      h('label', { className: 'ex-host-input' }, h(Icon, { name: 'server', size: 14 }), h('span', { className: 'ex-mgrow ex-mono' }, picked ? picked.name : q, h('span', { className: 'ex-caret' })),
        picked && picked.fromConfig ? h('span', { className: 'ex-mcard-tag' }, 'from ~/.ssh/config') : null),
      h(Fold, { open: !picked }, h('div', { className: 'ex-host-sugg' }, h('div', { className: 'ex-host-label' }, 'From ~/.ssh/config'),
        hosts.map(function (x, i) { return h('div', { key: x.name, className: cx('ex-host-row', i === 0 && 'is-hi') }, h(Icon, { name: 'server', size: 13 }), h('span', { className: 'ex-mono' }, x.name), h('span', { className: 'ex-mgrow ex-host-d ex-mono' }, x.detail), i === 0 ? h('kbd', { className: 'ex-kbd' }, '↵') : null); }),
        h('div', { className: 'ex-host-row is-other' }, h(Icon, { name: 'plus', size: 13 }), 'Or type ', h('span', { className: 'ex-mono' }, 'user@host:port')))),
      h(Fold, { open: !!picked }, picked ? h('div', { className: 'ex-host-facts' },
        h('div', null, h('span', null, 'User'), h('b', { className: 'ex-mono' }, picked.user)), h('div', null, h('span', null, 'Port'), h('b', { className: 'ex-mono' }, picked.port || 22)),
        h('div', { className: 'is-wide' }, h('span', null, 'Sign in with'), h('b', null, h(Icon, { name: 'key', size: 13 }), ' ', picked.auth || 'SSH agent'))) : null));
  }
  /* The host key, checked once per server and pinned. If it ever changes, Elevenex stops and says so. */
  function HostKeyCheck(props) {
    var changed = !!props.changed;
    return h('div', { className: cx('ex-hostkey', changed && 'is-changed') },
      h('div', { className: 'ex-hostkey-h' }, h(Icon, { name: 'shield', size: 15 }), changed ? h('span', null, 'The host key of ', h('span', { className: 'ex-mono' }, props.host), ' changed') : h('span', null, 'First time connecting to ', h('span', { className: 'ex-mono' }, props.host))),
      h('div', { className: 'ex-hostkey-fp' }, h('span', { className: 'ex-hostkey-k' }, props.type || 'ED25519'), h('span', { className: 'ex-mono' }, props.fingerprint)),
      h('p', { className: 'ex-hostkey-p' }, changed ? 'This can mean the server was reinstalled, or that someone is in the middle. Elevenex won’t connect until you confirm it with whoever runs the server.' : h(F, null, 'To be sure, compare it with ', h('span', { className: 'ex-mono' }, 'ssh-keygen -lf'), ' on the server. We remember it and warn you if it ever changes.')));
  }
  /* Pairing: the computer that hosts gives a long text; the other one pastes it. Once only; after that it opens without asking. */
  function PairingText(props) {
    return h('div', { className: 'ex-pair' },
      h('div', { className: 'ex-pair-text' }, h('span', { className: 'ex-pair-v ex-mono' }, props.text),
        h('span', { className: 'ex-pair-copy' }, h(Button, { size: 'sm', variant: props.copied ? 'secondary' : 'primary', icon: props.copied ? 'check' : 'copy', onClick: props.onCopy }, h('span', { key: props.copied ? 'y' : 'n', className: 'ex-mswap' }, props.copied ? 'Copied' : 'Copy')))),
      h('p', { className: 'ex-pair-p' }, 'Paste it in Elevenex on the other computer, in Machines › Pair a computer. Keep it to yourself: it lets that computer use this one.'));
  }
  function PairPaste(props) {
    var found = props.found;
    return h('div', { className: 'ex-pair' },
      h('label', { className: cx('ex-host-input ex-pair-in', props.text && 'is-filled') }, props.text ? h('span', { key: 'v', className: 'ex-pair-pasted ex-mono' }, props.text) : h('span', { key: 'e', className: 'ex-mgrow ex-pair-ph' }, 'Paste the pairing text', h('span', { className: 'ex-caret' })), props.text ? null : h('kbd', { className: 'ex-kbd' }, '⌘V')),
      h(Fold, { open: !!found }, found ? h('div', { className: 'ex-pair-found' }, h('span', { className: 'ex-mcard-ic' }, h(Icon, { name: 'peer', size: 15 }), h('span', { className: 'ex-mpres is-on' })),
        h('span', { className: 'ex-mgrow ex-mpanel-id' }, h('span', { className: 'ex-mcard-name' }, found.name), h('span', { className: 'ex-mcard-line' }, found.detail))) : null),
      h('p', { className: 'ex-pair-p' }, found ? 'You pair once. After this it opens from Machines, any time, without asking again.' : 'On the other computer: Settings › Pairing › Copy pairing text.'));
  }


  /* ── Modal surfaces: the window recedes ──
     Anything modal (a sheet, a confirm) sits over the whole window, title bar included, and the window behind steps back:
     it scales to 98.5%, blurs a little and dims, on the launch curve, and comes forward again quicker when it closes.
     Menus and popovers don't recede the window; the machine launch and the lightbox keep their own motion. */
  function useRecede(on, ref) {
    useLayout(function () {
      if (!on) return;
      var el = ref && ref.current, win = (el && el.closest && el.closest('.ex-window')) || document.querySelector('.ex-window');
      var shell = win && (win.querySelector(':scope > .ex-shell') || win.querySelector('.ex-launch.is-home > .ex-launch-home'));
      if (!shell) return;
      var n = (+shell.getAttribute('data-recede') || 0) + 1; shell.setAttribute('data-recede', n); shell.classList.add('is-receded');
      return function () { var m = (+shell.getAttribute('data-recede') || 1) - 1; shell.setAttribute('data-recede', m); if (!m) shell.classList.remove('is-receded'); };
    }, [!!on]);
  }
  /* A dialog opened from something on screen opens like a launch: its box grows out of that element (the element's face
     rides it and fades), the dialog's content scales up inside, cover-fit, never stretched, and fades in. Closing runs it
     backwards into the same place. One curve and time for all of it, the launch's. */
  function morphDialog(layer, box, from, face, opening, fadeIn) {
    var z = (layer.offsetWidth && layer.getBoundingClientRect().width / layer.offsetWidth) || 1, L = layer.getBoundingClientRect();
    var W = box.offsetWidth, H = box.offsetHeight, X0 = box.offsetLeft, Y0 = box.offsetTop;
    var c = { l: (from.left - L.left) / z, t: (from.top - L.top) / z, w: from.width / z, h: from.height / z };
    var Rd = parseFloat(getComputedStyle(box).borderTopLeftRadius) || 14, Rc = from.radius || 14, N = 14;
    var kb = [], kc = [], kf = [], ks = [];
    for (var i = 0; i <= N; i++) {
      var q = i / N, p = opening ? q : 1 - q, w = c.w + (W - c.w) * p, hh = c.h + (H - c.h) * p;
      var cx = (c.l + c.w / 2) * (1 - p) + (X0 + W / 2) * p, cy = (c.t + c.h / 2) * (1 - p) + (Y0 + H / 2) * p;
      var sc = Math.max(w / W, hh / H), ix = (W - w / sc) / 2, iy = (H - hh / sc) / 2, r = (Rc * (1 - p) + Rd * p) / sc;
      var dx = cx - (X0 + W / 2), dy = cy - (Y0 + H / 2);
      kb.push({ offset: q, transform: 'translate(' + dx + 'px,' + dy + 'px) scale(' + sc + ')', clipPath: 'inset(' + iy + 'px ' + ix + 'px round ' + r + 'px)', opacity: fadeIn ? Math.min(1, p / fadeIn) : (!opening && i === N) ? 0 : 1 });
      kc.push({ offset: q, opacity: Math.max(0, Math.min(1, (p - 0.18) / 0.4)) });
      kf.push({ offset: q, transform: 'translate(' + (cx - w / 2 - c.l) + 'px,' + (cy - hh / 2 - c.t) + 'px) scale(' + (w / c.w) + ',' + (hh / c.h) + ')', opacity: Math.max(0, Math.min(1, 1 - (p - 0.12) / 0.38)) });
      ks.push({ offset: q, transform: 'translate(' + (cx - w / 2 - X0) + 'px,' + (cy - hh / 2 - Y0) + 'px) scale(' + (w / W) + ',' + (hh / H) + ')', opacity: Math.max(0, Math.min(1, (p - 0.1) / 0.5)) * ((!opening && i === N) ? 0 : 1) });
    }
    var opt = { duration: opening ? 560 : 500, easing: LAUNCH_EASE, fill: 'both' }, out = [];
    /* the dialog's shadow follows the box outside the clip, so it never pops in at the end */
    var sh = document.createElement('div'); sh.className = 'ex-modal-shadow'; sh.style.cssText = 'left:' + X0 + 'px;top:' + Y0 + 'px;width:' + W + 'px;height:' + H + 'px;border-radius:' + Rd + 'px;box-shadow:' + getComputedStyle(box).boxShadow;
    layer.insertBefore(sh, box); out.push(sh.animate(ks, opt));
    box.style.transformOrigin = '50% 50%'; out.push(box.animate(kb, opt));
    Array.prototype.forEach.call(box.children, function (n) { out.push(n.animate(kc, opt)); });
    if (face) { face.classList.add('ex-modal-face'); face.style.left = c.l + 'px'; face.style.top = c.t + 'px'; face.style.width = c.w + 'px'; face.style.height = c.h + 'px'; layer.appendChild(face); out.push(face.animate(kf, opt)); }
    out[0].onfinish = function () { if (sh.parentNode) sh.parentNode.removeChild(sh); if (face && face.parentNode) face.parentNode.removeChild(face); if (opening) out.forEach(function (a) { a.cancel(); }); };
    return out;
  }
  /* The morph behind a dialog opened from something on screen (ModalLayer `from`, CommitPanel). `ref` is the layer, whose
     first child is the box; `pm` its usePresence. `opts.noFace` + `opts.fadeIn` (a share of the run): for a popover that
     opens beside what it came from, the box fades in over it instead of carrying its face (so the face never stretches),
     and closing, fades out into it, whatever it says by then. */
  function useMorphFrom(ref, pm, morph, getFrom, opts) {
    /* `from`: the element it opened from. Read where it is (and copy its face) when it opens; close back into it,
       or into whatever now sits in its place. */
    var origin = React.useRef(null), anims = React.useRef([]), phase = React.useRef(null);
    useLayout(function () {
      var el = ref.current, box = el && el.querySelector(':scope > :not(.ex-modal-face):not(.ex-modal-shadow)');
      if (!pm.m) { origin.current = null; phase.current = null; return; }
      if (!morph || !box || !box.animate) {
        /* `from` cleared as it closes: it leaves the plain way (it doesn't go back); stop any morph still running */
        if (pm.l && anims.current.length) { anims.current.forEach(function (a) { a.cancel(); }); anims.current = []; Array.prototype.forEach.call(el.querySelectorAll('.ex-modal-face, .ex-modal-shadow'), function (n) { n.parentNode.removeChild(n); }); }
        return;
      }
      var want = pm.l ? 'out' : 'in'; if (phase.current === want) return; phase.current = want;
      if (want === 'in') {
        var f = getFrom(); if (!f) return; var r = f.getBoundingClientRect();
        origin.current = { left: r.left, top: r.top, width: r.width, height: r.height, radius: parseFloat(getComputedStyle(f).borderTopLeftRadius) || 10, face: f.cloneNode(true) };
      }
      var o = origin.current; if (!o) return;
      /* closing: back to the same place, into whatever sits there now (the element itself, or what replaced it) */
      var face = null;
      if (want === 'out') {
        var px = o.left + o.width / 2, py = o.top + o.height / 2, hit = null;
        (document.elementsFromPoint ? document.elementsFromPoint(px, py) : []).some(function (n) { if (el.contains(n)) return false; hit = (n.closest && n.closest('[data-key], button')) || n; return true; });
        if (hit && hit !== document.body && hit.getBoundingClientRect) {
          var r2 = hit.getBoundingClientRect(), zl = (el.offsetWidth && el.getBoundingClientRect().width / el.offsetWidth) || 1;
          /* its size without any transform it's in the middle of (a card growing in) */
          var w2 = hit.offsetWidth * zl, h2 = hit.offsetHeight * zl, cx2 = r2.left + r2.width / 2, cy2 = r2.top + r2.height / 2;
          o = Object.assign({}, o, { left: cx2 - w2 / 2, top: cy2 - h2 / 2, width: w2, height: h2, radius: parseFloat(getComputedStyle(hit).borderTopLeftRadius) || o.radius });
          face = hit.cloneNode(true); face.style.opacity = ''; face.style.transform = ''; face.style.zIndex = '';
        }
      } else face = o.face.cloneNode(true);
      anims.current.forEach(function (a) { a.cancel(); });
      Array.prototype.forEach.call(el.querySelectorAll('.ex-modal-face, .ex-modal-shadow'), function (n) { n.parentNode.removeChild(n); });
      if (face) { face.classList.remove('is-hi', 'is-press'); face.removeAttribute('data-machine'); face.removeAttribute('data-key'); face.setAttribute('tabindex', '-1'); face.setAttribute('aria-hidden', 'true'); }
      anims.current = morphDialog(el, box, o, opts && opts.noFace ? null : face, want === 'in', opts && opts.fadeIn);
    });
  }
  function ModalLayer(props) {
    var morph = !!props.from && !reducedMotion();
    var pm = usePresence(props.open, morph ? 520 : 220), ref = React.useRef(null), kept = React.useRef(null);
    /* while it leaves, it keeps showing what it showed, so it can go back where it came from */
    if (props.open) kept.current = props.children;
    useRecede(pm.m && !pm.l, ref);
    React.useEffect(function () {
      if (!props.open || !props.onClose) return;
      function k(e) { if (e.key === 'Escape') { e.stopPropagation(); props.onClose(); } }
      document.addEventListener('keydown', k); return function () { document.removeEventListener('keydown', k); };
    }, [props.open]);
    useMorphFrom(ref, pm, morph, function () { return props.from; });
    if (!pm.m) return null;
    return h('div', { ref: ref, className: cx('ex-modal', 'is-' + (props.align || 'center'), pm.l && 'is-leaving', morph && 'has-from', props.className), onMouseDown: function (e) { if (e.target === e.currentTarget && props.onClose) props.onClose(); } }, props.open ? props.children : kept.current);
  }
  /* A sheet: settings-sized, a close × on top. Changes apply as they're made, so there's nothing to confirm: × or Esc
     only closes. Give it `sections` and it lays them out as one scroll: the sections listed on the left (under `navHead`),
     every section in turn on the right (after `hero`); the list follows the scroll, its highlight gliding to the section
     you're in, and a click scrolls there. Under 680px wide the list gives way to a sticky tab strip with the same highlight. */
  function Sheet(props) {
    var secs = props.sections || null;
    var _a = React.useState(props.section || (secs && secs[0] ? secs[0].id : null)), act = _a[0], setAct = _a[1];
    var scroll = React.useRef(null), jumping = React.useRef(false);
    var listTh = useThumb('[aria-current="true"]', [act, props.open, secs ? secs.length : 0]), tabTh = useThumb('[aria-current="true"]', [act, props.open, secs ? secs.length : 0]);
    function secEl(id) { return scroll.current && scroll.current.querySelector('[data-sheet-sec="' + id + '"]'); }
    function tabsH() { var t = scroll.current && scroll.current.querySelector('.ex-sheet-tabs'); return t && t.offsetHeight ? t.offsetHeight : 0; }
    function go(id, instant) {
      var sc = scroll.current, el = secEl(id); if (!sc || !el) return;
      setAct(id); jumping.current = true;   /* the section you picked stays current until you scroll yourself */
      var top = Math.max(0, el.offsetTop - tabsH() - 8);
      if (instant || reducedMotion()) sc.scrollTop = top; else sc.scrollTo({ top: top, behavior: 'smooth' });
    }
    function spy() {
      var sc = scroll.current; if (!sc || jumping.current || !secs) return;
      var cur = secs[0].id, off = tabsH() + 40;
      secs.forEach(function (x) { var el = secEl(x.id); if (el && el.offsetTop - off <= sc.scrollTop) cur = x.id; });
      if (sc.scrollTop > 0 && sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 4) cur = secs[secs.length - 1].id;   /* at the end, the last one, even if short */
      if (cur !== act) setAct(cur);
    }
    /* opening on a section: start there, without a scroll animation */
    useLayout(function () {
      if (!props.open || !secs) return;
      var id = props.section || secs[0].id;
      var t = setTimeout(function () { if (id === secs[0].id) { if (scroll.current) scroll.current.scrollTop = 0; setAct(id); } else go(id, true); }, 0);
      return function () { clearTimeout(t); };
    }, [props.open, props.section]);
    function item(x, tab) {
      var on = x.id === act;
      return h('button', { key: x.id, type: 'button', className: tab ? 'ex-sheet-tab' : 'ex-sheet-nav-i', 'aria-current': on ? 'true' : undefined, onClick: function () { go(x.id); } },
        !tab && x.icon ? h(Icon, { name: x.icon, size: 14 }) : null, h('span', { className: 'ex-grow' }, x.label), !tab && x.count != null ? h('span', { className: 'ex-pmenu-n' }, x.count) : null);
    }
    var nav = secs ? h(F, null, props.navHead || null,
      h('div', { ref: listTh.ref, className: cx('ex-sheet-list', listTh.has && 'has-thumb', listTh.ready && 'is-ready') }, h('span', { className: 'ex-thumb ex-sheet-thumb', 'aria-hidden': 'true', style: listTh.style }),
        secs.map(function (x) { return item(x, false); }))) : props.nav;
    var body = secs ? h(F, null, props.hero || null,
      h('div', { ref: tabTh.ref, className: cx('ex-sheet-tabs', tabTh.has && 'has-thumb', tabTh.ready && 'is-ready'), role: 'tablist', 'aria-label': 'Sections' }, h('span', { className: 'ex-thumb ex-sheet-thumb', 'aria-hidden': 'true', style: tabTh.style }),
        secs.map(function (x) { return item(x, true); })),
      secs.map(function (x) { return h('section', { key: x.id, 'data-sheet-sec': x.id, className: 'ex-sheet-sec', 'aria-label': x.label }, h('div', { className: 'ex-sheet-sec-t' }, x.label), x.content); })) : props.children;
    function user() { jumping.current = false; }
    return h(ModalLayer, { open: props.open, onClose: props.onClose, align: 'top' },
      h('div', { className: cx('ex-sheet', secs && 'is-scroll', props.className), role: 'dialog', 'aria-label': props.label || 'Settings' },
        nav ? h('nav', { className: 'ex-sheet-nav', 'aria-label': 'Sections' }, nav) : null,
        h('div', { className: 'ex-sheet-body' },
          h('div', { className: 'ex-sheet-top' }, h('span', { style: { flex: 1 } }), h(IconButton, { icon: 'x', label: 'Close (Esc)', className: 'ex-sheet-x', onClick: props.onClose })),
          h('div', { className: 'ex-sheet-scroll', key: secs ? undefined : props.page, ref: scroll, onScroll: spy, onWheel: user, onTouchStart: user, onMouseDown: user, onKeyDown: user }, body))));
  }
  function SetGroup(props) { return h('div', { className: 'ex-set-group' }, props.title ? h('div', { className: 'ex-set-group-t' }, props.title) : null, h('div', { className: 'ex-set-card' }, props.children), props.note ? h('div', { className: 'ex-set-note' }, props.note) : null); }
  function SetRow(props) { return h('div', { className: 'ex-set-row' }, h('span', { className: 'ex-set-row-l' }, h('span', null, props.label), props.sub ? h('span', { className: 'ex-set-sub' }, props.sub) : null), h('span', { className: 'ex-set-row-c' }, props.children)); }
  function SetField(props) { return h('span', { className: cx('ex-set-field', props.mono && 'is-mono', props.wide && 'is-wide') }, h('input', { defaultValue: props.value, placeholder: props.placeholder, spellCheck: false, 'aria-label': props.label })); }
  /* A value that reads as text: hover (or focus) shows a soft fill and a pencil; click it and it becomes the field in
     the same place. ↵ or leaving keeps it, Esc puts it back. `well` sets it in a code well, `prompt` adds the $, `field`
     shows it as a field from the start (a box with a pencil), for a value people must find without hovering. */
  function SetValue(props) {
    var _e = React.useState(false), ed = _e[0], setEd = _e[1], _v = React.useState(props.value || ''), v = _v[0], setV = _v[1];
    var ref = React.useRef(null), btn = React.useRef(null), was = React.useRef(''), refocus = React.useRef(false), live = React.useRef(false);
    useLayout(function () { if (ed && ref.current) { ref.current.focus(); ref.current.select(); } else if (!ed && refocus.current && btn.current) { refocus.current = false; btn.current.focus(); } }, [ed]);
    function set(x) { setV(x); if (props.onInput) props.onInput(x); }
    function done(keep) { if (!live.current) return; live.current = false; if (!keep) set(was.current); else if (props.onChange && v !== was.current) props.onChange(v); setEd(false); }
    var cls = cx('ex-set-val', props.mono && 'is-mono', props.well && 'is-well', props.field && 'is-field', props.className);
    if (ed) return h('span', { className: cls + ' is-editing' }, props.prompt ? h('span', { className: 'ex-set-val-p', 'aria-hidden': 'true' }, '$') : null,
      h('input', { ref: ref, value: v, placeholder: props.placeholder, spellCheck: false, 'aria-label': props.label,
        onChange: function (e) { set(e.target.value); }, onBlur: function () { done(true); },
        onKeyDown: function (e) { if (e.key === 'Enter' || e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); refocus.current = true; done(e.key === 'Enter'); } } }));
    return h('button', { ref: btn, type: 'button', className: cx(cls, !v && 'is-empty'), 'aria-label': props.label + ': ' + (v || props.placeholder || 'empty') + ', edit', onClick: function () { was.current = v; live.current = true; setEd(true); } },
      props.prompt ? h('span', { className: 'ex-set-val-p', 'aria-hidden': 'true' }, '$') : null, h('span', { className: 'ex-set-val-t' }, v || props.placeholder), h(Icon, { name: 'pencil', size: 12, className: 'ex-set-val-pen' }));
  }
  function SetChoice(props) { return h('button', { type: 'button', className: 'ex-set-choice' }, props.children, h(Icon, { name: 'chevron-down', size: 11 })); }

  /* ── The project's menu: the ⋯ in the sidebar head ── */
  function ProjectMenu(props) {
    var p = props.project || {}, n = props.repoCount || 1;
    function item(icon, label, on, right, danger) {
      return h('button', { type: 'button', role: 'menuitem', className: cx('ex-menu-item ex-pmenu-i', danger && 'is-danger'), onClick: on }, h(Icon, { name: icon, size: 15 }), h('span', { className: 'ex-grow' }, label), right || null);
    }
    return h('div', { className: cx('ex-menu ex-pmenu', props.leaving && 'is-leaving'), role: 'menu', 'aria-label': p.name },
      h('div', { className: 'ex-pmenu-h' }, h(ProjectMark, Object.assign({}, p, { size: 28, decorative: true })),
        h('span', { className: 'ex-grow' }, h('b', null, p.name), h('span', null, n + (n === 1 ? ' repository' : ' repositories') + (props.machine ? ' · ' + props.machine : '')))),
      h('div', { className: 'ex-menu-sep' }),
      item('grid', 'Project settings', props.onSettings, h(Kbd, null, '⌘,')),
      item('repo', 'Add a repository…', props.onAddRepo),
      item('archive', 'Closed tasks', props.onClosed, props.closed != null ? h('span', { className: 'ex-pmenu-n' }, props.closed) : null),
      h('div', { className: 'ex-menu-sep' }),
      item('layers', 'Archive project', props.onArchive),
      item('trash', 'Delete project…', props.onDelete, null, true));
  }

  /* ── Project settings: a Sheet ── */
  var PS_NAV = [['general', 'General', 'pencil'], ['repos', 'Repositories', 'repo'], ['tasks', 'Tasks', 'task'], ['agents', 'Agents', 'bolt'], ['git', 'Git', 'branch']];
  var PS_HUES = ['ocean', 'pine', 'plum', 'rust', 'steel', 'rose'];
  /* One repository: a row that opens in place. Opened: what its tasks get (the tag, a field from the start; the branch
     they start from), then its commands in code wells that show they're editable on hover. Everything shown can be changed. */
  function PsRepo(props) {
    var r = props.repo, _t = React.useState(r.short || ''), tag = _t[0], setTag = _t[1], n = r.tasks || 0;
    function change(patch) { if (props.onChange) props.onChange(patch); }
    var shown = { name: r.name, path: r.path, short: tag || undefined };
    return h('div', { className: cx('ex-ps-repo', props.open && 'is-open') },
      h('button', { type: 'button', className: 'ex-ps-repo-h', 'aria-expanded': String(!!props.open), onClick: props.onToggle },
        h('span', { className: 'ex-ps-repo-ic' }, h(Icon, { name: 'repo', size: 15 })),
        h('span', { className: 'ex-ps-repo-t' }, h('b', null, r.name), h('span', { className: 'ex-mono' }, r.path)),
        h('span', { className: 'ex-ps-repo-m' }, tag ? h(RepoTag, { repo: shown }) : null, r.base ? h('span', { className: 'ex-mono' }, r.base) : null),
        h(Icon, { name: 'chevron-down', size: 13, className: cx('ex-ps-chev', props.open && 'is-open') })),
      h(Fold, { open: !!props.open }, h('div', { className: 'ex-ps-repo-b' },
        h('div', { className: 'ex-ps-grp' }, h('div', { className: 'ex-ps-grp-t' }, 'Its tasks'),
          h('div', { className: 'ex-ps-line' }, h('span', { className: 'ex-ps-l' }, 'Tag'),
            h(SetValue, { field: true, value: r.short, placeholder: r.name, label: 'Tag', mono: true, onInput: setTag, onChange: function (v) { change({ short: v }); } }),
            h('span', { className: 'ex-set-sub' }, 'Shown next to its tasks')),
          h('div', { className: 'ex-ps-line' }, h('span', { className: 'ex-ps-l' }, 'Start from'),
            h(SetChoice, null, h(Icon, { name: 'branch', size: 12 }), h('span', { className: 'ex-mono' }, r.base || 'main')), h('span', { className: 'ex-set-sub' }, 'New task branches are made from it'))),
        h('div', { className: 'ex-ps-grp' }, h('div', { className: 'ex-ps-grp-t' }, 'Commands'),
          h('div', { className: 'ex-ps-cmd' }, h('span', { className: 'ex-ps-l' }, 'When a workspace is prepared'), h(SetValue, { value: r.setup, label: 'Setup', mono: true, well: true, prompt: true, placeholder: 'Nothing to run', onChange: function (v) { change({ setup: v }); } })),
          h('div', { className: 'ex-ps-cmd' }, h('span', { className: 'ex-ps-l' }, 'Before merging'), h(SetValue, { value: r.check, label: 'Checks', mono: true, well: true, prompt: true, placeholder: 'Nothing to run', onChange: function (v) { change({ check: v }); } }))),
        h('div', { className: 'ex-ps-repo-f' }, h('span', { className: 'ex-set-sub' }, (n ? n + (n === 1 ? ' task' : ' tasks') : 'No tasks') + (r.sync ? ' · ' + r.sync : ' in this repository')), h('span', { style: { flex: 1 } }),
          h(Button, { size: 'sm', variant: 'ghost', className: 'ex-ps-remove', onClick: props.onRemove }, 'Remove from project')))));
  }
  /* Add a repository: a row at the end of the list that becomes the path field, where the new row will be */
  function PsAdd(props) {
    var _q = React.useState(props.query || '~/code/'), q = _q[0], setQ = _q[1], ref = React.useRef(null);
    React.useEffect(function () { if (props.adding && ref.current) ref.current.focus(); }, [props.adding]);
    if (!props.adding) return h('button', { type: 'button', className: 'ex-ps-repo ex-ps-addrow', onClick: props.onStart },
      h('span', { className: 'ex-ps-repo-ic is-add' }, h(Icon, { name: 'plus', size: 14 })), h('span', { className: 'ex-ps-repo-t' }, h('b', null, 'Add a repository'), h('span', null, 'A folder on ' + (props.machine || 'this machine') + ', or a URL to clone')));
    var items = props.list ? props.list(q) : [];
    return h('div', { className: 'ex-ps-repo ex-ps-adding' },
      h('div', { className: 'ex-ps-add-in' }, h(Icon, { name: /^(git@|https?:)/.test(q) ? 'link' : 'folder', size: 15 }),
        h('input', { ref: ref, value: q, spellCheck: false, 'aria-label': 'Folder or clone URL', onChange: function (e) { setQ(e.target.value); }, onKeyDown: function (e) { if (e.key === 'Escape') { e.stopPropagation(); props.onCancel && props.onCancel(); } if (e.key === 'Enter' && items[0] && props.onAdd) props.onAdd(items[0]); } }),
        h(Kbd, null, 'Esc'), h(Button, { size: 'sm', variant: 'primary', disabled: !items.length, onClick: function () { if (props.onAdd) props.onAdd(items[0]); } }, 'Add')),
      items.length ? h('div', { className: 'ex-ps-add-list' }, items.map(function (x, i) {
        return h('button', { key: x.path, type: 'button', className: cx('ex-ps-add-i', i === 0 && 'is-hi'), onClick: function () { if (props.onAdd) props.onAdd(x); } },
          h(Icon, { name: x.git ? 'repo' : 'folder', size: 14 }), h('span', { className: 'ex-mono' }, x.path), h('span', { className: 'ex-set-sub' }, x.git || 'not a repository yet: Elevenex sets up git'), i === 0 ? h(Kbd, null, '↵') : null);
      })) : h('div', { className: 'ex-ps-add-none' }, 'Nothing on ' + (props.machine || 'this machine') + ' starts with that.'));
  }
  /* Project settings: a Sheet in one scroll (the sections listed on the left, every section on the right, the face and
     name first); B's tabs instead of the list when narrow. */
  function ProjectSettings(props) {
    var p = props.project || {}, repos = props.repos || [];
    var _o = React.useState(props.openRepo || null), open = _o[0], setOpen = _o[1];
    var _ad = React.useState(!!props.adding), adding = _ad[0], setAdding = _ad[1];
    var _h = React.useState(props.helpers || 'auto'), helpers = _h[0], setHelpers = _h[1];
    useLayout(function () {
      if (!props.open) return;
      if (props.adding != null) setAdding(!!props.adding);
      if (props.openRepo !== undefined) setOpen(props.openRepo);
    }, [props.open, props.section]);
    function body(id) {
      if (id === 'general') return h(F, null,
        h(SetGroup, { title: 'Look' },
          h(SetRow, { label: 'Face' }, h(Segmented, { label: 'Face', value: p.look || 'letters', onChange: function (v) { if (props.onChange) props.onChange({ look: v }); }, options: [{ id: 'letters', label: 'Letters' }, { id: 'emoji', label: 'Emoji' }, { id: 'icon', label: 'Icon' }] })),
          h(SetRow, { label: 'Color' }, h('span', { className: 'ex-ps-sw' }, PS_HUES.map(function (hu) { return h('button', { key: hu, type: 'button', 'aria-label': hu, 'aria-pressed': String(p.hue === hu), className: cx('ex-ps-swatch', 'ex-tile-' + hu, p.hue === hu && 'is-on'), onClick: function () { if (props.onChange) props.onChange({ hue: hu }); } }); })))),
        h(SetGroup, { title: 'Project' },
          h(SetRow, { label: 'Archive', sub: 'Leaves the rail. Tasks and sessions stay, read-only; bring it back from All projects.' }, h(Button, { size: 'sm', variant: 'secondary', icon: 'layers', onClick: props.onArchive }, 'Archive')),
          h(SetRow, { label: 'Delete', sub: 'Removes it from Elevenex. The repositories and branches on ' + (props.machine || 'the machine') + ' stay untouched.' }, h(Button, { size: 'sm', variant: 'danger', icon: 'trash', onClick: props.onDelete }, 'Delete…'))));
      if (id === 'repos') return h(F, null, h('p', { className: 'ex-sheet-sec-p' }, 'Each task works in one. New tasks ask which, once there are two or more.'),
        h('div', { className: 'ex-ps-repos' }, repos.map(function (r) { return h(PsRepo, { key: r.id || r.name, repo: r, open: open === (r.id || r.name), onToggle: function () { setOpen(open === (r.id || r.name) ? null : (r.id || r.name)); }, onChange: props.onRepoChange ? function (patch) { props.onRepoChange(r, patch); } : undefined, onRemove: props.onRemoveRepo ? function () { props.onRemoveRepo(r); } : undefined }); }),
          h(PsAdd, { adding: adding, machine: props.machine, list: props.listFolders, query: props.addQuery, onStart: function () { setAdding(true); }, onCancel: function () { setAdding(false); }, onAdd: function (x) { setAdding(false); if (props.onAddRepo) props.onAddRepo(x); } })));
      if (id === 'tasks') return h(F, null,
        h(SetGroup, null, h(SetRow, { label: 'Branch prefix', sub: (props.prefix || 'leo/') + 'rate-limit-refunds' }, h(SetField, { value: props.prefix || 'leo/', mono: true, label: 'Branch prefix' })),
          h(SetRow, { label: 'New tasks', sub: 'Where ⌘N puts them' }, h(Segmented, { label: 'New tasks', value: 'active', options: [{ id: 'active', label: 'In progress' }, { id: 'planned', label: 'Planned' }] }))),
        h(SetGroup, { title: 'Closing' }, h(SetRow, { label: 'Suggest closing', sub: 'When its PR merges' }, h(Switch, { on: true, label: 'Suggest closing' })), h(SetRow, { label: 'Clean up workspaces', sub: 'Back to the pool on close' }, h(Switch, { on: true, label: 'Clean up workspaces' }))));
      if (id === 'agents') return h(SetGroup, null, h(SetRow, { label: 'Default preset', sub: 'Preselected in a new session' }, h(SetChoice, null, h('span', { className: 'ex-ps-mk' }, 'Cl'), 'Deep work', h('span', { className: 'ex-set-sub' }, 'Opus 5.5 · High'))),
        h(SetRow, { label: 'Git helper', sub: 'Runs the sessions git jobs start' }, h(SetChoice, null, h('span', { className: 'ex-ps-mk' }, 'Cl'), 'Git helper', h('span', { className: 'ex-set-sub' }, 'Sonnet 5.5 · Medium'))));
      return h(SetGroup, { note: helpers === 'auto' ? 'When a merge or a sync needs judgement, Elevenex starts one session for it and tells you.' : helpers === 'ask' ? 'Elevenex asks first: the toast has Start.' : 'The git button opens the conflicts in Changes; nothing starts on its own.' },
        h(SetRow, { label: 'Helper sessions' }, h(Segmented, { label: 'Helper sessions', value: helpers, onChange: setHelpers, options: [{ id: 'auto', label: 'Automatically' }, { id: 'ask', label: 'Ask first' }, { id: 'never', label: 'Never' }] })),
        h(SetRow, { label: 'Merging sub-tasks' }, h(SetChoice, null, 'Squash and merge')));
    }
    return h(Sheet, { open: props.open, onClose: props.onClose, label: p.name + ' settings', className: 'ex-ps-sheet', section: props.section,
      navHead: h('div', { className: 'ex-sheet-nav-p' }, h(ProjectMark, Object.assign({}, p, { size: 22, decorative: true })), h('b', null, p.name)),
      hero: h('div', { className: 'ex-ps-hero' }, h('span', { className: 'ex-ps-face', key: (p.hue || '') + String(p.initials || '') + String(p.emoji || '') + String(p.icon || '') }, h(ProjectMark, Object.assign({}, p, { size: 64, decorative: true }))),
        h('span', { className: 'ex-ps-hero-t' }, h('input', { className: 'ex-ps-name', defaultValue: p.name, 'aria-label': 'Project name', onChange: function (e) { if (props.onChange) props.onChange({ name: e.target.value }); } }),
          h('span', { className: 'ex-set-sub' }, [repos.length + (repos.length === 1 ? ' repository' : ' repositories'), props.machine, props.since ? props.since.replace(/^Created/, 'created') : null].filter(Boolean).join(' · ')))),
      sections: PS_NAV.map(function (n) { return { id: n[0], label: n[1], icon: n[2], count: n[0] === 'repos' ? repos.length : undefined, content: body(n[0]) }; }) });
  }
  /* Delete a project: what goes, what stays, and Archive instead. Shown in a ModalLayer. */
  function DeleteProject(props) {
    var p = props.project || {};
    return h('section', { className: 'ex-dialog ex-pdel', role: 'alertdialog', 'aria-label': 'Delete ' + p.name },
      h('div', { className: 'ex-dialog-title' }, 'Delete “' + p.name + '”?'),
      h('ul', { className: 'ex-dialog-list' },
        h('li', { className: 'is-warn' }, h(StatusGlyph, { status: 'attention', size: 14 }), 'Removes its ' + (props.tasks || 0) + ' tasks and ' + (props.sessions || 0) + ' sessions from Elevenex, for good.'),
        props.running ? h('li', null, h(StatusGlyph, { status: 'running', size: 14 }), 'Stops ' + props.running + (props.running === 1 ? ' running session.' : ' running sessions.')) : null,
        h('li', null, h(Icon, { name: 'check', size: 14 }), 'Leaves its repositories and their branches on ' + (props.machine || 'the machine') + ' as they are.')),
      h('p', { className: 'ex-pdel-p' }, 'Archive keeps everything instead.'),
      h('div', { className: 'ex-dialog-foot' }, h(Button, { variant: 'ghost', onClick: props.onCancel }, 'Cancel'), h('span', { style: { flex: 1 } }),
        h(Button, { variant: 'secondary', icon: 'layers', onClick: props.onArchive }, 'Archive instead'), h(Button, { variant: 'danger', icon: 'trash', onClick: props.onDelete }, 'Delete project')));
  }

  /* ── New project: 1 Repositories ↵ 2 Name ↵ 3 Look ↵ (New task's numbered rows) ── */
  var NP_EMOJI = ['🦊', '🚀', '🧪', '🛒', '💳', '🛰️', '🌿', '🔥', '🧭', '🎯', '🐙', '⚡️'];
  var NP_ICONS = ['repo', 'code', 'globe', 'server', 'layers', 'bolt', 'shield', 'plug', 'bulb', 'workspace', 'terminal', 'grid'];
  function npInitials(n) { var w = String(n || '').replace(/[^a-z0-9]+/gi, ' ').trim().split(' '); if (!w[0]) return ''; return (w[0][0] + (w[1] ? w[1][0] : (w[0][1] || ''))).toUpperCase(); }
  /* a color from the name, until you pick one */
  function npHue(n) { var x = 0; String(n || 'project').split('').forEach(function (c) { x = (x * 31 + c.charCodeAt(0)) >>> 0; }); return PS_HUES[x % PS_HUES.length]; }
  function npIsUrl(q) { return /^(git@|https?:\/\/)/.test(q); }
  function npName(path) { return String(path || '').replace(/\.git$/, '').replace(/\/+$/, '').split(/[\/:]/).pop(); }
  /* ProjectMark props for a face being made: { name, look: 'letters' | 'emoji' | 'icon', emoji, icon, hue (null: from the name) } */
  function npMark(f) {
    var m = { name: f.name || 'New project', hue: f.hue || npHue(f.name) };
    if (f.look === 'emoji') m.emoji = f.emoji; else if (f.look === 'icon') m.icon = f.icon; else m.initials = npInitials(f.name);
    return m;
  }
  function NpFace(props) {
    var f = props.face, s = props.size, blank = f.look === 'letters' && !npInitials(f.name);
    if (blank) return h('span', { className: 'ex-np-blank', style: { width: s, height: s }, 'data-np': props.hook, 'aria-hidden': 'true' }, h(Icon, { name: 'folder', size: Math.round(s * 0.4) }));
    return h('span', { className: 'ex-np-face', key: f.look + (f.emoji || '') + (f.icon || ''), 'data-np': props.hook }, h(ProjectMark, Object.assign(npMark(f), { size: s, decorative: true })));
  }
  function NewProject(props) {
    var machine = props.machine || 'this machine';
    var _st = React.useState(props.step || 'repos'), step = _st[0], setStep = _st[1];
    var _r = React.useState(props.repos || []), repos = _r[0], setRepos = _r[1];
    var _q = React.useState(props.query != null ? props.query : (props.repos && props.repos.length ? '' : '~/code/')), q = _q[0], setQ = _q[1];
    var _o = React.useState(!!props.listOpen), open = _o[0], setOpen = _o[1];
    var _hi = React.useState(0), hi = _hi[0], setHi = _hi[1];
    var _f = React.useState({ name: props.name || (props.repos && props.repos[0] ? props.repos[0].name : ''), named: !!props.name, look: props.look || 'letters', emoji: props.emoji || NP_EMOJI[3], icon: props.icon || 'repo', hue: props.hue || null });
    var f = _f[0], setF = _f[1];
    var _done = React.useState(null), made = _done[0], setMade = _done[1];
    var rq = React.useRef(null), rn = React.useRef(null), rc = React.useRef(null), card = React.useRef(null), mounted = React.useRef(false);
    var items = props.listFolders && q ? props.listFolders(q) || [] : [], hiN = Math.min(hi, Math.max(0, items.length - 1));
    var added = {}; repos.forEach(function (r) { added[r.path] = 1; });
    React.useEffect(function () {
      if (!mounted.current) { mounted.current = true; if (!props.autoFocus) return; }
      var el = step === 'repos' ? rq.current : step === 'name' ? rn.current : rc.current && rc.current.querySelector('button');
      if (el) el.focus();
    }, [step]);
    function set(x) { setF(function (o) { return Object.assign({}, o, x); }); }
    function add(it) {
      if (!it || added[it.path]) return;
      if (it.dir && !it.git && !it.clone) { setQ(it.path.replace(/\/?$/, '/')); setHi(0); return; }   /* a plain folder: go into it */
      var r = { id: it.path, name: it.name || npName(it.path), path: it.path, branch: it.branch || null, clone: it.clone || null };
      setRepos(function (rs) { return rs.concat([r]); });
      setF(function (o) { return o.named || repos.length ? o : Object.assign({}, o, { name: r.name }); });
      setQ(''); setHi(0);
    }
    function remove(id) {
      var rs = repos.filter(function (r) { return r.id !== id; });
      setRepos(rs); if (!f.named) set({ name: rs[0] ? rs[0].name : '' });
      if (!rs.length) setQ('~/code/');
    }
    var ok = repos.length > 0 && !!f.name.trim();
    function create() {
      if (!ok) return;
      var res = { name: f.name.trim(), repos: repos, look: f.look, emoji: f.look === 'emoji' ? f.emoji : undefined, icon: f.look === 'icon' ? f.icon : undefined, hue: f.hue || npHue(f.name) };
      if (props.onCreate) props.onCreate(res, card.current); else setMade(res);
    }
    var order = ['repos', 'name', 'look'], at = order.indexOf(step);
    function go(s) { setStep(s); setHi(0); }
    function next() { if (step === 'repos' && repos.length) go('name'); else if (step === 'name' && f.name.trim()) go('look'); else if (step === 'look') create(); }
    function onKey(e) {
      if (e.key === 'Escape' && props.onCancel) { e.preventDefault(); props.onCancel(); return; }
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); create(); return; }
      /* on Look, ↵ creates wherever focus is (Space still picks a face or a color) */
      if (e.key === 'Enter' && step === 'look' && !e.altKey) { e.preventDefault(); create(); return; }
      if (e.key === 'Tab' && e.shiftKey && at > 0 && (e.target === rn.current || (step === 'look' && rc.current && rc.current.contains(e.target)))) { e.preventDefault(); go(order[at - 1]); }
    }
    function fieldKey(e) {
      if (e.key === 'ArrowDown' && items.length) { e.preventDefault(); setHi((hiN + 1) % items.length); }
      else if (e.key === 'ArrowUp' && items.length) { e.preventDefault(); setHi((hiN - 1 + items.length) % items.length); }
      else if (e.key === 'Tab' && !e.shiftKey && items[hiN] && q !== items[hiN].path) { e.preventDefault(); setQ(items[hiN].path + (items[hiN].dir && !items[hiN].git ? '/' : '')); setHi(0); }
      else if (e.key === 'Enter' && !e.metaKey && !e.ctrlKey) { e.preventDefault(); if (!q) next(); else add(items[hiN]); }
    }
    function state(id) { return step === id ? 'active' : at > order.indexOf(id) ? 'done' : 'todo'; }
    function Row(n, id, label, value, body) {
      var st = state(id);
      return h('div', { className: cx('ex-nt-row', 'is-' + st) },
        h('button', { type: 'button', className: 'ex-nt-row-head', disabled: st === 'active', onClick: function () { go(id); } },
          h(StepNum, { n: n, state: st }), h('span', { className: 'ex-nt-row-l' }, label), st === 'active' ? null : h('span', { className: 'ex-nt-row-v' }, value)),
        h(Fold, { open: st === 'active' }, h('div', { className: 'ex-nt-body' }, body)));
    }
    var dropOpen = open && items.length > 0;
    var field = h('div', { className: cx('ex-np-field', dropOpen && 'is-open') },
      h('span', { className: 'ex-np-field-in' }, h(Icon, { name: npIsUrl(q) ? 'link' : repos.length ? 'plus' : 'folder', size: 14 }),
        h('input', { ref: rq, value: q, spellCheck: false, 'aria-label': 'Repository: a folder on ' + machine + ' or a git URL', autoFocus: !!props.autoFocus && step === 'repos',
          placeholder: repos.length ? 'Add another, or ↵ to go on' : 'A folder on ' + machine + ', or a git URL',
          onFocus: function () { setOpen(true); }, onBlur: function () { setOpen(false); }, onKeyDown: fieldKey,
          onChange: function (e) { setQ(e.target.value); setHi(0); setOpen(true); } })),
      dropOpen ? h('div', { className: 'ex-menu ex-np-drop', role: 'listbox', 'aria-label': 'Folders on ' + machine }, items.map(function (it, i) {
        var isAdded = !!added[it.path], name = it.name || npName(it.path);
        return h('button', { key: it.path, type: 'button', role: 'option', 'aria-selected': String(i === hiN), className: cx('ex-np-opt', i === hiN && 'is-hi', isAdded && 'is-added'),
          onMouseDown: function (e) { e.preventDefault(); }, onMouseEnter: function () { setHi(i); }, onClick: function () { add(it); } },
          h(Icon, { name: it.clone ? 'link' : it.git ? 'repo' : 'folder', size: 14 }), h('span', { className: 'ex-np-opt-t ex-mono' }, name),
          h('span', { className: 'ex-np-opt-m' }, isAdded ? 'Added' : it.clone ? 'clones into ~/code' : it.git || (it.dir ? '' : 'no git yet: Elevenex sets it up')),
          isAdded ? h(Icon, { name: 'check', size: 13 }) : it.dir && !it.git ? h(Icon, { name: 'chevron-right', size: 12 }) : i === hiN ? h(Kbd, null, '↵') : null);
      })) : null);
    var label = step === 'look' ? 'Create project' : 'Next';
    var can = step === 'repos' ? repos.length > 0 : step === 'name' ? !!f.name.trim() : ok;
    return h('section', { ref: card, className: 'ex-newtask ex-nt ex-np', 'aria-label': 'New project', onKeyDown: onKey },
      h('div', { className: 'ex-np-head' }, h('span', { className: 'ex-np-crumb' }, h(Icon, { name: props.machineIcon || 'server', size: 13 }), machine), h('span', { className: 'ex-np-slash' }, '/'),
        h('span', { className: 'ex-np-title' }, 'New project'), h('span', { style: { flex: 1 } }), props.onCancel ? h(Kbd, null, 'Esc') : null),
      h(AutoHeight, { innerClassName: 'ex-nt-stack' }, made
        ? h('div', { className: 'ex-nt-created' }, h(StatusGlyph, { status: 'done', size: 16 }), h('span', null, 'Created ', h('b', null, made.name), ' with ' + made.repos.length + (made.repos.length === 1 ? ' repository' : ' repositories')),
            h('span', { style: { flex: 1 } }), h(Button, { variant: 'ghost', size: 'sm', icon: 'reset', onClick: function () { setMade(null); setRepos([]); setF({ name: '', named: false, look: 'letters', emoji: NP_EMOJI[3], icon: 'repo', hue: null }); setQ('~/code/'); go('repos'); } }, 'Again'))
        : h(F, null,
          h('div', { className: 'ex-nt-rows' },
            Row(1, 'repos', 'Repositories', repos.length ? h('span', { className: 'ex-np-sum' }, repos.map(function (r) { return r.name; }).join(', ')) : h('span', { className: 'ex-muted' }, 'One or more, on ' + machine),
              h('div', { className: 'ex-np-repos' },
                h(MotionList, { className: 'ex-np-list', items: repos.map(function (r) {
                  return { key: r.id, node: h('div', { className: 'ex-np-repo' },
                    h('span', { className: 'ex-np-repo-ic' }, h(Icon, { name: r.clone ? 'link' : 'repo', size: 14 })),
                    h('span', { className: 'ex-np-repo-t' }, h('b', null, r.name), h('span', { className: 'ex-mono' }, r.clone ? 'clones into ' + r.path : r.path)),
                    h('span', { className: 'ex-np-repo-m ex-mono' }, r.branch || (r.clone ? '' : 'git init')),
                    h(IconButton, { icon: 'x', label: 'Remove ' + r.name, size: 'sm', className: 'ex-np-repo-x', onClick: function () { remove(r.id); } })) };
                }) }),
                field)),
            Row(2, 'name', 'Name', f.name ? h('span', { className: 'ex-nt-title-v', 'data-np': step === 'name' ? null : 'name' }, f.name) : h('span', { className: 'ex-muted' }, 'From the first repository'),
              h('input', { ref: rn, className: 'ex-newtask-title ex-nt-name', 'data-np': step === 'name' ? 'name' : null, value: f.name, placeholder: 'Project name', 'aria-label': 'Project name', spellCheck: false,
                onKeyDown: function (e) { if (e.key === 'Enter' && !e.metaKey && !e.ctrlKey) { e.preventDefault(); next(); } },
                onChange: function (e) { set({ name: e.target.value, named: true }); } })),
            Row(3, 'look', 'Look', h('span', { className: 'ex-np-sumface' }, h(NpFace, { face: f, size: 18, hook: step === 'look' ? null : 'face' }), f.look === 'emoji' ? 'Emoji' : f.look === 'icon' ? 'Icon' : 'Letters'),
              h('div', { className: 'ex-np-look' }, h(NpFace, { face: f, size: 52, hook: step === 'look' ? 'face' : null }),
                h('div', { className: 'ex-np-look-c' },
                  h(Segmented, { label: 'Look', value: f.look, onChange: function (v) { set({ look: v }); }, options: [{ id: 'letters', label: 'Letters' }, { id: 'emoji', label: 'Emoji' }, { id: 'icon', label: 'Icon' }] }),
                  h(Fold, { open: f.look !== 'letters' }, h('div', { className: 'ex-np-grid', key: f.look }, (f.look === 'icon' ? NP_ICONS : NP_EMOJI).map(function (x) {
                    var on = f.look === 'icon' ? f.icon === x : f.emoji === x;
                    return h('button', { key: x, type: 'button', className: cx('ex-np-cell', on && 'is-on'), 'aria-pressed': String(on), 'aria-label': x, onClick: function () { set(f.look === 'icon' ? { icon: x } : { emoji: x }); } },
                      f.look === 'icon' ? h(Icon, { name: x, size: 16 }) : h('span', { className: 'ex-pmark-emoji' }, x));
                  }))),
                  h('div', { className: 'ex-np-hues', role: 'radiogroup', 'aria-label': 'Color' }, PS_HUES.map(function (hu) {
                    var on = (f.hue || npHue(f.name)) === hu;
                    return h('button', { key: hu, type: 'button', role: 'radio', 'aria-checked': String(on), 'aria-label': hu, className: cx('ex-np-hue ex-tile-' + hu, on && 'is-on'), onClick: function () { set({ hue: hu }); } });
                  })))))),
          h('div', { className: 'ex-newtask-foot ex-np-foot', ref: rc },
            h('span', { style: { flex: 1 } }),
            h(Button, { variant: 'primary', className: 'ex-np-next', disabled: !can, onClick: next },
              h(EaseSwap, { k: label }, h('span', { className: 'ex-np-next-in' }, label, h(Kbd, null, '↵'))))))));
  }

  /* ── The new project goes home: a copy of its face jumps into the rail, and the tile settles ── */
  function npBezier(x1, y1, x2, y2) {
    function at(t, a, b) { return 3 * a * t * (1 - t) * (1 - t) + 3 * b * t * t * (1 - t) + t * t * t; }
    return function (x) { if (x <= 0) return 0; if (x >= 1) return 1; var lo = 0, hi = 1, t = x; for (var i = 0; i < 40; i++) { var v = at(t, x1, x2); if (Math.abs(v - x) < 1e-5) break; if (v < x) lo = t; else hi = t; t = (lo + hi) / 2; } return at(t, y1, y2); };
  }
  var NP_FLIGHT = npBezier(0.4, 0, 0.2, 1);
  function npOff(el, root) { var x = 0, y = 0; while (el && el !== root) { x += el.offsetLeft; y += el.offsetTop; el = el.offsetParent; } return { x: x, y: y }; }
  function npGhost(root, el, text) {
    var p = npOff(el, root), node, w = el.offsetWidth, hh = el.offsetHeight;
    if (el.tagName === 'INPUT') {   /* a field: only its text travels */
      var cs = getComputedStyle(el), pad = parseFloat(cs.paddingLeft) || 0;
      node = document.createElement('span'); node.className = 'ex-np-ghost-text'; node.textContent = text != null ? text : el.value;
      node.style.cssText = 'font-size:' + cs.fontSize + ';font-weight:' + cs.fontWeight + ';letter-spacing:' + cs.letterSpacing + ';line-height:' + hh + 'px;';
      root.appendChild(node); w = node.offsetWidth; p.x += pad;
    } else { node = el.cloneNode(true); root.appendChild(node); }
    node.classList.add('ex-np-flier');
    node.style.cssText += ';position:absolute;margin:0;left:' + p.x + 'px;top:' + p.y + 'px;width:' + w + 'px;height:' + hh + 'px;transform-origin:0 0;z-index:60;pointer-events:none;';
    return { node: node, x: p.x, y: p.y, w: w, h: hh };
  }
  /* One bell-shaped jump from `from` to `to` (both inside `root`): up to `peak` (a y in root, so it rises over the
     title bar) and down onto the target, never up again. One curve times it all; the copy grows towards the top of the
     arc (`grow`) and shrinks back to the target's size; its shadow follows the height. The target shows as the copy lands. */
  function jumpHome(root, from, to, o) {
    o = o || {};
    if (!root || !from || !to) { if (o.landed) o.landed(to); return null; }
    if (reducedMotion() || !to.animate) { if (o.landed) o.landed(to); return null; }
    var g = npGhost(root, from, o.text), b = npOff(to, root), S = o.scale != null ? o.scale : to.offsetWidth / g.w, G = o.grow == null ? 0.4 : o.grow;
    var c0 = { x: g.x + g.w / 2, y: g.y + g.h / 2 }, c1 = { x: b.x + g.w * S / 2, y: b.y + g.h * S / 2 + (o.ny || 0) }, dx = c1.x - c0.x, dy = c1.y - c0.y;
    function size(u) { return (1 + (S - 1) * u) * (1 + G * 4 * u * (1 - u)); }
    function cy(u, H) { return c0.y + dy * u - 4 * H * u * (1 - u); }
    function topAt(H) { var m = Infinity; for (var k = 0; k <= 60; k++) { var u = k / 60; m = Math.min(m, cy(u, H) - g.h * size(u) / 2); } return m; }
    var peak = o.peak == null ? 4 : o.peak, lo = 0, hi = 2000, H = 0;
    if (topAt(0) > peak) for (var it = 0; it < 40; it++) { H = (lo + hi) / 2; if (topAt(H) > peak) lo = H; else hi = H; }
    var frames = [], N = 90;
    for (var i = 0; i <= N; i++) {
      var t = i / N, u = NP_FLIGHT(t), s = size(u), bell = 4 * u * (1 - u);
      var fr = { offset: t, transform: 'translate(' + (c0.x + dx * u - g.w * s / 2 - g.x).toFixed(2) + 'px,' + (cy(u, H) - g.h * s / 2 - g.y).toFixed(2) + 'px) scale(' + s.toFixed(4) + ')', opacity: t > 0.94 ? Math.max(0, (1 - t) / 0.06) : 1 };
      if (o.shadow !== false) fr.filter = 'drop-shadow(0 ' + (2 + 16 * bell).toFixed(1) + 'px ' + (4 + 22 * bell).toFixed(1) + 'px rgba(10, 20, 40, ' + (0.08 + 0.2 * bell).toFixed(3) + '))';
      frames.push(fr);
    }
    var dur = o.dur || 1000, delay = o.delay || 0;
    to.style.opacity = '0';
    var an = g.node.animate(frames, { duration: dur, delay: delay, easing: 'linear', fill: 'both' });
    var land = to.animate([{ opacity: 0 }, { opacity: 1 }], { duration: Math.max(1, dur * 0.06), delay: delay + dur * 0.94, easing: 'linear', fill: 'both' });
    an.onfinish = function () { g.node.remove(); };
    land.onfinish = function () { to.style.opacity = ''; land.cancel(); if (o.landed) o.landed(to); };
    return an;
  }
  /* It's placed: the tile squashes as it lands and springs back, and one soft ring in its color goes out. */
  /* one soft ring in the project's color goes out from a tile: where the project went */
  function markRing(root, el, hue, delay) {
    if (!root || !el || reducedMotion() || !el.animate) return;
    var p = npOff(el, root), r = document.createElement('span'); r.className = 'ex-np-ring';
    r.style.cssText = 'left:' + (p.x - 4) + 'px;top:' + (p.y - 4) + 'px;width:' + (el.offsetWidth + 8) + 'px;height:' + (el.offsetHeight + 8) + 'px;color:var(--project-' + (hue || 'steel') + ');';
    root.appendChild(r);
    r.animate([{ transform: 'scale(.85)', opacity: 0 }, { transform: 'scale(.95)', opacity: 0.8, offset: 0.12 }, { transform: 'scale(1.55)', opacity: 0 }], { duration: 680, delay: delay || 0, easing: 'cubic-bezier(0.2, 0.7, 0.3, 1)', fill: 'both' }).onfinish = function () { r.remove(); };
  }
  function settleMark(root, el, hue) {
    if (!root || !el || reducedMotion() || !el.animate) return;
    el.style.transformOrigin = '50% 100%';
    el.animate([{ transform: 'scale(1.16, 0.84)' }, { transform: 'scale(0.93, 1.07)', offset: 0.38 }, { transform: 'scale(1.03, 0.98)', offset: 0.7 }, { transform: 'scale(1)' }], { duration: 480, easing: 'cubic-bezier(0.2, 0.7, 0.3, 1)' });
    var p = npOff(el, root), r = document.createElement('span'); r.className = 'ex-np-ring';
    r.style.cssText = 'left:' + (p.x - 4) + 'px;top:' + (p.y - 4) + 'px;width:' + (el.offsetWidth + 8) + 'px;height:' + (el.offsetHeight + 8) + 'px;color:var(--project-' + (hue || 'steel') + ');';
    root.appendChild(r);
    r.animate([{ transform: 'scale(.85)', opacity: 0.8 }, { transform: 'scale(1.55)', opacity: 0 }], { duration: 620, easing: 'cubic-bezier(0.2, 0.7, 0.3, 1)', fill: 'forwards' }).onfinish = function () { r.remove(); };
  }

  var api = { Icon: Icon, Button: Button, IconButton: IconButton, Kbd: Kbd, StatusGlyph: StatusGlyph, StatusBadge: StatusBadge, StatusSummary: StatusSummary, ProjectRail: ProjectRail, ProjectMark: ProjectMark, StageGlyph: StageGlyph, TaskStage: TaskStage, LinkChip: LinkChip, TaskHeader: TaskHeader, CloseTask: CloseTask, NewTask: NewTask, BranchChip: BranchChip, BranchPicker: BranchPicker, branchItems: branchItems, WorkspacePicker: WorkspacePicker, WorkspaceStatus: WorkspaceStatus, TaskLine: TaskLine, branchFromTitle: branchFromTitle, STAGE: STAGE, SessionRow: SessionRow, TaskGroup: TaskGroup, TaskList: TaskList, PanelTabs: PanelTabs, AgentPicker: AgentPicker, PresetCard: PresetCard, PresetPicker: PresetPicker, SessionStart: SessionStart, ModeToggle: ModeToggle, PermissionPicker: PermissionPicker, ToolsMenu: ToolsMenu, ComposerQueue: ComposerQueue, Switch: Switch, Segmented: Segmented, Waveform: Waveform, PERMS: PERMS, THINKING: THINKING, Mention: Mention, Composer: Composer, Message: Message, SideThread: SideThread, PlanMeter: PlanMeter, UsageCard: UsageCard, PlanNotice: PlanNotice, ContextNotice: ContextNotice, GitBar: GitBar, CommitPanel: CommitPanel, ChangeList: ChangeList, DiffReview: DiffReview, Markdown: Markdown, BrowserView: BrowserView, TerminalView: TerminalView, ViewTabs: ViewTabs, diffLines: diffLines, usePanelTakeover: usePanelTakeover, Diff: Diff, Ticker: Ticker, Presence: Presence, play: play, Fold: Fold, Turn: Turn, WorkTimeline: WorkTimeline, NowLine: NowLine, FileChip: FileChip, OutcomeBar: OutcomeBar, TurnNav: TurnNav, TurnActs: TurnActs, FlipScope: FlipScope, AutoHeight: AutoHeight, MotionList: MotionList, usePresence: usePresence, useHold: useHold, isSay: isSay, groupSteps: groupSteps, summarize: summarize, settle: settle, fmtDur: fmtDur, ApprovalCard: ApprovalCard, QuestionCard: QuestionCard, PlanCard: PlanCard, ThinkingBlock: ThinkingBlock, ToolStep: ToolStep, StreamText: StreamText, MentionMenu: MentionMenu, Toast: Toast, Tooltip: Tooltip, SubtaskGlyph: SubtaskGlyph, ModalLayer: ModalLayer, Sheet: Sheet, useRecede: useRecede, SetGroup: SetGroup, SetRow: SetRow, SetField: SetField, SetValue: SetValue, ProjectMenu: ProjectMenu, ProjectSettings: ProjectSettings, DeleteProject: DeleteProject, NewProject: NewProject, projectFace: npMark, jumpHome: jumpHome, settleMark: settleMark, RepoTag: RepoTag, JobBrief: JobBrief, Skeleton: Skeleton, ContextMeter: ContextMeter, NewMessagesPill: NewMessagesPill, ProgressLine: ProgressLine, STATUS: STATUS, EaseSwap: EaseSwap, ChatScroll: ChatScroll, TitleIsland: TitleIsland, TitleBar: TitleBar, IslandName: IslandName, IslandEvent: IslandEvent, MachinePanel: MachinePanel, MachineCard: MachineCard, MachineHome: MachineHome, MachineLaunch: MachineLaunch, GettingReady: GettingReady, stagedSteps: stagedSteps, AddMachine: AddMachine, MachineAdd: MachineAdd, MachineMenu: MachineMenu, EditMachine: EditMachine, HostField: HostField, HostKeyCheck: HostKeyCheck, PairingText: PairingText, PairPaste: PairPaste, MACHINE_ICON: MACHINE_ICON };
  window.Elevenex = Object.assign(window.Elevenex || {}, api);
})();
