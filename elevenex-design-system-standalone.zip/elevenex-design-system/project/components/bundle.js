/* @ds-bundle: {"format":4,"namespace":"Elevenex","components":[{"name":"Icon"},{"name":"Button"},{"name":"IconButton"},{"name":"Kbd"},{"name":"StatusGlyph"},{"name":"StatusBadge"},{"name":"StatusSummary"},{"name":"ProjectRail"},{"name":"ProjectMark"},{"name":"TaskStage"},{"name":"LinkChip"},{"name":"TaskGroup"},{"name":"TaskList"},{"name":"SessionRow"},{"name":"TaskHeader"},{"name":"NewTask"},{"name":"BranchPicker"},{"name":"BranchChip"},{"name":"WorkspacePicker"},{"name":"TaskLine"},{"name":"CloseTask"},{"name":"PanelTabs"},{"name":"SessionStart"},{"name":"PresetPicker"},{"name":"AgentPicker"},{"name":"ModeToggle"},{"name":"PermissionPicker"},{"name":"ToolsMenu"},{"name":"ComposerQueue"},{"name":"Switch"},{"name":"Segmented"},{"name":"Mention"},{"name":"Composer"},{"name":"Message"},{"name":"ChatScroll"},{"name":"SideThread"},{"name":"GitBar"},{"name":"ChangeList"},{"name":"DiffReview"},{"name":"ApprovalCard"},{"name":"QuestionCard"},{"name":"PlanCard"},{"name":"ThinkingBlock"},{"name":"ToolStep"},{"name":"StreamText"},{"name":"MentionMenu"},{"name":"Toast"},{"name":"Tooltip"},{"name":"Skeleton"},{"name":"ContextMeter"},{"name":"NewMessagesPill"},{"name":"ProgressLine"},{"name":"Presence"},{"name":"Turn"},{"name":"WorkTimeline"},{"name":"NowLine"},{"name":"OutcomeBar"},{"name":"FileChip"},{"name":"TurnNav"},{"name":"Fold"},{"name":"TitleIsland"},{"name":"MachinePanel"},{"name":"MachineCard"},{"name":"MachineHome"},{"name":"MachineLaunch"},{"name":"GettingReady"},{"name":"RunChoice"},{"name":"HostField"},{"name":"HostKeyCheck"},{"name":"PairingText"},{"name":"PairPaste"}]} */
(function () {
  'use strict';
  var React = window.React;
  var h = React.createElement;
  var F = React.Fragment;
  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(' '); }

  /* ── Motion helpers ── */
  var useLayout = React.useLayoutEffect || React.useEffect;
  /* Measures the selected child of a container so a single "thumb" can glide between options. */
  function useThumb(sel, deps) {
    var ref = React.useRef(null);
    var _s = React.useState(null); var box = _s[0], setBox = _s[1];
    var _r = React.useState(false); var ready = _r[0], setReady = _r[1];
    useLayout(function () {
      var el = ref.current; if (!el || !el.querySelector) return;
      function measure() {
        var on = el.querySelector(sel);
        if (!on) { setBox(null); return; }
        setBox({ left: on.offsetLeft, top: on.offsetTop, width: on.offsetWidth, height: on.offsetHeight });
      }
      measure();
      var t = setTimeout(function () { setReady(true); }, 30);
      var ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(measure) : null;
      if (ro) ro.observe(el);
      return function () { clearTimeout(t); if (ro) ro.disconnect(); };
    }, deps);
    return { ref: ref, style: box ? { transform: 'translate(' + box.left + 'px,' + box.top + 'px)', width: box.width, height: box.height } : { opacity: 0 }, ready: ready, has: !!box };
  }
  function reducedMotion() { try { return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } }
  function tokenOf(el, name, fallback) { try { var v = getComputedStyle(el || document.documentElement).getPropertyValue('--' + name).trim(); return v || fallback; } catch (e) { return fallback; } }
  function msOf(el, name, fallback) { var v = parseFloat(tokenOf(el, name, '')); return isNaN(v) ? fallback : v; }
  /* Web Animations with the system's spring; silently skipped where unsupported or under reduced motion. */
  function play(el, frames, opts) {
    if (!el || !el.animate || reducedMotion()) return null;
    opts = opts || {};
    var easing = tokenOf(el, opts.ease || 'ease-glide', 'cubic-bezier(0.16, 1, 0.3, 1)');
    var dur = msOf(el, opts.dur || 'dur-glide', 320);
    try { return el.animate(frames, { duration: dur, easing: easing, fill: opts.fill || 'none' }); }
    catch (e) { try { return el.animate(frames, { duration: dur, easing: 'cubic-bezier(0.16, 1, 0.3, 1)' }); } catch (e2) { return null; } }
  }
  /* FLIP: children that move because of a layout change slide from where they were. */
  function useFlip(ref, sel, deps) {
    var last = React.useRef(null);
    useLayout(function () {
      var el = ref.current; if (!el || !el.querySelectorAll) return;
      var now = {}; var nodes = el.querySelectorAll(sel);
      for (var i = 0; i < nodes.length; i++) { var k = nodes[i].getAttribute('data-key') || i; now[k] = nodes[i].offsetLeft; }
      var before = last.current; last.current = now;
      if (!before) return;
      for (var j = 0; j < nodes.length; j++) {
        var key = nodes[j].getAttribute('data-key') || j;
        var dx = (before[key] == null ? now[key] : before[key]) - now[key];
        if (Math.abs(dx) > 0.5) play(nodes[j], [{ transform: 'translateX(' + dx + 'px)' }, { transform: 'none' }]);
      }
    }, deps);
  }
  /* Keeps a child mounted while it plays its exit (.is-leaving), then removes it. */
  function Presence(props) {
    var _m = React.useState(!!props.show); var mounted = _m[0], setMounted = _m[1];
    var _l = React.useState(false); var leaving = _l[0], setLeaving = _l[1];
    React.useEffect(function () {
      if (props.show) { setMounted(true); setLeaving(false); return; }
      if (!mounted) return;
      setLeaving(true);
      var t = setTimeout(function () { setMounted(false); setLeaving(false); }, props.exit || 160);
      return function () { clearTimeout(t); };
    }, [props.show]);
    if (!mounted) return null;
    return h('div', { className: cx('ex-presence', leaving && 'is-leaving') }, props.children);
  }
  /* Presence as a hook: { m: mounted, l: leaving }. Keeps an element for `exit` ms after it should go. */
  function usePresence(show, exit) {
    var _m = React.useState(!!show); var m = _m[0], setM = _m[1];
    var _l = React.useState(false); var l = _l[0], setL = _l[1];
    React.useEffect(function () {
      if (show) { setM(true); setL(false); return; }
      if (!m) return;
      setL(true);
      var t = setTimeout(function () { setM(false); setL(false); }, exit || 140);
      return function () { clearTimeout(t); };
    }, [!!show]);
    return { m: m, l: l };
  }
  /* The last non-empty value, held for `ms` after it empties: bridges the short gaps between two actions. */
  function useHold(value, ms) {
    var last = React.useRef(value);
    var _h = React.useState(!!value); var held = _h[0], setHeld = _h[1];
    if (value) last.current = value;
    React.useEffect(function () {
      if (value) { setHeld(true); return; }
      var t = setTimeout(function () { setHeld(false); }, ms || 600);
      return function () { clearTimeout(t); };
    }, [!!value]);
    return { value: last.current, on: !!value || held };
  }
  /* A box whose height eases to its content's. Small steps (a list row growing in) are followed as they come;
     jumps (a card collapsing, a line of text, a footer appearing) ease over dur-base. Content is never delayed. */
  function AutoHeight(props) {
    var outer = React.useRef(null), inner = React.useRef(null);
    useLayout(function () {
      var o = outer.current, i = inner.current;
      if (!o || !i || typeof ResizeObserver === 'undefined') return;
      var last = i.offsetHeight, sizing = false, t = null;
      function end() { sizing = false; o.style.height = ''; o.classList.remove('is-sizing'); }
      var ro = new ResizeObserver(function () {
        var next = i.offsetHeight;
        if (next === last) return;
        if (reducedMotion()) { last = next; return; }
        if (sizing) { o.style.height = next + 'px'; }
        else if (Math.abs(next - last) < 8) { last = next; return; }
        else {
          sizing = true; o.classList.add('is-sizing');
          o.style.height = last + 'px'; void o.offsetHeight; o.style.height = next + 'px';
        }
        last = next;
        clearTimeout(t); t = setTimeout(end, props.duration || 240);
      });
      ro.observe(i);
      return function () { ro.disconnect(); clearTimeout(t); };
    }, []);
    return h('div', { ref: outer, className: cx('ex-autoh', props.className) }, h('div', { ref: inner, className: cx('ex-autoh-in', props.innerClassName) }, props.children));
  }
  /* A keyed list whose rows grow in and collapse out instead of popping. items: [{ key, node }]. */
  function MotionList(props) {
    var store = React.useRef(null);
    var _f = React.useState(0); var force = _f[1];
    var first = store.current == null;
    var prev = store.current || [];
    var next = props.items || [];
    var inNext = {}; next.forEach(function (it) { inNext[it.key] = 1; });
    var prevAt = {}; prev.forEach(function (p, i) { prevAt[p.key] = i; });
    var leaving = prev.filter(function (p) { return !inNext[p.key]; }).map(function (p) { return p.leave ? p : Object.assign({}, p, { leave: Date.now() }); });
    var out = [], li = 0;
    next.forEach(function (it) {
      var at = prevAt[it.key];
      if (at != null) while (li < leaving.length && prevAt[leaving[li].key] < at) out.push(leaving[li++]);
      var was = at != null ? prev[at] : null;
      out.push({ key: it.key, node: it.node, enter: was ? (was.leave ? true : was.enter) : !first });
    });
    while (li < leaving.length) out.push(leaving[li++]);
    store.current = out;
    var exit = props.exit || 300;
    React.useEffect(function () {
      if (!leaving.length) return;
      var t = setTimeout(function () { var now = Date.now(); store.current = store.current.filter(function (p) { return !p.leave || now - p.leave < exit - 10; }); force(function (x) { return x + 1; }); }, exit);
      return function () { clearTimeout(t); };
    });
    return h(props.as || 'div', { className: props.className, role: props.role }, out.map(function (p) {
      return h(props.itemAs || 'div', { key: p.key, className: cx('ex-ml', p.enter && 'is-enter', p.leave && 'is-leave'), 'aria-hidden': p.leave ? 'true' : undefined }, h('div', { className: 'ex-ml-in' }, p.node));
    }));
  }
  /* FLIP across a region: anything marked data-flip="key" glides from where it was to where it is after a change:
     a reorder, a move to another list (a task changing stage), a filter. The copy a list keeps while it leaves
     hides at once when the same key lives on elsewhere, so a move reads as one thing travelling.
     `selected` (a data-flip key) also glides the selection highlight from the previous row to the new one. */
  function flipSnap(root) {
    /* in the root's own CSS pixels, so a zoomed or scaled page (a preview, a thumbnail) still travels the right distance */
    var r = root.getBoundingClientRect(), k = root.offsetWidth ? r.width / root.offsetWidth : 1, out = {};
    if (!k) k = 1;
    var nodes = root.querySelectorAll('[data-flip]');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i]; if (el.closest('.is-leave')) continue;
      var b = el.getBoundingClientRect();
      out[el.getAttribute('data-flip')] = { el: el, x: (b.left - r.left) / k + root.scrollLeft, y: (b.top - r.top) / k + root.scrollTop, w: b.width / k, h: b.height / k, hidden: !!el.closest('.ex-fold.is-closed') };
    }
    return out;
  }
  function FlipScope(props) {
    var ref = React.useRef(null), before = React.useRef(null), prevSel = React.useRef(props.selected);
    /* read the DOM while it still shows the previous state (render runs before the commit) */
    if (ref.current) before.current = flipSnap(ref.current);
    useLayout(function () {
      var root = ref.current; if (!root) return;
      var prev = before.current; before.current = null;
      var sel = props.selected, was = prevSel.current; prevSel.current = sel;
      if (!prev || reducedMotion()) return;
      var now = flipSnap(root);
      var ghosts = root.querySelectorAll('.ex-ml.is-leave [data-flip]');
      /* a copy only hides when the thing lives on in view; moving into something folded, it fades and collapses as it leaves */
      for (var g = 0; g < ghosts.length; g++) { var gk = now[ghosts[g].getAttribute('data-flip')]; if (gk && !gk.hidden) ghosts[g].closest('.ex-ml').classList.add('is-moved-away'); }
      /* document order, so a parent's move is known before its children: a child only moves by what it adds */
      var moved = {};
      Object.keys(now).forEach(function (k) {
        var a = prev[k], b = now[k]; if (!a || a.hidden || b.hidden) return;
        var dx = a.x - b.x, dy = a.y - b.y;
        var up = b.el.parentElement && b.el.parentElement.closest('[data-flip]');
        var pk = up && root.contains(up) ? up.getAttribute('data-flip') : null;
        if (pk && moved[pk]) { dx -= moved[pk][0]; dy -= moved[pk][1]; }
        if (Math.abs(dx) < 1 && Math.abs(dy) < 1) return;
        moved[k] = [a.x - b.x, a.y - b.y];
        var entering = b.el.closest('.ex-ml.is-enter'); if (entering) entering.classList.add('is-moved');
        if (b.el.getAnimations) b.el.getAnimations().forEach(function (an) { if (an.id === 'ex-flip') an.cancel(); });
        var an = play(b.el, [{ transform: 'translate(' + dx + 'px,' + dy + 'px)' }, { transform: 'none' }], { fill: 'backwards' });
        if (an) { an.id = 'ex-flip'; b.el.classList.add('is-flipping'); an.onfinish = an.oncancel = function () { b.el.classList.remove('is-flipping'); }; }
      });
      if (sel != null && was != null && sel !== was && prev[was] && now[sel] && !prev[was].hidden && !now[sel].hidden) {
        var from = prev[was], to = now[sel], tgt = to.el;
        var glide = document.createElement('div'); glide.className = 'ex-sel-glide'; glide.setAttribute('aria-hidden', 'true');
        glide.style.left = to.x + 'px'; glide.style.top = to.y + 'px'; glide.style.width = to.w + 'px'; glide.style.height = to.h + 'px';
        root.insertBefore(glide, root.firstChild); tgt.classList.add('is-sel-gliding');
        var ga = play(glide, [{ transform: 'translate(' + (from.x - to.x) + 'px,' + (from.y - to.y) + 'px)', width: from.w + 'px', height: from.h + 'px' }, { transform: 'none', width: to.w + 'px', height: to.h + 'px' }], { fill: 'backwards' });
        var done = function () { if (glide.parentNode) glide.parentNode.removeChild(glide); tgt.classList.remove('is-sel-gliding'); };
        if (ga) ga.onfinish = ga.oncancel = done; else done();
      }
    });
    return h(props.as || 'div', { ref: ref, className: cx('ex-flip', props.className), style: props.style }, props.children);
  }
  /* A number that rolls when it changes. */
  function Ticker(props) {
    var prev = React.useRef(props.value);
    var dir = props.value > prev.current ? 'up' : props.value < prev.current ? 'down' : null;
    React.useEffect(function () { prev.current = props.value; });
    return h('span', { className: 'ex-tick' }, h('span', { key: String(props.value), className: cx('ex-tick-n', dir && 'is-' + dir) }, props.value));
  }

  /* ── Icon: 16px grid, 1.5 stroke, round caps ── */
  var P = {
    plus: 'M8 3v10M3 8h10',
    'arrow-up': 'M8 13V3M4 7l4-4 4 4',
    terminal: 'M3.5 3h9A1.5 1.5 0 0 1 14 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 11.5v-7A1.5 1.5 0 0 1 3.5 3zM5 6.5l2 1.5-2 1.5M8.5 10H11',
    code: 'M6 4L2.5 8 6 12M10 4l3.5 4L10 12',
    changes: 'M9.5 2.5h-5a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1v-7zM8 6v3M6.5 7.5h3M6.5 11h3',
    actions: 'M5 3.5v9l7-4.5z',
    globe: 'M8 2.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11zM2.5 8h11M8 2.5c1.6 1.5 2.4 3.4 2.4 5.5S9.6 12 8 13.5C6.4 12 5.6 10.1 5.6 8S6.4 4 8 2.5z',
    fork: 'M5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM8 11a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM5 5v1a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2V5M8 8v3',
    'side-chat': 'M2.5 4A1.5 1.5 0 0 1 4 2.5h6A1.5 1.5 0 0 1 11.5 4v3.5A1.5 1.5 0 0 1 10 9H6.5l-2.5 2V9A1.5 1.5 0 0 1 2.5 7.5zM13.5 6.5v4a1.5 1.5 0 0 1-1.5 1.5v1.5L10 12H7.5',
    chat: 'M4 2.5h8A1.5 1.5 0 0 1 13.5 4v5.5A1.5 1.5 0 0 1 12 11H7.5l-3 2.5V11H4a1.5 1.5 0 0 1-1.5-1.5V4A1.5 1.5 0 0 1 4 2.5z',
    check: 'M3.5 8.5l3 3 6-7',
    x: 'M4.5 4.5l7 7M11.5 4.5l-7 7',
    'chevron-down': 'M4.5 6.5L8 10l3.5-3.5',
    'chevron-right': 'M6.5 4.5L10 8l-3.5 3.5',
    at: 'M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0zM10.5 8v1a1.75 1.75 0 0 0 3.5 0V8A6 6 0 1 0 11.5 12.9',
    search: 'M7 2.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zM10.3 10.3L13.5 13.5',
    commit: 'M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM1.5 8h4M10.5 8h4',
    push: 'M8 11V3M4.5 6.5L8 3l3.5 3.5M3 13.5h10',
    more: 'M3.5 8h.01M8 8h.01M12.5 8h.01',
    stop: 'M5.5 4.5h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1z',
    sidebar: 'M3.5 3h9A1.5 1.5 0 0 1 14 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 11.5v-7A1.5 1.5 0 0 1 3.5 3zM6 3v10',
    panel: 'M3.5 3h9A1.5 1.5 0 0 1 14 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 11.5v-7A1.5 1.5 0 0 1 3.5 3zM10 3v10',
    attach: 'M12.5 7.5l-4.6 4.6a3 3 0 0 1-4.2-4.2L8.5 3.1a2 2 0 0 1 2.8 2.8L6.6 10.6a1 1 0 0 1-1.4-1.4L9.5 5',
    repo: 'M4.5 2.5h7.5v9H4.5a1.5 1.5 0 0 0-1.5 1.5V4a1.5 1.5 0 0 1 1.5-1.5zM3 13a1.5 1.5 0 0 0 1.5 1h7.5v-2.5',
    task: 'M3 4.5h1M6.5 4.5H13M3 8h1M6.5 8H13M3 11.5h1M6.5 11.5H10',
    copy: 'M6 5.5h6a.5.5 0 0 1 .5.5v6.5a.5.5 0 0 1-.5.5H6a.5.5 0 0 1-.5-.5V6a.5.5 0 0 1 .5-.5zM10.5 5.5V3.5a.5.5 0 0 0-.5-.5H4a.5.5 0 0 0-.5.5V10a.5.5 0 0 0 .5.5h1.5',
    expand: 'M9.5 2.5h4v4M13.5 2.5L9 7M6.5 13.5h-4v-4M2.5 13.5L7 9',
    folder: 'M2.5 4.5a1 1 0 0 1 1-1h3l1.5 1.5h4.5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1z',
    'expand-up': 'M8 10.5v-7M5 6.5l3-3 3 3M3 13h10',
    'expand-down': 'M3 3h10M8 5.5v7M5 9.5l3 3 3-3',
    unfold: 'M8 6V1.5M5.5 4L8 1.5 10.5 4M8 10v4.5M5.5 12L8 14.5 10.5 12M3 8h10',
    shrink: 'M13.5 2.5L9.5 6.5M9.5 3v3.5H13M2.5 13.5l4-4M3 9.5h3.5V13',
    wrap: 'M2.5 4h11M2.5 8h9a2 2 0 0 1 0 4H8M9.5 10.5L8 12l1.5 1.5M2.5 12h3',
    file: 'M9.5 2.5h-5a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1v-7zM9.5 2.5v3h3',
    pr: 'M4.5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM4.5 11a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11.5 11a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM4.5 5v6M11.5 11V6.5a2 2 0 0 0-2-2H7.5M9 3L7.5 4.5 9 6',
    merged: 'M4.5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM4.5 11a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11.5 7.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM4.5 5v6M4.5 5.5c0 2 1.5 3.5 5.5 3.5',
    ticket: 'M3.5 3.5h9a1 1 0 0 1 1 1v1.75a1.75 1.75 0 0 0 0 3.5v1.75a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1v-1.75a1.75 1.75 0 0 0 0-3.5V4.5a1 1 0 0 1 1-1zM9.5 3.5v1.5M9.5 7.25v1.5M9.5 11v1.5',
    link: 'M7 9a2.5 2.5 0 0 0 3.5 0l2-2A2.5 2.5 0 0 0 9 3.5l-.75.75M9 7a2.5 2.5 0 0 0-3.5 0l-2 2A2.5 2.5 0 0 0 7 12.5l.75-.75',
    archive: 'M2.5 3.5h11v3h-11zM3.5 6.5v5.5a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V6.5M6.5 9h3',
    layers: 'M8 2.5l5.5 3L8 8.5 2.5 5.5zM2.5 8.25L8 11.25l5.5-3M2.5 10.75L8 13.75l5.5-3',
    focus: 'M8 2.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11zM8 6.25a1.75 1.75 0 1 0 0 3.5 1.75 1.75 0 0 0 0-3.5z',
    clock: 'M8 2.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11zM8 5v3l2 1.5',
    mic: 'M8 2.5a2 2 0 0 0-2 2v3.5a2 2 0 0 0 4 0V4.5a2 2 0 0 0-2-2zM4 7.75a4 4 0 0 0 8 0M8 11.75v1.75',
    bolt: 'M8.75 2L4 9h3.75L7.25 14 12 7H8.25z',
    shield: 'M8 2l5 2v3.5c0 3-2.2 5.3-5 6.5-2.8-1.2-5-3.5-5-6.5V4z',
    plug: 'M6 2.5v3M10 2.5v3M4.5 5.5h7v2a3.5 3.5 0 0 1-7 0zM8 11v2.5',
    steer: 'M3.5 3v4.5a2 2 0 0 0 2 2h7M10 7l2.5 2.5L10 12',
    pencil: 'M10.5 3l2.5 2.5L6 12.5 3 13l.5-3z',
    trash: 'M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.5 8.5h6l.5-8.5',
    plan: 'M2.75 4.25l1 1 2-2M2.75 9.25l1 1 2-2M8 4.5h5.25M8 9.5h5.25M8 13h3.5',
    branch: 'M5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM5 11a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11 3.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM5 5v6M11 6.5c0 2.5-2.5 3.5-6 4.5',
    workspace: 'M2.5 5L8 2.5 13.5 5v6L8 13.5 2.5 11zM2.5 5L8 7.5 13.5 5M8 7.5v6',
    reset: 'M3 8a5 5 0 1 0 1.5-3.5M3 2.5v2.5h2.5',
    'arrow-down': 'M8 3v10M4 9l4 4 4-4',
    bulb: 'M6 12.5h4M6.5 14.25h3M8 1.75a4.25 4.25 0 0 0-2.6 7.6c.5.4.85 1 .85 1.65v.25h3.5V11c0-.65.35-1.25.85-1.65A4.25 4.25 0 0 0 8 1.75z',
    laptop: 'M3.5 4.5h9a1 1 0 0 1 1 1v5.5h-11V5.5a1 1 0 0 1 1-1zM1.5 11h13l-.6 1.2a1 1 0 0 1-.9.55H3a1 1 0 0 1-.9-.55z',
    server: 'M3 2.5h10a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1zM3 8.5h10a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1zM4.5 5h1M4.5 11h1',
    peer: 'M2 4.5h5v4H2zM9 7.5h5v4H9zM4.5 8.5v2.5h4.5M11.5 7.5V5H7',
    key: 'M10 2.5a3.5 3.5 0 1 1-2.9 5.46L3 12v1.5H1.5V12l4.4-4.4A3.5 3.5 0 0 1 10 2.5zM10.5 5.2h.01',
    download: 'M8 2.5v8M4.5 7.5L8 11l3.5-3.5M3 13.5h10',
    wifi: 'M2 6.2a8.5 8.5 0 0 1 12 0M4.2 8.6a5.3 5.3 0 0 1 7.6 0M6.4 11a2.2 2.2 0 0 1 3.2 0M8 13.2h.01',
    refresh: 'M13 4.5V2M13 4.5h-2.5M12.6 4.4A5.5 5.5 0 1 0 13.5 8',
    grid: 'M3 3h4v4H3zM9 3h4v4H9zM3 9h4v4H3zM9 9h4v4H9z',
    window: 'M2.5 3.5h11v9h-11zM2.5 6h11M9.5 8.5v3M8 10h3',
    question: 'M8 14a6 6 0 1 0 0-12 6 6 0 0 0 0 12zM6.25 6.25a1.85 1.85 0 1 1 2.6 1.7c-.5.25-.85.7-.85 1.3v.25M8 11.25v.05'
  };
  function Icon(props) {
    var size = props.size || 16;
    return h('svg', { className: cx('ex-icon', props.className), width: size, height: size, viewBox: '0 0 16 16', fill: 'none', stroke: 'currentColor', strokeWidth: props.name === 'more' ? 2.4 : 1.5, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': 'true' },
      h('path', { d: P[props.name] || P.plus }));
  }

  function Kbd(props) { return h('kbd', { className: 'ex-kbd' }, props.children); }

  function Button(props) {
    var variant = props.variant || 'secondary';
    var size = props.size || 'md';
    var rest = Object.assign({}, props);
    ['variant', 'size', 'icon', 'iconRight', 'kbd', 'className', 'children'].forEach(function (k) { delete rest[k]; });
    var isz = size === 'sm' ? 14 : 16;
    return h('button', Object.assign({ type: 'button' }, rest, { className: cx('ex-btn', 'ex-btn-' + variant, size === 'sm' && 'ex-btn-sm', props.className) }),
      props.icon && h(Icon, { name: props.icon, size: isz }),
      props.children,
      props.iconRight && h(Icon, { name: props.iconRight, size: isz }),
      props.kbd && h(Kbd, null, props.kbd));
  }

  function IconButton(props) {
    var rest = Object.assign({}, props);
    ['icon', 'label', 'active', 'size', 'className'].forEach(function (k) { delete rest[k]; });
    return h('button', Object.assign({ type: 'button', 'aria-label': props.label, title: props.label }, rest, {
      className: cx('ex-iconbtn', props.size === 'sm' && 'ex-iconbtn-sm', props.className),
      'aria-pressed': props.active === undefined ? undefined : String(!!props.active)
    }), h(Icon, { name: props.icon, size: props.size === 'sm' ? 14 : 16 }));
  }

  /* ── Status ── */
  var STATUS = {
    running: 'Running', attention: 'Needs you', review: 'Review', done: 'Done', failed: 'Failed', queued: 'Queued'
  };
  function glyphChange(from, to) {
    if (from === to) return null;
    if (from === 'running' && (to === 'done' || to === 'review')) return 'is-finish';
    if (to === 'attention') return 'is-nudge';
    if (to === 'failed') return 'is-shake';
    return 'is-swap';
  }
  function StatusGlyph(props) {
    var s = props.status || 'queued';
    var size = props.size || 14;
    var prev = React.useRef(s);
    var _c = React.useState(null); var change = _c[0], setChange = _c[1];
    useLayout(function () {
      var c = glyphChange(prev.current, s); prev.current = s;
      if (!c) return;
      setChange(c);
      var t = setTimeout(function () { setChange(null); }, 900);
      return function () { clearTimeout(t); };
    }, [s]);
    var kids;
    if (s === 'running') kids = [
      h('circle', { key: 't', cx: 7, cy: 7, r: 5, fill: 'none', stroke: 'currentColor', strokeOpacity: 0.25, strokeWidth: 2 }),
      h('path', { key: 'a', className: 'ex-spin', d: 'M7 2a5 5 0 0 1 5 5', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round' })];
    else if (s === 'attention') kids = [
      h('path', { key: 'd', d: 'M7 .9l6.1 6.1L7 13.1.9 7z', fill: 'currentColor' }),
      h('path', { key: 'e', d: 'M7 4.2v3.4M7 9.6v.1', stroke: 'var(--surface-raised)', strokeWidth: 1.6, strokeLinecap: 'round' })];
    else if (s === 'review') kids = [
      h('circle', { key: 'o', cx: 7, cy: 7, r: 5.25, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 }),
      h('path', { key: 'f', d: 'M7 3.5a3.5 3.5 0 0 1 0 7z', fill: 'currentColor' })];
    else if (s === 'done') kids = [
      h('circle', { key: 'o', cx: 7, cy: 7, r: 5.25, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 }),
      h('path', { key: 'c', d: 'M4.6 7.2l1.7 1.7 3.2-3.6', fill: 'none', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' })];
    else if (s === 'failed') kids = [
      h('circle', { key: 'o', cx: 7, cy: 7, r: 6, fill: 'currentColor' }),
      h('path', { key: 'x', d: 'M5 5l4 4M9 5l-4 4', stroke: 'var(--surface-raised)', strokeWidth: 1.5, strokeLinecap: 'round' })];
    else kids = [h('circle', { key: 'o', cx: 7, cy: 7, r: 5.25, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5, strokeDasharray: '2.2 2.2' })];
    if (change === 'is-finish') kids = kids.concat([h('circle', { key: 'burst', className: 'ex-burst', cx: 7, cy: 7, r: 6, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 })]);
    return h('svg', { className: cx('ex-glyph', 'ex-glyph-' + s, change), width: size, height: size, viewBox: '0 0 14 14', role: 'img', 'aria-label': STATUS[s] || s }, kids);
  }
  function StatusBadge(props) {
    var s = props.status || 'queued';
    return h('span', { className: 'ex-badge ex-badge-' + s }, h(StatusGlyph, { status: s, size: 12 }), props.label || STATUS[s]);
  }
  function StatusSummary(props) {
    var c = props.counts || {};
    var order = [['attention', 'Needs you'], ['running', 'Running'], ['review', 'Review'], ['done', 'Done']];
    return h('div', { className: 'ex-sum', role: 'group', 'aria-label': 'Session status' }, order.map(function (o) {
      var n = c[o[0]] || 0;
      return h('button', { key: o[0], type: 'button', className: cx('ex-sum-item', n === 0 && 'is-zero'), 'aria-pressed': String(props.active === o[0]), onClick: props.onSelect && function () { props.onSelect(o[0]); } },
        h('span', { className: 'ex-sum-n' }, h(StatusGlyph, { status: o[0], size: 12 }), h(Ticker, { value: n })),
        h('span', { className: 'ex-sum-l' }, o[1]));
    }));
  }

  /* ── Project rail ── */
  /* A project's face: its logo when it has one, else a monogram on its hue. */
  function ProjectMark(props) {
    var size = props.size || 36;
    var r = size >= 28 ? 'var(--radius-md)' : size >= 20 ? '6px' : '4px';
    var style = { width: size, height: size, borderRadius: r, fontSize: Math.round(size * 0.36) };
    if (props.logo) return h('span', { className: 'ex-pmark ex-pmark-logo', style: style, 'aria-hidden': props.decorative ? 'true' : undefined }, h('img', { src: props.logo, alt: props.decorative ? '' : props.name }));
    return h('span', { className: 'ex-pmark ex-tile-' + (props.hue || 'steel'), style: style, 'aria-hidden': props.decorative ? 'true' : undefined }, props.initials || (props.name || '').slice(0, 2));
  }
  function RailPips(p) {
    if (p.muted) return null;
    if (p.attention) return h('span', { className: 'ex-tile-pip', 'aria-hidden': 'true' }, p.attention);
    if (p.running) return h('span', { className: 'ex-tile-run', 'aria-hidden': 'true' }, h(StatusGlyph, { status: 'running', size: 14 }));
    return null;
  }
  function railLabel(name, p) {
    if (p.muted) return name + ', muted';
    return name + (p.attention ? ', ' + p.attention + ' need you' : '') + (p.running ? ', ' + p.running + ' running' : '');
  }
  function ProjectRail(props) {
    var projects = props.projects || [];
    var all = props.all || {};
    var sel = props.onSelect;
    var ind = useThumb('[aria-current="true"]', [props.activeId, projects.length]);
    var bar = React.useRef(null), firstRail = React.useRef(true);
    React.useEffect(function () {
      if (firstRail.current) { firstRail.current = false; return; }
      play(bar.current, [{ transform: 'scaleY(1)' }, { transform: 'scaleY(1.7)', offset: 0.35 }, { transform: 'scaleY(1)' }], { ease: 'ease-out', dur: 'dur-glide' });
    }, [props.activeId]);
    return h('nav', { ref: ind.ref, className: cx('ex-rail ex-glass', ind.has && 'has-ind', ind.ready && 'is-ready'), 'aria-label': 'Projects' },
      h('span', { className: 'ex-rail-ind', 'aria-hidden': 'true', style: ind.style }, h('i', { ref: bar })),
      props.all !== false && h('button', { type: 'button', className: 'ex-tile ex-tile-all', 'aria-label': railLabel('All projects', all), title: 'All projects  ⌘0', 'aria-current': String(props.activeId === 'all'), onClick: sel && function () { sel('all'); } },
        h(Icon, { name: 'layers' }), h(RailPips, all)),
      props.all !== false && h('span', { className: 'ex-rail-sep', 'aria-hidden': 'true' }),
      projects.map(function (p, i) {
        return h('button', { key: p.id, type: 'button', className: cx('ex-tile ex-tile-proj', p.muted && 'is-muted'), 'aria-label': railLabel(p.name, p), title: p.name + (i < 9 ? '  ⌘' + (i + 1) : ''), 'aria-current': String(p.id === props.activeId), onClick: sel && function () { sel(p.id); } },
          h(ProjectMark, Object.assign({}, p, { size: 36, decorative: true })), h(RailPips, p));
      }),
      h('span', { className: 'ex-rail-sep', 'aria-hidden': 'true' }),
      h('button', { type: 'button', className: 'ex-tile ex-tile-add', 'aria-label': 'Add project', title: 'Add project' }, h(Icon, { name: 'plus' })));
  }

  /* ── Task lifecycle ── */
  var STAGE = { planned: 'Planned', active: 'In progress', waiting: 'Waiting', closed: 'Closed' };
  function StageGlyph(props) {
    var s = props.stage || 'planned';
    var size = props.size || 14;
    var box = { x: 1.75, y: 1.75, width: 10.5, height: 10.5, rx: 3, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 };
    var kids;
    if (s === 'planned') kids = [h('rect', Object.assign({ key: 'b' }, box, { strokeDasharray: '2.4 2' }))];
    else if (s === 'active') kids = [h('rect', Object.assign({ key: 'b' }, box)), h('rect', { key: 'f', x: 4, y: 7, width: 6, height: 3, rx: 1, fill: 'currentColor' })];
    else if (s === 'waiting') kids = [h('rect', Object.assign({ key: 'b' }, box)), h('path', { key: 'p', d: 'M5.75 5v4M8.25 5v4', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round' })];
    else kids = [h('rect', { key: 'b', x: 1, y: 1, width: 12, height: 12, rx: 3.5, fill: 'currentColor' }), h('path', { key: 'c', d: 'M4.4 7.2l1.7 1.7 3.5-3.8', fill: 'none', stroke: 'var(--surface-raised)', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' })];
    return h('svg', { className: 'ex-glyph ex-stage-' + s, width: size, height: size, viewBox: '0 0 14 14', role: 'img', 'aria-label': STAGE[s] }, kids);
  }
  function TaskStage(props) {
    var s = props.stage || 'planned';
    return h('button', { type: 'button', className: 'ex-stage ex-stage-pill-' + s, 'aria-haspopup': 'menu', title: 'Change stage' },
      h(StageGlyph, { stage: s, size: 12 }), STAGE[s], h(Icon, { name: 'chevron-down', size: 12 }));
  }
  var PR_STATE = { draft: 'Draft', open: 'Open', approved: 'Approved', failing: 'Checks failing', merged: 'Merged', closed: 'Closed' };
  function LinkChip(props) {
    var kind = props.kind || 'pr';
    var st = props.state;
    var icon = kind === 'ticket' ? 'ticket' : st === 'merged' ? 'merged' : 'pr';
    var word = kind === 'pr' ? PR_STATE[st] : st;
    return h(props.href ? 'a' : 'span', { href: props.href, className: cx('ex-link', 'ex-link-' + kind, st && 'is-' + st, props.compact && 'is-compact'), title: (kind === 'pr' ? 'Pull request ' : 'Ticket ') + props.label + (word ? ' · ' + word : '') },
      h(Icon, { name: icon, size: 12 }), h('span', { className: 'ex-link-label' }, props.label),
      !props.compact && word ? h('span', { className: 'ex-link-state' }, word) : null);
  }
  function TaskHeader(props) {
    var links = props.links || [];
    return h('header', { className: 'ex-taskhead' },
      h('div', { className: 'ex-taskhead-row' },
        h('div', { className: 'ex-shell-title' }, props.project ? h(ProjectMark, Object.assign({}, props.project, { size: 20, decorative: true })) : null, h('span', { className: 'ex-taskhead-name' }, props.title), h(TaskStage, { stage: props.stage })),
        h('span', { className: 'ex-grow' }),
        props.closeSuggested
          ? h(Button, { variant: props.git && (props.git.files || props.git.ahead) ? 'secondary' : 'primary', size: 'sm', icon: 'archive' }, 'Close task')
          : h(IconButton, { icon: 'archive', label: 'Close task' }),
        h(IconButton, { icon: 'panel', label: 'Toggle side panel', active: !!props.panelOpen })),
      h('div', { className: 'ex-taskhead-row' },
        h('div', { className: 'ex-shell-meta' },
          props.branch ? h(BranchChip, { name: props.branch, compact: true }) : null,
          links.map(function (l, i) { return h(LinkChip, Object.assign({ key: i }, l)); }),
          links.length ? null : h('button', { type: 'button', className: 'ex-link-add' }, h(Icon, { name: 'link', size: 12 }), 'Link PR or ticket'),
          props.meta ? h('span', { className: 'ex-taskhead-meta' }, props.meta) : null),
        h('span', { className: 'ex-grow' }),
        !props.git ? null
          : h(GitBar, Object.assign({ compact: true }, props.git))));
  }
  function CloseTask(props) {
    var unpushed = props.unpushed || 0;
    var running = props.running || 0;
    var ticket = props.ticket;
    var _c = React.useState(true); var moveTicket = _c[0], setMove = _c[1];
    return h('section', { className: 'ex-dialog', role: 'dialog', 'aria-label': 'Close task' },
      h('div', { className: 'ex-dialog-title' }, 'Close “' + props.title + '”?'),
      h('ul', { className: 'ex-dialog-list' },
        running ? h('li', null, h(StatusGlyph, { status: 'running', size: 14 }), 'Stops ' + running + (running === 1 ? ' running session' : ' running sessions')) : null,
        h('li', null, h(Icon, { name: 'archive', size: 14 }), 'Archives ' + (props.sessions || 0) + ' sessions. Reopen them any time from Closed.'),
        h('li', null, h(Icon, { name: 'check', size: 14 }), 'Cleans up the task’s files on disk.'),
        unpushed ? h('li', { className: 'is-warn' }, h(StatusGlyph, { status: 'attention', size: 14 }), unpushed + (unpushed === 1 ? ' commit is' : ' commits are') + ' not pushed yet.') : null),
      ticket ? h('label', { className: 'ex-check-row' }, h('input', { type: 'checkbox', checked: moveTicket, onChange: function () { setMove(!moveTicket); } }), 'Move ', h(LinkChip, { kind: 'ticket', label: ticket, compact: true }), ' to Done') : null,
      h('div', { className: 'ex-dialog-foot' },
        h(Button, { variant: 'ghost' }, 'Cancel'),
        h('span', { style: { flex: 1 } }),
        unpushed ? h(Button, { variant: 'secondary' }, 'Close without pushing') : null,
        h(Button, { variant: 'primary', icon: unpushed ? 'push' : 'archive' }, unpushed ? 'Push and close' : 'Close task')));
  }
  /* ── Branch and workspace ── */
  function branchFromTitle(title, prefix) {
    var slug = String(title || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    if (slug.length > 48) slug = slug.slice(0, 48).replace(/-[^-]*$/, '');
    return slug ? (prefix || '') + slug : '';
  }
  var BAD_BRANCH = /(\s|\.\.|[~^:?*\[\\]|@\{|\/\/|\/$|\.lock$|^-|\.$)/;
  function BranchChip(props) {
    var _c = React.useState(false); var copied = _c[0], setCopied = _c[1];
    function copy() { try { if (navigator.clipboard) navigator.clipboard.writeText(props.name); } catch (e) {} setCopied(true); setTimeout(function () { setCopied(false); }, 1200); }
    return h('span', { className: cx('ex-branch', props.compact && 'is-compact', copied && 'is-copied') },
      h('button', { type: 'button', className: 'ex-branch-name', title: 'Branch · rename' }, h(Icon, { name: 'branch', size: 12 }), h('span', null, props.name)),
      props.base && !props.compact ? h('span', { className: 'ex-branch-base' }, 'from ', h('span', { className: 'ex-mono' }, props.base)) : null,
      h('button', { type: 'button', className: 'ex-branch-copy', 'aria-label': copied ? 'Copied' : 'Copy branch name', title: copied ? 'Copied' : 'Copy branch name', onClick: copy }, h(Icon, { key: copied ? 'c' : 'k', name: copied ? 'check' : 'copy', size: 12 })));
  }
  function WorkspacePicker(props) {
    var pm = usePresence(props.open);
    var v = props.value || 'auto';
    var items = props.items || [];
    var free = items.filter(function (w) { return w.state === 'free'; });
    var auto = free[0];
    var label = v === 'auto' ? 'Automatic' : v;
    var sub = v === 'auto' ? (auto ? 'reuses ' + auto.name + (auto.note ? ', ' + auto.note : '') : 'creates a new one') : '';
    return h('div', { className: 'ex-agent-wrap' },
      h('button', { type: 'button', className: 'ex-agent ex-ws', 'aria-haspopup': 'listbox', 'aria-expanded': String(!!props.open) },
        h(Icon, { name: 'workspace', size: 14 }), label, sub ? h('span', { className: 'ex-agent-sub' }, sub) : null, h(Icon, { name: 'chevron-down', size: 13 })),
      pm.m && h('div', { className: 'ex-menu' + (pm.l ? ' is-leaving' : ''), role: 'listbox', style: { top: 32, left: 0, minWidth: 340 } },
        h('div', { className: 'ex-menu-item', role: 'option', 'aria-selected': String(v === 'auto') },
          h('span', { className: 'ex-grow' }, h('span', null, 'Automatic'), h('span', { className: 'ex-muted', style: { fontSize: 12, lineHeight: '16px' } }, 'Reuse a free workspace from the pool, or add one')),
          v === 'auto' ? h(Icon, { name: 'check', size: 14, className: 'ex-check' }) : null),
        h('div', { className: 'ex-menu-sep' }),
        h('div', { className: 'ex-overline ex-menu-label', style: { display: 'flex' } }, h('span', { style: { flex: 1 } }, 'Pool'), h('span', { style: { letterSpacing: 0, textTransform: 'none', fontWeight: 500 } }, free.length + ' free of ' + items.length)),
        items.map(function (w, i) {
          var used = w.state === 'used';
          return h('div', { key: i, role: 'option', className: cx('ex-menu-item', used && 'is-used'), 'aria-selected': String(v === w.name), 'aria-disabled': used ? 'true' : undefined },
            h('span', { className: cx('ex-dot', used ? 'is-off' : 'is-ok') }),
            h('span', { className: 'ex-grow' }, h('span', { className: 'ex-mono' }, w.name), h('span', { className: 'ex-muted', style: { fontSize: 12, lineHeight: '16px' } }, used ? 'In use · ' + w.task : 'Free' + (w.note ? ' · ' + w.note : ''))),
            v === w.name ? h(Icon, { name: 'check', size: 14, className: 'ex-check' }) : null);
        }),
        h('div', { className: 'ex-menu-item' }, h(Icon, { name: 'plus', size: 14 }), h('span', { className: 'ex-grow' }, 'New workspace')),
        h('div', { className: 'ex-menu-sep' }),
        h('div', { className: 'ex-menu-item ex-muted' }, h(Icon, { name: 'workspace', size: 14 }), h('span', { className: 'ex-grow' }, 'Manage workspaces…'))));
  }
  function WorkspaceStatus(props) {
    var s = props.state || 'ready';
    if (s === 'ready') return h('span', { className: 'ex-wsstat' }, h(Icon, { name: 'check', size: 12 }), 'Workspace ready');
    return h('span', { className: 'ex-wsstat is-setup' }, h(StatusGlyph, { status: 'running', size: 12 }), 'Setting up workspace', props.step ? h('span', { className: 'ex-muted' }, '· ' + props.step) : null);
  }

  /* Branch combobox list: matches for what you typed, plus "Create" when it doesn't exist yet. */
  function tokensOf(q) { return String(q || '').toLowerCase().split(/[\s\/_-]+/).filter(Boolean); }
  function branchItems(query, branches, allowCreate) {
    var q = String(query || '').trim();
    var toks = tokensOf(q);
    var list = (branches || []).filter(function (b) {
      if (!toks.length) return true;
      var n = b.name.toLowerCase();
      return toks.every(function (t) { return n.indexOf(t) !== -1; });
    }).map(function (b) {
      var n = b.name.toLowerCase(), ql = q.toLowerCase();
      var score = n === ql ? 0 : (b.isDefault ? 1 : 2) + (n.indexOf(ql) === 0 ? 0 : 2);
      return { kind: 'branch', name: b.name, meta: b.meta, when: b.when, remote: b.remote, task: b.task, isDefault: b.isDefault, score: score };
    }).sort(function (a, b) { return a.score - b.score; });
    var exact = list.some(function (b) { return b.name === q; });
    if (allowCreate && q && !exact) {
      var bad = BAD_BRANCH.test(q);
      list.unshift({ kind: bad ? 'invalid' : 'create', name: q });
    }
    return list.slice(0, 7);
  }
  function Highlight(props) {
    var toks = tokensOf(props.query);
    if (!toks.length) return h(F, null, props.text);
    var re = new RegExp('(' + toks.map(function (t) { return t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('|') + ')', 'ig');
    return h(F, null, String(props.text).split(re).map(function (part, i) { return i % 2 ? h('mark', { key: i }, part) : part; }));
  }
  function BranchPicker(props) {
    var items = props.items || branchItems(props.query, props.branches, props.allowCreate);
    var hi = props.hi || 0;
    var th = useThumb('[aria-selected="true"]', [hi, props.query, items.length]);
    return h('div', { ref: th.ref, className: cx('ex-combo-list', th.has && 'has-thumb', th.ready && 'is-ready'), role: 'listbox', 'aria-label': props.label || 'Branches' },
      h('span', { className: 'ex-thumb ex-list-thumb', 'aria-hidden': 'true', style: th.style }),
      items.length ? items.map(function (it, i) {
        var used = !!it.task;
        var cls = cx('ex-combo-item', 'is-' + it.kind, used && 'is-used');
        var sel = i === hi && !used && it.kind !== 'invalid';
        if (it.kind === 'invalid') return h('div', { key: i, className: cls, role: 'option', 'aria-disabled': 'true' },
          h(Icon, { name: 'x', size: 13 }), h('span', { className: 'ex-grow' }, 'Not a valid branch name: no spaces, “..”, or ~ ^ : ? * [ \\'));
        if (it.kind === 'create') return h('div', { key: i, className: cls, role: 'option', 'aria-selected': String(sel), onClick: props.onPick && function () { props.onPick(it); } },
          h(Icon, { name: 'plus', size: 13 }), h('span', { className: 'ex-combo-verb' }, 'Create'), h('span', { className: 'ex-mono ex-grow' }, it.name),
          props.base ? h('span', { className: 'ex-combo-meta' }, 'from ' + props.base) : null, sel ? h(Kbd, null, '↵') : null);
        return h('div', { key: i, className: cls, role: 'option', 'aria-selected': String(sel), 'aria-disabled': used ? 'true' : undefined, onClick: !used && props.onPick ? function () { props.onPick(it); } : undefined },
          h(Icon, { name: 'branch', size: 13 }), h('span', { className: 'ex-mono ex-grow' }, h(Highlight, { text: it.name, query: props.query })),
          it.isDefault ? h('span', { className: 'ex-bf-tag' }, 'default') : null,
          h('span', { className: 'ex-combo-meta' }, used ? 'In use · ' + it.task : [it.remote ? 'remote' : null, it.when].filter(Boolean).join(' · ')),
          sel ? h(Kbd, null, '↵') : null);
      }) : h('div', { className: 'ex-combo-empty' }, 'No branch matches “' + props.query + '”'));
  }

  /* ── New task: 1 Name ↵ 2 Branch ↵ 3 From ↵ (numbered rows, all visible) ── */
  var NT_ORDER = { name: 0, branch: 1, base: 2, created: 3 };
  function StepNum(props) {
    var st = props.state;
    return h('span', { className: 'ex-nt-num is-' + st, 'aria-hidden': 'true' }, st === 'done' ? h(Icon, { name: 'check', size: 11 }) : st === 'skip' ? '–' : props.n);
  }
  function NewTask(props) {
    var p = props.project || { name: 'Project', hue: 'steel' };
    var prefix = props.branchPrefix || '';
    var branches = props.branches || [];
    var bases = props.bases || branches.filter(function (b) { return !b.task; });
    var defBase = props.base || 'main';
    var _st = React.useState(props.step || 'name'); var step = _st[0], setStep = _st[1];
    var _t = React.useState(props.title || ''); var title = _t[0], setTitle = _t[1];
    var _bq = React.useState(props.branchQuery === undefined ? null : props.branchQuery); var bq = _bq[0], setBq = _bq[1];
    var _bp = React.useState(null); var bPick = _bp[0], setBPick = _bp[1];
    var _oq = React.useState(props.baseQuery || ''); var oq = _oq[0], setOq = _oq[1];
    var _ob = React.useState(defBase); var base = _ob[0], setBase = _ob[1];
    var _hi = React.useState(props.hi || 0); var hi = _hi[0], setHi = _hi[1];
    var rn = React.useRef(null), rb = React.useRef(null), ro = React.useRef(null), mounted = React.useRef(false);
    var inferred = branchFromTitle(title, prefix);
    var bQuery = bq === null ? inferred : bq;
    var bItems = branchItems(bQuery, branches, true);
    var oItems = branchItems(oq, bases, false);
    var first = null; for (var i = 0; i < bItems.length; i++) if (bItems[i].kind !== 'invalid' && !bItems[i].task) { first = bItems[i]; break; }
    var branch = bPick || (String(bQuery).trim() && first ? { name: first.name, existing: first.kind === 'branch' } : null);
    var skipBase = !!(branch && branch.existing);
    React.useEffect(function () {
      if (!mounted.current) { mounted.current = true; return; }
      var r = step === 'name' ? rn : step === 'branch' ? rb : step === 'base' ? ro : null;
      if (r && r.current) r.current.focus();
    }, [step]);
    function go(s) { setStep(s); setHi(0); }
    function create(b, o) {
      var res = { title: title, branch: (b || branch || {}).name, existing: !!(b || branch || {}).existing, base: (b || branch || {}).existing ? null : (o || base) };
      if (props.onCreate) props.onCreate(res); else go('created');
    }
    function pickBranch(it) { var b = { name: it.name, existing: it.kind === 'branch' }; setBPick(b); if (b.existing) create(b); else go('base'); }
    function pickBase(it) { setBase(it.name); setOq(''); create(null, it.name); }
    function reset() { setStep('name'); setTitle(''); setBq(null); setBPick(null); setOq(''); setBase(defBase); setHi(0); }
    function back() { if (step === 'branch') go('name'); else if (step === 'base') go('branch'); }
    function onKey(e) {
      if (e.key === 'Escape') { e.preventDefault(); if (props.onCancel) props.onCancel(); else reset(); return; }
      if (e.key === 'Tab' && e.shiftKey && (step === 'branch' || step === 'base')) { e.preventDefault(); back(); return; }
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); if (title.trim() && branch) create(); return; }
      if (e.key === 'Enter' && e.altKey) { e.preventDefault(); if (props.onPlan) props.onPlan({ title: title, branch: branch && branch.name, base: base }); return; }
      var items = step === 'branch' ? bItems : step === 'base' ? oItems : null;
      if (items && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) { e.preventDefault(); setHi(Math.max(0, Math.min(items.length - 1, hi + (e.key === 'ArrowDown' ? 1 : -1)))); return; }
      if (e.key !== 'Enter') return;
      e.preventDefault();
      if (step === 'name') { if (title.trim()) go('branch'); }
      else if (step === 'branch') { var it = bItems[hi]; if (it && it.kind !== 'invalid' && !it.task) pickBranch(it); }
      else if (step === 'base') { var ob = oItems[hi]; if (ob) pickBase(ob); }
    }
    function state(id) {
      if (id === 'base' && skipBase) return 'skip';
      if (step === id) return 'active';
      return NT_ORDER[step] > NT_ORDER[id] ? 'done' : 'todo';
    }
    function Row(n, id, label, value, body) {
      var st = state(id);
      return h('div', { className: cx('ex-nt-row', 'is-' + st) },
        h('button', { type: 'button', className: 'ex-nt-row-head', disabled: st === 'skip' || st === 'active', onClick: function () { go(id); } },
          h(StepNum, { n: n, state: st }), h('span', { className: 'ex-nt-row-l' }, label), st === 'active' ? null : h('span', { className: 'ex-nt-row-v' }, value)),
        h(Fold, { open: st === 'active' }, h('div', { className: 'ex-nt-body' }, body)));
    }
    var lastStep = step === 'base' || (step === 'branch' && branch && branch.existing);
    var links = props.links || [];
    return h('section', { className: 'ex-newtask ex-nt', 'aria-label': 'New task', onKeyDown: onKey },
      h('div', { className: 'ex-newtask-head' },
        h('button', { type: 'button', className: 'ex-agent', 'aria-haspopup': 'listbox' }, h(ProjectMark, Object.assign({}, p, { size: 18, decorative: true })), p.name, h(Icon, { name: 'chevron-down', size: 13 })),
        h('span', { className: 'ex-muted', style: { fontSize: 12 } }, '/'),
        h('span', { className: 'ex-muted', style: { fontSize: 12.5, fontWeight: 500 } }, 'New task'),
        h('span', { style: { flex: 1 } }), h(Kbd, null, 'Esc')),
      h(AutoHeight, { innerClassName: 'ex-nt-stack' }, step === 'created'
        ? h('div', { className: 'ex-nt-created' }, h(StatusGlyph, { status: 'done', size: 16 }),
            h('span', null, 'Created ', h('b', null, title), ' on ', h('span', { className: 'ex-mono' }, branch ? branch.name : ''), skipBase ? '' : ' from ' + base),
            h('span', { style: { flex: 1 } }), h(Button, { variant: 'ghost', size: 'sm', icon: 'reset', onClick: reset }, 'Again'))
        : h(F, null,
          h('div', { className: 'ex-nt-rows' },
            Row(1, 'name', 'Name', title ? h('span', { className: 'ex-nt-title-v' }, title) : h('span', { className: 'ex-muted' }, 'Task name'),
              h('input', { ref: rn, className: 'ex-newtask-title ex-nt-name', value: title, placeholder: 'What are you working on?', 'aria-label': 'Task name', autoFocus: !!props.autoFocus && step === 'name', onChange: function (e) { setTitle(e.target.value); setBPick(null); } })),
            Row(2, 'branch', 'Branch',
              branch ? h(F, null, h(Icon, { name: 'branch', size: 13 }), h('span', { className: 'ex-mono' }, branch.name), h('span', { className: 'ex-bf-tag' }, branch.existing ? 'existing' : 'new')) : h('span', { className: 'ex-muted' }, 'from the task name'),
              h(F, null,
                h('label', { className: 'ex-bf-input ex-nt-input' }, h(Icon, { name: 'branch', size: 14 }),
                  h('input', { ref: rb, value: bQuery, spellCheck: false, placeholder: 'Search or create a branch', 'aria-label': 'Branch: type to search or create', autoFocus: !!props.autoFocus && step === 'branch', onChange: function (e) { setBq(e.target.value); setBPick(null); setHi(0); } }),
                  bq !== null ? h('button', { type: 'button', className: 'ex-bf-reset', title: 'Back to the name from the task', onClick: function () { setBq(null); setBPick(null); } }, h(Icon, { name: 'reset', size: 12 })) : h('span', { className: 'ex-bf-tag' }, 'from the name')),
                h(BranchPicker, { items: bItems, query: bQuery, base: base, hi: hi, onPick: pickBranch }))),
            Row(3, 'base', 'From',
              skipBase ? h('span', { className: 'ex-muted' }, 'not needed: an existing branch keeps its history')
                       : h(F, null, h(Icon, { name: 'branch', size: 13 }), h('span', { className: 'ex-mono' }, base), base === defBase ? h('span', { className: 'ex-bf-tag' }, 'default') : null),
              h(F, null,
                h('label', { className: 'ex-bf-input ex-nt-input' }, h(Icon, { name: 'search', size: 14 }),
                  h('input', { ref: ro, value: oq, spellCheck: false, placeholder: 'Search branches to start from', 'aria-label': 'Start from', autoFocus: !!props.autoFocus && step === 'base', onChange: function (e) { setOq(e.target.value); setHi(0); } })),
                h(BranchPicker, { items: oItems, query: oq, hi: hi, onPick: pickBase, label: 'Start from' })))),
          h('div', { className: 'ex-nt-extras' },
            h('span', { className: 'ex-nt-extra-l' }, 'Workspace'), h(WorkspacePicker, { value: props.workspace, items: props.workspaces, open: props.workspaceOpen }),
            h('span', { className: 'ex-nt-extra-l' }, 'Link'),
            h('span', { className: 'ex-nt-links' }, links.map(function (l, i) { return h(LinkChip, Object.assign({ key: i }, l)); }),
              h('button', { type: 'button', className: 'ex-link-add' }, h(Icon, { name: 'link', size: 12 }), links.length ? 'Link another' : 'Paste a ticket or PR (optional)'))),
          h('div', { className: 'ex-newtask-foot' },
            h('span', { className: 'ex-keys' }, h(Kbd, null, '↵'), lastStep ? ' Create' : ' Next', h('span', { className: 'ex-keys-sep' }), h(Kbd, null, '⇧⇥'), ' Back', h('span', { className: 'ex-keys-sep' }), h(Kbd, null, '⌘↵'), ' Create now'),
            h('span', { style: { flex: 1 } }),
            h(Button, { variant: 'ghost', kbd: '⌥↵' }, 'Save as planned'),
            h(Button, { variant: 'primary', disabled: !title.trim() || !branch, onClick: function () { create(); } }, 'Create task')))));
  }

  /* The task line atop a new session: name, branch, workspace progress. */
  function TaskLine(props) {
    var t = props.task || {};
    return h('div', { className: 'ex-taskline' },
      t.project ? h(ProjectMark, Object.assign({}, t.project, { size: 16, decorative: true })) : null,
      h('button', { type: 'button', className: 'ex-taskline-name', title: 'Rename task' }, t.title),
      t.branch ? h(BranchChip, { name: t.branch, base: t.base }) : null,
      t.workspace ? h(WorkspaceStatus, t.workspace) : null);
  }

  /* ── Sessions and tasks ── */
  function Diff(props) {
    if (!props.add && !props.del) return null;
    return h('span', { className: 'ex-diff', 'aria-label': props.add + ' lines added, ' + props.del + ' removed' },
      props.add ? h('span', { className: 'ex-diff-add' }, '+', h(Ticker, { value: props.add })) : null, props.del ? h('span', { className: 'ex-diff-del' }, '\u2212', h(Ticker, { value: props.del })) : null);
  }
  function SessionRow(props) {
    var s = props.status || 'queued';
    var kindIcon = props.kind === 'fork' ? 'fork' : props.kind === 'side' ? 'side-chat' : null;
    return h('button', {
      type: 'button', className: cx('ex-session', s === 'attention' && !props.selected && 'is-attention', s === 'done' && 'is-done', props.fresh && 'is-fresh'),
      'aria-current': props.selected ? 'true' : undefined, style: { '--ex-indent': ((props.depth || 0) * 16) + 'px', '--i': props.index || 0 }, onClick: props.onClick
    },
      h(StatusGlyph, { status: s, size: 14 }),
      kindIcon && h('span', { className: 'ex-session-kind', title: props.kind === 'fork' ? 'Fork' : 'Side chat' }, h(Icon, { name: kindIcon, size: 13 })),
      h('span', { className: 'ex-session-title' }, props.title),
      props.diff ? h(Diff, props.diff) : props.meta ? h('span', { className: 'ex-session-meta' }, props.meta) : null,
      props.unread && h('span', { className: 'ex-session-unread', 'aria-label': 'Unread' }));
  }
  /* ── Tasks in the sidebar: an outline ──
     A task is a strong header row (chevron, project, 13.5 semibold title, link, signal, + new session) that stays
     pinned while you scroll its sessions. Its sessions hang under a guide line, lighter: working ones first, the
     finished ones folded into one “N finished” row. A session that needs you is marked, never moved. */
  var SESSION_ACTIVE = { attention: 1, running: 1, review: 1, queued: 1, failed: 1 };
  function sessionKey(s, i) { return s.id || s.title || String(i); }
  function TaskSignal(props) {
    var asks = props.asks, running = props.running, quiet = !asks && !running;
    return h('span', { className: 'ex-task-signal', title: asks ? asks + (asks === 1 ? ' session needs you' : ' sessions need you') : running ? running + ' working' : undefined },
      h('span', { className: cx('ex-task-ask', !asks && 'is-hidden') }, h(StatusGlyph, { status: 'attention', size: 12 }), h(Ticker, { value: asks || 1 })),
      h('span', { className: cx('ex-task-run', (!running || asks) && 'is-hidden') }, h(StatusGlyph, { status: 'running', size: 12 }), h(Ticker, { value: running || 1 })),
      h('span', { className: cx('ex-task-count', !(quiet && props.collapsed && props.total) && 'is-hidden') }, h(Ticker, { value: props.total || 0 })));
  }
  function TaskSession(props) {
    var s = props.s;
    return h('div', { 'data-flip': s.id || undefined, className: 'ex-task-srow' },
      h(SessionRow, Object.assign({}, s, { depth: 0, selected: !!(s.selected || (props.selected != null && props.selected === s.id)) })));
  }
  function TaskSessions(props) {
    return h(MotionList, { className: 'ex-task-sessions', items: props.sessions.map(function (s, i) { return { key: sessionKey(s, i), node: h(TaskSession, { s: s, selected: props.selected }) }; }) });
  }
  function TaskFinished(props) {
    var fin = props.sessions;
    var _o = React.useState(false); var open = _o[0], setOpen = _o[1];
    var holdsSel = fin.some(function (s) { return s.selected || (props.selected != null && s.id === props.selected); });
    var isOpen = open || holdsSel;
    return h(Fold, { open: fin.length > 0, className: 'ex-task-finfold' }, h('div', { className: 'ex-task-fin' },
      h('button', { type: 'button', className: 'ex-task-finrow', 'aria-expanded': String(isOpen), onClick: function () { setOpen(!open); } },
        h(Icon, { name: 'chevron-down', size: 12, className: cx('ex-chev', !isOpen && 'is-closed') }), h(Ticker, { value: fin.length }), ' finished'),
      h(Fold, { open: isOpen }, h(TaskSessions, { sessions: fin, selected: props.selected }))));
  }
  function TaskGroup(props) {
    var sessions = props.sessions || [];
    var folded = props.collapsed != null ? !!props.collapsed : (props.stage === 'waiting' || props.stage === 'planned' || props.stage === 'closed');
    /* a task that arrives in a folded stage arrives open, then folds: you see its sessions go away */
    var _s = React.useState(props.startOpen ? false : folded); var collapsedState = _s[0], setCollapsed = _s[1];
    React.useEffect(function () { if (props.startOpen && folded) { var t = setTimeout(function () { setCollapsed(true); }, 360); return function () { clearTimeout(t); }; } }, []);
    var filter = props.filter;
    var collapsed = filter ? false : collapsedState;
    var links = props.links || (props.link ? [props.link] : []);
    var lead = links.filter(function (l) { return l.kind === 'pr'; })[0] || links[0];
    var act = sessions.filter(function (x) { return SESSION_ACTIVE[x.status || 'queued'] && (!filter || x.status === filter); });
    var fin = filter ? [] : sessions.filter(function (x) { return !SESSION_ACTIVE[x.status || 'queued']; });
    var asks = sessions.filter(function (x) { return x.status === 'attention'; }).length;
    var running = sessions.filter(function (x) { return x.status === 'running'; }).length;
    return h('div', { className: cx('ex-task', collapsed && 'is-collapsed', props.fresh && 'is-fresh'), 'data-flip': props.id || undefined },
      h('div', { className: 'ex-task-head' },
        h('button', { type: 'button', className: 'ex-task-toggle', 'aria-expanded': String(!collapsed), onClick: function () { setCollapsed(!collapsedState); } },
          h(Icon, { name: 'chevron-down', size: 12, className: cx('ex-chev', collapsed && 'is-closed') }),
          props.project ? h(ProjectMark, Object.assign({}, props.project, { size: 18, decorative: true })) : null,
          h('span', { className: 'ex-task-title' }, props.title),
          props.repo ? h('span', { className: 'ex-task-repo' }, props.repo) : null),
        props.showLink && lead ? h(LinkChip, Object.assign({}, lead, { compact: true })) : null,
        h(TaskSignal, { asks: asks, running: running, total: sessions.length, collapsed: collapsed }),
        props.onAdd !== false ? h(IconButton, { icon: 'plus', label: 'New session in this task', size: 'sm', className: 'ex-task-add', onClick: props.onAdd }) : null),
      h(Fold, { open: !collapsed, className: 'ex-task-fold' },
        h('div', { className: 'ex-task-tree' }, h(TaskSessions, { sessions: act, selected: props.selected }), h(TaskFinished, { sessions: fin, selected: props.selected }))));
  }
  /* The sidebar's body: tasks by stage (In progress, Waiting, Planned), each group counted. Tasks keep their place
     when a session needs you; a filter (a status) folds away everything else. Anything that changes stage travels. */
  var TASK_STAGES = [['active', 'In progress'], ['waiting', 'Waiting'], ['planned', 'Planned']];
  function TaskList(props) {
    var tasks = props.tasks || [], filter = props.filter;
    var seen = React.useRef({}), first = React.useRef(true);
    var shown = tasks.filter(function (t) { return !filter || (t.sessions || []).some(function (x) { return x.status === filter; }); });
    var groups = TASK_STAGES.map(function (g) { return { id: g[0], label: g[1], tasks: shown.filter(function (t) { return (t.stage || 'active') === g[0]; }) }; }).filter(function (g) { return g.tasks.length; });
    var moved = {};
    tasks.forEach(function (t) { var was = seen.current[t.id]; if (!first.current && was && was !== (t.stage || 'active')) moved[t.id] = true; });
    React.useEffect(function () { first.current = false; var m = {}; tasks.forEach(function (t) { m[t.id] = t.stage || 'active'; }); seen.current = m; });
    return h(FlipScope, { className: cx('ex-tasklist', props.className), selected: props.selected },
      h(MotionList, { items: groups.map(function (g) {
        return { key: g.id, node: h('div', { className: 'ex-tasklist-group' },
          h('div', { className: 'ex-overline ex-tasklist-over' }, g.label, h('span', { className: 'ex-tasklist-n' }, h(Ticker, { value: g.tasks.length }))),
          h(MotionList, { className: 'ex-tasklist-tasks', items: g.tasks.map(function (t) {
            return { key: t.id, node: h(TaskGroup, Object.assign({}, t, { selected: props.selected, filter: filter, startOpen: !!moved[t.id], project: props.showProjects === false ? null : t.project,
              onAdd: props.onAdd ? function () { props.onAdd(t); } : t.onAdd })) };
          }) })) };
      }) }));
  }


  /* ── Side-view tabs ── */
  function PanelTabs(props) {
    var tabs = props.tabs || [];
    var th = useThumb('[aria-selected="true"]', [props.active, props.labelled, tabs.length]);
    useFlip(th.ref, '.ex-tab', [props.active, props.labelled]);
    return h('div', { ref: th.ref, className: cx('ex-tabs', props.labelled && 'is-labelled', th.has && 'has-thumb', th.ready && 'is-ready'), role: 'tablist', 'aria-label': props.label || 'Side views' }, h('span', { className: 'ex-thumb', 'aria-hidden': 'true', style: th.style }), tabs.map(function (t) {
      var on = t.id === props.active;
      return h('button', { key: t.id, 'data-key': t.id, type: 'button', role: 'tab', className: 'ex-tab', 'aria-selected': String(on), title: t.label, onClick: props.onSelect && function () { props.onSelect(t.id); } },
        h(Icon, { name: t.icon, size: 15 }), h('span', { className: 'ex-tab-label' }, t.label),
        t.badge ? h('span', { className: 'ex-tab-dot', 'aria-label': 'Has updates' }) : null);
    }));
  }

  /* ── Small controls: Switch, Segmented ── */
  function Switch(props) {
    var on = !!props.on;
    return h('button', { type: 'button', role: 'switch', 'aria-checked': String(on), 'aria-label': props.label, className: cx('ex-switch', on && 'is-on'), onClick: props.onChange && function () { props.onChange(!on); } }, h('span', { className: 'ex-switch-thumb' }));
  }
  function Segmented(props) {
    var opts = props.options || [];
    var th = useThumb('[aria-checked="true"]', [props.value, opts.length]);
    return h('div', { ref: th.ref, className: cx('ex-seg', props.size === 'sm' && 'ex-seg-sm', th.has && 'has-thumb', th.ready && 'is-ready', props.className), role: 'radiogroup', 'aria-label': props.label },
      h('span', { className: 'ex-thumb', 'aria-hidden': 'true', style: th.style }),
      opts.map(function (o) {
        var on = o.id === props.value;
        return h('button', { key: o.id, type: 'button', role: 'radio', 'aria-checked': String(on), className: 'ex-seg-opt', title: o.title || o.label, onClick: props.onChange && function () { props.onChange(o.id); } },
          o.icon ? h(Icon, { name: o.icon, size: 13 }) : null, o.label ? h('span', null, o.label) : null);
      }));
  }

  /* ── Mode: plan or code ── */
  function ModeToggle(props) {
    return h(Segmented, { label: 'Mode', size: 'sm', className: 'ex-mode', value: props.value || 'code', onChange: props.onChange, options: [
      { id: 'plan', label: 'Plan', icon: 'plan', title: 'Plan: read and propose, no edits  ⇧Tab' },
      { id: 'code', label: 'Code', icon: 'code', title: 'Code: make changes  ⇧Tab' }] });
  }

  /* ── Agent picker: presets in one click, custom below ── */
  var THINKING = ['Off', 'Low', 'Medium', 'High', 'Max'];
  function AgentMark(props) { return h('span', { className: 'ex-agent-mark', 'aria-hidden': 'true' }, props.mark); }
  function agentSub(a) { return [a.preset ? a.model : a.harness, a.thinking || a.effort].filter(Boolean).join(' · '); }
  function AgentPicker(props) {
    var pm = usePresence(props.open);
    var cur = props.value || { mark: 'Cl', harness: 'Claude Code', model: 'Opus 5.5', thinking: 'High' };
    var harnesses = props.harnesses || ['Claude Code', 'Codex', 'Local'];
    var locked = props.locked !== false;
    return h('div', { className: 'ex-agent-wrap' },
      h('button', { type: 'button', className: 'ex-agent', 'aria-haspopup': 'dialog', 'aria-expanded': String(!!props.open), title: 'Agent  ⌘J' },
        h(AgentMark, cur), h('span', null, cur.preset || cur.model), h('span', { className: 'ex-agent-sub' }, agentSub(cur)),
        cur.fast ? h('span', { className: 'ex-fast', title: 'Fast mode on' }, h(Icon, { name: 'bolt', size: 12 })) : null,
        cur.context != null ? h(ContextMeter, { used: cur.context, compact: true }) : null,
        h(Icon, { name: 'chevron-down', size: 13 })),
      pm.m && h('div', { className: 'ex-menu ex-agent-menu' + (pm.l ? ' is-leaving' : ''), role: 'dialog', 'aria-label': 'Agent', style: props.placement === 'top' ? { bottom: 32, left: 0 } : { top: 32, left: 0 } },
        h('div', { className: 'ex-overline ex-menu-label' }, cur.preset ? 'Adjust “' + cur.preset + '”' : 'Agent'),
        h('div', { className: 'ex-field' }, h('span', { className: 'ex-field-l' }, 'Harness'),
          locked
            ? h(F, null, h('span', { className: 'ex-field-v' }, h(AgentMark, cur), cur.harness), h('span', { style: { flex: 1 } }), h(Button, { variant: 'ghost', size: 'sm', icon: 'fork', title: 'Fork this session into another harness' }, 'Fork to…'))
            : h(Segmented, { size: 'sm', label: 'Harness', value: cur.harness, options: harnesses.map(function (x) { return { id: x, label: x }; }) })),
        h('div', { className: 'ex-field' }, h('span', { className: 'ex-field-l' }, 'Model'), h('button', { type: 'button', className: 'ex-select' }, h('span', null, cur.model), h(Icon, { name: 'chevron-down', size: 13 }))),
        h('div', { className: 'ex-field' }, h('span', { className: 'ex-field-l' }, 'Thinking'), h(Segmented, { size: 'sm', label: 'Thinking level', value: cur.thinking || cur.effort, options: THINKING.map(function (x) { return { id: x, label: x === 'Medium' ? 'Med' : x, title: x }; }) })),
        h('div', { className: 'ex-field' }, h('span', { className: 'ex-field-l' }, h(Icon, { name: 'bolt', size: 13 }), 'Fast mode'), h('span', { className: 'ex-muted', style: { fontSize: 12, flex: 1 } }, 'Quicker replies'), h(Switch, { on: !!cur.fast, label: 'Fast mode' })),
        h('div', { className: 'ex-menu-sep' }),
        h('div', { className: 'ex-menu-foot' }, h(Button, { variant: 'ghost', size: 'sm', icon: 'plus' }, 'Save as preset'), h('span', { style: { flex: 1 } }), h('span', { className: 'ex-muted', style: { fontSize: 12, paddingRight: 6 } }, 'Applies from the next message'))));
  }

  /* ── Presets: chosen when a session starts ── */
  function PresetCard(props) {
    var p = props.preset || {};
    var on = !!props.selected;
    return h('button', { type: 'button', role: 'radio', 'aria-checked': String(on), className: cx('ex-preset', on && 'is-on', props.custom && 'is-custom'), onClick: props.onSelect, title: props.kbd ? (p.preset || 'Custom') + '  ' + props.kbd : undefined },
      props.custom
        ? h(F, null, h('span', { className: 'ex-preset-top' }, h('span', { className: 'ex-preset-plus' }, h(Icon, { name: 'plus', size: 14 })), h('span', { style: { flex: 1 } })),
            h('span', { className: 'ex-preset-name' }, 'Custom'), h('span', { className: 'ex-preset-sub' }, 'Pick harness, model, thinking'))
        : h(F, null,
            h('span', { className: 'ex-preset-top' }, h(AgentMark, p), h('span', { style: { flex: 1 } }),
              on ? h('span', { className: 'ex-preset-check' }, h(Icon, { name: 'check', size: 12 })) : props.kbd ? h(Kbd, null, props.kbd) : null),
            h('span', { className: 'ex-preset-name' }, p.preset, p.fast ? h('span', { className: 'ex-fast', title: 'Fast mode' }, h(Icon, { name: 'bolt', size: 12 })) : null),
            h('span', { className: 'ex-preset-sub' }, [p.model, p.thinking].filter(Boolean).join(' · ')),
            h('span', { className: 'ex-preset-harness' }, p.harness)));
  }
  function PresetPicker(props) {
    var presets = props.presets || [];
    var sel = props.value;
    return h('div', { className: cx('ex-presets', props.compact && 'is-compact'), role: 'radiogroup', 'aria-label': 'Start with' },
      presets.map(function (p, i) { return h(PresetCard, { key: i, preset: p, selected: sel === p.preset, kbd: i < 9 ? '⌥' + (i + 1) : null, onSelect: props.onSelect && function () { props.onSelect(p.preset); } }); }),
      props.custom !== false ? h(PresetCard, { custom: true, selected: sel === 'custom' }) : null);
  }
  function SessionStart(props) {
    var presets = props.presets || [];
    var _s = React.useState(props.value || (presets[0] && presets[0].preset)); var sel = _s[0], setSel = _s[1];
    var agent = presets.filter(function (p) { return p.preset === sel; })[0] || presets[0];
    return h('div', { className: 'ex-start' },
      h('div', { className: 'ex-start-inner' },
        props.task ? h(TaskLine, { task: props.task }) : props.context ? h('div', { className: 'ex-start-ctx' }, props.context) : null,
        h('h2', { className: 'ex-start-title' }, props.title || 'What should we work on?'),
        h(PresetPicker, { presets: presets, value: sel, onSelect: setSel }),
        h(Composer, Object.assign({ agent: agent, mode: 'code', permission: 'edits' }, props.composer || {}, { hideAgent: true }))));
  }

  /* ── Permissions ── */
  var PERMS = [
    { id: 'ask', label: 'Ask first', short: 'Ask', note: 'Approve every edit and command' },
    { id: 'edits', label: 'Auto-edit', short: 'Auto-edit', note: 'Edits apply, commands ask' },
    { id: 'auto', label: 'Full auto', short: 'Full auto', note: 'Nothing asks; runs sandboxed' }];
  function PermissionPicker(props) {
    var pm = usePresence(props.open);
    var v = props.value || 'ask';
    var cur = PERMS.filter(function (p) { return p.id === v; })[0] || PERMS[0];
    return h('div', { className: 'ex-agent-wrap' },
      h('button', { type: 'button', className: cx('ex-agent ex-perm', 'is-' + v), 'aria-haspopup': 'listbox', 'aria-expanded': String(!!props.open), title: 'Permissions: ' + cur.label },
        h(Icon, { name: 'shield', size: 14 }), cur.short),
      pm.m && h('div', { className: 'ex-menu' + (pm.l ? ' is-leaving' : ''), role: 'listbox', style: { bottom: 32, left: 0, minWidth: 248 } },
        h('div', { className: 'ex-overline ex-menu-label' }, 'Permissions'),
        PERMS.map(function (p) {
          var sel = p.id === v;
          return h('div', { key: p.id, role: 'option', className: 'ex-menu-item', 'aria-selected': String(sel) },
            h('span', { className: 'ex-grow' }, h('span', null, p.label), h('span', { className: 'ex-muted', style: { fontSize: 12, lineHeight: '16px' } }, p.note)),
            sel ? h(Icon, { name: 'check', size: 14, className: 'ex-check' }) : null);
        })));
  }

  /* ── Tools: attach, mention, MCP servers ── */
  function ToolsMenu(props) {
    var pm = usePresence(props.open);
    var servers = props.servers || [];
    var onCount = servers.filter(function (s) { return s.on; }).length;
    return h('div', { className: 'ex-agent-wrap' },
      h('button', { type: 'button', className: 'ex-iconbtn', 'aria-label': 'Add files, mentions and tools', title: 'Add  ⌘U', 'aria-expanded': String(!!props.open) }, h(Icon, { name: 'plus' })),
      pm.m && h('div', { className: 'ex-menu' + (pm.l ? ' is-leaving' : ''), style: { bottom: 34, right: 0, minWidth: 280 } },
        h('div', { className: 'ex-menu-item' }, h(Icon, { name: 'attach', size: 14 }), h('span', { className: 'ex-grow' }, 'Attach files'), h(Kbd, null, '⌘U')),
        h('div', { className: 'ex-menu-item' }, h(Icon, { name: 'at', size: 14 }), h('span', { className: 'ex-grow' }, 'Mention a session, task or file'), h(Kbd, null, '@')),
        h('div', { className: 'ex-menu-sep' }),
        h('div', { className: 'ex-overline ex-menu-label', style: { display: 'flex' } }, h('span', { style: { flex: 1 } }, 'MCP servers'), h('span', { style: { letterSpacing: 0, textTransform: 'none', fontWeight: 500 } }, onCount + ' on')),
        servers.map(function (s, i) {
          return h('div', { key: i, className: 'ex-menu-item' },
            h('span', { className: cx('ex-dot', 'is-' + (s.on ? (s.error ? 'error' : 'ok') : 'off')), 'aria-hidden': 'true' }),
            h('span', { className: 'ex-grow' }, h('span', null, s.name), h('span', { className: cx('ex-muted', s.error && 'ex-err'), style: { fontSize: 12, lineHeight: '16px' } }, s.error ? s.error : s.tools + ' tools')),
            h(Switch, { on: !!s.on, label: s.name }));
        }),
        h('div', { className: 'ex-menu-sep' }),
        h('div', { className: 'ex-menu-item ex-muted' }, h(Icon, { name: 'plug', size: 14 }), h('span', { className: 'ex-grow' }, 'Manage MCP servers…'))));
  }

  /* ── Mention ── */
  function Mention(props) {
    var kind = props.kind || 'session';
    return h('span', { className: 'ex-mention ex-mention-' + kind },
      kind === 'session' ? h(StatusGlyph, { status: props.status || 'done', size: 12 }) : h(Icon, { name: kind === 'task' ? 'task' : 'file', size: 12 }),
      props.children,
      props.removable ? h('button', { type: 'button', className: 'ex-mention-x', 'aria-label': 'Remove' }, h(Icon, { name: 'x', size: 11 })) : null);
  }

  /* ── Queue: messages waiting for the agent's turn to end ── */
  function ComposerQueue(props) {
    var items = props.items || [];
    if (!items.length) return null;
    return h('div', { className: 'ex-queue', role: 'list', 'aria-label': 'Queued messages' },
      h('div', { className: 'ex-queue-head' }, h(StatusGlyph, { status: 'queued', size: 12 }), items.length + (items.length === 1 ? ' queued message' : ' queued messages'), h('span', { style: { flex: 1 } }), h('span', { className: 'ex-muted' }, 'Sent when this turn ends')),
      items.map(function (q, i) {
        return h('div', { key: i, role: 'listitem', className: 'ex-queue-item' },
          h('span', { className: 'ex-queue-n' }, i + 1),
          h('span', { className: 'ex-queue-text' }, q.text),
          h('span', { className: 'ex-queue-acts' },
            h(IconButton, { icon: 'pencil', label: 'Edit', size: 'sm' }),
            h(IconButton, { icon: 'trash', label: 'Remove', size: 'sm' })),
          h(Button, { variant: 'ghost', size: 'sm', icon: 'steer', title: 'Send now: the agent reads it at its next step, without stopping  ⌥↵' }, 'Steer'));
      }));
  }

  /* ── Dictation ── */
  function Waveform(props) {
    var bars = props.levels || [3, 6, 10, 7, 12, 5, 9, 14, 8, 4, 11, 6, 3, 8, 12, 7, 5, 9, 4, 3];
    return h('span', { className: 'ex-wave', 'aria-hidden': 'true' }, bars.map(function (b, i) { return h('i', { key: i, style: { height: b } }); }));
  }

  /* ── Composer ── */
  function Composer(props) {
    var running = !!props.running;
    var mode = props.mode || 'code';
    var hasText = props.hasText !== undefined ? props.hasText : !!props.children;
    var rec = props.recording;
    var context = (props.context || []);
    var send;
    if (running && !hasText) send = null;
    else if (running) send = h(Button, { variant: 'primary', className: 'ex-send-q', title: 'Queue  ↵ · Steer now  ⌥↵' }, 'Queue');
    else send = h(Button, { variant: 'primary', className: 'ex-send', 'aria-label': 'Send', title: 'Send  ↵', disabled: !hasText }, h(Icon, { name: 'arrow-up' }));
    return h('div', { className: cx('ex-composer', mode === 'plan' && 'is-plan', props.dropping && 'is-drop', props.className) },
      props.dropping ? h('div', { className: 'ex-drop', 'aria-hidden': 'true' }, h(Icon, { name: 'attach', size: 16 }), 'Drop to attach') : null,
      h(ComposerQueue, { items: props.queue }),
      context.length ? h('div', { className: 'ex-composer-context' }, context.map(function (c, i) { return h(Mention, Object.assign({ key: i, removable: true }, c), c.label); })) : null,
      h('div', { className: 'ex-composer-input', contentEditable: true, suppressContentEditableWarning: true, role: 'textbox', 'aria-multiline': 'true', 'aria-label': 'Message', 'data-placeholder': props.placeholder || (running ? 'Queue a message, or steer…' : mode === 'plan' ? 'Describe what to plan…' : 'Ask, or @mention a session…') },
        props.children, rec && rec.interim ? h('span', { className: 'ex-interim' }, ' ' + rec.interim) : null),
      h('div', { className: 'ex-composer-bar' },
        h(ModeToggle, { value: mode }),
        props.hideAgent ? null : h(AgentPicker, { value: props.agent, open: props.agentOpen, locked: !props.agentUnlocked, placement: 'top' }),
        mode === 'code' ? h(PermissionPicker, { value: props.permission, open: props.permissionOpen }) : null,
        h('span', { className: 'ex-grow' }),
        rec
          ? h('span', { className: 'ex-rec' }, h('span', { className: 'ex-rec-dot', 'aria-hidden': 'true' }), h(Waveform, null), h('span', { className: 'ex-mono' }, rec.time || '0:00'),
              h(IconButton, { icon: 'x', label: 'Cancel dictation', size: 'sm' }), h(IconButton, { icon: 'check', label: 'Finish dictation', size: 'sm' }))
          : h(F, null,
              h(ToolsMenu, { servers: props.servers, open: props.toolsOpen }),
              h(IconButton, { icon: 'mic', label: 'Dictate  ⌘D' })),
        running ? h(Button, { variant: 'secondary', className: 'ex-send', 'aria-label': 'Stop', title: 'Stop  ⌘.' }, h(Icon, { name: 'stop' })) : null,
        send));
  }


  /* ── ChatScroll: the chat's scrolling area. While you read a reply whose message has scrolled away above,
     that message stays pinned at the top as a reminder: two lines, Back to it, Hide. ── */
  function ChatScroll(props) {
    var sc = React.useRef(null), stick = React.useRef(props.startAtEnd !== false), measured = React.useRef(false), instantKey = React.useRef(null), last = React.useRef(null), raf = React.useRef(0), flashT = React.useRef(0);
    var st = React.useState(null), pin = st[0], setPin = st[1];
    var hs = React.useState({}), hidden = hs[0], setHidden = hs[1];
    function measure() {
      raf.current = 0;
      var el = sc.current; if (!el) return;
      if (stick.current && el.scrollHeight - el.scrollTop - el.clientHeight > 1) el.scrollTop = el.scrollHeight; /* at the bottom, the chat follows what arrives */
      var top = el.getBoundingClientRect().top, hgt = el.clientHeight, ms = el.querySelectorAll('.ex-you'), chosen = null, ci = -1;
      for (var i = 0; i < ms.length; i++) { if (ms[i].getBoundingClientRect().bottom < top + 8) { chosen = ms[i]; ci = i; } else break; }
      var next = ci >= 0 ? ms[ci + 1] : null;
      /* once the next message reaches the upper part of the view, the reply below it is the one you're reading: no reminder */
      if (chosen && next && next.getBoundingClientRect().top < top + hgt * 0.4) chosen = null;
      var p = null;
      if (chosen) { var b = chosen.querySelector('.ex-msg-user'); p = { key: chosen.getAttribute('data-msg') || 'm' + ci, text: (b ? b.textContent : '').trim() }; }
      if (!measured.current) { measured.current = true; instantKey.current = p ? p.key : null; }
      setPin(function (o) { return (!o && !p) || (o && p && o.key === p.key && o.text === p.text) ? o : p; });
    }
    function soon() { if (!raf.current) raf.current = requestAnimationFrame(measure); }
    function onScroll() { var el = sc.current; if (el) stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 24; soon(); }
    useLayout(function () {
      var el = sc.current; if (!el) return;
      if (props.startAtEnd !== false) el.scrollTop = el.scrollHeight; /* a chat opens on its latest message */
      measure();
      el.addEventListener('scroll', onScroll, { passive: true });
      var mo = window.MutationObserver ? new MutationObserver(soon) : null; if (mo) mo.observe(el, { childList: true, subtree: true, characterData: true });
      var ro = window.ResizeObserver ? new ResizeObserver(soon) : null; if (ro) ro.observe(el);
      return function () { el.removeEventListener('scroll', onScroll); if (mo) mo.disconnect(); if (ro) ro.disconnect(); if (raf.current) cancelAnimationFrame(raf.current); clearTimeout(flashT.current); };
    }, []);
    function back() {
      var el = sc.current; if (!el || !pin) return;
      var ms = el.querySelectorAll('.ex-you'), target = null;
      for (var i = 0; i < ms.length; i++) if ((ms[i].getAttribute('data-msg') || 'm' + i) === pin.key) target = ms[i];
      if (!target) return;
      var d = target.getBoundingClientRect().top - el.getBoundingClientRect().top - 12;
      el.scrollTo({ top: el.scrollTop + d, behavior: reducedMotion() ? 'auto' : 'smooth' });
      var bubble = target.querySelector('.ex-msg-user');
      if (bubble) { bubble.classList.remove('is-flash'); void bubble.offsetWidth; bubble.classList.add('is-flash'); clearTimeout(flashT.current); flashT.current = setTimeout(function () { bubble.classList.remove('is-flash'); }, 1400); }
    }
    var show = !!pin && !hidden[pin.key] && props.reminder !== false;
    if (show) last.current = pin;
    var shown = show ? pin : last.current;
    return h('div', { className: cx('ex-chatscroll', props.className), style: props.style },
      h('div', { ref: sc, className: cx('ex-chatscroll-in', props.innerClassName) }, props.children),
      h(Presence, { show: show, exit: 160 }, shown ? h('div', { className: cx('ex-pin', shown.key === instantKey.current && 'is-instant'), role: 'region', 'aria-label': 'Your message' },
        h('button', { type: 'button', className: 'ex-pin-body', onClick: back, title: 'Back to your message' },
          h('span', { className: 'ex-pin-label' }, 'You asked'), h('span', { key: shown.key, className: 'ex-pin-text' }, shown.text)),
        h(IconButton, { icon: 'arrow-up', label: 'Back to your message', size: 'sm', onClick: back }),
        h(IconButton, { icon: 'x', label: 'Hide', size: 'sm', onClick: function () { var o = Object.assign({}, hidden); o[shown.key] = true; setHidden(o); } })) : null));
  }
  /* ── Message ── */
  function Message(props) {
    var role = props.role || 'agent';
    if (role === 'user') return h('div', { className: cx('ex-you', props.isNew && 'is-new'), 'data-msg': props.id },
      h('div', { className: cx('ex-msg ex-msg-user', props.isNew && 'is-new') }, h('div', null, props.children)),
      props.time ? h('span', { className: 'ex-you-time' }, props.time) : null);
    return h('section', { className: cx('ex-msg ex-msg-agent', props.pinned && 'is-pinned') },
      h('div', { className: 'ex-turn-gutter', 'aria-hidden': 'true' }, h('span', { className: 'ex-turn-avatar', title: (props.author || 'Opus 5.5') + (props.time ? ' · ' + props.time : '') }, h(AgentMark, { mark: props.mark || 'Cl' }))),
      h('div', { className: 'ex-msg-body' },
        h('div', { className: 'ex-turn-answer' }, props.children),
        props.sideChats ? h('button', { type: 'button', className: 'ex-msg-branches' }, h(Icon, { name: 'side-chat', size: 13 }), props.sideChats + (props.sideChats === 1 ? ' side chat' : ' side chats')) : null,
        h('div', { className: 'ex-turn-foot' }, h('span', { style: { flex: 1 } }), h(TurnActs))));
  }
  /* Side chat, fork, copy: on hover or focus, at the end of the reply's footer. */
  function TurnActs() {
    return h('span', { className: 'ex-msg-acts' },
      h(IconButton, { icon: 'side-chat', label: 'Side chat from here', size: 'sm' }),
      h(IconButton, { icon: 'fork', label: 'Fork from here', size: 'sm' }),
      h(IconButton, { icon: 'copy', label: 'Copy', size: 'sm' }));
  }

  /* ── Side thread ── */
  function SideThread(props) {
    return h('section', { className: cx('ex-side', props.className), 'aria-label': 'Side chat' },
      h('div', { className: 'ex-side-head' }, h(Icon, { name: 'side-chat', size: 15 }), h('span', { className: 'ex-grow' }, props.title || 'Side chat'),
        h(IconButton, { icon: 'expand', label: 'Promote to fork', size: 'sm' }), h(IconButton, { icon: 'x', label: 'Close', size: 'sm' })),
      props.anchor && h('div', { className: 'ex-side-anchor' }, props.anchor),
      h('div', { className: 'ex-side-body' }, props.children),
      h('div', { className: 'ex-side-note' }, h(Icon, { name: 'check', size: 13 }), 'Not added to the main session’s context'),
      h('div', { className: 'ex-side-foot' }, h('div', { className: 'ex-composer' },
        h('div', { className: 'ex-composer-input', contentEditable: true, suppressContentEditableWarning: true, role: 'textbox', 'aria-label': 'Reply in side chat', 'data-placeholder': 'Ask a follow-up…' }),
        h('div', { className: 'ex-composer-bar' }, h('span', { className: 'ex-grow' }), h(Button, { variant: 'primary', size: 'sm', className: 'ex-send', style: { width: 24, height: 24 }, 'aria-label': 'Send' }, h(Icon, { name: 'arrow-up', size: 14 }))))));
  }

  /* ── Git ── */
  /* Swaps inline content without a jump: the old content fades out where it was, the new one fades in over it,
     and the box's width eases from one to the other. Content with the same key updates in place (its width still eases). */
  function EaseSwap(props) {
    var outer = React.useRef(null), mounted = React.useRef(false), ids = React.useRef(1), timers = React.useRef([]), shown = React.useRef(props.children);
    var st = React.useState([{ id: 0, k: props.k, node: null }]), layers = st[0], setLayers = st[1];
    useLayout(function () {
      var top = layers[layers.length - 1];
      if (top.k === props.k) return;
      var id = ids.current++, prevNode = shown.current; /* what the last render showed */
      setLayers(function (ls) { return ls.map(function (l) { return l.leaving ? l : Object.assign({}, l, { leaving: true, node: l === ls[ls.length - 1] ? prevNode : l.node }); }).concat([{ id: id, k: props.k, node: null }]); });
      timers.current.push(setTimeout(function () { setLayers(function (ls) { return ls.filter(function (l) { return !l.leaving || l.id > id; }); }); }, 260));
    }, [props.k]);
    useLayout(function () {
      shown.current = props.children;
      var o = outer.current; if (!o) return;
      var t = o.querySelector('.ex-eswap-l.is-top'); if (!t) return;
      var w = t.offsetWidth + 'px', hh = t.offsetHeight + 'px';
      if (!mounted.current) { mounted.current = true; requestAnimationFrame(function () { if (outer.current) outer.current.classList.add('is-live'); }); }
      if (o.style.width === w && o.style.height === hh) return;
      /* inside a slot that's hidden (or growing in this very frame), take the new size at once: the slot is what moves */
      if (o.closest('[data-still]') && o.classList.contains('is-live')) { o.classList.remove('is-live'); o.style.width = w; o.style.height = hh; void o.offsetWidth; o.classList.add('is-live'); }
      else { o.style.width = w; o.style.height = hh; }
    });
    React.useEffect(function () { return function () { timers.current.forEach(clearTimeout); }; }, []);
    return h('span', { ref: outer, className: cx('ex-eswap', props.className) }, layers.map(function (l, n) {
      var top = n === layers.length - 1;
      return h('span', { key: l.id, className: cx('ex-eswap-l', top && 'is-top', l.leaving && 'is-out', top && l.id > 0 && 'is-in'), 'aria-hidden': top ? null : 'true' }, top ? props.children : l.node);
    }));
  }

  /* One button for the next git step: Commit while there are uncommitted changes, Push once commits are waiting, nothing when
     the task is up to date. The chevron holds the combinations. The button is one element throughout: its icon and label
     crossfade in place and its width eases; it only grows in or leaves when there's a step to show or none. */
  function GitBar(props) {
    var files = props.files || 0, ahead = props.ahead || 0, busy = props.busy;
    var step = busy === 'commit' || (!busy && files) ? 'commit' : busy === 'push' || ahead ? 'push' : null;
    var statKind = files ? 'diff' : step ? null : 'quiet';
    var stat = statKind === 'diff'
      ? h('span', { className: 'ex-git-stat', role: 'button', tabIndex: 0, title: files + (files === 1 ? ' changed file' : ' changed files') + ', open changes' }, h(Icon, { name: 'changes', size: 15 }), h(Diff, { add: props.add || 0, del: props.del || 0 }))
      : statKind === 'quiet' ? h('span', { className: 'ex-git-stat is-quiet' }, 'Up to date') : null;
    var label = busy === 'commit' ? 'Committing…' : busy === 'push' ? 'Pushing…' : step === 'commit' ? 'Commit' : 'Push';
    var count = busy ? 0 : step === 'push' ? ahead : files;
    var kbd = !props.compact && step === 'commit' && !busy;
    var menu = step === 'commit'
      ? (ahead ? 'Commit and push · Push the ' + ahead + ' waiting · Commit and open PR · Sync with main' : 'Commit and push · Commit and open PR · Sync with main')
      : 'Push and open PR · Push to a new name · Sync with main';
    var variant = props.compact ? 'secondary' : 'primary';
    return h('div', { className: 'ex-git' },
      h(GitAction, { show: !!statKind, className: 'is-stat' }, h(EaseSwap, { k: statKind || 'none', className: 'ex-git-statswap' }, stat)),
      h(GitAction, { show: !!step },
        h('span', { className: 'ex-split' },
          h(Button, { variant: variant, disabled: !!busy, 'aria-busy': busy ? 'true' : null, onClick: step === 'commit' ? props.onCommit : props.onPush },
            h(EaseSwap, { k: busy ? 'busy' : step || 'none', className: 'ex-git-ic' }, busy ? h(StatusGlyph, { status: 'running', size: 13 }) : h(Icon, { name: step === 'commit' ? 'commit' : 'push', size: 14 })),
            h(EaseSwap, { k: label + (count ? '#' : '') + (kbd ? 'k' : '') },
              h('span', { className: 'ex-git-label' }, label),
              count ? h('span', { className: 'ex-git-ahead', title: step === 'push' ? count + ' to push' : count + (count === 1 ? ' changed file' : ' changed files') }, h(Ticker, { value: count })) : null,
              kbd ? h(Kbd, null, '⌘↵') : null)),
          h(Button, { variant: variant, disabled: !!busy, 'aria-label': 'More: ' + menu, title: menu }, h(Icon, { name: 'chevron-down', size: 14 })))));
  }
  /* A slot that grows in or closes. While it's shown its width is auto (the content eases itself). Growing in, the pill
     opens from the right with its rounded edge while the space for it opens, and its label fades in once there's room;
     closing is the reverse. It keeps its last content while it closes. It sets is-gone itself, so neither way snaps. */
  function GitAction(props) {
    var outer = React.useRef(null), inner = React.useRef(null), prev = React.useRef(null), last = React.useRef(props.children), t = React.useRef(0);
    if (props.show) last.current = props.children;
    useLayout(function () {
      var o = outer.current, i = inner.current; if (!o || !i) return;
      var was = prev.current; prev.current = props.show;
      /* while hidden, the content inside doesn't ease (EaseSwap reads this): when the slot grows in, its content is already at its final size */
      if (props.show) o.removeAttribute('data-still'); else o.setAttribute('data-still', '');
      if (was === null) { if (!props.show) { o.classList.add('is-gone'); o.style.width = '0px'; } return; } /* first paint: no motion */
      if (was === props.show) return;
      clearTimeout(t.current);
      o.style.width = (props.show ? 0 : o.offsetWidth) + 'px'; void o.offsetWidth;
      o.classList.add('is-moving');
      o.classList.toggle('is-gone', !props.show);
      o.style.width = (props.show ? i.offsetWidth : 0) + 'px';
      t.current = setTimeout(function () { o.classList.remove('is-moving'); if (props.show) o.style.width = ''; }, 360);
    }, [props.show]);
    React.useEffect(function () { return function () { clearTimeout(t.current); }; }, []);
    return h('span', { ref: outer, className: cx('ex-git-act', props.className), 'aria-hidden': props.show ? null : 'true', inert: props.show ? null : '' },
      h('span', { ref: inner, className: 'ex-git-act-in' }, props.show ? props.children : last.current));
  }
  /* The changed files: status letter (M modified, A added, D deleted, R renamed), name in bold with its folder muted, line
     counts, and a check once viewed. Grouped, files sit under their folder. The current file has the raised highlight,
     which glides when it changes. */
  function ChangeList(props) {
    var items = props.items || [];
    var th = useThumb('[aria-current="true"]', [items.map(function (f) { return f.path + (f.current || f.selected ? '*' : ''); }).join('|'), !!props.grouped]);
    var rows = [], lastDir = null;
    items.forEach(function (f, i) {
      var parts = f.path.split('/'), name = parts.pop(), dir = parts.join('/');
      if (props.grouped && dir !== lastDir) { lastDir = dir; if (dir) rows.push(h('div', { key: 'd' + i, className: 'ex-change-dir', role: 'presentation' }, h(Icon, { name: 'folder', size: 13 }), h('bdi', null, dir + '/'))); }
      var nested = props.grouped && dir;
      rows.push(h(props.onSelect ? 'button' : 'div', { key: i, type: props.onSelect ? 'button' : undefined, role: 'listitem', className: cx('ex-change', nested && 'is-nested', f.viewed && 'is-viewed'), 'data-key': f.path,
        'aria-current': f.current || f.selected ? 'true' : undefined, onClick: props.onSelect && function () { props.onSelect(f.path); } },
        h('span', { className: 'ex-change-st st-' + f.status, title: { M: 'Modified', A: 'Added', D: 'Deleted', R: 'Renamed' }[f.status] }, f.status),
        h('span', { className: 'ex-change-path' }, h('bdi', null, h('b', null, name), !nested && dir ? h('span', null, '  ' + dir) : null)),
        f.changed ? h('span', { className: 'ex-change-again', title: 'Changed since you viewed it' }) : null,
        h(Diff, { add: f.add || 0, del: f.del || 0 }),
        f.viewed !== undefined ? h('span', { className: cx('ex-change-v', f.viewed && 'is-on'), 'aria-label': f.viewed ? 'Viewed' : null }, h(Icon, { name: 'check', size: 12 })) : null));
    });
    return h('div', { ref: th.ref, className: cx('ex-changes', th.has && 'has-thumb', th.ready && 'is-ready'), role: 'list' },
      h('span', { className: 'ex-thumb', 'aria-hidden': 'true', style: th.style }), rows);
  }

  /* ════ Changes review (DiffReview) ════
     A pull-request-style review of a task's changes: one long scroll of every changed file, each with its hunks and a few
     lines around them; expand above or below a hunk; mark a file Viewed to fold it away; jump between files from the list.
     Full files shows each file whole with its changes marked in place (like an editor's inline diff). */

  function splitLines(s) { if (s == null || s === '') return []; var a = String(s).split('\n'); if (a[a.length - 1] === '') a.pop(); return a; }
  /* Line diff (longest common subsequence after trimming the shared head and tail): fine for files of a few thousand lines. */
  function diffLines(a, b) {
    var n = a.length, m = b.length, pre = 0, suf = 0;
    while (pre < n && pre < m && a[pre] === b[pre]) pre++;
    while (suf < n - pre && suf < m - pre && a[n - 1 - suf] === b[m - 1 - suf]) suf++;
    var A = a.slice(pre, n - suf), B = b.slice(pre, m - suf), N = A.length, M = B.length, W = M + 1;
    var L = new Uint32Array((N + 1) * W), i, j;
    for (i = N - 1; i >= 0; i--) for (j = M - 1; j >= 0; j--) L[i * W + j] = A[i] === B[j] ? L[(i + 1) * W + j + 1] + 1 : Math.max(L[(i + 1) * W + j], L[i * W + j + 1]);
    var ops = [], k;
    for (k = 0; k < pre; k++) ops.push({ t: ' ', o: k, n: k, s: a[k] });
    var x = 0, y = 0;
    while (x < N || y < M) {
      if (x < N && y < M && A[x] === B[y]) { ops.push({ t: ' ', o: pre + x, n: pre + y, s: A[x] }); x++; y++; }
      else if (x < N && (y >= M || L[(x + 1) * W + y] >= L[x * W + y + 1])) { ops.push({ t: '-', o: pre + x, n: null, s: A[x] }); x++; }
      else { ops.push({ t: '+', o: null, n: pre + y, s: B[y] }); y++; }
    }
    for (k = suf; k > 0; k--) ops.push({ t: ' ', o: n - k, n: m - k, s: a[n - k] });
    /* in each run of changes, removed lines come before added ones; pair them up for word-level highlights */
    var out = [], r = 0;
    while (r < ops.length) {
      if (ops[r].t === ' ') { out.push(ops[r]); r++; continue; }
      var s0 = r; while (r < ops.length && ops[r].t !== ' ') r++;
      var run = ops.slice(s0, r), dels = run.filter(function (o) { return o.t === '-'; }), adds = run.filter(function (o) { return o.t === '+'; });
      for (var p = 0; p < Math.min(dels.length, adds.length); p++) wordPair(dels[p], adds[p]);
      var kind = dels.length && adds.length ? 'mod' : dels.length ? 'del' : 'add', all = dels.concat(adds);
      all[0].blk = kind; all[all.length - 1].blkEnd = true;
      out.push.apply(out, all);
    }
    return out;
  }
  /* Word-level change inside a removed/added pair: the span between their shared start and shared end. */
  function wordPair(d, a) {
    var x = d.s, y = a.s, p = 0, q = 0;
    while (p < x.length && p < y.length && x[p] === y[p]) p++;
    while (q < x.length - p && q < y.length - p && x[x.length - 1 - q] === y[y.length - 1 - q]) q++;
    var same = p + q, len = Math.max(x.length, y.length);
    if (!len || same < len * 0.3) return; /* too different: the whole line is the change */
    while (p > 0 && /\w/.test(x[p - 1] || '') && /\w/.test(x[p] || y[p] || '')) p--; /* widen to whole words */
    if (x.length - q > p) d.x = [p, x.length - q];
    if (y.length - q > p) a.x = [p, y.length - q];
  }

  /* A small syntax colouring for JS/TS: keywords, strings, numbers, comments, called functions. */
  var TK_RE = /(\/\/.*$|\/\*.*?\*\/)|("(?:[^"\\]|\\.)*"?|'(?:[^'\\]|\\.)*'?|`(?:[^`\\]|\\.)*`?)|(\b\d[\d_.]*\b|\b(?:true|false|null|undefined)\b)|(\b(?:const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|delete|typeof|instanceof|in|of|async|await|export|import|from|default|class|extends|implements|interface|type|enum|public|private|protected|readonly|static|try|catch|finally|throw|this|super|yield|as|void)\b)|([A-Za-z_$][\w$]*)(?=\s*\()/g;
  var TK_CLS = [null, 'c', 's', 'n', 'k', 'f'];
  function codeTokens(text, lang) {
    if (!lang) return [{ c: null, s: text }];
    var out = [], last = 0, m; TK_RE.lastIndex = 0;
    while ((m = TK_RE.exec(text))) {
      if (!m[0]) { TK_RE.lastIndex++; continue; }
      if (m.index > last) out.push({ c: null, s: text.slice(last, m.index) });
      for (var g = 1; g < 6; g++) if (m[g] != null) { out.push({ c: TK_CLS[g], s: m[0] }); break; }
      last = m.index + m[0].length;
    }
    if (last < text.length) out.push({ c: null, s: text.slice(last) });
    return out;
  }
  function codeNodes(text, lang, x) {
    var toks = codeTokens(text, lang), nodes = [], pos = 0;
    toks.forEach(function (t, i) {
      var a = pos, b = pos + t.s.length; pos = b;
      var cuts = [a]; if (x) { if (x[0] > a && x[0] < b) cuts.push(x[0]); if (x[1] > a && x[1] < b) cuts.push(x[1]); } cuts.push(b);
      for (var c = 0; c < cuts.length - 1; c++) {
        var s = cuts[c], e = cuts[c + 1], inX = x && s >= x[0] && e <= x[1];
        var cls = cx(t.c && 'ex-tk-' + t.c, inX && 'ex-dr-x', inX && s === x[0] && 'is-s', inX && e === x[1] && 'is-e');
        nodes.push(cls ? h('span', { key: i + '.' + c, className: cls }, text.slice(s, e)) : text.slice(s, e));
      }
    });
    return nodes.length ? nodes : ['​'];
  }
  function langOf(path) { return /\.(m?[jt]sx?|cjs)$/.test(path || '') ? 'js' : null; }
  var SCOPE_RE = /^\s*(export\s+)?(default\s+)?(async\s+)?(function\b|class\b|interface\b|type\s+\w+\s*=|(const|let)\s+\w+\s*=\s*(async\s*)?(\(|function))/;

  function prepFile(f) {
    var parts = (f.path || '').split('/'), name = parts.pop();
    var base = { path: f.path, name: name, dir: parts.join('/'), status: f.status || 'M', oldPath: f.oldPath, binary: !!f.binary, lang: langOf(f.path) };
    if (f.binary) return Object.assign(base, { ops: [], add: 0, del: 0, sig: 'bin' });
    if (f.old === undefined && f['new'] === undefined) return Object.assign(base, { pending: true, ops: [], add: f.add || 0, del: f.del || 0, sig: 'p' });
    var a = f.status === 'A' ? [] : splitLines(f.old), b = f.status === 'D' ? [] : splitLines(f['new']);
    var ops = diffLines(a, b), add = 0, del = 0;
    ops.forEach(function (o) { if (o.t === '+') add++; else if (o.t === '-') del++; });
    return Object.assign(base, { ops: ops, add: add, del: del, newLines: b, sig: add + ':' + del + ':' + (f['new'] || '').length + ':' + (f.old || '').length });
  }
  /* How tall a file will be before its lines arrive, so the scroll, the ruler and jumps hold still while it loads. */
  function estRows(f, ctx) { var ch = f.add + f.del, hunks = Math.max(1, Math.min(10, Math.ceil(ch / 14))); return { rows: Math.min(ch, 400) + hunks * ctx * 2, gaps: hunks }; }
  function hashOf(s) { var x = 7; for (var i = 0; i < s.length; i++) x = (x * 31 + s.charCodeAt(i)) | 0; return Math.abs(x); }

  /* Rows and gaps for the changes view: every change plus `ctx` lines around it; the rest are gaps you can open. */
  function diffSegments(ops, ctx, exp) {
    var n = ops.length, vis = new Uint8Array(n), i, j;
    for (i = 0; i < n; i++) if (ops[i].t !== ' ') for (j = Math.max(0, i - ctx); j <= Math.min(n - 1, i + ctx); j++) vis[j] = 1;
    var segs = []; i = 0;
    while (i < n) {
      var s = i, v = vis[i]; while (i < n && vis[i] === v) i++;
      if (v || i - s <= 2) { if (segs.length && segs[segs.length - 1].k === 'rows') segs[segs.length - 1].to = i; else segs.push({ k: 'rows', from: s, to: i }); continue; }
      var e = exp[s] || { d: [], u: [] }, dn = e.d.reduce(function (x, y) { return x + y; }, 0), up = e.u.reduce(function (x, y) { return x + y; }, 0);
      segs.push({ k: 'gap', id: s, from: s, to: i, d: e.d, u: e.u, left: Math.max(0, i - s - dn - up), first: s === 0, last: i === n });
    }
    return segs;
  }
  function hunkHead(f, ops, from, to) {
    var o0 = null, n0 = null, oc = 0, nc = 0;
    for (var i = from; i < to; i++) { var op = ops[i]; if (op.o != null) { if (o0 == null) o0 = op.o; oc++; } if (op.n != null) { if (n0 == null) n0 = op.n; nc++; } }
    var scope = '';
    var startN = n0 == null ? 0 : n0;
    for (var k = startN - 1; k >= 0 && f.newLines && k > startN - 400; k--) if (SCOPE_RE.test(f.newLines[k])) { scope = f.newLines[k].trim().replace(/\s*\{\s*$/, ''); break; }
    return { text: '@@ −' + ((o0 == null ? 0 : o0) + 1) + ',' + oc + ' +' + (startN + 1) + ',' + nc + ' @@', scope: scope };
  }

  /* Grows in on mount (an opened gap, a comment box). With `keepBelow`, the review pins what's under it, so that stays
     where it is on screen and the new lines grow upward. */
  /* A file's body before and after its lines arrive: in view, the skeleton eases to the real height while the lines fade
     in; out of view it simply changes (the review's anchoring keeps what you're reading still). */
  function DrSwap(props) {
    var ref = React.useRef(null), was = React.useRef(props.state), last = React.useRef(0), t = React.useRef(0);
    useLayout(function () {
      var el = ref.current; if (!el) return;
      var from = last.current, to = el.offsetHeight; last.current = to;
      if (was.current === props.state) return;
      was.current = props.state;
      var sc = el.closest('.ex-dr-scroll'); if (!sc || reducedMotion() || !from) return;
      var r = el.getBoundingClientRect(), b = sc.getBoundingClientRect();
      if (r.bottom <= b.top || r.top >= b.bottom) return;
      clearTimeout(t.current);
      el.style.height = from + 'px'; void el.offsetHeight; el.classList.add('is-arriving'); el.style.height = to + 'px';
      t.current = setTimeout(function () { el.classList.remove('is-arriving'); el.style.height = ''; }, 320);
    });
    React.useEffect(function () { return function () { clearTimeout(t.current); }; }, []);
    return h('div', { ref: ref, className: cx('ex-dr-swap', 'is-' + props.state) }, props.children);
  }
  function DrGrow(props) {
    var ref = React.useRef(null);
    useLayout(function () {
      var el = ref.current; if (!el || reducedMotion()) return;
      /* what you were looking at stays put: the hunk under it (opening context above), else what's just before it */
      var still = props.keepBelow ? el.nextElementSibling : el.previousElementSibling;
      if (props.pin && still) props.pin(still, 420);
      var full = el.offsetHeight, dur = Math.round(Math.min(320, 180 + full * 0.25));
      el.style.setProperty('--dr-grow', dur + 'ms'); el.style.height = '0px'; void el.offsetHeight;
      el.classList.add('is-growing'); el.style.height = full + 'px';
      var t = setTimeout(function () { el.classList.remove('is-growing'); el.style.height = ''; }, dur + 20);
      return function () { clearTimeout(t); };
    }, []);
    return h('div', { ref: ref, className: cx('ex-dr-grow', props.className) }, props.children);
  }

  /* A file's body opening and closing. Only what you can see moves: the part below the view is trimmed (or added) at once,
     so a long file folds over the same short distance as a short one, and the time follows that distance. Closing, the
     lines lift 8px and fade first, then the box closes and the header's corners round; opening is the reverse. */
  function DrFold(props) {
    var ref = React.useRef(null), was = React.useRef(null), t = React.useRef(0);
    useLayout(function () {
      var el = ref.current; if (!el) return;
      var open = !!props.open, first = was.current === null;
      if (!first && was.current === open) return;
      was.current = open; clearTimeout(t.current); el.classList.remove('is-closing', 'is-opening');
      if (first || reducedMotion()) { if (open) { el.removeAttribute('data-shut'); el.style.height = ''; } else { el.setAttribute('data-shut', ''); el.style.height = '0px'; } return; }
      var sc = el.closest('.ex-dr-scroll'), bottom = sc ? sc.getBoundingClientRect().bottom : window.innerHeight, top = el.getBoundingClientRect().top, dur;
      if (!open) {
        var vis = Math.max(0, Math.min(el.offsetHeight, bottom - top));
        el.style.height = vis + 'px'; void el.offsetHeight;
        dur = Math.round(Math.min(260, 150 + vis * 0.18));
        el.style.setProperty('--dr-fold', dur + 'ms'); el.classList.add('is-closing'); el.style.height = '0px';
        t.current = setTimeout(function () { el.classList.remove('is-closing'); el.setAttribute('data-shut', ''); }, dur);
      } else {
        el.removeAttribute('data-shut'); el.style.height = ''; var full = el.offsetHeight, target = Math.max(0, Math.min(full, bottom - top));
        el.style.height = '0px'; void el.offsetHeight;
        dur = Math.round(Math.min(340, 200 + target * 0.2));
        el.style.setProperty('--dr-fold', dur + 'ms'); el.classList.add('is-opening'); el.style.height = target + 'px';
        t.current = setTimeout(function () { el.classList.remove('is-opening'); el.style.height = ''; }, dur);
      }
    }, [!!props.open]);
    React.useEffect(function () { return function () { clearTimeout(t.current); }; }, []);
    return h('div', { ref: ref, className: 'ex-dr-foldbox', 'aria-hidden': props.open ? null : 'true', inert: props.open ? null : '' }, h('div', { className: 'ex-dr-fold-in' }, props.children));
  }

  function ViewedBox(props) {
    return h('button', { type: 'button', role: 'checkbox', 'aria-checked': String(!!props.on), className: cx('ex-dr-viewed', props.on && 'is-on'), title: (props.on ? 'Viewed' : 'Mark as viewed') + '  V', onClick: props.onClick },
      h('span', { className: 'ex-dr-box', 'aria-hidden': 'true' }, h(Icon, { name: 'check', size: 12 })), h('span', { className: 'ex-dr-viewed-l' }, 'Viewed'));
  }
  function ViewedRing(props) {
    var r = 6, c = 2 * Math.PI * r, p = props.total ? props.done / props.total : 0;
    return h('span', { className: cx('ex-dr-ring', p === 1 && 'is-all'), title: props.done + ' of ' + props.total + ' files viewed' },
      h('svg', { width: 16, height: 16, viewBox: '0 0 16 16', 'aria-hidden': 'true' },
        h('circle', { cx: 8, cy: 8, r: r, className: 'ex-dr-ring-bg' }),
        h('circle', { cx: 8, cy: 8, r: r, className: 'ex-dr-ring-fg', style: { strokeDasharray: c, strokeDashoffset: c * (1 - p) } })),
      h('span', { className: 'ex-dr-ring-n' }, h(Ticker, { value: props.done }), '/' + props.total));
  }

  function DiffReview(props) {
    var files = props.files || [], ctx = props.context == null ? 3 : props.context;
    var _ct = React.useState({}), content = _ct[0], setContent = _ct[1];
    var _ld = React.useState({}), loading = _ld[0], setLoading = _ld[1];
    var _er = React.useState({}), failed = _er[0], setFailed = _er[1];
    var prepped = React.useMemo(function () { return files.map(function (f) { var c = content[f.path]; var p = prepFile(c && c.rev === f.rev ? Object.assign({}, f, { old: c.old, 'new': c['new'] }) : f); if (f.rev != null) p.sig = 'r' + f.rev; return p; }); }, [files, content]);
    var root = React.useRef(null), scroll = React.useRef(null), stream = React.useRef(null), anchor = React.useRef(null), sigs = React.useRef({});
    function useS(v) { return React.useState(v); }
    var _m = useS(props.mode || 'changes'), mode = _m[0], setMode = _m[1];
    var _w = useS(props.wrap !== false), wrap = _w[0], setWrap = _w[1];
    var _v = useS(function () { var o = {}; files.forEach(function (f) { if (f.viewed && !f.changedSinceViewed) o[f.path] = true; }); return o; }), viewed = _v[0], setViewed = _v[1];
    var _c = useS(function () { var o = {}; files.forEach(function (f) { if (f.changedSinceViewed) o[f.path] = true; }); return o; }), changed = _c[0], setChanged = _c[1];
    var _o = useS(function () { var o = {}; files.forEach(function (f) { o[f.path] = !(f.viewed && !f.changedSinceViewed); }); return o; }), open = _o[0], setOpen = _o[1];
    var _l = useS({}), loaded = _l[0], setLoaded = _l[1];
    var _e = useS({}), exp = _e[0], setExp = _e[1];
    var _f = useS({}), fullOf = _f[0], setFullOf = _f[1];
    var _cur = useS(files[0] ? files[0].path : null), cur = _cur[0], setCur = _cur[1];
    var _j = useS(false), jump = _j[0], setJump = _j[1];
    var _mn = useS(null), menu = _mn[0], setMenu = _mn[1];
    var _d = useS(null), draft = _d[0], setDraft = _d[1];
    var _s = useS([]), sent = _s[0], setSent = _s[1];
    var _wd = useS(false), autoWide = _wd[0], setAutoWide = _wd[1];
    var _mk = useS({ marks: [], ticks: [], thumb: null }), ruler = _mk[0], setRuler = _mk[1];
    var wide = props.wide == null ? autoWide : !!props.wide, showList = true;
    var prevWide = React.useRef(wide); if (prevWide.current !== wide) { prevWide.current = wide; if (!anchor.current) anchor.current = grabAnchor(); }
    var largeAt = props.largeAt || 400;
    var jp = usePresence(jump, 140), mp = usePresence(!!menu, 140);
    var menuFile = React.useRef(null); if (menu) menuFile.current = menu;
    /* a click anywhere else closes the file list and the file menu */
    React.useEffect(function () {
      if (!jump && !menu) return;
      function away(e) { var el = root.current; if (!el) return; if (!e.target.closest || !e.target.closest('.ex-agent-wrap')) { setJump(false); setMenu(null); } }
      document.addEventListener('mousedown', away);
      return function () { document.removeEventListener('mousedown', away); };
    }, [jump, menu]);

    /* a file the agent changes again after you viewed it opens back up, marked */
    React.useEffect(function () {
      var was = sigs.current, now = {}, again = [];
      prepped.forEach(function (f) { now[f.path] = f.sig === 'p' ? was[f.path] : f.sig; if (was[f.path] && f.sig !== 'p' && was[f.path] !== f.sig && viewed[f.path]) again.push(f.path); });
      sigs.current = now;
      if (!again.length) return;
      setViewed(function (v) { var o = Object.assign({}, v); again.forEach(function (p) { delete o[p]; }); return o; });
      setChanged(function (v) { var o = Object.assign({}, v); again.forEach(function (p) { o[p] = true; }); return o; });
      setOpen(function (v) { var o = Object.assign({}, v); again.forEach(function (p) { o[p] = true; }); return o; });
    }, [prepped]);

    /* width decides the layout when `wide` isn't given */
    useLayout(function () {
      var el = root.current; if (!el || props.wide != null || typeof ResizeObserver === 'undefined') return;
      var ro = new ResizeObserver(function () { setAutoWide(el.offsetWidth >= 720); }); ro.observe(el);
      return function () { ro.disconnect(); };
    }, [props.wide]);

    /* Anchoring: whatever changes above what you're reading (files loading, folding, context opening), it stays where it is
       on screen. A pin (a jump to a file, context opened above a hunk) holds a chosen element instead, for a while. */
    var keep = React.useRef(null), pinUntil = React.useRef(0);
    function record() {
      if (Date.now() < pinUntil.current) return;
      var sc = scroll.current; if (!sc) return;
      var top = sc.getBoundingClientRect().top + 40, secs = sc.querySelectorAll('.ex-dr-file'), el = null;
      for (var i = 0; i < secs.length && !el; i++) {
        var r = secs[i].getBoundingClientRect(); if (r.bottom <= top) continue;
        var rows = secs[i].querySelectorAll('.ex-dr-ln, .ex-dr-skrow, .ex-dr-exp, .ex-dr-msg');
        for (var j = 0; j < rows.length; j++) { var rr = rows[j].getBoundingClientRect(); if (rr.bottom > top && rr.height) { el = rows[j]; break; } }
        if (!el) el = secs[i];
      }
      keep.current = el ? { el: el, top: el.getBoundingClientRect().top } : null;
    }
    function pin(el, ms) { if (!el) return; keep.current = { el: el, top: el.getBoundingClientRect().top }; pinUntil.current = Date.now() + (ms || 400); }
    function hold() {
      var k = keep.current, sc = scroll.current; if (!k || !sc || !k.el.isConnected) return;
      var d = k.el.getBoundingClientRect().top - k.top; if (Math.abs(d) > 0.5) sc.scrollTop += d;
    }
    function unpin() { pinUntil.current = 0; record(); }

    /* lines load as their file comes near: the visible ones first, then two screens ahead, three at a time */
    var queue = React.useRef([]), active = React.useRef(0), state = React.useRef({}); state.current = { content: content, loading: loading, failed: failed, open: open };
    function need(path, first) {
      var f = files.find(function (x) { return x.path === path; }), st = state.current;
      if (!f || !props.loadFile || f.binary || f.old !== undefined || f['new'] !== undefined || (st.content[path] && st.content[path].rev === f.rev) || st.loading[path] || st.failed[path] || !st.open[path]) return;
      if (queue.current.indexOf(path) < 0) { if (first) queue.current.unshift(path); else queue.current.push(path); }
      pump();
    }
    function pump() {
      var sc = scroll.current;
      while (active.current < 3 && queue.current.length) {
        if (sc) { var mid = sc.getBoundingClientRect().top + sc.clientHeight / 2; queue.current.sort(function (a, b) { var A = secOf(a), B = secOf(b); return (A ? Math.abs(A.getBoundingClientRect().top - mid) : 1e9) - (B ? Math.abs(B.getBoundingClientRect().top - mid) : 1e9); }); }
        var path = queue.current.shift(), rev = (files.find(function (x) { return x.path === path; }) || {}).rev; active.current++;
        setLoading(function (l) { var o = Object.assign({}, l); o[path] = true; return o; });
        (function (path, rev) {
          Promise.resolve().then(function () { return props.loadFile(path); }).then(function (res) {
            setContent(function (c) { var o = Object.assign({}, c); o[path] = { rev: rev, old: res && res.old != null ? res.old : '', 'new': res && res['new'] != null ? res['new'] : '' }; return o; });
          }, function (err) { setFailed(function (x) { var o = Object.assign({}, x); o[path] = (err && err.message) || 'Couldn’t load it'; return o; }); })
          .then(function () { active.current--; setLoading(function (l) { var o = Object.assign({}, l); delete o[path]; return o; }); pump(); });
        })(path, rev);
      }
    }
    function retry(path) { setFailed(function (x) { var o = Object.assign({}, x); delete o[path]; return o; }); setTimeout(function () { need(path, true); }, 0); }
    useLayout(function () {
      var sc = scroll.current; if (!sc || !props.loadFile || typeof IntersectionObserver === 'undefined') return;
      var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) need(e.target.getAttribute('data-path')); }); }, { root: sc, rootMargin: '1400px 0px' });
      [].forEach.call(sc.querySelectorAll('.ex-dr-file[data-pending]'), function (el) { io.observe(el); });
      return function () { io.disconnect(); };
    }, [prepped, open]);

    /* which file you're in, and the overview ruler */
    var raf = React.useRef(0);
    var marksDirty = React.useRef(true);
    function measure() {
      raf.current = 0;
      var sc = scroll.current; if (!sc) return;
      var full = marksDirty.current; marksDirty.current = false;
      var top = sc.getBoundingClientRect().top, secs = sc.querySelectorAll('.ex-dr-file'), c = secs.length ? secs[0].getAttribute('data-path') : null;
      for (var i = 0; i < secs.length; i++) { if (secs[i].getBoundingClientRect().top - top <= 2) c = secs[i].getAttribute('data-path'); else break; }
      setCur(function (p) { return p === c ? p : c; });
      var H = sc.scrollHeight, vh = sc.clientHeight; if (!H || !vh) return;
      var thumb0 = H > vh + 1 ? { top: sc.scrollTop / H * vh, h: Math.max(12, vh * vh / H) } : null;
      if (!full) { setRuler(function (r) { return Object.assign({}, r, { thumb: thumb0 }); }); return; }
      var marks = [], starts = sc.querySelectorAll('[data-blk]');
      for (var k = 0; k < starts.length; k++) {
        var s = starts[k], e = s; while (e && !e.hasAttribute('data-blk-end')) e = e.nextElementSibling;
        if (!s.offsetHeight) continue;
        var t0 = s.getBoundingClientRect().top - top + sc.scrollTop, t1 = (e || s).getBoundingClientRect().bottom - top + sc.scrollTop;
        marks.push({ k: s.getAttribute('data-blk'), top: t0 / H * vh, h: Math.max(2, (t1 - t0) / H * vh) });
      }
      var ticks = []; for (var q = 1; q < secs.length; q++) ticks.push((secs[q].getBoundingClientRect().top - top + sc.scrollTop) / H * vh);
      setRuler({ marks: marks, ticks: ticks, thumb: thumb0 });
    }
    function soon() { if (!raf.current) raf.current = requestAnimationFrame(measure); }
    function remeasure() { marksDirty.current = true; soon(); }
    useLayout(function () {
      var sc = scroll.current; if (!sc) return;
      measure(); record();
      function onScroll() { record(); soon(); }
      function onInput() { if (pinUntil.current) unpin(); }
      sc.addEventListener('scroll', onScroll, { passive: true });
      sc.addEventListener('wheel', onInput, { passive: true }); sc.addEventListener('touchstart', onInput, { passive: true });
      var ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(function () { hold(); record(); remeasure(); }) : null; if (ro && stream.current) { ro.observe(stream.current); ro.observe(sc); }
      return function () { sc.removeEventListener('scroll', onScroll); sc.removeEventListener('wheel', onInput); sc.removeEventListener('touchstart', onInput); if (ro) ro.disconnect(); if (raf.current) cancelAnimationFrame(raf.current); };
    }, []);

    /* switching Changes ↔ Full files keeps the line you were looking at where it was */
    function grabAnchor() {
      var sc = scroll.current; if (!sc) return null;
      /* the change you're reading if one is in the upper part of the view, else the first line in view */
      var box = sc.getBoundingClientRect(), top = box.top + 40, rows = sc.querySelectorAll('.ex-dr-ln'), first = null, pick = null;
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i].getBoundingClientRect(); if (r.bottom <= top || !rows[i].offsetHeight) continue;
        if (r.top > box.top + box.height * 0.6) break;
        if (!first) first = rows[i];
        if (/is-(add|del)/.test(rows[i].className)) { pick = rows[i]; break; }
      }
      var el = pick || first; if (!el) return null;
      var sec = el.closest('.ex-dr-file');
      return { path: sec && sec.getAttribute('data-path'), n: el.getAttribute('data-n'), o: el.getAttribute('data-o'), dy: el.getBoundingClientRect().top - box.top };
    }
    useLayout(function () {
      var a = anchor.current; anchor.current = null;
      var sc = scroll.current; if (!a || !sc) return;
      var sec = null; [].forEach.call(sc.querySelectorAll('.ex-dr-file'), function (s) { if (s.getAttribute('data-path') === a.path) sec = s; });
      if (!sec) return;
      var row = (a.n && sec.querySelector('.ex-dr-ln[data-n="' + a.n + '"]')) || (a.o && sec.querySelector('.ex-dr-ln[data-o="' + a.o + '"]'));
      if (!row && a.n) { var all = sec.querySelectorAll('.ex-dr-ln[data-n]'); for (var i = 0; i < all.length; i++) if (+all[i].getAttribute('data-n') >= +a.n) { row = all[i]; break; } }
      var el = row || sec;
      sc.scrollTop += el.getBoundingClientRect().top - sc.getBoundingClientRect().top - (row ? a.dy : 0);
      pin(el, 420);
      if (stream.current && !reducedMotion()) { stream.current.classList.remove('is-swapping'); void stream.current.offsetWidth; stream.current.classList.add('is-swapping'); }
    });
    function changeMode(m) { if (m === mode) return; anchor.current = grabAnchor(); setMode(m); setFullOf({}); if (props.onMode) props.onMode(m); }
    function toggleWrap() { anchor.current = grabAnchor(); setWrap(!wrap); }

    function secOf(path) { var sc = scroll.current, out = null; if (sc) [].forEach.call(sc.querySelectorAll('.ex-dr-file'), function (s) { if (s.getAttribute('data-path') === path) out = s; }); return out; }
    function goTo(path) {
      var sc = scroll.current, sec = secOf(path); setJump(false); if (!sc || !sec) return;
      setCur(path); need(path, true);
      var d = sec.getBoundingClientRect().top - sc.getBoundingClientRect().top;
      if (Math.abs(d) > sc.clientHeight * 1.5 || reducedMotion()) {
        /* far: go at once, hold the file at the top while what's above it loads, and let it fade in */
        sc.scrollTop += d; pin(sec, 2500);
        if (!reducedMotion()) { sec.classList.remove('is-landing'); void sec.offsetWidth; sec.classList.add('is-landing'); }
      } else sc.scrollTo({ top: sc.scrollTop + d, behavior: 'smooth' });
    }
    if (props.controller) props.controller.current = { goTo: goTo, step: function (d) { step(d); } };
    function step(d) { var i = prepped.findIndex(function (f) { return f.path === cur; }); var n = prepped[Math.max(0, Math.min(prepped.length - 1, i + d))]; if (n) goTo(n.path); }
    function nextChange(d) {
      var sc = scroll.current; if (!sc) return;
      var top = sc.getBoundingClientRect().top, starts = [].filter.call(sc.querySelectorAll('[data-blk]'), function (s) { return s.offsetHeight; });
      var ys = starts.map(function (s) { return s.getBoundingClientRect().top - top; }), pick = null;
      for (var i = 0; i < ys.length; i++) { if (d > 0 && ys[i] > 60) { pick = ys[i]; break; } if (d < 0 && ys[i] < 40) pick = ys[i]; }
      if (pick != null) sc.scrollTo({ top: sc.scrollTop + pick - 48, behavior: reducedMotion() ? 'auto' : 'smooth' });
    }

    function setViewedOf(path, on) {
      setViewed(function (v) { var o = Object.assign({}, v); if (on) o[path] = true; else delete o[path]; return o; });
      if (on) setChanged(function (v) { if (!v[path]) return v; var o = Object.assign({}, v); delete o[path]; return o; });
      if (props.onViewed) props.onViewed(path, on);
      if (on) closeFile(path); else openFile(path);
    }
    /* the header you clicked stays where it is; what's under it moves */
    function pinHead(path) { var sec = secOf(path); if (sec) pin(sec.querySelector('.ex-dr-fh') || sec, 480); }
    function openFile(path) { pinHead(path); setOpen(function (o) { var x = Object.assign({}, o); x[path] = true; state.current.open = x; return x; }); need(path, true); }
    function closeFile(path) {
      var sc = scroll.current, sec = secOf(path), shut = function () { setOpen(function (o) { var x = Object.assign({}, o); x[path] = false; return x; }); };
      if (sc && sec && sec.getBoundingClientRect().top - sc.getBoundingClientRect().top < -1 && !reducedMotion()) {
        /* its header is stuck at the top while you're inside the file: the lines fade, the scroll moves to the file's start
           (the header looks the same there), then the body folds into the header and the next file rises under it */
        sec.classList.add('is-leaving');
        setTimeout(function () { sec.classList.remove('is-leaving'); sc.scrollTop += sec.getBoundingClientRect().top - sc.getBoundingClientRect().top; pin(sec, 400); shut(); }, 110);
        return;
      }
      pinHead(path); shut();
    }
    function expand(path, gap, dir, n) {
      setExp(function (e) {
        var fe = Object.assign({}, e[path] || {}), g = fe[gap] ? { d: fe[gap].d.slice(), u: fe[gap].u.slice() } : { d: [], u: [] };
        g[dir].push(n); fe[gap] = g; var o = Object.assign({}, e); o[path] = fe; return o;
      });
    }

    function onKey(e) {
      var t = e.target; if (t && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT')) return;
      if (e.altKey && e.key === 'ArrowDown') { e.preventDefault(); step(1); }
      else if (e.altKey && e.key === 'ArrowUp') { e.preventDefault(); step(-1); }
      else if (e.key === 'F7') { e.preventDefault(); nextChange(e.shiftKey ? -1 : 1); }
      else if ((e.key === 'v' || e.key === 'V') && !e.metaKey && !e.ctrlKey && !e.altKey && cur) { e.preventDefault(); setViewedOf(cur, !viewed[cur]); }
      else if (e.key === 'Escape') { if (jump || menu || draft) { setJump(false); setMenu(null); } else if (props.onExit) props.onExit(); }
    }

    var total = prepped.length, done = prepped.filter(function (f) { return viewed[f.path]; }).length;
    var sumAdd = prepped.reduce(function (s, f) { return s + f.add; }, 0), sumDel = prepped.reduce(function (s, f) { return s + f.del; }, 0);
    var curIdx = Math.max(0, prepped.findIndex(function (f) { return f.path === cur; })), curF = prepped[curIdx];
    var listItems = prepped.map(function (f) { return { path: f.path, status: f.status, add: f.add, del: f.del, viewed: !!viewed[f.path], changed: !!changed[f.path], current: f.path === cur }; });


    function lineRow(f, op, i) {
      var kind = op.t === '+' ? 'add' : op.t === '-' ? 'del' : 'ctx';
      var key = f.path + ':' + (op.n != null ? 'n' + op.n : 'o' + op.o), line = op.n != null ? op.n + 1 : op.o + 1, side = op.n != null ? 'new' : 'old';
      /* both gutters are always there; the old-number one opens and closes with the layout, in the same motion */
      var nums = [h('span', { key: 'o', className: 'ex-dr-no is-o' }, op.o != null ? op.o + 1 : ''),
        h('span', { key: 'n', className: cx('ex-dr-no', 'is-n', !wide && op.t === '-' && 'is-old') }, wide ? (op.n != null ? op.n + 1 : '') : line)];
      var rows = [h('div', { key: 'l' + i, className: cx('ex-dr-ln', 'is-' + kind), 'data-n': op.n != null ? op.n + 1 : null, 'data-o': op.o != null ? op.o + 1 : null, 'data-blk': op.blk || null, 'data-blk-end': op.blkEnd ? '' : null },
        h('span', { className: 'ex-dr-gut' }, nums),
        h('span', { className: 'ex-dr-sign', 'aria-label': kind === 'add' ? 'added' : kind === 'del' ? 'removed' : null }, kind === 'add' ? '+' : kind === 'del' ? '−' : ' ',
          props.onComment !== false ? h('button', { type: 'button', className: 'ex-dr-say', 'aria-label': 'Ask the agent about line ' + line, title: 'Ask the agent about this line', onClick: function () { setDraft({ key: key, path: f.path, line: line, side: side, text: '' }); } }, h(Icon, { name: 'plus', size: 12 })) : null),
        h('span', { className: 'ex-dr-code' }, codeNodes(op.s, f.lang, op.x)))];
      sent.forEach(function (c, ci) { if (c.key === key) rows.push(h(DrGrow, { key: 'c' + ci, className: 'ex-dr-note', pin: pin }, h('div', { className: 'ex-dr-note-in' }, h(Icon, { name: 'chat', size: 13 }), h('span', { className: 'ex-dr-note-t' }, c.text), h('span', { className: 'ex-muted' }, 'Sent to the session')))); });
      if (draft && draft.key === key) rows.push(h(DrGrow, { key: 'd', className: 'ex-dr-ask', pin: pin }, h(DraftBox, { draft: draft, onCancel: function () { setDraft(null); }, onSend: function (text) {
        setSent(sent.concat([{ key: key, text: text }])); setDraft(null);
        if (typeof props.onComment === 'function') props.onComment({ path: f.path, line: line, side: side, text: text });
      } })));
      return rows;
    }
    function gapRow(f, g, segs, si) {
      var next = segs[si + 1], left = g.left, head = next ? hunkHead(f, f.ops, next.from, next.to) : null;
      var btn = function (dir, icon, label, n) { return h('button', { key: dir + icon, type: 'button', className: 'ex-dr-exp-b', 'aria-label': label, title: label, onClick: function () { expand(f.path, g.id, dir, n); } }, h(Icon, { name: icon, size: 14 })); };
      var btns = g.last ? [btn('d', 'expand-down', 'Show ' + Math.min(20, left) + ' more lines', Math.min(20, left))]
        : g.first ? [btn('u', 'expand-up', 'Show ' + Math.min(20, left) + ' lines above', Math.min(20, left))]
        : left <= 20 ? [btn('u', 'unfold', 'Show the ' + left + ' hidden lines', left)]
        : [btn('u', 'expand-up', 'Show 20 lines above', 20), btn('d', 'expand-down', 'Show 20 lines below', 20)];
      return h(Fold, { key: 'g' + g.id, open: left > 0, className: 'ex-dr-expf' },
        h('div', { className: 'ex-dr-exp' }, h('span', { className: 'ex-dr-exp-bs' }, btns),
          head && !g.last ? h('span', { className: 'ex-dr-exp-t' }, h('span', { className: 'ex-dr-exp-h' }, head.text), head.scope ? h('span', { className: 'ex-dr-exp-s' }, head.scope) : null)
            : h('span', { className: 'ex-dr-exp-t ex-muted' }, left + (left === 1 ? ' more line' : ' more lines'))));
    }
    function skeleton(f) {
      var e = estRows(f, ctx), rows = [], seed = hashOf(f.path), n = Math.min(e.rows, 60), perGap = Math.max(1, Math.round(n / e.gaps));
      for (var i = 0; i < n; i++) {
        if (i && i % perGap === 0) rows.push(h('div', { key: 'g' + i, className: 'ex-dr-skrow is-gap' }));
        var w = 18 + ((seed >> (i % 13)) + i * 37) % 62, ind = ((seed >> (i % 7)) + i) % 4;
        rows.push(h('div', { key: i, className: 'ex-dr-skrow' }, h('span', { className: 'ex-dr-skno' }), h('span', { className: 'ex-skel', style: { width: w + '%', marginLeft: ind * 2 + 'ch' } })));
      }
      return h('div', { className: 'ex-dr-body is-pending', 'aria-busy': 'true', 'aria-label': 'Loading the changes of ' + f.name, style: { height: e.rows * 20 + e.gaps * 28 } }, rows);
    }
    function fileBody(f) {
      if (f.binary) return h('div', { className: 'ex-dr-msg' }, 'Binary file, not shown.');
      if (failed[f.path]) return h('div', { className: 'ex-dr-msg' }, h('span', null, 'Couldn’t load these changes.'), h(Button, { size: 'sm', icon: 'refresh', onClick: function () { retry(f.path); } }, 'Try again'));
      if (f.pending) return skeleton(f);
      var big = f.add + f.del > largeAt;
      if ((f.status === 'D' || big) && !loaded[f.path]) return h('div', { className: 'ex-dr-msg' },
        h('span', null, f.status === 'D' ? 'This file was deleted · ' + f.del + ' lines' : 'Large change · ' + (f.add + f.del).toLocaleString() + ' lines'),
        h(Button, { size: 'sm', onClick: function () { var o = Object.assign({}, loaded); o[f.path] = true; setLoaded(o); } }, f.status === 'D' ? 'Show' : 'Load the diff'));
      var full = mode === 'full' || fullOf[f.path] || f.status === 'A' || f.status === 'D';
      var out = [];
      if (full) f.ops.forEach(function (op, i) { out.push.apply(out, lineRow(f, op, i)); });
      else {
        var segs = diffSegments(f.ops, ctx, exp[f.path] || {});
        segs.forEach(function (sg, si) {
          if (sg.k === 'rows') { for (var i = sg.from; i < sg.to; i++) out.push.apply(out, lineRow(f, f.ops[i], i)); return; }
          var at = sg.from;
          sg.d.forEach(function (n, k) { var rows = []; for (var i = at; i < at + n && i < sg.to; i++) rows.push.apply(rows, lineRow(f, f.ops[i], i)); at += n; out.push(h(DrGrow, { key: 'gd' + sg.id + '.' + k, pin: pin }, rows)); });
          out.push(gapRow(f, sg, segs, si));
          /* "above" steps stack upward from the hunk below: the latest sits highest. While one grows, the hunk under it stays put. */
          var end = sg.to, ups = [];
          sg.u.forEach(function (n, k) { var s0 = Math.max(at, end - n), rows = []; for (var i = s0; i < end; i++) rows.push.apply(rows, lineRow(f, f.ops[i], i)); end = s0; ups.push(h(DrGrow, { key: 'gu' + sg.id + '.' + k, keepBelow: true, pin: pin }, rows)); });
          out.push.apply(out, ups.reverse());
        });
      }
      return h('div', { className: 'ex-dr-body' }, h('div', { className: 'ex-dr-lines' }, out));
    }
    function fileHead(f) {
      var isOpen = !!open[f.path], v = !!viewed[f.path], st = { M: 'Modified', A: 'Added', D: 'Deleted', R: 'Renamed' }[f.status];
      return h('div', { className: 'ex-dr-fh' },
        h('button', { type: 'button', className: 'ex-dr-fold', 'aria-expanded': String(isOpen), 'aria-label': (isOpen ? 'Collapse ' : 'Expand ') + f.name, onClick: function () { if (isOpen) closeFile(f.path); else openFile(f.path); } },
          h(Icon, { name: 'chevron-down', size: 14, className: cx('ex-chev', !isOpen && 'is-closed') }),
          h('span', { className: 'ex-change-st st-' + f.status, title: st }, f.status),
          h('span', { className: 'ex-dr-path' }, h('bdi', null, h('b', null, f.name), f.status === 'R' && f.oldPath ? h('span', null, '  from ' + f.oldPath) : f.dir ? h('span', null, '  ' + f.dir) : null)),
          f.binary ? null : h(Diff, { add: f.add, del: f.del }), loading[f.path] ? h('span', { className: 'ex-dr-loading', 'aria-label': 'Loading' }, h(StatusGlyph, { status: 'running', size: 12 })) : null),
        changed[f.path] ? h('span', { className: 'ex-dr-again', title: 'The agent changed this file after you marked it viewed' }, wide ? 'Changed since viewed' : 'Changed') : null,
        h(ViewedBox, { on: v, onClick: function () { setViewedOf(f.path, !v); } }),
        h('span', { className: 'ex-agent-wrap' }, h(IconButton, { icon: 'more', label: 'More for ' + f.name, size: 'sm', 'aria-expanded': String(menu === f.path), onClick: function () { setMenu(menu === f.path ? null : f.path); } }),
          mp.m && menuFile.current === f.path ? h('div', { className: cx('ex-menu', 'ex-dr-menu', mp.l && 'is-leaving'), role: 'menu' },
            mode !== 'full' && f.status === 'M' ? h('div', { className: 'ex-menu-item', role: 'menuitem', onClick: function () { anchor.current = grabAnchor(); var o = Object.assign({}, fullOf); o[f.path] = !o[f.path]; setFullOf(o); setMenu(null); } }, h(Icon, { name: 'file', size: 14 }), fullOf[f.path] ? 'Show changes only' : 'Show the full file') : null,
            h('div', { className: 'ex-menu-item', role: 'menuitem', onClick: function () { try { navigator.clipboard.writeText(f.path); } catch (e) {} setMenu(null); } }, h(Icon, { name: 'copy', size: 14 }), 'Copy path'),
            h('div', { className: 'ex-menu-item', role: 'menuitem', onClick: function () { setMenu(null); if (props.onOpenFile) props.onOpenFile(f.path); } }, h(Icon, { name: 'code', size: 14 }), 'Open in Code')) : null));
    }

    return h('div', { ref: root, className: cx('ex-dr', wide && 'is-wide', wide && showList && 'has-list', !wrap && 'is-nowrap', props.className), style: props.style, tabIndex: -1, onKeyDown: onKey, 'aria-label': 'Changes' },
      h('div', { className: 'ex-dr-bar' },
        h('div', { className: 'ex-dr-bar-tree', 'aria-hidden': wide && showList ? null : 'true' }, h('b', null, total + (total === 1 ? ' file' : ' files')), h(Diff, { add: sumAdd, del: sumDel })),
        h('div', { className: 'ex-dr-bar-main' },
          h('div', { className: 'ex-dr-jumpw ex-agent-wrap', 'aria-hidden': wide ? 'true' : null },
            h('button', { type: 'button', className: 'ex-dr-jump', 'aria-haspopup': 'listbox', 'aria-expanded': String(jump), title: 'Go to a file', onClick: function () { setJump(!jump); } },
              h(EaseSwap, { k: curF ? curF.path : 'none', className: 'ex-dr-jump-name' }, h('b', null, curF ? curF.name : 'No changes')),
              h('span', { className: 'ex-dr-jump-n' }, total ? h(F, null, h(Ticker, { value: curIdx + 1 }), ' of ' + total) : null),
              h(Icon, { name: 'chevron-down', size: 13 })),
            jp.m ? h('div', { className: cx('ex-menu', 'ex-dr-jumpmenu', jp.l && 'is-leaving'), role: 'listbox', 'aria-label': 'Changed files' },
              h('div', { className: 'ex-dr-jumphead' }, h('span', null, total + ' files'), h(Diff, { add: sumAdd, del: sumDel }), h('span', { style: { flex: 1 } }), h('span', { className: 'ex-muted' }, done + ' of ' + total + ' viewed')),
              h(ChangeList, { items: listItems, grouped: true, onSelect: goTo })) : null),
          h(IconButton, { icon: 'arrow-up', size: 'sm', label: 'Previous file  ⌥↑', disabled: curIdx <= 0, onClick: function () { step(-1); } }),
          h(IconButton, { icon: 'arrow-down', size: 'sm', label: 'Next file  ⌥↓', disabled: curIdx >= total - 1, onClick: function () { step(1); } }),
          h('span', { style: { flex: 1, minWidth: 4 } }),
          h(ViewedRing, { done: done, total: total }),
          h(Segmented, { size: 'sm', label: 'Show', value: mode, onChange: changeMode, options: [{ id: 'changes', label: 'Changes', title: 'Each file’s changes with a few lines around them' }, { id: 'full', label: wide ? 'Full files' : 'Full', title: 'Each file whole, with its changes marked in place' }] }),
          h(IconButton, { icon: 'wrap', size: 'sm', label: wrap ? 'Don’t wrap lines' : 'Wrap long lines', active: wrap, onClick: toggleWrap }),
          props.toolbarEnd || null)),
      h('div', { className: 'ex-dr-main' },
        h('aside', { className: 'ex-dr-tree', 'aria-label': 'Changed files', 'aria-hidden': wide && showList ? null : 'true', inert: wide && showList ? null : '' },
          h(ChangeList, { items: listItems, grouped: true, onSelect: goTo }),
          h('div', { className: 'ex-dr-tree-foot ex-muted' }, done + ' of ' + total + ' viewed')),
        h('div', { className: 'ex-dr-view' },
          h('div', { ref: scroll, className: 'ex-dr-scroll' },
            h('div', { ref: stream, className: 'ex-dr-stream' },
              total ? prepped.map(function (f) {
                var st = failed[f.path] ? 'failed' : f.pending ? 'pending' : 'ready';
                return h('section', { key: f.path, className: cx('ex-dr-file', viewed[f.path] && 'is-viewed', changed[f.path] && 'is-again'), 'data-path': f.path, 'data-pending': f.pending ? '' : null, 'aria-label': f.path },
                  fileHead(f), h(DrFold, { open: !!open[f.path] }, h(DrSwap, { state: st }, fileBody(f))));
              }) : h('div', { className: 'ex-dr-empty ex-muted' }, 'No changes yet.'))),
          h('div', { className: 'ex-dr-ruler', 'aria-hidden': 'true', onMouseDown: function (e) {
            var sc = scroll.current; if (!sc) return; var r = e.currentTarget.getBoundingClientRect();
            sc.scrollTo({ top: (e.clientY - r.top) / r.height * sc.scrollHeight - sc.clientHeight / 2, behavior: reducedMotion() ? 'auto' : 'smooth' });
          } },
            ruler.ticks.map(function (t, i) { return h('span', { key: 't' + i, className: 'ex-dr-tick', style: { top: t } }); }),
            ruler.marks.map(function (m, i) { return h('span', { key: i, className: 'ex-dr-mark is-' + m.k, style: { top: m.top, height: m.h } }); }),
            ruler.thumb ? h('span', { className: 'ex-dr-thumb', style: { transform: 'translateY(' + ruler.thumb.top + 'px)', height: ruler.thumb.h } }) : null))));
  }
  /* The Changes panel takes over the chat for a while (the expand icon in the panel header): the panel eases wide over
     the chat's place while the chat fades, laid out at its own width so nothing in it reflows; back is the reverse.
     Put the returned ref on the main area; the shell (.ex-shell) gets is-takeover. */
  function usePanelTakeover(on) {
    var ref = React.useRef(null), was = React.useRef(null), w = React.useRef(0), t = React.useRef(0);
    useLayout(function () {
      var m = ref.current; if (!m) return; var sh = m.closest('.ex-shell');
      var first = was.current === null; was.current = !!on;
      if (on) m.setAttribute('inert', ''); else m.removeAttribute('inert');
      if (!first) {
        clearTimeout(t.current);
        if (on) w.current = m.offsetWidth;
        m.style.setProperty('--freeze-w', (w.current || m.offsetWidth) + 'px'); m.classList.add('is-frozen');
        if (!on) t.current = setTimeout(function () { m.classList.remove('is-frozen'); }, 340);
      }
      if (sh) sh.classList.toggle('is-takeover', !!on);
    }, [!!on]);
    React.useEffect(function () { return function () { clearTimeout(t.current); }; }, []);
    return ref;
  }
  function DraftBox(props) {
    var _t = React.useState(props.draft.text || ''), text = _t[0], setText = _t[1], ta = React.useRef(null);
    React.useEffect(function () { if (ta.current) ta.current.focus(); }, []);
    function send() { if (text.trim()) props.onSend(text.trim()); }
    return h('div', { className: 'ex-dr-ask-in' },
      h('textarea', { ref: ta, rows: 2, className: 'ex-dr-ask-ta', value: text, placeholder: 'Ask the agent about line ' + props.draft.line + '…', 'aria-label': 'Message about line ' + props.draft.line,
        onChange: function (e) { setText(e.target.value); },
        onKeyDown: function (e) { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); send(); } else if (e.key === 'Escape') { e.preventDefault(); props.onCancel(); } } }),
      h('div', { className: 'ex-dr-ask-bar' }, h('span', { className: 'ex-muted' }, 'Goes to the chat with line ' + props.draft.line + ' attached'), h('span', { style: { flex: 1 } }),
        h(Button, { size: 'sm', onClick: props.onCancel }, 'Cancel'), h(Button, { size: 'sm', variant: 'primary', disabled: !text.trim(), kbd: '⌘↵', onClick: send }, 'Send')));
  }

  /* ════ Live agent moments ════ */

  /* The agent waits for a yes: run a command, apply an edit, call a tool. */
  /* The card eases between its states (pending ↔ resolved) instead of snapping. */
  function ApprovalCard(props) { return h(AutoHeight, { className: 'ex-card-autoh' }, h(ApprovalCardInner, props)); }
  function ApprovalCardInner(props) {
    var _s = React.useState(props.status || 'pending'); var status = _s[0], setStatus = _s[1];
    var kind = props.kind || 'command';
    var verb = { command: 'Run a command', edit: 'Apply an edit', tool: 'Use a tool' }[kind];
    if (status !== 'pending') {
      var ok = status !== 'denied';
      return h('div', { className: cx('ex-approval is-resolved', ok ? 'is-ok' : 'is-no') },
        h(Icon, { name: ok ? 'check' : 'x', size: 13 }),
        h('span', null, status === 'always' ? 'Always allowed' : ok ? 'Approved' : 'Denied'),
        h('span', { className: 'ex-mono ex-approval-sum' }, props.command || props.file || props.tool),
        props.onUndo !== false ? h('button', { type: 'button', className: 'ex-link-add', onClick: function () { setStatus('pending'); } }, 'Undo') : null);
    }
    function act(s) { setStatus(s); if (props.onResolve) props.onResolve(s); }
    return h('section', { className: 'ex-approval', role: 'group', 'aria-label': 'Needs you: ' + verb },
      h('div', { className: 'ex-approval-head' }, h(StatusGlyph, { status: 'attention', size: 14 }), h('span', { className: 'ex-approval-verb' }, verb), props.reason ? h('span', { className: 'ex-approval-why' }, props.reason) : null),
      kind === 'edit'
        ? h('div', { className: 'ex-approval-body' }, h(Icon, { name: 'file', size: 13 }), h('span', { className: 'ex-mono ex-grow' }, props.file), props.diff ? h(Diff, props.diff) : null)
        : h('div', { className: 'ex-approval-body is-code' }, h('span', { className: 'ex-approval-prompt', 'aria-hidden': 'true' }, kind === 'tool' ? '→' : '$'), h('span', { className: 'ex-mono ex-grow' }, props.command || props.tool), props.where ? h('span', { className: 'ex-approval-where' }, props.where) : null),
      h('div', { className: 'ex-approval-acts' },
        h(Button, { variant: 'primary', size: 'sm', kbd: '↵', onClick: function () { act('approved'); } }, 'Approve'),
        h(Button, { variant: 'secondary', size: 'sm', onClick: function () { act('always'); } }, kind === 'command' ? 'Always allow this command' : 'Always allow'),
        h('span', { style: { flex: 1 } }),
        h(Button, { variant: 'ghost', size: 'sm', kbd: 'Esc', onClick: function () { act('denied'); } }, 'Deny')));
  }

  /* The agent asks you to choose. Number keys pick; or type your own answer. */
  /* The card eases between its states (pending ↔ resolved) instead of snapping. */
  function QuestionCard(props) { return h(AutoHeight, { className: 'ex-card-autoh' }, h(QuestionCardInner, props)); }
  function questionList(props) {
    if (props.questions && props.questions.length) return props.questions.map(function (q, i) { return Object.assign({}, q, { id: q.id || 'q' + i, kind: q.kind || 'single', options: q.options || [] }); });
    return [{ id: 'q0', question: props.question, header: props.header, kind: props.kind || 'single', options: props.options || [] }];
  }
  function QuestionCardInner(props) {
    var qs = questionList(props), many = qs.length > 1;
    var init = props.answers || (props.answer != null ? { q0: [].concat(props.answer) } : null);
    var _i = React.useState(0), idx = _i[0], setIdx = _i[1];
    var _d = React.useState(1), dir = _d[0], setDir = _d[1];
    var _a = React.useState(init || {}), answers = _a[0], setAnswers = _a[1];
    var _o = React.useState({}), others = _o[0], setOthers = _o[1];   /* your own answer per question */
    var _e = React.useState(null), editing = _e[0], setEditing = _e[1];
    var _s = React.useState(!!init), sent = _s[0], setSent = _s[1];
    var _dr = React.useState(''), draft = _dr[0], setDraft = _dr[1];
    var timer = React.useRef(0), committed = React.useRef(false);
    /* writing your own answer selects it at once (pick one: the other options let go); nothing is sent until you say so */
    function edit(q) { committed.current = false; clearTimeout(timer.current); setDraft(others[q.id] || ''); setEditing(q.id); if (q.kind !== 'multi') setFor(q, [], false); }
    React.useEffect(function () { return function () { clearTimeout(timer.current); }; }, []);
    function picked(q) { return answers[q.id] || []; }
    function answered(q) { return picked(q).length > 0; }
    function go(n) { if (n < 0 || n >= qs.length) return; setDir(n > idx ? 1 : -1); setIdx(n); setEditing(null); }
    function send(a) { setSent(true); setEditing(null); if (props.onSubmit) props.onSubmit(a || answers); }
    function setFor(q, list, after) {
      /* list is a value or a function of the current answers for q (so quick successive picks never drop one) */
      var o = null;
      setAnswers(function (prev) { o = Object.assign({}, prev); o[q.id] = typeof list === 'function' ? list(prev[q.id] || []) : list; return o; });
      if (after && q.kind !== 'multi') {
        clearTimeout(timer.current);
        if (!many) timer.current = setTimeout(function () { send(o); }, 180);        /* one question, one pick: that's the answer */
        else if (idx < qs.length - 1) timer.current = setTimeout(function () { setDir(1); setIdx(idx + 1); }, 220); /* in a run, move on */
      }
    }
    function choose(q, label) {
      if (q.kind === 'multi') setFor(q, function (cur) { return cur.indexOf(label) >= 0 ? cur.filter(function (x) { return x !== label; }) : cur.concat([label]); }, false);
      else setFor(q, [label], true);
    }
    function commitOther(q, text, then) {
      text = (text || '').trim(); var prev = others[q.id];
      var oo = Object.assign({}, others); if (text) oo[q.id] = text; else delete oo[q.id]; setOthers(oo); setEditing(null);
      var cur = (answers[q.id] || []).filter(function (x) { return x !== prev; });
      var list = !text ? cur : q.kind === 'multi' ? cur.concat([text]) : [text];
      var next = Object.assign({}, answers); next[q.id] = list; setAnswers(next);
      if (!text) return;
      if (then === 'send') send(next);
      else if (then === 'next' && idx < qs.length - 1) { setDir(1); setIdx(idx + 1); }
    }
    var allDone = qs.every(answered);

    if (sent) {
      if (!many) return h('div', { className: 'ex-approval is-resolved is-ok' }, h(Icon, { name: 'check', size: 13 }), h('span', null, 'You chose'), h('b', { className: 'ex-approval-sum' }, picked(qs[0]).join(', ')),
        h('button', { type: 'button', className: 'ex-link-add', onClick: function () { setSent(false); } }, 'Change'));
      return h('div', { className: 'ex-approval is-resolved is-ok ex-q-sent' },
        h('div', { className: 'ex-q-sent-h' }, h(Icon, { name: 'check', size: 13 }), h('span', null, 'You answered ' + qs.length + ' questions'), h('button', { type: 'button', className: 'ex-link-add', onClick: function () { setSent(false); setIdx(0); } }, 'Change')),
        h('ul', { className: 'ex-q-sent-list' }, qs.map(function (q, i) { return h('li', { key: q.id }, h('span', null, q.header || 'Question ' + (i + 1)), h('b', null, picked(q).join(', '))); })));
    }

    var q = qs[idx], cur = picked(q), mine = others[q.id], multi = q.kind === 'multi';
    function onKey(e) {
      if (e.target && e.target.tagName === 'INPUT') return;
      var n = parseInt(e.key, 10);
      if (n >= 1 && n <= q.options.length) { e.preventDefault(); choose(q, q.options[n - 1].label); return; }
      if (e.key === 'Enter') { e.preventDefault(); if (idx < qs.length - 1 && answered(q)) go(idx + 1); else if (allDone && (many || multi)) send(); }
      if (e.key === 'ArrowLeft' && many) go(idx - 1);
      if (e.key === 'ArrowRight' && many && answered(q)) go(idx + 1);
    }
    function row(o, i) {
      var on = cur.indexOf(o.label) >= 0;
      return h('button', { key: o.label, type: 'button', role: multi ? 'checkbox' : 'radio', 'aria-checked': String(on), className: cx('ex-q-opt', on && 'is-picked'), style: { '--i': i }, onClick: function () { choose(q, o.label); } },
        h('span', { className: cx('ex-q-ind', multi ? 'is-check' : 'is-radio') }, multi ? h('svg', { viewBox: '0 0 16 16', width: 12, height: 12, 'aria-hidden': 'true' }, h('path', { d: 'M3.5 8.5l3 3 6-7' })) : h('span')),
        h('span', { className: 'ex-grow' }, h('span', { className: 'ex-q-label' }, o.label), o.detail ? h('span', { className: 'ex-q-detail' }, o.detail) : null),
        o.recommended ? h('span', { className: 'ex-bf-tag' }, 'suggested') : null,
        i < 9 ? h(Kbd, null, String(i + 1)) : null);
    }
    var otherRow = editing === q.id
      ? h('div', { key: 'other-edit', className: 'ex-q-opt ex-q-other is-editing is-picked' },
          h('span', { className: cx('ex-q-ind', multi ? 'is-check' : 'is-radio') }, multi ? h('svg', { viewBox: '0 0 16 16', width: 12, height: 12, 'aria-hidden': 'true' }, h('path', { d: 'M3.5 8.5l3 3 6-7' })) : h('span')),
          h('input', { autoFocus: true, value: draft, onChange: function (e) { setDraft(e.target.value); }, placeholder: 'Write your own answer', 'aria-label': 'Your own answer',
            onKeyDown: function (e) {
              if (e.key === 'Enter') { e.preventDefault(); if (!draft.trim()) return; committed.current = true; commitOther(q, draft, multi ? null : many ? 'next' : 'send'); }
              if (e.key === 'Escape') { e.preventDefault(); committed.current = true; setEditing(null); }
            },
            onBlur: function () { if (committed.current) return; committed.current = true; if (draft.trim()) commitOther(q, draft, null); else setEditing(null); } }),
          h(Kbd, null, '↵'))
      : mine
        ? h('button', { key: 'other-mine', type: 'button', role: multi ? 'checkbox' : 'radio', 'aria-checked': String(cur.indexOf(mine) >= 0), className: cx('ex-q-opt ex-q-other is-mine', cur.indexOf(mine) >= 0 && 'is-picked'), onClick: function () { choose(q, mine); } },
            h('span', { className: cx('ex-q-ind', multi ? 'is-check' : 'is-radio') }, multi ? h('svg', { viewBox: '0 0 16 16', width: 12, height: 12, 'aria-hidden': 'true' }, h('path', { d: 'M3.5 8.5l3 3 6-7' })) : h('span')),
            h('span', { className: 'ex-grow' }, h('span', { className: 'ex-q-label' }, mine), h('span', { className: 'ex-q-detail' }, 'Your answer')),
            h('span', { className: 'ex-q-edit', role: 'button', tabIndex: 0, onClick: function (e) { e.stopPropagation(); edit(q); } }, 'Edit'))
        : h('button', { key: 'other-add', type: 'button', className: 'ex-q-opt ex-q-other', onClick: function () { edit(q); } },
            h('span', { className: 'ex-q-ind is-pen' }, h(Icon, { name: 'pencil', size: 12 })), h('span', { className: 'ex-grow' }, h('span', { className: 'ex-q-label' }, 'Something else…')));
    var writing = editing === q.id, ownPicked = writing || (!!mine && cur.indexOf(mine) >= 0);
    var hint = writing ? (multi ? '↵ adds it' : many ? '↵ keeps it and goes on' : '↵ sends it') : multi ? (cur.length ? cur.length + ' picked' : 'Pick any') : (many ? 'Pick one' : ownPicked ? 'Your own answer' : null);
    var canGo = writing ? !!draft.trim() || (multi && cur.length > 0) : answered(q);
    function goOn(then) { if (writing && draft.trim()) { committed.current = true; commitOther(q, draft, then); } else if (then === 'send') send(); else go(idx + 1); }
    var nextBtn = idx < qs.length - 1
      ? h(Button, { size: 'sm', variant: canGo ? 'primary' : 'secondary', kbd: canGo && !writing ? '↵' : null, disabled: !canGo, onMouseDown: function (e) { e.preventDefault(); }, onClick: function () { goOn('next'); } }, 'Next')
      : (function () { var ready = qs.every(function (qq) { return qq.id === q.id ? canGo : answered(qq); });
          return h(Button, { size: 'sm', variant: 'primary', kbd: ready && !writing ? '↵' : null, disabled: !ready, onMouseDown: function (e) { e.preventDefault(); }, onClick: function () { goOn('send'); } }, many ? 'Send answers' : 'Send'); })();
    /* one question, pick one: no footer unless your own answer is the choice (then you send it yourself) */
    var foot = many || multi || ownPicked;
    return h('section', { className: cx('ex-approval ex-question', many && 'is-many'), role: 'group', 'aria-label': 'Needs you: ' + (many ? qs.length + ' questions' : 'a question'), onKeyDown: onKey },
      many ? h('div', { className: 'ex-q-steps', role: 'tablist' },
        qs.map(function (qq, i) { var ok = answered(qq);
          return h('button', { key: qq.id, type: 'button', role: 'tab', 'aria-selected': String(i === idx), className: cx('ex-q-step', i === idx && 'is-on', ok && 'is-done'), onClick: function () { go(i); } },
            h('span', { className: 'ex-q-step-n' }, ok && i !== idx ? h(Icon, { name: 'check', size: 10 }) : i + 1), h('span', { className: 'ex-q-step-l' }, qq.header || 'Question ' + (i + 1))); }),
        h('span', { style: { flex: 1 } }), h('span', { className: 'ex-q-count' }, h(Ticker, { value: qs.filter(answered).length }), '\u00a0of ' + qs.length)) : null,
      h('div', { key: q.id, className: cx('ex-q-pane', many && (dir > 0 ? 'is-fwd' : 'is-back')) },
        h('div', { className: 'ex-approval-head' }, h(StatusGlyph, { status: 'attention', size: 14 }), h('span', { className: 'ex-approval-verb' }, q.question)),
        h('div', { className: 'ex-q-opts', role: multi ? 'group' : 'radiogroup', 'aria-label': q.question }, q.options.map(row), otherRow)),
      foot ? h('div', { className: 'ex-q-foot' },
        many && idx > 0 ? h(Button, { size: 'sm', variant: 'ghost', onClick: function () { go(idx - 1); } }, 'Back') : null,
        hint ? h('span', { className: 'ex-q-hint' }, hint) : null, h('span', { style: { flex: 1 } }), nextBtn) : null);
  }

  /* A proposed plan: steps that tick off as the agent works. */
  /* The card eases between its states (pending ↔ resolved) instead of snapping. */
  function PlanCard(props) { return h(AutoHeight, { className: 'ex-card-autoh' }, h(PlanCardInner, props)); }
  function PlanCardInner(props) {
    var steps = props.steps || [];
    var status = props.status || 'proposed';
    var done = steps.filter(function (s) { return s.state === 'done'; }).length;
    return h('section', { className: cx('ex-plan', 'is-' + status), 'aria-label': 'Plan' },
      h('div', { className: 'ex-plan-head' },
        h(Icon, { name: 'plan', size: 14 }), h('span', { className: 'ex-plan-title' }, props.title || 'Plan'),
        h('span', { style: { flex: 1 } }),
        status === 'proposed' ? h('span', { className: 'ex-plan-meta' }, steps.length + ' steps') : h('span', { className: 'ex-plan-meta' }, h(Ticker, { value: done }), ' of ' + steps.length)),
      status !== 'proposed' ? h(ProgressLine, { value: steps.length ? done / steps.length : 0 }) : null,
      h('ol', { className: 'ex-plan-steps' }, steps.map(function (s, i) {
        var st = s.state || 'todo';
        return h('li', { key: i, className: 'ex-plan-step is-' + st, style: { '--i': i } },
          h('span', { className: 'ex-plan-mark' }, st === 'running' ? h(StatusGlyph, { status: 'running', size: 14 }) : st === 'done' ? h(StatusGlyph, { status: 'done', size: 14 }) : h('span', { className: 'ex-plan-n' }, i + 1)),
          h('span', { className: 'ex-plan-text' }, s.text));
      })),
      status === 'proposed' ? h('div', { className: 'ex-plan-acts' },
        h(Button, { variant: 'primary', size: 'sm', icon: 'code', kbd: '⇧⇥', onClick: props.onStart }, 'Start coding'),
        h(Button, { variant: 'ghost', size: 'sm', icon: 'pencil' }, 'Refine'),
        h('span', { style: { flex: 1 } }), h('span', { className: 'ex-plan-meta' }, 'Switches to Code and follows these steps')) : null);
  }

  /* The model thinking: a live shimmer and timer, collapsed to one line when done. */
  function ThinkingBlock(props) {
    var _o = React.useState(!!props.open); var open = _o[0], setOpen = _o[1];
    var active = !!props.active;
    return h('div', { className: cx('ex-think', active && 'is-active', open && 'is-open') },
      h('button', { type: 'button', className: 'ex-think-head', 'aria-expanded': String(open), onClick: function () { setOpen(!open); } },
        h(Icon, { name: 'bulb', size: 13 }),
        h('span', { className: active ? 'ex-shimmer-text' : null }, active ? 'Thinking' : 'Thought for ' + (props.seconds || 0) + 's'),
        active && props.seconds != null ? h('span', { className: 'ex-think-time' }, props.seconds + 's') : null,
        h(Icon, { name: 'chevron-right', size: 12, className: 'ex-think-chev' })),
      h(Fold, { open: open }, h('div', { className: 'ex-think-body' }, props.children)));
  }

  /* One tool call: shimmer while running, a check (and its duration) when done, output on demand. */
  function ToolStep(props) {
    var _o = React.useState(!!props.open); var open = _o[0], setOpen = _o[1];
    var st = props.status || 'done';
    var hasOut = !!props.output;
    return h('div', { className: cx('ex-step2', 'is-' + st, open && 'is-open') },
      h('button', { type: 'button', className: 'ex-step2-head', 'aria-expanded': hasOut ? String(open) : undefined, onClick: hasOut ? function () { setOpen(!open); } : undefined, tabIndex: hasOut ? 0 : -1 },
        h(Icon, { name: props.icon || 'terminal', size: 14 }),
        props.verb ? h('span', { className: 'ex-step2-verb' }, props.verb) : null,
        h('span', { className: 'ex-mono ex-step2-detail' }, props.detail),
        h('span', { style: { flex: 1 } }),
        props.meta ? h('span', { className: 'ex-step2-meta' }, props.meta) : null,
        st === 'running' ? h(StatusGlyph, { status: 'running', size: 13 }) : st === 'failed' ? h(StatusGlyph, { status: 'failed', size: 13 }) : h('span', { className: 'ex-step2-done' }, h(StatusGlyph, { status: 'done', size: 13 })),
        hasOut ? h(Icon, { name: 'chevron-right', size: 12, className: 'ex-step2-chev' }) : null),
      hasOut ? h(Fold, { open: open }, h('pre', { className: 'ex-step2-out' }, props.output)) : null);
  }

  /* Streaming text: new words fade in, a caret blinks until the turn ends. `demo` types it out. */
  function StreamText(props) {
    var full = String(props.text || '');
    var _n = React.useState(props.demo ? 0 : full.length); var n = _n[0], setN = _n[1];
    var prev = React.useRef(0);
    React.useEffect(function () {
      if (!props.demo) { setN(full.length); return; }
      setN(0); prev.current = 0;
      var t = setInterval(function () { setN(function (x) { if (x >= full.length) { clearInterval(t); return x; } var next = full.indexOf(' ', x + 3); return next === -1 ? full.length : next; }); }, props.speed || 55);
      return function () { clearInterval(t); };
    }, [full, props.demo, props.run]);
    var cut = Math.min(n, full.length);
    var stable = Math.min(prev.current, cut);
    React.useEffect(function () { prev.current = cut; });
    var streaming = props.streaming != null ? props.streaming : cut < full.length;
    return h('p', { className: 'ex-stream' }, full.slice(0, stable), h('span', { key: stable, className: 'ex-chunk' }, full.slice(stable, cut)), streaming ? h('span', { className: 'ex-caret', 'aria-hidden': 'true' }) : null);
  }

  /* The @ menu: sessions (with live status), tasks and files that match. */
  function MentionMenu(props) {
    var q = props.query || '';
    var groups = [
      { id: 'sessions', label: 'Sessions', items: (props.sessions || []) },
      { id: 'tasks', label: 'Tasks', items: (props.tasks || []) },
      { id: 'files', label: 'Files', items: (props.files || []) }];
    var idx = -1, hi = props.hi || 0;
    var th = useThumb('[aria-selected="true"]', [hi, q]);
    return h('div', { ref: th.ref, className: cx('ex-menu ex-mention-menu', th.has && 'has-thumb', th.ready && 'is-ready'), role: 'listbox', 'aria-label': 'Mention', style: props.inline ? { position: 'relative' } : { bottom: 36, left: 0 } },
      h('span', { className: 'ex-thumb ex-list-thumb', 'aria-hidden': 'true', style: th.style }),
      h('div', { className: 'ex-mm-q' }, h('span', { className: 'ex-mm-at' }, '@'), h('span', { className: 'ex-mono' }, q), h('span', { className: 'ex-caret', 'aria-hidden': 'true' })),
      groups.map(function (g) {
        if (!g.items.length) return null;
        return h(F, { key: g.id }, h('div', { className: 'ex-overline ex-menu-label' }, g.label),
          g.items.map(function (it, i) {
            idx++;
            var sel = idx === hi;
            return h('div', { key: i, role: 'option', 'aria-selected': String(sel), className: 'ex-menu-item ex-mm-item' },
              g.id === 'sessions' ? h(StatusGlyph, { status: it.status || 'done', size: 13 }) : g.id === 'tasks' ? h(StageGlyph, { stage: it.stage || 'active', size: 13 }) : h(Icon, { name: 'file', size: 13 }),
              h('span', { className: cx('ex-grow', g.id === 'files' && 'ex-mono') }, h(Highlight, { text: it.label, query: q })),
              it.meta ? h('span', { className: 'ex-combo-meta' }, it.meta) : null,
              sel ? h(Kbd, null, '↵') : null);
          }));
      }),
      h('div', { className: 'ex-mm-foot' }, h(Kbd, null, '↑↓'), ' choose', h('span', { className: 'ex-keys-sep' }), h(Kbd, null, '↵'), ' insert', h('span', { className: 'ex-keys-sep' }), h(Kbd, null, '⇥'), ' next group'));
  }

  /* Toast: brief confirmation with Undo; a thin bar shows the time left and pauses on hover. */
  function Toast(props) {
    return h('div', { className: cx('ex-toast', props.tone && 'is-' + props.tone), role: 'status', style: { '--ex-toast-time': (props.duration || 5000) + 'ms' } },
      props.tone === 'danger' ? h(StatusGlyph, { status: 'failed', size: 14 }) : h(StatusGlyph, { status: props.glyph || 'done', size: 14 }),
      h('span', { className: 'ex-toast-text' }, h('span', null, props.title), props.detail ? h('span', { className: 'ex-toast-detail' }, props.detail) : null),
      props.action ? h('button', { type: 'button', className: 'ex-toast-act' }, props.action) : null,
      h('button', { type: 'button', className: 'ex-toast-x', 'aria-label': 'Dismiss' }, h(Icon, { name: 'x', size: 12 })),
      props.duration !== 0 ? h('span', { className: 'ex-toast-bar', 'aria-hidden': 'true' }) : null);
  }

  /* Tooltip bubble: name plus shortcut. Shown after 400ms, then instantly for 600ms while you move along a toolbar. */
  function Tooltip(props) {
    return h('span', { className: cx('ex-tip', 'is-' + (props.side || 'top')), role: 'tooltip' }, props.label, props.kbd ? h('span', { className: 'ex-tip-kbd' }, props.kbd) : null);
  }

  /* Skeletons: only after 150ms of waiting, shimmering, replaced in place. */
  function Skeleton(props) {
    var v = props.variant || 'rows';
    var n = props.count || 3;
    if (v === 'message') return h('div', { className: 'ex-skel-msg', 'aria-busy': 'true', 'aria-label': 'Loading' },
      h('span', { className: 'ex-skel', style: { width: 120, height: 12 } }),
      h('span', { className: 'ex-skel', style: { width: '92%', height: 12 } }), h('span', { className: 'ex-skel', style: { width: '78%', height: 12 } }), h('span', { className: 'ex-skel', style: { width: '54%', height: 12 } }));
    return h('div', { className: 'ex-skel-rows', 'aria-busy': 'true', 'aria-label': 'Loading' }, Array.apply(null, Array(n)).map(function (_, i) {
      return h('div', { key: i, className: 'ex-skel-row' }, h('span', { className: 'ex-skel', style: { width: 14, height: 14, borderRadius: 7 } }), h('span', { className: 'ex-skel', style: { width: (52 + (i * 17) % 38) + '%', height: 10 } }));
    }));
  }

  /* How full the agent's context is: a ring that turns attention near the limit. */
  function ContextMeter(props) {
    var u = Math.max(0, Math.min(1, props.used || 0));
    var tone = u >= 0.9 ? 'danger' : u >= 0.75 ? 'attention' : 'ok';
    var r = 5.25, c = 2 * Math.PI * r;
    return h('span', { className: cx('ex-ctx', 'is-' + tone, props.compact && 'is-compact'), title: 'Context ' + Math.round(u * 100) + '% used' + (props.tokens ? ' · ' + props.tokens : '') },
      h('svg', { width: 14, height: 14, viewBox: '0 0 14 14', 'aria-hidden': 'true' },
        h('circle', { cx: 7, cy: 7, r: r, fill: 'none', stroke: 'currentColor', strokeOpacity: 0.22, strokeWidth: 1.75 }),
        h('circle', { className: 'ex-ctx-arc', cx: 7, cy: 7, r: r, fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeDasharray: c, strokeDashoffset: c * (1 - u), transform: 'rotate(-90 7 7)' })),
      props.compact ? null : h('span', { className: 'ex-ctx-pct' }, Math.round(u * 100) + '%'));
  }

  /* Pill that appears when new messages arrive below what you're reading. */
  function NewMessagesPill(props) {
    return h('button', { type: 'button', className: 'ex-newmsg' }, h(Icon, { name: 'arrow-down', size: 13 }), (props.count || 1) + (props.count === 1 ? ' new message' : ' new messages'));
  }

  /* Progress: determinate (value 0–1) or indeterminate (no value). */
  function ProgressLine(props) {
    var det = props.value != null;
    return h('span', { className: cx('ex-progress', !det && 'is-indeterminate'), role: 'progressbar', 'aria-valuenow': det ? Math.round(props.value * 100) : undefined, 'aria-valuemin': 0, 'aria-valuemax': 100 },
      h('span', { className: 'ex-progress-fill', style: det ? { transform: 'scaleX(' + props.value + ')' } : undefined }));
  }

  /* ════ Agent turns: the work, condensed ════ */

  /* Height that animates to and from auto (CSS grid 1fr ↔ 0fr). Content stays mounted. */
  function Fold(props) {
    /* Clipped only while it moves or is closed: once open and settled, focus rings and hover fills can spill out. */
    var open = !!props.open;
    var _s = React.useState(open); var settled = _s[0], setSettled = _s[1];
    var was = React.useRef(open);
    if (was.current !== open) { was.current = open; if (settled) setSettled(false); }
    React.useEffect(function () {
      if (!open || settled) return;
      var t = setTimeout(function () { setSettled(true); }, 420);
      return function () { clearTimeout(t); };
    }, [open, settled]);
    return h('div', { className: cx('ex-fold', open ? 'is-open' : 'is-closed', open && settled && 'is-settled', props.className), 'aria-hidden': open ? undefined : 'true', inert: open ? undefined : 'true',
      onTransitionEnd: function (e) { if (e.target === e.currentTarget && open && e.propertyName === 'grid-template-rows') setSettled(true); } }, h('div', { className: 'ex-fold-in' }, props.children));
  }

  var STEP_META = {
    think: { icon: 'bulb', verb: 'Thought' }, read: { icon: 'file', verb: 'Read' }, search: { icon: 'search', verb: 'Searched' },
    list: { icon: 'search', verb: 'Listed' }, edit: { icon: 'changes', verb: 'Edited' }, create: { icon: 'plus', verb: 'Created' },
    run: { icon: 'terminal', verb: 'Ran' }, test: { icon: 'terminal', verb: 'Tested' }, tool: { icon: 'plug', verb: 'Used' },
    web: { icon: 'globe', verb: 'Opened' }, ask: { icon: 'question', verb: 'You answered' }, note: { icon: null, verb: '' } };
  var GATHER = { read: 1, search: 1, list: 1, think: 1 };

  function fmtDur(sec) {
    sec = Math.max(0, Math.round(sec || 0));
    if (sec < 60) return sec + 's';
    var m = Math.floor(sec / 60), s = sec % 60;
    if (m < 60) return m + 'm' + (s ? ' ' + s + 's' : '');
    return Math.floor(m / 60) + 'h ' + (m % 60) + 'm';
  }
  /* Consecutive look-around steps (reads, searches, thinking) collapse into one row. */
  function groupSteps(steps) {
    var out = [], run = [];
    function flush() {
      if (run.length >= 2) {
        var c = {}; run.forEach(function (s) { c[s.kind] = (c[s.kind] || 0) + 1; });
        var parts = [];
        if (c.think) parts.push('thought');
        if (c.read) parts.push('read ' + c.read + (c.read === 1 ? ' file' : ' files'));
        if (c.search) parts.push('searched ' + c.search + (c.search === 1 ? ' time' : ' times'));
        if (c.list) parts.push('listed ' + c.list + (c.list === 1 ? ' folder' : ' folders'));
        var label = parts.join(', '); label = label.charAt(0).toUpperCase() + label.slice(1);
        out.push({ kind: 'group', label: label, items: run.slice(), status: run.some(function (s) { return s.status === 'running'; }) ? 'running' : 'done' });
      } else out.push.apply(out, run);
      run = [];
    }
    (steps || []).forEach(function (s) { if (GATHER[s.kind] && !(s.kind === 'think' && (s.text || s.title))) run.push(s); else { flush(); out.push(s); } });
    flush();
    return out;
  }
  /* A failure is history once the agent got past it: a later success of the same kind supersedes it, and a
     failure the agent caused on purpose (reproducing a bug) is marked expected. Only what still fails stays loud. */
  function settle(steps) {
    steps = steps || [];
    return steps.map(function (s, i) {
      if (s.status !== 'failed' || s.recovered || s.expected) return s;
      if (s.kind === 'run' || s.kind === 'test') {
        for (var j = i + 1; j < steps.length; j++) if ((steps[j].kind === 'run' || steps[j].kind === 'test') && steps[j].status !== 'failed' && steps[j].status !== 'running') return Object.assign({}, s, { recovered: 'passed later' });
      }
      return s;
    });
  }
  /* What a finished turn did, in a few facts, most important first. */
  function summarize(steps) {
    var files = {}, add = 0, del = 0, runs = 0, reads = 0, fails = 0, test = null, asks = 0;
    steps = settle(steps);
    (steps || []).forEach(function (s) {
      if (s.kind === 'edit' || s.kind === 'create') { files[s.detail] = 1; add += (s.diff && s.diff.add) || 0; del += (s.diff && s.diff.del) || 0; }
      if (s.kind === 'run') runs++;
      if (s.kind === 'read') reads++;
      if (s.kind === 'test') test = s;
      if (s.kind === 'ask') asks++;
      if (s.status === 'failed' && !s.recovered && !s.expected) fails++;
    });
    var facts = [];
    if (fails) facts.push({ tone: 'danger', icon: 'x', text: fails + (fails === 1 ? ' step failed' : ' steps failed') });
    var nf = Object.keys(files).length;
    if (nf) facts.push({ icon: 'changes', text: 'Edited ' + nf + (nf === 1 ? ' file' : ' files'), diff: { add: add, del: del } });
    if (test) facts.push({ tone: test.status === 'failed' && !test.recovered ? 'danger' : 'ok', icon: test.status === 'failed' && !test.recovered ? 'x' : 'check', text: test.result || test.meta || 'Tests' });
    if (runs) facts.push({ icon: 'terminal', text: 'Ran ' + runs + (runs === 1 ? ' command' : ' commands') });
    if (reads && facts.length < 4) facts.push({ icon: 'file', text: 'Read ' + reads + (reads === 1 ? ' file' : ' files') });
    if (asks && facts.length < 4) facts.push({ icon: 'question', text: asks === 1 ? '1 decision' : asks + ' decisions' });
    return facts.slice(0, 4);
  }

  function Fact(props) {
    var f = props.fact;
    return h('span', { className: cx('ex-fact', f.tone && 'is-' + f.tone), style: { '--i': props.index || 0 } },
      h(Icon, { name: f.icon, size: 12 }), f.text, f.diff ? h(Diff, f.diff) : null);
  }

  /* Interim messages: what the agent says while it works (kind 'say'; 'note' is the older name). */
  function isSay(s) { return s && (s.kind === 'say' || s.kind === 'note'); }

  function TimelineStep(props) {
    var s = props.step;
    var _o = React.useState(!!s.open); var open = _o[0], setOpen = _o[1];
    if (isSay(s)) return h('div', { className: 'ex-tl-say', style: { '--i': props.index } }, s.text);
    var meta = STEP_META[s.kind] || STEP_META.tool;
    var isGroup = s.kind === 'group', isThink = s.kind === 'think';
    var expandable = isGroup || !!s.output || !!s.hunk || (isThink && !!s.text);
    var st = s.status || 'done';
    var calm = s.recovered || s.expected;
    return h('div', { className: cx('ex-tl-step', 'is-' + st, isThink && 'is-think', s.recovered && 'is-recovered', s.expected && 'is-expected', open && 'is-open'), style: { '--i': props.index } },
      h('span', { className: 'ex-tl-dot', 'aria-hidden': 'true' }, st === 'running' ? h(StatusGlyph, { status: 'running', size: 12 }) : st === 'failed' && !calm ? h(StatusGlyph, { status: 'failed', size: 12 }) : h(Icon, { name: isGroup ? 'search' : meta.icon || 'check', size: 12 })),
      h('div', { className: 'ex-tl-body' },
        h('button', { type: 'button', className: 'ex-tl-head', onClick: expandable ? function () { setOpen(!open); } : undefined, 'aria-expanded': expandable ? String(open) : undefined, tabIndex: expandable ? 0 : -1 },
          h('span', { className: 'ex-tl-verb' }, isGroup ? s.label : (s.verb || meta.verb)),
          isThink && s.title ? h('span', { className: 'ex-tl-title' }, s.title) : null,
          !isGroup && !isThink && s.detail ? h('span', { className: 'ex-mono ex-tl-detail' }, s.detail) : null,
          s.diff ? h(Diff, s.diff) : null,
          s.recovered ? h('span', { className: 'ex-tl-tag' }, s.recovered === true ? 'fixed' : s.recovered) : s.expected ? h('span', { className: 'ex-tl-tag' }, s.expected === true ? 'reproduced' : s.expected) : null,
          h('span', { style: { flex: 1 } }),
          s.meta ? h('span', { className: cx('ex-tl-meta', st === 'failed' && !calm && 'is-bad') }, s.meta) : null,
          s.dur ? h('span', { className: 'ex-tl-dur' }, s.dur) : null,
          expandable ? h(Icon, { name: 'chevron-right', size: 12, className: 'ex-tl-chev' }) : null),
        expandable ? h(Fold, { open: open },
          isGroup ? h('div', { className: 'ex-tl-files' }, s.items.map(function (it, i) { return h('span', { key: i, className: 'ex-tl-file' }, h(Icon, { name: (STEP_META[it.kind] || {}).icon || 'file', size: 11 }), h('span', { className: 'ex-mono' }, it.detail || (STEP_META[it.kind] || {}).verb)); }))
            : isThink ? h('div', { className: 'ex-tl-think' }, s.text)
            : s.hunk ? h('div', { className: 'ex-hunk ex-tl-out' }, s.hunk.map(function (l, i) { return h('div', { key: i, className: l[0] === '+' ? 'add' : l[0] === '-' ? 'del' : null }, h('i', null, l[0] === '+' || l[0] === '-' ? (l[0] === '-' ? '−' : '+') : ''), l.slice(1)); }))
            : h('pre', { className: 'ex-tl-out ex-step2-out' }, s.output)) : null));
  }

  /* The thread of a turn: what the agent said, and the steps under it.
     Live, it keeps the latest thing the agent said plus the last few steps; the rest folds into “N earlier steps”. */
  function WorkTimeline(props) {
    var rows = groupSteps(settle((props.steps || []).map(function (st, i) { return Object.assign({}, st, { _i: i }); })));
    var max = props.maxVisible || 4;
    var _a = React.useState(false); var all = _a[0], setAll = _a[1];
    var parts = rows.map(function (s, i) { return { s: s, i: i }; });
    if (props.live && !all) {
      var lastSay = -1; rows.forEach(function (s, i) { if (isSay(s)) lastSay = i; });
      var tail = parts.slice(lastSay + 1), keepTail = tail.slice(-max);
      var head = lastSay >= 0 ? parts.slice(0, lastSay) : parts.slice(0, parts.length - keepTail.length);
      var mid = lastSay >= 0 ? tail.slice(0, tail.length - keepTail.length) : [];
      /* folding a single row saves nothing: show it */
      function fold(list, k) { return list.length >= 2 ? [{ more: list.length, k: k }] : list; }
      parts = fold(head, 'b').concat(lastSay >= 0 ? [{ s: rows[lastSay], i: lastSay }] : [], fold(mid, 'm'), keepTail);
    }
    var n = 0;
    return h(MotionList, { as: 'ol', itemAs: 'li', className: cx('ex-timeline', props.live && 'is-live'), items: parts.map(function (p) {
      if (p.more) return { key: 'more-' + p.k, node: h('div', { className: 'ex-tl-step is-more' }, h('span', { className: 'ex-tl-dot', 'aria-hidden': 'true' }, h(Icon, { name: 'more', size: 12 })),
        h('button', { type: 'button', className: 'ex-tl-head ex-tl-more', onClick: function () { setAll(true); } }, h(Ticker, { value: p.more }), p.more === 1 ? ' earlier step' : ' earlier steps')) };
      var k = p.s.kind === 'group' ? p.s.items[0]._i : p.s._i;
      return { key: 's' + k, node: h(TimelineStep, { step: p.s, index: n++ }) };
    }) });
  }

  /* What the agent is doing right now: one line that rolls to the next action.
     While it thinks, the line also shows the last lines of its reasoning, fading at the top. */
  function NowLine(props) {
    var meta = STEP_META[props.kind] || {};
    var think = props.kind === 'think' && !!props.text;
    var lastText = React.useRef(props.text); if (think) lastText.current = props.text;
    return h('div', { className: cx('ex-now', think && 'is-think'), 'aria-live': 'polite' },
      h('div', { className: 'ex-now-row' },
        h(StatusGlyph, { status: 'running', size: 14 }),
        h('span', { key: (props.verb || '') + (props.detail || '') + (props.title || ''), className: 'ex-now-text' },
          h('span', { className: 'ex-now-verb' }, props.verb || meta.verb || 'Working'),
          props.title ? h('span', { className: 'ex-now-title' }, props.title) : props.detail ? h('span', { className: 'ex-mono ex-now-detail' }, props.detail) : null),
        h('span', { style: { flex: 1 } }),
        props.meta ? h('span', { className: 'ex-now-meta' }, props.meta) : null,
        props.elapsed != null ? h('span', { className: 'ex-now-time' }, fmtDur(props.elapsed)) : null),
      lastText.current ? h(Fold, { open: think, className: 'ex-now-think-fold' }, h('div', { className: 'ex-now-think' }, props.stream && think ? h(StreamText, { demo: true, text: props.text, speed: 45, streaming: false }) : h('p', { className: 'ex-stream' }, lastText.current))) : null,
      props.progress != null ? h('span', { className: 'ex-now-bar' }, h(ProgressLine, { value: props.progress })) : null);
  }

  /* A file the turn changed: name first, folder muted, diff; opens it in Changes. */
  function FileChip(props) {
    var parts = String(props.path || '').split('/'); var name = parts.pop();
    return h('button', { type: 'button', className: 'ex-filechip', style: { '--i': props.index || 0 }, title: props.path },
      h(Icon, { name: props.status === 'A' ? 'plus' : 'file', size: 12 }), h('span', { className: 'ex-filechip-name' }, name),
      parts.length ? h('span', { className: 'ex-filechip-dir' }, parts.join('/')) : null, h(Diff, { add: props.add || 0, del: props.del || 0 }));
  }
  /* What a finished turn left behind: files to review, and the one next action. */
  function OutcomeBar(props) {
    var files = props.files || [];
    var max = props.max || 3;
    return h('div', { className: 'ex-outcome' },
      files.slice(0, max).map(function (f, i) { return h(FileChip, Object.assign({ key: f.path, index: i }, f)); }),
      files.length > max ? h('button', { type: 'button', className: 'ex-filechip is-more', style: { '--i': max } }, '+' + (files.length - max) + ' more') : null,
      h('span', { style: { flex: 1 } }),
      props.action ? h(Button, { variant: 'ghost', size: 'sm', icon: props.actionIcon || 'changes' }, props.action) : null);
  }



  /* One agent turn, in the chat's reply column: the agent's mark in a narrow gutter, the work line, the answer.
     Live: “Working” with a thread of what it says and does, the current action, the reply streaming; a line runs
     down the gutter beside the thread. Finished: “Worked 4m 12s”; its facts appear on hover, failures always show. */
  var NOW_VERB = { run: 'Running', test: 'Testing', read: 'Reading', search: 'Searching', list: 'Listing', edit: 'Editing', create: 'Creating', tool: 'Using', web: 'Opening', think: 'Thinking' };
  function Turn(props) {
    var status = props.status || 'done';
    var live = status === 'live';
    var steps = props.steps || [];
    var _o = React.useState(!!props.open); var open = _o[0], setOpen = _o[1];
    var prev = React.useRef(status);
    var _f = React.useState(false); var folding = _f[0], setFolding = _f[1];
    useLayout(function () {
      if (prev.current === 'live' && status !== 'live') { setFolding(true); setOpen(false); var t = setTimeout(function () { setFolding(false); }, 900); prev.current = status; return function () { clearTimeout(t); }; }
      prev.current = status;
    }, [status]);
    /* the render that sees the turn finish already counts as folding, so the thread never flashes its full list */
    var foldingNow = folding || (prev.current === 'live' && !live);
    var facts = live ? [] : summarize(steps);
    var nowStep = live ? steps.filter(function (s) { return s.status === 'running'; }).slice(-1)[0] : null;
    var now = useHold(nowStep, 700);
    var doneSteps = live ? steps.filter(function (s) { return s.status !== 'running'; }) : steps;
    var count = doneSteps.filter(function (s) { return !isSay(s); }).length;
    var thread = live || open;
    var label = live ? 'Working' : status === 'stopped' ? 'Stopped after ' + fmtDur(props.duration) : status === 'failed' ? 'Failed after ' + fmtDur(props.duration) : 'Worked ' + fmtDur(props.duration);
    var outcome = props.outcome || {}, files = outcome.files || [], max = outcome.max || 3;
    var who = (props.author || 'Opus 5.5') + (props.time ? ' · ' + props.time : '');
    var workKids = live ? [
        h(StatusGlyph, { key: 'g', status: 'running', size: 13 }),
        h('span', { key: 'w', className: 'ex-work-label ex-shimmer-text' }, label),
        props.elapsed != null ? h('span', { key: 't', className: 'ex-work-time' }, fmtDur(props.elapsed)) : null,
        count ? h('span', { key: 'c', className: 'ex-work-count' }, '· ', h(Ticker, { value: count }), count === 1 ? ' step' : ' steps') : null,
        props.onStop !== false ? h('button', { key: 's', type: 'button', className: 'ex-work-stop', title: 'Stop  ⌘.', onClick: props.onStop }, h(Icon, { name: 'stop', size: 10 }), 'Stop') : null]
      : [
        h('span', { key: 'd', className: cx('ex-work-label', status === 'failed' && 'is-bad') }, label),
        h('span', { key: 'f', className: 'ex-work-facts', ref: function (el) { if (el) requestAnimationFrame(function () { el.classList.toggle('is-clipped', el.scrollWidth > el.clientWidth + 1); }); } },
          facts.map(function (f, i) { return h('span', { key: i, className: cx('ex-work-item', f.tone === 'danger' && 'is-pinned'), style: { '--i': i } }, h(Fact, { fact: f, index: i })); })),
        h('span', { key: 'chev', className: 'ex-work-item ex-work-chevitem', style: { '--i': facts.length } }, h(Icon, { name: 'chevron-right', size: 12, className: 'ex-work-chev' }))];
    var ns = now.value;
    return h('section', { className: cx('ex-turn', 'is-' + status, foldingNow && 'is-folding', thread && steps.length && 'is-thread'), 'aria-label': 'Agent turn' }, h(AutoHeight, { innerClassName: 'ex-turn-grid' },
      h('div', { className: 'ex-turn-gutter', 'aria-hidden': 'true' },
        h('span', { className: cx('ex-turn-avatar', live && 'is-live'), title: who }, h(AgentMark, { mark: props.mark || 'Cl' })),
        h('span', { className: 'ex-turn-line' })),
      h('div', { className: 'ex-turn-body' },
        steps.length ? (live
          ? h('div', { className: 'ex-work' }, workKids)
          : h('button', { type: 'button', className: 'ex-work', 'aria-expanded': String(open), onClick: function () { setOpen(!open); } }, workKids)) : null,
        steps.length ? h(Fold, { open: thread, className: 'ex-thread-fold' }, h(WorkTimeline, { steps: doneSteps, live: live || foldingNow, maxVisible: props.maxVisible })) : null,
        ns ? h(Fold, { open: live && now.on, className: 'ex-now-fold' }, h(NowLine, { kind: ns.kind, verb: ns.verb || NOW_VERB[ns.kind], detail: ns.detail, title: ns.title, text: ns.text, stream: ns.stream, meta: ns.meta, elapsed: ns.elapsed, progress: ns.progress })) : null,
        props.error ? h('div', { className: 'ex-turn-error' }, h(StatusGlyph, { status: 'failed', size: 14 }), h('span', { className: 'ex-grow' }, props.error), h(Button, { variant: 'secondary', size: 'sm', icon: 'reset' }, 'Retry')) : null,
        status === 'stopped' ? h('div', { className: 'ex-turn-stopped' }, h('span', { className: 'ex-grow' }, 'You stopped this turn. Nothing after the last step ran.'), h(Button, { variant: 'secondary', size: 'sm', icon: 'arrow-up' }, 'Continue')) : null,
        props.children ? h('div', { className: 'ex-turn-answer' }, props.children) : null,
        h(Fold, { open: !live, className: 'ex-turn-foot-fold' }, h('div', { className: 'ex-turn-foot' },
          h('span', { className: 'ex-turn-files' },
            files.slice(0, max).map(function (f, i) { return h(FileChip, Object.assign({ key: f.path, index: i }, f)); }),
            files.length > max ? h('button', { type: 'button', className: 'ex-filechip is-more', style: { '--i': max } }, '+' + (files.length - max)) : null),
          h(TurnActs),
          files.length || outcome.action ? h(Button, { variant: 'ghost', size: 'sm', icon: outcome.actionIcon || 'changes' }, outcome.action || 'Review') : null)))));
  }

  /* A slim map of the session's turns at the chat's edge: jump to any; changes and needs-you stand out. */
  function TurnNav(props) {
    var turns = props.turns || [];
    return h('nav', { className: 'ex-turnnav', 'aria-label': 'Turns' }, turns.map(function (t, i) {
      return h('button', { key: i, type: 'button', className: cx('ex-turnnav-item', t.id === props.active && 'is-active', t.state && 'is-' + t.state), 'aria-label': t.label, 'aria-current': t.id === props.active ? 'true' : undefined },
        h('span', { className: 'ex-turnnav-bar' }), h('span', { className: 'ex-turnnav-tip' }, h('span', { className: 'ex-turnnav-label' }, t.label), t.meta ? h('span', { className: 'ex-turnnav-meta' }, t.meta) : null));
    }));
  }


  /* ═════ Machines: where Elevenex runs ═════
     One machine per window. A window is Home (no machine), getting ready (connecting, installing, updating), or on a machine.
     Home connects to nothing; opening a machine connects to it; a connection lives while a window uses it. */
  var MACHINE_ICON = { local: 'laptop', ssh: 'server', peer: 'peer' };
  function machineLive(m) { return m.conn === 'live' || m.conn === 'kept'; }

  /* The title-bar island: one pill that names the window's machine and grows to say something, then shrinks back. */
  function TitleIsland(props) {
    var outer = React.useRef(null), inner = React.useRef(null);
    useLayout(function () { var o = outer.current, i = inner.current; if (!o || !i) return; o.style.width = i.offsetWidth + 'px'; o.style.height = i.offsetHeight + 'px'; });
    var tone = props.tone || 'rest';
    return h(props.onClick ? 'button' : 'div', { ref: outer, type: props.onClick ? 'button' : undefined, onClick: props.onClick, 'aria-expanded': props.onClick ? String(!!props.open) : undefined,
        className: cx('ex-island', 'is-' + tone, props.tall && 'is-tall', props.open && 'is-open', props.className), role: props.onClick ? undefined : 'status', 'aria-live': 'polite' },
      h('div', { key: props.contentKey, ref: inner, className: 'ex-island-in' }, props.children),
      props.progress != null ? h('span', { className: 'ex-island-p', style: { transform: 'scaleX(' + Math.max(0, Math.min(1, props.progress)) + ')' } }) : null);
  }
  /* The window's own title bar: the window controls on the left and the island centered. Window chrome, not an app bar: no actions, no tabs. */
  function TitleBar(props) {
    return h('div', { className: cx('ex-titlebar', props.className) }, h('span', { className: 'ex-titlebar-lights', 'aria-hidden': 'true' }, h('i'), h('i'), h('i')),
      h('div', { className: 'ex-titlebar-island' }, props.children));
  }
  /* The island's resting content: color dot, kind icon, name, and a mark per connected computer. */
  function IslandName(props) {
    var m = props.machine || {};
    return h(F, null, h('span', { className: 'ex-island-dot', style: { background: m.color || 'var(--accent)' } }), h(Icon, { name: MACHINE_ICON[m.kind] || 'laptop', size: 13 }), h('span', { className: 'ex-island-name' }, m.name),
      props.guests ? h('span', { className: 'ex-island-mark' }, h(Icon, { name: 'peer', size: 11 }), props.guests) : null);
  }
  /* A moment the island grows for (someone connected, back online): an icon, two lines, one action. Shrinks back on its own. */
  function IslandEvent(props) {
    return h('span', { className: 'ex-island-ev' }, h('span', { className: 'ex-island-ev-i' }, h(Icon, { name: props.icon || 'peer', size: 15 })),
      h('span', null, h('span', { className: 'ex-island-ev-t' }, props.title), props.sub ? h('span', { className: 'ex-island-ev-s' }, props.sub) : null),
      props.action ? h('button', { type: 'button', className: 'ex-island-ev-a ex-mpanel-chip', onClick: props.onAction }, props.action) : null);
  }
  /* The island open: the machine (and changing it) on top, its connection and who else is on it, other windows at the foot. */
  function MachinePanel(props) {
    var m = props.machine || {}, guests = props.guests || [], hi = props.highlight;
    return h('div', { className: 'ex-mpanel' },
      h('div', { className: 'ex-mpanel-head' }, h('span', { className: 'ex-mpanel-ic' }, h(Icon, { name: MACHINE_ICON[m.kind] || 'laptop', size: 16 }), h('span', { className: 'ex-island-dot', style: { background: m.color || 'var(--accent)' } })),
        h('span', { className: 'ex-mgrow ex-mpanel-id' }, h('span', { className: 'ex-mpanel-name' }, m.name), h('span', { className: 'ex-mpanel-sub' }, m.address || m.sub)),
        h('button', { type: 'button', className: cx('ex-mpanel-chip', hi === 'change' && 'is-hi'), onClick: props.onChange }, 'Change')),
      m.kind === 'ssh' ? h('div', { className: 'ex-mpanel-sec' }, h('div', { className: 'ex-mpanel-label' }, 'Connection'),
        h('div', { className: 'ex-mpanel-row' }, h('span', { className: 'ex-mpanel-av' }, h(Icon, { name: 'server', size: 13 })),
          h('span', { className: 'ex-mgrow ex-mpanel-id' }, h('span', { className: 'ex-mpanel-strong' }, 'Connected over SSH'), h('span', { className: 'ex-mpanel-sub' }, 'Shared by its windows; drops when none uses it')),
          h('button', { type: 'button', className: 'ex-mpanel-chip is-quiet', onClick: props.onDisconnect }, 'Disconnect'))) : null,
      guests.length ? h('div', { className: 'ex-mpanel-sec' }, h('div', { className: 'ex-mpanel-label' }, 'Also using ' + (m.kind === 'local' ? 'this Mac' : m.name)),
        guests.map(function (g) {
          return h('div', { key: g.name, className: 'ex-mpanel-row' }, h('span', { className: 'ex-mpanel-av is-guest' }, h(Icon, { name: 'peer', size: 13 })),
            h('span', { className: 'ex-mgrow ex-mpanel-id' }, h('span', { className: 'ex-mpanel-strong' }, g.name), h('span', { className: 'ex-mpanel-sub' }, 'Connected since ' + g.since)),
            h('button', { type: 'button', className: 'ex-mpanel-chip is-quiet', onClick: function () { props.onDisconnectGuest && props.onDisconnectGuest(g); } }, 'Disconnect'));
        })) : null,
      h('button', { type: 'button', className: cx('ex-mpanel-new', hi === 'new' && 'is-hi'), onClick: props.onNewWindow }, h(Icon, { name: 'window', size: 14 }), h('span', { className: 'ex-mpanel-strong' }, 'New window'), h('span', { className: 'ex-mpanel-sub' }, 'on any machine'), h('span', { className: 'ex-mgrow' }), h('kbd', { className: 'ex-kbd' }, '⇧⌘N')));
  }

  /* A machine on Home. Connected ones say what's happening now; the others say what we knew last, dated. */
  function MachineCard(props) {
    var m = props.machine, live = machineLive(m);
    var dot = m.update ? 'is-info' : live ? 'is-on' : m.conn === 'fail' ? 'is-fail' : 'is-idle';
    var tag = m.update ? h('span', { className: 'ex-mcard-tag is-info' }, 'Update') : m.windows ? h('span', { className: 'ex-mcard-tag' }, m.windows + (m.windows > 1 ? ' windows' : ' window')) : m.conn === 'kept' ? h('span', { className: 'ex-mcard-tag' }, 'until you pick') : null;
    return h('button', { type: 'button', 'data-machine': m.id, onClick: function () { props.onOpen && props.onOpen(m); },
        className: cx('ex-mcard', props.highlighted && 'is-hi', props.pressed && 'is-press', !live && 'is-idle'), style: { '--mc': m.color || 'var(--ink)' } },
      h('span', { className: 'ex-mcard-top' }, h('span', { className: 'ex-mcard-ic' }, h(Icon, { name: MACHINE_ICON[m.kind] || 'laptop', size: 15 }), h('span', { className: cx('ex-mpres', dot) })),
        h('span', { className: 'ex-mgrow' }), tag, props.highlighted ? h('kbd', { className: 'ex-kbd' }, '↵') : null),
      h('span', { className: 'ex-mcard-name' }, m.name),
      h('span', { className: 'ex-mcard-line' }, m.update ? 'Had ' + m.update + ' · updates when opened' : live ? m.status : m.last));
  }
  /* Home: what a window shows before it has a machine. */
  function MachineHome(props) {
    var ms = props.machines || [], on = ms.filter(machineLive), off = ms.filter(function (m) { return !machineLive(m); });
    function grid(list) { return h('div', { className: 'ex-mhome-grid' }, list.map(function (m) { return h(MachineCard, { key: m.id, machine: m, highlighted: props.highlighted === m.id, pressed: props.pressed === m.id, onOpen: props.onOpen }); })); }
    return h('div', { className: 'ex-mhome' }, h('div', { className: 'ex-mhome-col' },
      h('div', { className: 'ex-mhome-head' }, h('div', { className: 'ex-mgrow' }, h('div', { className: 'ex-mhome-title' }, props.title || 'Machines'), h('div', { className: 'ex-mhome-sub' }, props.subtitle || 'Pick where this window runs')),
        h('span', { className: 'ex-mhome-search' }, h(Icon, { name: 'search', size: 13 }), h('span', { className: 'ex-mgrow' }, 'Find a machine'), h('kbd', { className: 'ex-kbd' }, '⌘O'))),
      on.length ? h(F, null, h('div', { className: 'ex-mhome-label' }, 'Connected'), grid(on)) : null,
      off.length ? h(F, null, h('div', { className: 'ex-mhome-label' }, 'Not connected', h('span', null, 'opening one connects to it')), grid(off)) : null,
      h('div', { className: 'ex-mhome-foot' }, h(Button, { size: 'sm', variant: 'ghost', icon: 'plus', onClick: props.onAdd }, 'Add a server'), h(Button, { size: 'sm', variant: 'ghost', onClick: props.onPair }, 'Pair a computer'))));
  }

  /* Opening a machine launches it like an app on a phone: its card becomes a box that grows to the window, the card's face
     fades as it grows, and the machine's view scales up inside the box (cover-fit, never stretched). Closing runs it backwards. */
  var LAUNCH_EASE = 'cubic-bezier(0.32, 0.72, 0, 1)';
  function runLaunch(body, pane, zoom, host, home, card, opening) {
    var l = 0, t = 0, el = card; while (el && el !== body) { l += el.offsetLeft; t += el.offsetTop; el = el.offsetParent; }
    t -= home.scrollTop; l -= home.scrollLeft;
    var cw = card.offsetWidth, ch = card.offsetHeight, W = body.offsetWidth, H = body.offsetHeight, R = parseFloat(getComputedStyle(card).borderTopLeftRadius) || 14;
    home.style.transformOrigin = (l + cw / 2) + 'px ' + (t + ch / 2 + home.scrollTop) + 'px';
    var cardBg = getComputedStyle(card).backgroundColor, appBg = getComputedStyle(pane).backgroundColor, N = 14, kp = [], kz = [], kf = [];
    for (var i = 0; i <= N; i++) {
      var q = i / N, p = opening ? q : 1 - q, x = l * (1 - p), y = t * (1 - p), w = cw + (W - cw) * p, hh = ch + (H - ch) * p;
      var sc = Math.max(w / W, hh / H), sf = Math.min(w / cw, hh / ch);
      kp.push({ offset: q, clipPath: 'inset(' + y + 'px ' + (W - x - w) + 'px ' + (H - y - hh) + 'px ' + x + 'px round ' + (R * sf * Math.min(1, 2 * (1 - p)) + 0.01) + 'px)', backgroundColor: p < 0.35 ? cardBg : appBg, opacity: (!opening && i === N) ? 0 : 1 });
      kz.push({ offset: q, transform: 'translate(' + (x + w / 2 - W * sc / 2) + 'px,' + (y + hh / 2 - H * sc / 2) + 'px) scale(' + sc + ')', opacity: Math.max(0, Math.min(1, (p - 0.18) / 0.4)) });
      kf.push({ offset: q, transform: 'translate(' + (x - l) + 'px,' + (y - t) + 'px) scale(' + (w / cw) + ',' + (hh / ch) + ')', opacity: Math.max(0, Math.min(1, 1 - (p - 0.12) / 0.38)) });
    }
    var face = card.cloneNode(true); face.classList.remove('is-hi', 'is-press'); face.classList.add('ex-launch-face'); face.removeAttribute('data-machine'); face.setAttribute('tabindex', '-1');
    face.style.left = l + 'px'; face.style.top = t + 'px'; face.style.width = cw + 'px'; face.style.height = ch + 'px';
    host.appendChild(face); card.classList.add('is-launching');
    var opt = { duration: opening ? 560 : 500, easing: LAUNCH_EASE, fill: 'both' };
    var a = [pane.animate(kp, opt), zoom.animate(kz, opt), face.animate(kf, opt)];
    a[0].onfinish = function () { if (face.parentNode) face.parentNode.removeChild(face); card.classList.remove('is-launching'); if (opening) { a[0].cancel(); a[1].cancel(); } };
    return a;
  }
  function MachineLaunch(props) {
    var body = React.useRef(null), pane = React.useRef(null), zoom = React.useRef(null), host = React.useRef(null), homeRef = React.useRef(null), prev = React.useRef(null), anims = React.useRef([]);
    var last = React.useRef(props.machine); if (props.machine) last.current = props.machine;
    var open = !!props.open;
    useLayout(function () {
      var was = prev.current; prev.current = open;
      if (was === null || was === open || !pane.current || !pane.current.animate || reducedMotion()) return;
      anims.current.forEach(function (x) { x.cancel(); }); host.current.innerHTML = '';
      Array.prototype.forEach.call(body.current.querySelectorAll('.is-launching'), function (c) { c.classList.remove('is-launching'); });
      var card = body.current.querySelector('[data-machine="' + last.current + '"]'); if (!card) return;
      anims.current = runLaunch(body.current, pane.current, zoom.current, host.current, homeRef.current, card, open);
    });
    return h('div', { ref: body, className: cx('ex-launch', open ? 'is-in' : 'is-home', props.className), style: props.style },
      h('div', { ref: homeRef, className: 'ex-launch-home', 'aria-hidden': open ? 'true' : null }, props.home),
      h('div', { ref: pane, className: cx('ex-launch-pane', open && 'is-on'), 'aria-hidden': open ? null : 'true' }, h('div', { ref: zoom, className: 'ex-launch-zoom' }, props.children)),
      h('div', { ref: host, className: 'ex-launch-host', 'aria-hidden': 'true' }));
  }

  /* Getting ready: connecting, installing or updating, outside the app. Nothing from the machine shows until it's done. */
  function stagedSteps(t, marks) { return marks.map(function (m, i) { var s0 = i ? marks[i - 1] : 0; return t >= m ? 'done' : t >= s0 ? 'active' : 'todo'; }); }
  function GettingReady(props) {
    return h('div', { className: cx('ex-ready', props.className) },
      h('div', { className: 'ex-ready-head' }, h('span', { className: 'ex-ready-ic' }, h(Icon, { name: props.icon || 'server', size: 18 })),
        h('div', { className: 'ex-mgrow' }, h('div', { className: 'ex-ready-title' }, props.title), props.sub ? h('div', { className: 'ex-ready-sub' }, props.sub) : null)),
      h('ol', { className: 'ex-ready-steps' }, (props.steps || []).map(function (r, i) {
        return h('li', { key: i, className: cx('ex-ready-step', 'is-' + (r.state || 'todo')) },
          h('span', { className: 'ex-ready-g' }, r.state === 'done' ? h(StatusGlyph, { status: 'done', size: 14 }) : r.state === 'active' ? h(StatusGlyph, { status: 'running', size: 14 }) : r.state === 'failed' ? h(StatusGlyph, { status: 'failed', size: 14 }) : h('span', { className: 'ex-ready-dot' })),
          h('span', { className: 'ex-ready-b' }, h('span', { className: 'ex-ready-l' }, r.label, r.detail ? h('span', { className: 'ex-ready-d' }, r.detail) : null),
            r.state === 'active' && r.progress != null ? h(ProgressLine, { value: r.progress }) : null),
          r.meta ? h('span', { className: 'ex-ready-m' }, r.meta) : null);
      })),
      props.actions || props.note ? h('div', { className: 'ex-ready-foot' }, props.actions || null, h('span', { className: 'ex-mgrow' }), props.note ? h('span', { className: 'ex-ready-note' }, props.note) : null) : null);
  }

  /* First run: where should Elevenex run? This Mac is chosen already. */
  var RUN_CHOICES = [
    { id: 'local', icon: 'laptop', title: 'This Mac', tag: 'Recommended', desc: 'Agents run here, next to your files. Nothing to set up.' },
    { id: 'ssh', icon: 'server', title: 'A server, over SSH', desc: 'A dev box or a cloud machine. Elevenex installs itself there and keeps itself up to date.' },
    { id: 'peer', icon: 'peer', title: 'Another computer', desc: 'A Mac or PC running Elevenex. Pair it once by pasting its pairing text.' }];
  function RunChoice(props) {
    var v = props.value || 'local';
    return h('div', { className: 'ex-runchoice', role: 'radiogroup', 'aria-label': 'Where should Elevenex run?' }, RUN_CHOICES.map(function (c) {
      return h('button', { key: c.id, type: 'button', role: 'radio', 'aria-checked': String(v === c.id), className: cx('ex-runchoice-item', v === c.id && 'is-sel'), onClick: function () { props.onChange && props.onChange(c.id); } },
        h('span', { className: 'ex-runchoice-ic' }, h(Icon, { name: c.icon, size: 18 })),
        h('span', { className: 'ex-mgrow' }, h('span', { className: 'ex-runchoice-t' }, c.title, c.tag ? h('span', { className: 'ex-mcard-tag is-accent' }, c.tag) : null), h('span', { className: 'ex-runchoice-d' }, c.desc)),
        v === c.id ? h('kbd', { className: 'ex-kbd' }, '↵') : null);
    }));
  }
  /* Add a server: hosts from ~/.ssh/config come first; once one is picked, its user, port and key show. */
  function HostField(props) {
    var q = props.query || '', hosts = (props.hosts || []).filter(function (x) { return !q || x.name.indexOf(q) === 0 || x.detail.indexOf(q) !== -1; }), picked = props.picked;
    return h('div', { className: 'ex-host' },
      h('label', { className: 'ex-host-input' }, h(Icon, { name: 'server', size: 14 }), h('span', { className: 'ex-mgrow ex-mono' }, picked ? picked.name : q, h('span', { className: 'ex-caret' })),
        picked && picked.fromConfig ? h('span', { className: 'ex-mcard-tag' }, 'from ~/.ssh/config') : null),
      h(Fold, { open: !picked }, h('div', { className: 'ex-host-sugg' }, h('div', { className: 'ex-host-label' }, 'From ~/.ssh/config'),
        hosts.map(function (x, i) { return h('div', { key: x.name, className: cx('ex-host-row', i === 0 && 'is-hi') }, h(Icon, { name: 'server', size: 13 }), h('span', { className: 'ex-mono' }, x.name), h('span', { className: 'ex-mgrow ex-host-d ex-mono' }, x.detail), i === 0 ? h('kbd', { className: 'ex-kbd' }, '↵') : null); }),
        h('div', { className: 'ex-host-row is-other' }, h(Icon, { name: 'plus', size: 13 }), 'Or type ', h('span', { className: 'ex-mono' }, 'user@host:port')))),
      h(Fold, { open: !!picked }, picked ? h('div', { className: 'ex-host-facts' },
        h('div', null, h('span', null, 'User'), h('b', { className: 'ex-mono' }, picked.user)), h('div', null, h('span', null, 'Port'), h('b', { className: 'ex-mono' }, picked.port || 22)),
        h('div', { className: 'is-wide' }, h('span', null, 'Sign in with'), h('b', null, h(Icon, { name: 'key', size: 13 }), ' ', picked.auth || 'SSH agent'))) : null));
  }
  /* The host key, checked once per server and pinned. If it ever changes, Elevenex stops and says so. */
  function HostKeyCheck(props) {
    var changed = !!props.changed;
    return h('div', { className: cx('ex-hostkey', changed && 'is-changed') },
      h('div', { className: 'ex-hostkey-h' }, h(Icon, { name: 'shield', size: 15 }), changed ? h('span', null, 'The host key of ', h('span', { className: 'ex-mono' }, props.host), ' changed') : h('span', null, 'First time connecting to ', h('span', { className: 'ex-mono' }, props.host))),
      h('div', { className: 'ex-hostkey-fp' }, h('span', { className: 'ex-hostkey-k' }, props.type || 'ED25519'), h('span', { className: 'ex-mono' }, props.fingerprint)),
      h('p', { className: 'ex-hostkey-p' }, changed ? 'This can mean the server was reinstalled, or that someone is in the middle. Elevenex won’t connect until you confirm it with whoever runs the server.' : h(F, null, 'To be sure, compare it with ', h('span', { className: 'ex-mono' }, 'ssh-keygen -lf'), ' on the server. We remember it and warn you if it ever changes.')));
  }
  /* Pairing: the computer that hosts gives a long text; the other one pastes it. Once only; after that it opens without asking. */
  function PairingText(props) {
    return h('div', { className: 'ex-pair' },
      h('div', { className: 'ex-pair-text' }, h('span', { className: 'ex-pair-v ex-mono' }, props.text),
        h('span', { className: 'ex-pair-copy' }, h(Button, { size: 'sm', variant: props.copied ? 'secondary' : 'primary', icon: props.copied ? 'check' : 'copy', onClick: props.onCopy }, h('span', { key: props.copied ? 'y' : 'n', className: 'ex-mswap' }, props.copied ? 'Copied' : 'Copy')))),
      h('p', { className: 'ex-pair-p' }, 'Paste it in Elevenex on the other computer, in Machines › Pair a computer. Keep it to yourself: it lets that computer use this one.'));
  }
  function PairPaste(props) {
    var found = props.found;
    return h('div', { className: 'ex-pair' },
      h('label', { className: cx('ex-host-input ex-pair-in', props.text && 'is-filled') }, props.text ? h('span', { key: 'v', className: 'ex-pair-pasted ex-mono' }, props.text) : h('span', { key: 'e', className: 'ex-mgrow ex-pair-ph' }, 'Paste the pairing text', h('span', { className: 'ex-caret' })), props.text ? null : h('kbd', { className: 'ex-kbd' }, '⌘V')),
      h(Fold, { open: !!found }, found ? h('div', { className: 'ex-pair-found' }, h('span', { className: 'ex-mcard-ic' }, h(Icon, { name: 'peer', size: 15 }), h('span', { className: 'ex-mpres is-on' })),
        h('span', { className: 'ex-mgrow ex-mpanel-id' }, h('span', { className: 'ex-mcard-name' }, found.name), h('span', { className: 'ex-mcard-line' }, found.detail))) : null),
      h('p', { className: 'ex-pair-p' }, found ? 'You pair once. After this it opens from Machines, any time, without asking again.' : 'On the other computer: Settings › Pairing › Copy pairing text.'));
  }


  var api = { Icon: Icon, Button: Button, IconButton: IconButton, Kbd: Kbd, StatusGlyph: StatusGlyph, StatusBadge: StatusBadge, StatusSummary: StatusSummary, ProjectRail: ProjectRail, ProjectMark: ProjectMark, StageGlyph: StageGlyph, TaskStage: TaskStage, LinkChip: LinkChip, TaskHeader: TaskHeader, CloseTask: CloseTask, NewTask: NewTask, BranchChip: BranchChip, BranchPicker: BranchPicker, branchItems: branchItems, WorkspacePicker: WorkspacePicker, WorkspaceStatus: WorkspaceStatus, TaskLine: TaskLine, branchFromTitle: branchFromTitle, STAGE: STAGE, SessionRow: SessionRow, TaskGroup: TaskGroup, TaskList: TaskList, PanelTabs: PanelTabs, AgentPicker: AgentPicker, PresetCard: PresetCard, PresetPicker: PresetPicker, SessionStart: SessionStart, ModeToggle: ModeToggle, PermissionPicker: PermissionPicker, ToolsMenu: ToolsMenu, ComposerQueue: ComposerQueue, Switch: Switch, Segmented: Segmented, Waveform: Waveform, PERMS: PERMS, THINKING: THINKING, Mention: Mention, Composer: Composer, Message: Message, SideThread: SideThread, GitBar: GitBar, ChangeList: ChangeList, DiffReview: DiffReview, diffLines: diffLines, usePanelTakeover: usePanelTakeover, Diff: Diff, Ticker: Ticker, Presence: Presence, play: play, Fold: Fold, Turn: Turn, WorkTimeline: WorkTimeline, NowLine: NowLine, FileChip: FileChip, OutcomeBar: OutcomeBar, TurnNav: TurnNav, TurnActs: TurnActs, FlipScope: FlipScope, AutoHeight: AutoHeight, MotionList: MotionList, usePresence: usePresence, useHold: useHold, isSay: isSay, groupSteps: groupSteps, summarize: summarize, settle: settle, fmtDur: fmtDur, ApprovalCard: ApprovalCard, QuestionCard: QuestionCard, PlanCard: PlanCard, ThinkingBlock: ThinkingBlock, ToolStep: ToolStep, StreamText: StreamText, MentionMenu: MentionMenu, Toast: Toast, Tooltip: Tooltip, Skeleton: Skeleton, ContextMeter: ContextMeter, NewMessagesPill: NewMessagesPill, ProgressLine: ProgressLine, STATUS: STATUS, EaseSwap: EaseSwap, ChatScroll: ChatScroll, TitleIsland: TitleIsland, TitleBar: TitleBar, IslandName: IslandName, IslandEvent: IslandEvent, MachinePanel: MachinePanel, MachineCard: MachineCard, MachineHome: MachineHome, MachineLaunch: MachineLaunch, GettingReady: GettingReady, stagedSteps: stagedSteps, RunChoice: RunChoice, HostField: HostField, HostKeyCheck: HostKeyCheck, PairingText: PairingText, PairPaste: PairPaste, MACHINE_ICON: MACHINE_ICON };
  window.Elevenex = Object.assign(window.Elevenex || {}, api);
})();
