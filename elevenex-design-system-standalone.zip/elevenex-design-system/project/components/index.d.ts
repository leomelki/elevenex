import type * as React from 'react';

export type Status = 'running' | 'attention' | 'review' | 'done' | 'failed' | 'queued';
export type IconName = 'plus' | 'arrow-up' | 'terminal' | 'code' | 'changes' | 'actions' | 'globe' | 'fork' | 'side-chat' | 'chat' | 'check' | 'x' | 'chevron-down' | 'chevron-right' | 'at' | 'search' | 'commit' | 'push' | 'more' | 'stop' | 'sidebar' | 'panel' | 'attach' | 'repo' | 'task' | 'copy' | 'expand' | 'file' | 'pr' | 'merged' | 'ticket' | 'link' | 'archive' | 'layers' | 'focus' | 'clock' | 'mic' | 'bolt' | 'shield' | 'plug' | 'steer' | 'pencil' | 'trash' | 'plan' | 'branch' | 'workspace' | 'reset' | 'arrow-down' | 'bulb' | 'question';
export type ProjectHue = 'ocean' | 'pine' | 'plum' | 'rust' | 'steel' | 'rose';

export interface IconProps { name: IconName; size?: number; className?: string }
export declare function Icon(props: IconProps): React.ReactElement;

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'md' | 'sm';
  icon?: IconName;
  iconRight?: IconName;
  kbd?: string;
}
export declare function Button(props: ButtonProps): React.ReactElement;

export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  icon: IconName;
  /** Required: accessible name and tooltip. */
  label: string;
  /** Present = a toggle; true = pressed. */
  active?: boolean;
  size?: 'md' | 'sm';
}
export declare function IconButton(props: IconButtonProps): React.ReactElement;

export interface KbdProps { children: React.ReactNode }
export declare function Kbd(props: KbdProps): React.ReactElement;

export interface StatusGlyphProps { status: Status; size?: number }
export declare function StatusGlyph(props: StatusGlyphProps): React.ReactElement;

export interface StatusBadgeProps { status: Status; label?: string }
export declare function StatusBadge(props: StatusBadgeProps): React.ReactElement;

export interface StatusSummaryProps {
  counts: { attention?: number; running?: number; review?: number; done?: number };
  active?: 'attention' | 'running' | 'review' | 'done';
  onSelect?: (status: 'attention' | 'running' | 'review' | 'done') => void;
}
export declare function StatusSummary(props: StatusSummaryProps): React.ReactElement;

export interface ProjectMarkProps {
  name: string;
  /** Image URL of the project's own logo (square, 72px or more). Falls back to the monogram. */
  logo?: string;
  initials?: string;
  hue?: ProjectHue;
  /** 36 rail, 20 headers, 16–18 rows and pickers. */
  size?: number;
  /** True when the name is written next to the mark. */
  decorative?: boolean;
}
export declare function ProjectMark(props: ProjectMarkProps): React.ReactElement;

export interface Project extends ProjectMarkProps {
  id: string;
  attention?: number;
  running?: number;
  /** Focus mode: dims the tile and hides its counts. */
  muted?: boolean;
}
export interface ProjectRailProps {
  projects: Project[];
  /** Totals for the All projects tile, or false to hide it. */
  all?: { attention?: number; running?: number; muted?: boolean } | false;
  /** 'all' or a project id. */
  activeId?: string;
  onSelect?: (id: string) => void;
  className?: string;
}
export declare function ProjectRail(props: ProjectRailProps): React.ReactElement;

export type Stage = 'planned' | 'active' | 'waiting' | 'closed';
export interface StageGlyphProps { stage: Stage; size?: number }
export declare function StageGlyph(props: StageGlyphProps): React.ReactElement;
export interface TaskStageProps { stage: Stage }
export declare function TaskStage(props: TaskStageProps): React.ReactElement;

export interface LinkChipProps {
  kind: 'pr' | 'ticket';
  /** '#482', 'PAY-212'. */
  label: string;
  /** PR: draft | open | approved | failing | merged | closed. Ticket: the tracker's status text. */
  state?: 'draft' | 'open' | 'approved' | 'failing' | 'merged' | 'closed' | string;
  href?: string;
  /** Key only, for sidebar rows. */
  compact?: boolean;
}
export declare function LinkChip(props: LinkChipProps): React.ReactElement;

export interface TaskHeaderProps {
  title: string;
  stage: Stage;
  branch?: string;
  links?: LinkChipProps[];
  meta?: string;
  project?: ProjectMarkProps;
  git?: GitBarProps;
  /** The linked PR merged or the work looks finished: Close task becomes a labelled button. */
  closeSuggested?: boolean;
  panelOpen?: boolean;
}
export declare function TaskHeader(props: TaskHeaderProps): React.ReactElement;

export interface CloseTaskProps { title: string; sessions: number; running?: number; unpushed?: number; ticket?: string }
export declare function CloseTask(props: CloseTaskProps): React.ReactElement;

export interface BranchInfo { name: string; when?: string; remote?: boolean; /** Held by this task: shown, not pickable. */ task?: string; /** The project's default base. */ isDefault?: boolean }
export interface Workspace { name: string; state: 'free' | 'used'; note?: string; task?: string }
export interface NewTaskProps {
  project: ProjectMarkProps;
  /** Every branch the project knows; `task` marks one another task holds. */
  branches: BranchInfo[];
  /** Branches offered in From; defaults to the free ones. */
  bases?: BranchInfo[];
  /** The project's default base, highlighted in From. */
  base?: string;
  /** Prefix for inferred branch names, from project settings (e.g. 'leo/'). */
  branchPrefix?: string;
  title?: string;
  /** Show a given state. */
  step?: 'name' | 'branch' | 'base';
  /** Text in the branch field; absent = follows the task name. */
  branchQuery?: string;
  baseQuery?: string;
  /** Highlighted row in the open list. */
  hi?: number;
  /** 'auto' or a workspace name. */
  workspace?: string;
  workspaces?: Workspace[];
  workspaceOpen?: boolean;
  links?: LinkChipProps[];
  autoFocus?: boolean;
  /** ↵ on the last step, ⌘↵ anywhere, or the button. Without it the card shows a demo “Created” line. */
  onCreate?: (task: { title: string; branch: string; existing: boolean; base: string | null }) => void;
  /** ⌥↵: save as Planned. */
  onPlan?: (task: { title: string; branch?: string; base?: string }) => void;
  /** Esc. */
  onCancel?: () => void;
}
export declare function NewTask(props: NewTaskProps): React.ReactElement;
export interface BranchRow { kind: 'create' | 'branch' | 'invalid'; name: string; when?: string; remote?: boolean; task?: string; isDefault?: boolean }
export interface BranchPickerProps { query: string; branches?: BranchInfo[]; items?: BranchRow[]; allowCreate?: boolean; base?: string; hi?: number; onPick?: (row: BranchRow) => void; label?: string }
export declare function BranchPicker(props: BranchPickerProps): React.ReactElement;
/** Rows for a query: matches (every word must appear), newest/default first; a Create row on top when allowCreate and the name is new. */
export declare function branchItems(query: string, branches: BranchInfo[], allowCreate?: boolean): BranchRow[];
export interface BranchChipProps { name: string; base?: string; compact?: boolean }
export declare function BranchChip(props: BranchChipProps): React.ReactElement;
export interface WorkspacePickerProps { value?: string; items?: Workspace[]; open?: boolean }
export declare function WorkspacePicker(props: WorkspacePickerProps): React.ReactElement;
export interface TaskLineProps { task: { project?: ProjectMarkProps; title: string; branch?: string; base?: string; workspace?: { state: 'setup' | 'ready'; step?: string } } }
export declare function TaskLine(props: TaskLineProps): React.ReactElement;
/** 'Rate-limit refunds', 'leo/' → 'leo/rate-limit-refunds' (lowercase, hyphens, ≤48 chars). */
export declare function branchFromTitle(title: string, prefix?: string): string;

export interface SessionRowProps {
  title: string;
  status: Status;
  kind?: 'main' | 'fork' | 'side';
  diff?: { add: number; del: number };
  meta?: string;
  selected?: boolean;
  unread?: boolean;
  /** Indent steps (16px each). */
  depth?: number;
  /** Position in its list, for the reveal stagger. */
  index?: number;
  /** Just created: flashes once. */
  fresh?: boolean;
  onClick?: () => void;
}
export declare function SessionRow(props: SessionRowProps): React.ReactElement;

export interface TaskSession extends SessionRowProps {
  /** Stable id: motion (moves, the selection glide) follows it. */
  id: string;
}
export interface TaskGroupProps {
  /** Stable id: the task travels when it changes stage. */
  id?: string;
  title: string;
  sessions: TaskSession[];
  /** The task's PR or ticket (the PR wins); shown in the row only with showLink (the task header always shows it). */
  link?: LinkChipProps;
  showLink?: boolean;
  links?: LinkChipProps[];
  /** Shown in the all-projects view. */
  project?: ProjectMarkProps | null;
  /** `waiting` and `planned` start folded. */
  stage?: 'active' | 'waiting' | 'planned';
  /** The selected session's id. */
  selected?: string;
  /** Show only sessions with this status (and fold away the finished ones). */
  filter?: Status | null;
  collapsed?: boolean;
  /** “+” on the header: a new session in this task. False hides it. */
  onAdd?: (() => void) | false;
  repo?: string;
  /** Just created: its header flashes once. */
  fresh?: boolean;
  /** Arrive open, then fold (set by TaskList when a task moves into a folded stage). */
  startOpen?: boolean;
}
export declare function TaskGroup(props: TaskGroupProps): React.ReactElement;
export interface TaskListProps {
  tasks: Array<TaskGroupProps & { id: string }>;
  /** The selected session's id; the highlight glides to it. */
  selected?: string;
  /** A status (usually 'attention', from StatusSummary): everything else folds away. */
  filter?: Status | null;
  /** False inside one project's view: no project marks. */
  showProjects?: boolean;
  onAdd?: (task: TaskGroupProps) => void;
  className?: string;
}
/** The sidebar's body: tasks by stage (In progress, Waiting, Planned), each group counted; moves between stages travel. */
export declare function TaskList(props: TaskListProps): React.ReactElement;
export interface FlipScopeProps { /** data-flip key of the selected element: its highlight glides there. */ selected?: string; as?: string; className?: string; style?: React.CSSProperties; children?: React.ReactNode }
/** Anything inside marked data-flip="key" glides from where it was to where it is after a change, across lists too. */
export declare function FlipScope(props: FlipScopeProps): React.ReactElement;

export interface PanelTab { id: string; label: string; icon: IconName; badge?: boolean }
export interface PanelTabsProps { tabs: PanelTab[]; active: string; onSelect?: (id: string) => void; labelled?: boolean; label?: string }
export declare function PanelTabs(props: PanelTabsProps): React.ReactElement;

export type Thinking = 'Off' | 'Low' | 'Medium' | 'High' | 'Max';
export interface AgentConfig {
  /** A saved preset's name, when this config is one. */
  preset?: string;
  /** Two-letter harness monogram. */
  mark: string;
  harness: string;
  model: string;
  thinking?: Thinking;
  fast?: boolean;
  /** Share of the context window used, 0–1; shows a ContextMeter in the chip. */
  context?: number;
}
export interface AgentPickerProps {
  value?: AgentConfig;
  open?: boolean;
  placement?: 'top' | 'bottom';
  /** Harness fixed for the running session (default true); 'Fork to…' switches it. */
  locked?: boolean;
  harnesses?: string[];
}
export declare function AgentPicker(props: AgentPickerProps): React.ReactElement;

export interface PresetCardProps { preset?: AgentConfig; selected?: boolean; kbd?: string; custom?: boolean; onSelect?: () => void }
export declare function PresetCard(props: PresetCardProps): React.ReactElement;
export interface PresetPickerProps {
  presets: AgentConfig[];
  /** Selected preset name, or 'custom'. */
  value?: string;
  onSelect?: (preset: string) => void;
  /** Pills instead of cards (NewTask). */
  compact?: boolean;
  /** False hides the Custom card. */
  custom?: boolean;
}
export declare function PresetPicker(props: PresetPickerProps): React.ReactElement;
export interface SessionStartProps {
  presets: AgentConfig[];
  /** Preset selected at first: the last used in this task, else the first. */
  value?: string;
  /** Task line: name, branch and workspace setup. */
  task?: TaskLineProps['task'];
  context?: React.ReactNode;
  title?: string;
  composer?: ComposerProps;
}
export declare function SessionStart(props: SessionStartProps): React.ReactElement;

export interface ModeToggleProps { value: 'plan' | 'code'; onChange?: (mode: 'plan' | 'code') => void }
export declare function ModeToggle(props: ModeToggleProps): React.ReactElement;

export type Permission = 'ask' | 'edits' | 'auto';
export interface PermissionPickerProps { value: Permission; open?: boolean }
export declare function PermissionPicker(props: PermissionPickerProps): React.ReactElement;

export interface McpServer { name: string; tools?: number; on?: boolean; error?: string }
export interface ToolsMenuProps { servers?: McpServer[]; open?: boolean }
export declare function ToolsMenu(props: ToolsMenuProps): React.ReactElement;

export interface ComposerQueueProps { items: Array<{ text: string }> }
export declare function ComposerQueue(props: ComposerQueueProps): React.ReactElement;

export interface SwitchProps { on: boolean; label: string; onChange?: (on: boolean) => void }
export declare function Switch(props: SwitchProps): React.ReactElement;

export interface SegmentedOption { id: string; label?: string; icon?: IconName; title?: string }
export interface SegmentedProps { options: SegmentedOption[]; value: string; onChange?: (id: string) => void; size?: 'md' | 'sm'; label?: string; className?: string }
export declare function Segmented(props: SegmentedProps): React.ReactElement;

export interface MentionProps { kind?: 'session' | 'task' | 'file'; status?: Status; removable?: boolean; children: React.ReactNode }
export declare function Mention(props: MentionProps): React.ReactElement;

export interface ComposerProps {
  mode?: 'plan' | 'code';
  agent?: AgentConfig;
  /** Hide the agent chip (SessionStart, where preset cards choose it). */
  hideAgent?: boolean;
  permission?: Permission;
  servers?: McpServer[];
  /** Attached files and mentions, shown as removable chips. */
  context?: Array<{ kind: 'session' | 'task' | 'file'; status?: Status; label: string }>;
  queue?: Array<{ text: string }>;
  /** Shows Stop; Send becomes Queue when there is text. */
  running?: boolean;
  /** Files are being dragged over: the edge breathes and the box says “Drop to attach”. */
  dropping?: boolean;
  /** Dictation in progress. */
  recording?: { time?: string; interim?: string } | false;
  placeholder?: string;
  hasText?: boolean;
  agentOpen?: boolean;
  permissionOpen?: boolean;
  toolsOpen?: boolean;
  className?: string;
  children?: React.ReactNode;
}
export declare function Composer(props: ComposerProps): React.ReactElement;

export interface MessageProps { /** A message you just sent: springs up from the composer. */ isNew?: boolean; /** Lets ChatScroll's reminder follow this message (user messages). */ id?: string; role: 'user' | 'agent'; author?: string; mark?: string; /** User: shown under the bubble on hover. Agent: in the mark's tooltip. */ time?: string; sideChats?: number; pinned?: boolean; children: React.ReactNode }
export declare function Message(props: MessageProps): React.ReactElement;

export interface SideThreadProps { title?: string; anchor?: React.ReactNode; className?: string; children?: React.ReactNode }
export declare function SideThread(props: SideThreadProps): React.ReactElement;

export interface GitBarProps { /** uncommitted changed files */ files: number; add?: number; del?: number; /** commits not pushed yet */ ahead?: number; /** while it runs: 'commit' or 'push' */ busy?: 'commit' | 'push'; onCommit?: () => void; onPush?: () => void; compact?: boolean }
export declare function GitBar(props: GitBarProps): React.ReactElement;

export interface ChangeItem { path: string; status: 'M' | 'A' | 'D' | 'R'; add?: number; del?: number; /** the file you're on (`selected` also works) */ current?: boolean; selected?: boolean; viewed?: boolean; /** changed since you viewed it */ changed?: boolean }
export interface ChangeListProps { items: ChangeItem[]; /** files under their folder */ grouped?: boolean; onSelect?: (path: string) => void }
export interface DiffFile { path: string; status: 'M' | 'A' | 'D' | 'R'; /** line counts, known before the lines load (git numstat) */ add?: number; del?: number; /** bump when the file changes: its lines are fetched again */ rev?: number; /** the file before, if already known (omit for added files) */ old?: string; /** the file now, if already known (omit for deleted files) */ new?: string; oldPath?: string; binary?: boolean; viewed?: boolean; changedSinceViewed?: boolean }
export interface DiffReviewProps {
  files: DiffFile[];
  /** fetch a file's two versions when it comes near the view */ loadFile?: (path: string) => Promise<{ old?: string; new?: string }>;
  mode?: 'changes' | 'full'; onMode?: (mode: 'changes' | 'full') => void;
  /** two gutters and the file column; otherwise decided by width (720px and up) */ wide?: boolean;
  wrap?: boolean; context?: number; largeAt?: number;
  onViewed?: (path: string, viewed: boolean) => void;
  /** a line question for the agent; false hides the line + */ onComment?: ((c: { path: string; line: number; side: 'old' | 'new'; text: string }) => void) | false;
  onOpenFile?: (path: string) => void;
  /** Esc with nothing open (leaves the wider review) */ onExit?: () => void;
  /** gets { goTo(path), step(dir) } */ controller?: { current: { goTo(path: string): void; step(dir: 1 | -1): void } | null };
  toolbarEnd?: React.ReactNode;
  className?: string; style?: React.CSSProperties;
}
/** The Changes view, reviewed like a pull request: every changed file in one scroll, hunks with context you can open, files you mark Viewed, a file list to jump with, and Full files to read each change in its whole file. */
export declare function DiffReview(props: DiffReviewProps): React.ReactElement;
/** The Changes panel takes over the chat for a while: returns the ref for the main area; the shell gets `is-takeover`. */
export declare function usePanelTakeover(on: boolean): React.RefObject<HTMLElement>;
/** The line diff DiffReview uses: [{ t: ' ' | '-' | '+', o, n, s }] with removed lines before added ones in each change. */
export declare function diffLines(a: string[], b: string[]): { t: ' ' | '-' | '+'; o: number | null; n: number | null; s: string }[];
export declare function ChangeList(props: ChangeListProps): React.ReactElement;

/* ── Agent moments ── */
export type ApprovalStatus = 'pending' | 'approved' | 'always' | 'denied';
export interface ApprovalCardProps { kind?: 'command' | 'edit' | 'tool'; command?: string; file?: string; diff?: { add: number; del: number }; tool?: string; reason?: string; where?: string; status?: ApprovalStatus; onResolve?: (s: ApprovalStatus) => void; onUndo?: false | (() => void) }
export declare function ApprovalCard(props: ApprovalCardProps): React.ReactElement;
export interface QuestionOption { label: string; detail?: string; recommended?: boolean }
export interface Question { id?: string; /** short name for the step strip, e.g. "Retry policy" */ header?: string; question: string; /** single: pick one (radio) · multi: pick any (checkboxes) */ kind?: 'single' | 'multi'; options: QuestionOption[] }
export interface QuestionCardProps {
  /** One question: question + options (+ kind). Several in a row: questions. */
  question?: string; options?: QuestionOption[]; kind?: 'single' | 'multi'; header?: string;
  questions?: Question[];
  /** Show it answered: answer (one question) or answers ({ [id]: labels }). */
  answer?: string | string[]; answers?: Record<string, string[]>;
  onSubmit?: (answers: Record<string, string[]>) => void;
}
export declare function QuestionCard(props: QuestionCardProps): React.ReactElement;
export interface PlanCardProps { title?: string; steps: Array<{ text: string; state?: 'todo' | 'running' | 'done' }>; status?: 'proposed' | 'running' | 'done'; onStart?: () => void }
export declare function PlanCard(props: PlanCardProps): React.ReactElement;
export interface ThinkingBlockProps { active?: boolean; seconds?: number; open?: boolean; children?: React.ReactNode }
export declare function ThinkingBlock(props: ThinkingBlockProps): React.ReactElement;
export interface ToolStepProps { icon?: IconName; verb?: string; detail: string; status?: 'running' | 'done' | 'failed'; meta?: string; output?: string; open?: boolean }
export declare function ToolStep(props: ToolStepProps): React.ReactElement;
export interface StreamTextProps { text: string; streaming?: boolean; /** Types the text out, for previews. */ demo?: boolean; speed?: number; run?: number }
export declare function StreamText(props: StreamTextProps): React.ReactElement;
export interface MentionMenuProps { query?: string; sessions?: Array<{ label: string; status?: Status; meta?: string }>; tasks?: Array<{ label: string; stage?: Stage; meta?: string }>; files?: Array<{ label: string; meta?: string }>; hi?: number; inline?: boolean }
export declare function MentionMenu(props: MentionMenuProps): React.ReactElement;

/* ── Feedback ── */
export interface ToastProps { title: string; detail?: string; action?: string; tone?: 'danger'; glyph?: Status; /** ms; 0 keeps it. */ duration?: number }
export declare function Toast(props: ToastProps): React.ReactElement;
export interface TooltipProps { label: string; kbd?: string; side?: 'top' | 'bottom' }
export declare function Tooltip(props: TooltipProps): React.ReactElement;
export interface SkeletonProps { variant?: 'rows' | 'message'; count?: number }
export declare function Skeleton(props: SkeletonProps): React.ReactElement;
export interface ContextMeterProps { used: number; tokens?: string; compact?: boolean }
export declare function ContextMeter(props: ContextMeterProps): React.ReactElement;
export interface NewMessagesPillProps { count?: number }
export declare function NewMessagesPill(props: NewMessagesPillProps): React.ReactElement;
export interface ProgressLineProps { /** 0–1; absent = indeterminate. */ value?: number }
export declare function ProgressLine(props: ProgressLineProps): React.ReactElement;
/* ── Agent turns ── */
export type StepKind = 'think' | 'read' | 'search' | 'list' | 'edit' | 'create' | 'run' | 'test' | 'tool' | 'web' | 'ask' | 'say' | 'note';
export interface Step {
  kind: StepKind;
  /** Path, command, query or tool target (mono). */
  detail?: string;
  /** Overrides the default verb (Ran, Edited…); live steps use the -ing form (Running, Testing…). */
  verb?: string;
  status?: 'running' | 'done' | 'failed';
  /** Result text: '6 of 50 failed', '143 / 200'. */
  meta?: string;
  /** Test result shown as a fact: '200/200 passed'. */
  result?: string;
  /** Shown only over a second: '48s'. */
  dur?: string;
  diff?: { add: number; del: number };
  output?: string;
  /** Diff lines prefixed with '+', '-' or ' '. */
  hunk?: string[];
  /** A failure the agent got past: true or a short reason ('fixed by backoff'). Inferred when a later run/test passes. */
  recovered?: boolean | string;
  /** A failure caused on purpose (reproducing a bug): true or a short reason. */
  expected?: boolean | string;
  /** kind 'say' (or the older 'note'): what the agent writes between steps, shown as prose in the thread.
   *  kind 'think': the reasoning, shown on click (finished) or streaming in the NowLine (live). */
  text?: string;
  /** kind 'think': a short title for the thought ('Backoff or a longer delay'). */
  title?: string;
  /** Live thinking: type the text out (demos). */
  stream?: boolean;
  /** Live only. */
  progress?: number;
  elapsed?: number;
  open?: boolean;
}
export interface TurnProps {
  status?: 'live' | 'done' | 'stopped' | 'failed';
  steps?: Step[];
  /** Seconds the turn took (finished). */
  duration?: number;
  /** Seconds so far (live). */
  elapsed?: number;
  outcome?: OutcomeBarProps;
  error?: string;
  /** Start unfolded. */
  open?: boolean;
  /** Thread rows visible while live (default 4). */
  maxVisible?: number;
  /** Shown as the agent mark's tooltip with the time. */
  author?: string; mark?: string; time?: string;
  /** Live: the Stop chip on the work line. Pass false to hide it. */
  onStop?: (() => void) | false;
  children?: React.ReactNode;
}
export declare function Turn(props: TurnProps): React.ReactElement;
/** Side chat, fork, copy: icon buttons shown on hover or focus of a reply. */
export declare function TurnActs(): React.ReactElement;
export declare function isSay(step: Step): boolean;
export interface WorkTimelineProps { steps: Step[]; live?: boolean; maxVisible?: number }
export declare function WorkTimeline(props: WorkTimelineProps): React.ReactElement;
export interface NowLineProps { kind?: StepKind; verb?: string; detail?: string; /** Thinking: the thought's title. */ title?: string; /** Thinking: the reasoning, last lines shown. */ text?: string; stream?: boolean; meta?: string; elapsed?: number; progress?: number }
export declare function NowLine(props: NowLineProps): React.ReactElement;
export interface FileChipProps { path: string; add?: number; del?: number; status?: 'M' | 'A' | 'D'; index?: number }
export declare function FileChip(props: FileChipProps): React.ReactElement;
export interface OutcomeBarProps { files: FileChipProps[]; action?: string; actionIcon?: IconName; max?: number }
export declare function OutcomeBar(props: OutcomeBarProps): React.ReactElement;
export interface TurnNavProps { turns: Array<{ id: string; label: string; meta?: string; state?: 'changes' | 'attention' | 'live' }>; active?: string }
export declare function TurnNav(props: TurnNavProps): React.ReactElement;
export interface FoldProps { open: boolean; className?: string; children: React.ReactNode }
export declare function Fold(props: FoldProps): React.ReactElement;
export interface AutoHeightProps { /** ms the box keeps its explicit height after the last change (default 240). */ duration?: number; className?: string; innerClassName?: string; children: React.ReactNode }
/** A box that eases to its content's height: swaps and jumps ease over dur-base; small steps are followed as they come. */
export declare function AutoHeight(props: AutoHeightProps): React.ReactElement;
export interface MotionListProps { items: Array<{ key: string; node: React.ReactNode }>; as?: string; itemAs?: string; className?: string; role?: string; /** Leave duration in ms (default 300; matches dur-slow plus a frame). */ exit?: number }
/** A keyed list whose new rows grow in and removed rows collapse out. */
export declare function MotionList(props: MotionListProps): React.ReactElement;
/** { m: mounted, l: leaving } — keeps an element for `exit` ms after `show` turns false. */
export declare function usePresence(show: boolean, exit?: number): { m: boolean; l: boolean };
/** The last non-empty value, held for `ms` after it empties (bridges gaps between two actions). */
export declare function useHold<T>(value: T | null | undefined, ms?: number): { value: T | null | undefined; on: boolean };
/** Consecutive reads, searches and thinking become one group row. */
export declare function groupSteps(steps: Step[]): Array<Step | { kind: 'group'; label: string; items: Step[]; status: 'running' | 'done' }>;
/** Marks failures superseded by a later passing run/test as recovered. */
export declare function settle(steps: Step[]): Step[];
/** Up to four facts for the work line, most important first. */
export declare function summarize(steps: Step[]): Array<{ text: string; icon: IconName; tone?: 'ok' | 'danger'; diff?: { add: number; del: number } }>;
/** 252 → '4m 12s'. */
export declare function fmtDur(seconds: number): string;

export interface PresenceProps { show: boolean; /** ms, default 160 */ exit?: number; children: React.ReactNode }
/** Keeps a child mounted while it plays its exit (.is-leaving). */
export declare function Presence(props: PresenceProps): React.ReactElement | null;
/** Web Animations with the system's spring tokens; no-op under reduced motion. */
export declare function play(el: Element | null, frames: Keyframe[], opts?: { ease?: string; dur?: string }): Animation | null;
/** A number that rolls up or down when it changes. */
export declare function Ticker(props: { value: number }): React.ReactElement;

/* ── Small parts used across components ── */
export interface DiffProps { add?: number; del?: number }
/** Line counts, +added in diff-add and −removed in diff-del; numbers roll when they change. Renders nothing when both are 0. */
export declare function Diff(props: DiffProps): React.ReactElement | null;
export interface WorkspaceStatusProps { state?: 'setup' | 'ready'; step?: string }
/** “Setting up workspace · installing deps” (running ring) or “Workspace ready” (check), in a task line. */
export declare function WorkspaceStatus(props: WorkspaceStatusProps): React.ReactElement;
export interface WaveformProps { levels?: number[] }
/** The dictation level bars in the composer while recording. */
export declare function Waveform(props: WaveformProps): React.ReactElement;

/** Labels for each status, as shown in badges and tooltips. */
export declare const STATUS: Record<'running' | 'attention' | 'review' | 'done' | 'failed' | 'queued', string>;
/** Labels for each task stage. */
export declare const STAGE: Record<'planned' | 'active' | 'waiting' | 'closed', string>;
/** Thinking levels, in order. */
export declare const THINKING: Array<'Off' | 'Low' | 'Medium' | 'High' | 'Max'>;
/** Permission modes: id, full label, short label for the chip, one-line note. */
export declare const PERMS: Array<{ id: 'ask' | 'edits' | 'auto'; label: string; short: string; note: string }>;

/* ── Machines: where Elevenex runs ── */
export type MachineKind = 'local' | 'ssh' | 'peer';
/** live: connected · kept: its window is picking another machine · idle: not connected (we show what we knew last) · fail: the last try failed */
export type MachineConn = 'live' | 'kept' | 'idle' | 'fail';
export interface Machine { id: string; name: string; kind: MachineKind; conn: MachineConn; address?: string; status?: string; last?: string; color?: string; windows?: number; /** the version it had, when it's behind the app */ update?: string }
export interface TitleIslandProps { contentKey?: string; tone?: 'rest' | 'info' | 'warn' | 'ok'; tall?: boolean; open?: boolean; progress?: number; onClick?: () => void; className?: string; children?: React.ReactNode }
/** The title-bar pill: names the window's machine, grows to tell machine news, opens into MachinePanel. */
export declare function TitleIsland(props: TitleIslandProps): React.ReactElement;
/** The window's title bar: controls on the left, the island centered. Window chrome, not an app bar. */
export declare function TitleBar(props: { className?: string; children?: React.ReactNode }): React.ReactElement;
export declare function IslandName(props: { machine: Machine; guests?: number }): React.ReactElement;
export declare function IslandEvent(props: { icon?: string; title: string; sub?: string; action?: string; onAction?: () => void }): React.ReactElement;
export interface MachinePanelProps { machine: Machine; guests?: Array<{ name: string; since: string }>; highlight?: 'change' | 'new'; onChange?: () => void; onDisconnect?: () => void; onDisconnectGuest?: (g: { name: string; since: string }) => void; onNewWindow?: () => void }
export declare function MachinePanel(props: MachinePanelProps): React.ReactElement;
export declare function MachineCard(props: { machine: Machine; highlighted?: boolean; pressed?: boolean; onOpen?: (m: Machine) => void }): React.ReactElement;
export interface MachineHomeProps { machines: Machine[]; highlighted?: string; pressed?: string; onOpen?: (m: Machine) => void; onAdd?: () => void; onPair?: () => void; title?: string; subtitle?: string }
/** What a window shows before it has a machine. Connects to nothing. */
export declare function MachineHome(props: MachineHomeProps): React.ReactElement;
export interface MachineLaunchProps { open: boolean; /** id of the card it grows from and lands back on */ machine?: string | null; home: React.ReactNode; children?: React.ReactNode; className?: string; style?: React.CSSProperties }
/** Home and a machine stacked; opening grows the machine out of its card like an app launch, closing runs it backwards. */
export declare function MachineLaunch(props: MachineLaunchProps): React.ReactElement;
export interface ReadyStep { label: string; detail?: string; state?: 'todo' | 'active' | 'done' | 'failed'; progress?: number; meta?: string }
export declare function GettingReady(props: { icon?: string; title: string; sub?: string; steps: ReadyStep[]; actions?: React.ReactNode; note?: string; className?: string }): React.ReactElement;
/** Turns one progress value (0 to 1) into step states, given where each step ends. */
export declare function stagedSteps(t: number, marks: number[]): Array<'todo' | 'active' | 'done'>;
export declare function RunChoice(props: { value?: MachineKind; onChange?: (v: MachineKind) => void }): React.ReactElement;
export declare function HostField(props: { query?: string; hosts?: Array<{ name: string; detail: string }>; picked?: { name: string; user: string; port?: number; auth?: string; fromConfig?: boolean } | null }): React.ReactElement;
export declare function HostKeyCheck(props: { host: string; fingerprint: string; type?: string; changed?: boolean }): React.ReactElement;
export declare function PairingText(props: { text: string; copied?: boolean; onCopy?: () => void }): React.ReactElement;
export declare function PairPaste(props: { text?: string; found?: { name: string; detail: string } | null }): React.ReactElement;
export declare const MACHINE_ICON: Record<MachineKind, string>;

export interface ChatScrollProps { children?: React.ReactNode; className?: string; innerClassName?: string; style?: React.CSSProperties; /** false turns the pinned reminder off */ reminder?: boolean; /** opens scrolled to the latest message and follows new content while at the bottom (default true) */ startAtEnd?: boolean }
/** The chat's scrolling area. While you read a reply whose message has scrolled away above, that message stays pinned at the top (two lines, Back to it, Hide). Give user Messages an `id`. */
export declare function ChatScroll(props: ChatScrollProps): React.ReactElement;
export interface EaseSwapProps { /** change it to swap: the old content fades out where it was and the new one fades in over it */ k: string; className?: string; children?: React.ReactNode }
/** Swaps inline content without a jump: crossfades old and new in place while the box's width eases between them. Content with the same key updates in place. */
export declare function EaseSwap(props: EaseSwapProps): React.ReactElement;
declare global {
  interface Window {
    Elevenex: {
      Icon: typeof Icon; Button: typeof Button; IconButton: typeof IconButton; Kbd: typeof Kbd;
      StatusGlyph: typeof StatusGlyph; StatusBadge: typeof StatusBadge; StatusSummary: typeof StatusSummary;
      ProjectRail: typeof ProjectRail; ProjectMark: typeof ProjectMark; StageGlyph: typeof StageGlyph; TaskStage: typeof TaskStage;
      LinkChip: typeof LinkChip; TaskHeader: typeof TaskHeader; CloseTask: typeof CloseTask; NewTask: typeof NewTask; BranchPicker: typeof BranchPicker; BranchChip: typeof BranchChip; WorkspacePicker: typeof WorkspacePicker; TaskLine: typeof TaskLine; SessionRow: typeof SessionRow; TaskGroup: typeof TaskGroup; TaskList: typeof TaskList; FlipScope: typeof FlipScope; PanelTabs: typeof PanelTabs;
      AgentPicker: typeof AgentPicker; PresetCard: typeof PresetCard; PresetPicker: typeof PresetPicker; SessionStart: typeof SessionStart; ModeToggle: typeof ModeToggle; PermissionPicker: typeof PermissionPicker; ToolsMenu: typeof ToolsMenu;
      ComposerQueue: typeof ComposerQueue; Switch: typeof Switch; Segmented: typeof Segmented; Mention: typeof Mention; Composer: typeof Composer; Message: typeof Message;
      SideThread: typeof SideThread; GitBar: typeof GitBar; ChangeList: typeof ChangeList; DiffReview: typeof DiffReview; diffLines: typeof diffLines; usePanelTakeover: typeof usePanelTakeover;
      ApprovalCard: typeof ApprovalCard; QuestionCard: typeof QuestionCard; PlanCard: typeof PlanCard; ThinkingBlock: typeof ThinkingBlock; ToolStep: typeof ToolStep; StreamText: typeof StreamText; MentionMenu: typeof MentionMenu;
      Toast: typeof Toast; Tooltip: typeof Tooltip; Skeleton: typeof Skeleton; ContextMeter: typeof ContextMeter; NewMessagesPill: typeof NewMessagesPill; ProgressLine: typeof ProgressLine; Ticker: typeof Ticker; Presence: typeof Presence; play: typeof play;
      Turn: typeof Turn; WorkTimeline: typeof WorkTimeline; NowLine: typeof NowLine; FileChip: typeof FileChip; OutcomeBar: typeof OutcomeBar; TurnNav: typeof TurnNav; Fold: typeof Fold;
      groupSteps: typeof groupSteps; settle: typeof settle; summarize: typeof summarize; fmtDur: typeof fmtDur;
      TurnActs: typeof TurnActs; isSay: typeof isSay; AutoHeight: typeof AutoHeight; MotionList: typeof MotionList; usePresence: typeof usePresence; useHold: typeof useHold;
      Diff: typeof Diff; WorkspaceStatus: typeof WorkspaceStatus; Waveform: typeof Waveform;
      EaseSwap: typeof EaseSwap; ChatScroll: typeof ChatScroll; TitleIsland: typeof TitleIsland; TitleBar: typeof TitleBar; IslandName: typeof IslandName; IslandEvent: typeof IslandEvent; MachinePanel: typeof MachinePanel; MachineCard: typeof MachineCard; MachineHome: typeof MachineHome; MachineLaunch: typeof MachineLaunch;
      GettingReady: typeof GettingReady; stagedSteps: typeof stagedSteps; RunChoice: typeof RunChoice; HostField: typeof HostField; HostKeyCheck: typeof HostKeyCheck; PairingText: typeof PairingText; PairPaste: typeof PairPaste; MACHINE_ICON: typeof MACHINE_ICON;
      branchItems: typeof branchItems; branchFromTitle: typeof branchFromTitle; STATUS: typeof STATUS; STAGE: typeof STAGE; THINKING: typeof THINKING; PERMS: typeof PERMS;
    };
  }
}
