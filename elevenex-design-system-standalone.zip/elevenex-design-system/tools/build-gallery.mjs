// Builds gallery/: one page per component preview (wrapped with tokens.css, bundle.css, React 18 and bundle.js,
// the way the Claude Design System runtime loads them) and an index that shows every card, in light or dark.
// Usage: node tools/build-gallery.mjs [project] [outDir]   then serve the repo root (npm run serve).
import fs from 'node:fs';
import path from 'node:path';

const proj = process.argv[2] || 'project';
const out = process.argv[3] || 'gallery';
const rel = path.relative(out, proj).split(path.sep).join('/');
/* React 18.3.1 from vendor/ when it's there (works offline), else from unpkg */
const vend = path.relative(out, 'vendor').split(path.sep).join('/');
const local = fs.existsSync(path.join('vendor', 'react.production.min.js'));
const REACT = local ? vend + '/react.production.min.js' : 'https://unpkg.com/react@18.3.1/umd/react.production.min.js';
const REACT_DOM = local ? vend + '/react-dom.production.min.js' : 'https://unpkg.com/react-dom@18.3.1/umd/react-dom.production.min.js';

fs.mkdirSync(out, { recursive: true });
const cards = [];
for (const name of fs.readdirSync(path.join(proj, 'components')).sort()) {
  const p = path.join(proj, 'components', name, 'preview.html');
  if (!fs.existsSync(p)) continue;
  let src = fs.readFileSync(p, 'utf8');
  const meta = /<!--\s*@dsCard([^>]*)-->/.exec(src);
  const attr = (k) => (meta && new RegExp(k + '="?([^"\\s]+)"?').exec(meta[1]) || [])[1];
  const card = { name, group: (meta && /group="([^"]+)"/.exec(meta[1]) || [])[1] || 'Overview', height: +(attr('height') || 200), width: +(attr('width') || 0), page: !!(meta && /\bpage\b/.test(meta[1])) };
  cards.push(card);
  const head = `<meta name="viewport" content="width=device-width, initial-scale=1">
<script>(function(){var t=new URLSearchParams(location.search).get('theme');if(t)document.documentElement.setAttribute('data-theme',t);})();</script>
<link rel="stylesheet" href="${rel}/tokens.css">
<link rel="stylesheet" href="${rel}/components/bundle.css">
<style>html,body{margin:0}body{background:var(--surface);color:var(--ink);font-family:var(--font-sans)}</style>
<script src="${REACT}"></script>
<script src="${REACT_DOM}"></script>
<script src="${rel}/components/bundle.js"></script>`;
  src = src.replace(/<head>/i, '<head>\n' + head);
  fs.writeFileSync(path.join(out, name + '.html'), src);
}

const groups = {};
for (const c of cards) (groups[c.group] = groups[c.group] || []).push(c);
const order = ['Overview', 'Foundations', 'Actions', 'Status', 'Projects', 'Tasks', 'Navigation', 'Chat', 'Conversation', 'Agent moments', 'Changes', 'Feedback', 'Machines', 'Pages'];
const names = Object.keys(groups).sort((a, b) => ((order.indexOf(a) + 1 || 99) - (order.indexOf(b) + 1 || 99)) || a.localeCompare(b));
const index = `<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Elevenex gallery</title>
<link rel="stylesheet" href="${rel}/tokens.css">
<style>
body{margin:0;background:var(--canvas);color:var(--ink);font-family:var(--font-sans)}
header{position:sticky;top:0;z-index:2;display:flex;align-items:center;gap:16px;padding:14px 24px;background:var(--glass);backdrop-filter:blur(20px);box-shadow:0 1px 0 var(--line)}
header h1{margin:0;font-size:17px} header .sp{flex:1} header button{font:inherit;font-size:13px;padding:5px 10px;border-radius:8px;border:1px solid var(--line-strong);background:var(--surface-raised);color:var(--ink);cursor:pointer}
nav{padding:12px 24px;display:flex;flex-wrap:wrap;gap:6px 12px;font-size:12.5px} nav a{color:var(--ink-muted)}
section{padding:8px 24px 24px} h2{font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--ink-muted);margin:16px 0 8px}
.grid{display:flex;flex-wrap:wrap;gap:16px;align-items:flex-start}
figure{margin:0;background:var(--surface);border-radius:12px;box-shadow:inset 0 0 0 1px var(--line);overflow:hidden;max-width:100%}
figcaption{display:flex;gap:8px;align-items:center;padding:8px 12px;font-size:13px;font-weight:600;border-bottom:1px solid var(--line)} figcaption a{margin-left:auto;font-weight:400;font-size:12px;color:var(--ink-muted)}
iframe{display:block;border:0;width:100%;background:var(--surface)}
</style></head><body>
<header><h1>Elevenex</h1><span style="color:var(--ink-muted);font-size:13px">${cards.length} cards · brand book in project/README.md</span><span class="sp"></span><button id="t">Dark</button></header>
<nav>${names.map((g) => `<a href="#${encodeURIComponent(g)}">${g}</a>`).join('')}</nav>
${names.map((g) => `<section id="${encodeURIComponent(g)}"><h2>${g}</h2><div class="grid">${groups[g].map((c) => {
  const w = c.width || (c.page ? 1100 : 760);
  return `<figure style="width:${w}px"><figcaption>${c.name}<a href="${c.name}.html" target="_blank">open</a></figcaption><iframe loading="lazy" data-src="${c.name}.html" src="${c.name}.html" style="height:${c.height}px" title="${c.name}"></iframe></figure>`;
}).join('')}</div></section>`).join('\n')}
<script>
var b=document.getElementById('t'),dark=false;
b.onclick=function(){dark=!dark;document.documentElement.setAttribute('data-theme',dark?'dark':'light');b.textContent=dark?'Light':'Dark';
document.querySelectorAll('iframe').forEach(function(f){f.src=f.getAttribute('data-src')+(dark?'?theme=dark':'');});};
</script></body></html>`;
fs.writeFileSync(path.join(out, 'index.html'), index);
console.log('wrote', cards.length, 'cards to', out);
