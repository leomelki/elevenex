// Writes project/tokens.css from project/tokens.json: every token as a CSS custom property, light and dark,
// plus the type styles as variables and .ex-text-<name> classes.
// Usage: node tools/build-tokens-css.mjs [project]
import fs from 'node:fs';
import path from 'node:path';

const proj = process.argv[2] || 'project';
const T = JSON.parse(fs.readFileSync(path.join(proj, 'tokens.json'), 'utf8'));
const themes = T.color.themes.map((t) => t.id);
const ref = (v) => (typeof v === 'string' && v.startsWith('{') ? `var(--${v.slice(1, -1)})` : v);

function themed(theme, first) {
  const out = [];
  for (const fam of ['color', 'shadow']) {
    for (const t of T[fam].tokens) {
      let v = t.value;
      if (v && typeof v === 'object') v = v[theme] ?? v[themes[0]];
      else if (!first) continue;
      out.push(`  --${t.name}: ${ref(v)};`);
    }
  }
  return out.join('\n');
}

const lines = [];
lines.push('/* Elevenex tokens, generated from tokens.json by tools/build-tokens-css.mjs. Do not edit by hand. */');
lines.push('');
lines.push(`:root, [data-theme="${themes[0]}"] {\n  color-scheme: ${themes[0]};\n${themed(themes[0], true)}\n}`);
for (const th of themes.slice(1)) {
  lines.push(`[data-theme="${th}"] {\n  color-scheme: ${th};\n${themed(th, false)}\n}`);
  lines.push(`@media (prefers-color-scheme: ${th}) {\n  :root:not([data-theme]) {\n    color-scheme: ${th};\n${themed(th, false).replace(/^/gm, '  ')}\n  }\n}`);
}

const root = [];
for (const [fam, v] of Object.entries(T)) {
  if (!v || typeof v !== 'object' || !Array.isArray(v.tokens) || fam === 'color' || fam === 'shadow') continue;
  for (const t of v.tokens) root.push(`  --${t.name}: ${t.value};`);
}
for (const [k, f] of Object.entries(T.type.families)) root.push(`  --font-${k}: ${f};`);
const classes = [];
for (const g of T.type.groups || []) {
  for (const s of g.styles || []) {
    const n = s.name;
    root.push(`  --text-${n}-size: ${s.fontSize};`, `  --text-${n}-line: ${s.lineHeight};`, `  --text-${n}-weight: ${s.fontWeight};`);
    if (s.letterSpacing) root.push(`  --text-${n}-tracking: ${s.letterSpacing};`);
    classes.push(`.ex-text-${n} { font-family: var(--font-${g.family}); font-size: var(--text-${n}-size); line-height: var(--text-${n}-line); font-weight: var(--text-${n}-weight);${s.letterSpacing ? ` letter-spacing: var(--text-${n}-tracking);` : ''}${n === 'overline' ? ' text-transform: uppercase;' : ''} }`);
  }
}
lines.push(`:root {\n${root.join('\n')}\n}`);
lines.push('/* Type styles */');
lines.push(...classes);
fs.writeFileSync(path.join(proj, 'tokens.css'), lines.join('\n') + '\n');
console.log('wrote', path.join(proj, 'tokens.css'));
