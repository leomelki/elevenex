"""Lean bundle.css without changing what renders.
1. Drops rules whose selectors only target classes nothing produces (passed as --dead).
2. For top-level rules with the exact same selector, drops declarations that a later rule redeclares
   (same property, later wins anyway), then drops rules left empty. Inside @media blocks the same is done
   per block. !important declarations are never dropped in favour of a non-important one.
3. Drops @keyframes passed as --dead-kf.
Usage: css_optimize.py in.css out.css --dead a,b --dead-kf k1,k2"""
import re, sys

src, out = sys.argv[1], sys.argv[2]
args = sys.argv[3:]
dead = args[args.index('--dead') + 1].split(',') if '--dead' in args else []
dead_kf = args[args.index('--dead-kf') + 1].split(',') if '--dead-kf' in args else []
css = open(src).read()

# keep the header comment line(s) at the top verbatim
def split_blocks(s):
    """Top-level items: ('comment', text) | ('rule', selector, body) | ('at', prelude, inner) | ('raw', text)."""
    items, i, n = [], 0, len(s)
    while i < n:
        if s.startswith('/*', i):
            j = s.index('*/', i) + 2; items.append(('comment', s[i:j])); i = j; continue
        if s[i].isspace():
            j = i
            while j < n and s[j].isspace(): j += 1
            items.append(('ws', s[i:j])); i = j; continue
        # read prelude up to { or ;
        j = i
        while j < n and s[j] not in '{;':
            if s.startswith('/*', j): j = s.index('*/', j) + 2
            else: j += 1
        if j >= n: items.append(('raw', s[i:])); break
        if s[j] == ';': items.append(('raw', s[i:j + 1])); i = j + 1; continue
        prelude = s[i:j].strip()
        depth, k = 1, j + 1
        while k < n and depth:
            if s.startswith('/*', k): k = s.index('*/', k) + 2; continue
            if s[k] == '{': depth += 1
            elif s[k] == '}': depth -= 1
            k += 1
        inner = s[j + 1:k - 1]
        if prelude.startswith('@'): items.append(('at', prelude, inner))
        else: items.append(('rule', prelude, inner))
        i = k
    return items

def decls(body):
    """Split a declaration block into (prop, value, important) keeping order; tolerant of ; in strings/urls."""
    out, buf, depth, q = [], '', 0, None
    for ch in body:
        if q:
            buf += ch
            if ch == q: q = None
            continue
        if ch in '"\'': q = ch; buf += ch; continue
        if ch == '(': depth += 1
        elif ch == ')': depth -= 1
        if ch == ';' and depth == 0:
            if buf.strip(): out.append(buf.strip())
            buf = ''
        else: buf += ch
    if buf.strip(): out.append(buf.strip())
    res = []
    for d in out:
        if ':' not in d: res.append((None, d, False)); continue
        p, v = d.split(':', 1)
        imp = '!important' in v
        res.append((p.strip().lower(), v.strip(), imp))
    return res

def is_dead(selector):
    parts = [p.strip() for p in selector.split(',')]
    keep = []
    for p in parts:
        cls = re.findall(r'\.(ex-[a-z0-9-]+)', p)
        if any(c in dead for c in cls): continue
        keep.append(p)
    return keep

stats = {'dead_rules': 0, 'dead_selectors': 0, 'dropped_decls': 0, 'empty_rules': 0, 'dead_kf': 0}

def optimize(items):
    # pass 1: dead selectors
    res = []
    for it in items:
        if it[0] == 'rule':
            keep = is_dead(it[1])
            if not keep: stats['dead_rules'] += 1; continue
            if len(keep) != len(it[1].split(',')): stats['dead_selectors'] += 1
            res.append(('rule', ', '.join(keep) if len(keep) != len(it[1].split(',')) else it[1], it[2]))
        elif it[0] == 'at' and it[1].startswith('@keyframes'):
            name = it[1].split()[1]
            if name in dead_kf: stats['dead_kf'] += 1; continue
            res.append(it)
        elif it[0] == 'at' and (it[1].startswith('@media') or it[1].startswith('@supports')):
            res.append(('at', it[1], render(optimize(split_blocks(it[2])))))
        else:
            res.append(it)
    # pass 2: overridden declarations for identical selectors (later wins)
    later = {}  # selector -> {prop: important}
    parsed = [None] * len(res)
    for idx in range(len(res) - 1, -1, -1):
        it = res[idx]
        if it[0] != 'rule': continue
        sel = re.sub(r'\s+', ' ', it[1])
        ds = decls(it[2])
        seen = later.setdefault(sel, {})
        kept = []
        for p, v, imp in reversed(ds):
            if p is None: kept.append((p, v, imp)); continue
            if p.startswith('--'):  # custom properties: also last wins
                pass
            if p in seen and (seen[p] or not imp):
                stats['dropped_decls'] += 1; continue
            seen[p] = seen.get(p, False) or imp
            kept.append((p, v, imp))
        kept.reverse()
        parsed[idx] = kept
    final = []
    for idx, it in enumerate(res):
        if it[0] == 'rule':
            kept = parsed[idx]
            if not kept: stats['empty_rules'] += 1; continue
            body = ' ' + '; '.join((v if p is None else p + ': ' + v) for p, v, imp in kept) + '; '
            final.append(('rule', it[1], body))
        else:
            final.append(it)
    return final

def render(items):
    out = []
    for it in items:
        if it[0] in ('comment', 'ws', 'raw'): out.append(it[1])
        elif it[0] == 'rule': out.append(it[1] + ' {' + it[2] + '}')
        elif it[0] == 'at': out.append(it[1] + ' {' + it[2] + '}')
    return ''.join(out)

items = split_blocks(css)
result = render(optimize(items))
result = re.sub(r'\n{3,}', '\n\n', result)
open(out, 'w').write(result)
print(stats, len(css), '->', len(result))
