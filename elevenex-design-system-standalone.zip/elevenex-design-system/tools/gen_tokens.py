import json, sys
from contrast import cr, blend

C = []  # name, light, dark, usage
def c(n, l, d, u): C.append((n, l, d, u))

# Neutrals — cool slate, the glass stack
c('canvas', '#e9edf1', '#090d12', 'The app backdrop behind every glass layer; shows in the gutters between rail, sidebar, main and side panel.')
c('glass', '#ffffffa8', '#161c24b3', 'Translucent chrome: project rail, sidebar, side-panel header, floating menus. Always with backdrop blur `blur-glass` over `canvas`.')
c('surface', '#f7f9fb', '#10151b', 'The working surface: the chat column and panel bodies.')
c('surface-raised', '#ffffff', '#171d25', 'Cards, the composer, popovers, menus, the selected sidebar row.')
c('surface-sunken', '#eef1f5', '#0c1116', 'Wells: terminal, code blocks, inputs inside raised cards, hovered rows.')
c('line', '#dce2e8', '#222a34', 'Hairlines between rows and inside panels. Decorative only, never the sole boundary of a control.')
c('line-strong', '#7a8693', '#5d6a79', 'Control borders (inputs, secondary buttons, checkboxes): 3:1 on canvas, glass and every surface.')
c('ink', '#0e1621', '#e6ebf1', 'Primary text and icons on canvas, glass and every surface.')
c('ink-muted', '#556271', '#93a0ae', 'Secondary text: metadata, timestamps, placeholders, inactive tabs. On canvas, glass and every surface.')
c('ink-inverse', '#ffffff', '#0e1621', 'Text on an `ink` fill (tooltips).')
# Accent — Tide
c('accent', '#08716a', '#3fd2c3', 'Tide, the one brand hue. Primary action, selection, focus, links and the running state; as text on any surface or `accent-soft`.')
c('accent-soft', '#dcf3f0', '#0e3532', 'Tinted ground behind `accent` text: selected row marker, active tab, mention chip.')
c('on-accent', '#ffffff', '#04201d', 'Text and icons on an `accent` fill (the primary button).')
# Status
c('running', '{accent}', '{accent}', 'Status: an agent is working. Alias of `accent`; always drawn with the spinning ring glyph.')
c('running-soft', '{accent-soft}', '{accent-soft}', 'Ground behind `running` text in a badge.')
c('attention', '#9a5200', '#f2b34a', 'Status: needs you (a question, a permission, a decision). The loudest state; text on any surface or `attention-soft`.')
c('attention-soft', '#fcefd9', '#3a2809', 'Ground behind `attention` text; the tint of a row that needs you.')
c('review', '#4a43d6', '#a9b1ff', 'Status: finished with changes to review. Text on any surface or `review-soft`.')
c('review-soft', '#ebeafc', '#24264f', 'Ground behind `review` text.')
c('done', '{ink-muted}', '{ink-muted}', 'Status: finished, nothing to review. Deliberately quiet: an alias of `ink-muted`, carried by the check glyph.')
c('danger', '#c0283a', '#ff8088', 'Status failed, destructive actions, errors; text on any surface or `danger-soft`.')
c('danger-soft', '#fde8ea', '#3d1519', 'Ground behind `danger` text; destructive confirm surfaces.')
# Diff
c('diff-add', '#1f7a45', '#5fd08a', 'Added lines and +N counts, on surfaces or `diff-add-soft`. Always paired with a + sign: never told from `diff-del` by hue alone.')
c('diff-add-soft', '#e6f4ea', '#0f2a1a', 'Added-line background in the changes view.')
c('diff-del', '#b4232f', '#ff8a8a', 'Removed lines and −N counts, on surfaces or `diff-del-soft`. Always paired with a − sign.')
c('diff-del-soft', '#fbe9ea', '#33161a', 'Removed-line background in the changes view.')
c('diff-add-strong', '#bfe3ca', '#1a472d', 'The changed words inside an added line (word-level highlight) in the changes view; `ink` and every `code-*` stay readable on it.')
c('diff-del-strong', '#f5c6ca', '#5e2630', 'The changed words inside a removed line.')
# Code: a small syntax palette for the changes view and code blocks. Each reads on every surface and diff ground.
c('code-keyword', '#7a3f9e', '#cfa3f0', 'Syntax: keywords (const, return, async, if).')
c('code-string', '#8a4a0b', '#e9b878', 'Syntax: strings and template literals.')
c('code-number', '#9a2c49', '#f5a3bb', 'Syntax: numbers and literals (true, null).')
c('code-function', '#1d5aa0', '#8ab9f2', 'Syntax: function and method names where they are called or declared.')
c('code-comment', '{ink-muted}', '{ink-muted}', 'Syntax: comments. An alias of `ink-muted`, set in italic; inside a word highlight they switch to `ink`.')
# Projects
P = [('ocean', '#1d5fa8', '#7fb3f0'), ('pine', '#2b6e4f', '#74c69d'), ('plum', '#7a3f8f', '#c99ae0'),
     ('rust', '#a5461d', '#f0a07a'), ('steel', '#4a5a6b', '#a8b6c5'), ('rose', '#a3324f', '#f09ab0')]
for n, l, d in P:
    c('project-' + n, l, d, f'Project identity hue “{n}”: the monogram tile fill in the project rail and switcher. Letter on it: `on-project`.')
c('on-project', '#ffffff', '#0b1016', 'Monogram letter on any `project-*` fill.')


def resolve(name, th):
    for n, l, d, u in C:
        if n == name:
            v = l if th == 0 else d
            return resolve(v[1:-1], th) if v.startswith('{') else v
    raise KeyError(name)

fail = False
for th in (0, 1):
    G = {g: resolve(g, th) for g in ['canvas', 'surface', 'surface-raised', 'surface-sunken']}
    gv = resolve('glass', th)
    G['glass'] = blend(gv[:7], int(gv[7:9], 16) / 255, G['canvas'])
    for fg in ['ink', 'ink-muted', 'accent', 'attention', 'review', 'danger', 'diff-add', 'diff-del']:
        for g, v in G.items():
            r = cr(resolve(fg, th), v)
            if r < 4.5: print('FAIL', th, fg, g, round(r, 2)); fail = True
    for g, v in G.items():
        r = cr(resolve('line-strong', th), v)
        if r < 3: print('FAIL border', th, g, round(r, 2)); fail = True
    for fg in ['code-keyword', 'code-string', 'code-number', 'code-function', 'code-comment', 'ink']:
        for bg in ['surface', 'surface-sunken', 'surface-raised', 'diff-add-soft', 'diff-del-soft', 'diff-add-strong', 'diff-del-strong']:
            if fg == 'code-comment' and 'strong' in bg: continue  # inside a word highlight, comments switch to ink
            r = cr(resolve(fg, th), resolve(bg, th))
            if r < 4.5: print('FAIL code', th, fg, 'on', bg, round(r, 2)); fail = True
    for fg, bg in [('accent', 'accent-soft'), ('attention', 'attention-soft'), ('review', 'review-soft'),
                   ('danger', 'danger-soft'), ('on-accent', 'accent'), ('diff-add', 'diff-add-soft'),
                   ('diff-del', 'diff-del-soft'), ('ink-inverse', 'ink'), ('ink', 'attention-soft'),
                   ('ink-muted', 'attention-soft'), ('ink', 'accent-soft'), ('ink-muted', 'accent-soft')]:
        r = cr(resolve(fg, th), resolve(bg, th))
        if r < 4.5: print('FAIL', th, fg, 'on', bg, round(r, 2)); fail = True
    for n, _, _ in P:
        r = cr(resolve('on-project', th), resolve('project-' + n, th))
        if r < 4.5: print('FAIL proj', th, n, round(r, 2)); fail = True
print('contrast FAIL' if fail else 'contrast OK')

def val(l, d): return {'light': l, 'dark': d}

tokens = {
    'name': 'Elevenex', 'version': 1,
    'color': {
        'note': 'Cool slate neutrals stacked as glass over a canvas, one teal accent (Tide), and four status hues that each carry a glyph too.',
        'themes': [{'id': 'light', 'name': 'Light'}, {'id': 'dark', 'name': 'Dark'}],
        'tokens': [{'name': n, 'value': val(l, d), 'usage': u} for n, l, d, u in C]},
    'type': {
        'fonts': [],
        'families': {'sans': '"Instrument Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif',
                     'mono': '"Geist Mono", ui-monospace, "SF Mono", Menlo, monospace'},
        'groups': [
            {'name': 'Interface', 'family': 'sans',
             'note': 'Instrument Sans from Google Fonts (400–700). Dense, calm UI type with one display step.',
             'styles': [
                 {'name': 'display', 'fontSize': '28px', 'lineHeight': '34px', 'fontWeight': 600, 'letterSpacing': '-0.02em', 'sample': 'What should we work on?', 'usage': 'Empty-state prompt and the project title in the switcher. Once per screen.'},
                 {'name': 'title', 'fontSize': '17px', 'lineHeight': '24px', 'fontWeight': 600, 'letterSpacing': '-0.01em', 'sample': 'Fix flaky checkout test', 'usage': 'The task title above the chat; dialog titles.'},
                 {'name': 'body', 'fontSize': '14px', 'lineHeight': '22px', 'fontWeight': 400, 'sample': 'I traced the timeout to the retry wrapper in payments/client.ts.', 'usage': 'Chat messages and panel prose.'},
                 {'name': 'ui', 'fontSize': '13px', 'lineHeight': '18px', 'fontWeight': 500, 'sample': 'New session', 'usage': 'Buttons, tabs, sidebar rows, menu items.'},
                 {'name': 'caption', 'fontSize': '12px', 'lineHeight': '16px', 'fontWeight': 400, 'sample': 'Opus 5.5 · 4m ago', 'usage': 'Metadata under rows, timestamps, helper text.'},
                 {'name': 'overline', 'fontSize': '11px', 'lineHeight': '14px', 'fontWeight': 600, 'letterSpacing': '0.06em', 'sample': 'NEEDS YOU', 'usage': 'Sidebar section labels only; set uppercase.'}]},
            {'name': 'Code', 'family': 'mono',
             'note': 'Geist Mono from Google Fonts. Code, terminal and identifiers.',
             'styles': [
                 {'name': 'code', 'fontSize': '12.5px', 'lineHeight': '20px', 'fontWeight': 400, 'sample': 'pnpm test --filter checkout', 'usage': 'Code blocks, terminal, diffs, editor.'},
                 {'name': 'mono-meta', 'fontSize': '11.5px', 'lineHeight': '16px', 'fontWeight': 500, 'sample': 'PAY-212 · #482 · +38 −12', 'usage': 'Ticket keys, PR numbers, branch names, diff counts, keyboard hints.'}]}]},
    'spacing': {'note': '4px base. Regions are separated by space-2 gutters of canvas, not by lines.', 'tokens': [
        {'name': 'space-1', 'value': '4px', 'usage': 'Icon-to-label gap; glyph padding.'},
        {'name': 'space-2', 'value': '8px', 'usage': 'Inside controls; the gutter between glass regions.'},
        {'name': 'space-3', 'value': '12px', 'usage': 'Row horizontal padding; between related items.'},
        {'name': 'space-4', 'value': '16px', 'usage': 'Card and panel padding.'},
        {'name': 'space-6', 'value': '24px', 'usage': 'Between chat turns; between sections.'},
        {'name': 'space-8', 'value': '32px', 'usage': 'Empty states and page-level spacing.'}]},
    'radius': {'note': 'Soft rectangles that nest: an inner radius is the outer radius minus the padding.', 'tokens': [
        {'name': 'radius-xs', 'value': '4px', 'usage': 'Kbd hints, inline code, mention chips.'},
        {'name': 'radius-sm', 'value': '7px', 'usage': 'Buttons, inputs, tabs, sidebar rows.'},
        {'name': 'radius-md', 'value': '11px', 'usage': 'Cards, menus, popovers, project tiles.'},
        {'name': 'radius-lg', 'value': '16px', 'usage': 'Glass regions (sidebar, main, side panel) and the composer.'},
        {'name': 'radius-full', 'value': '9999px', 'usage': 'Status badges, avatars, the running ring.'}]},
    'shadow': {'note': 'Glass is lit from above: a 1px inner highlight plus a soft drop. Dark leans on the highlight.', 'tokens': [
        {'name': 'shadow-glass', 'value': val('inset 0 1px 0 #ffffffcc, 0 1px 2px #0e16210d, 0 8px 24px -12px #0e16211f', 'inset 0 1px 0 #ffffff0f, 0 1px 2px #00000066, 0 8px 24px -12px #00000099'), 'usage': 'Glass regions: rail, sidebar, main, side panel.'},
        {'name': 'shadow-raised', 'value': val('0 1px 2px #0e162114, 0 2px 6px #0e16210d', 'inset 0 1px 0 #ffffff0d, 0 1px 3px #00000080'), 'usage': 'Composer, cards, the selected row.'},
        {'name': 'shadow-pop', 'value': val('0 12px 32px -8px #0e162133, 0 2px 6px #0e162114', 'inset 0 1px 0 #ffffff14, 0 16px 40px -8px #000000cc'), 'usage': 'Menus, the agent picker, command palette, side-chat popover.'},
        {'name': 'focus-ring', 'value': val('0 0 0 2px #f7f9fb, 0 0 0 4px #08716a', '0 0 0 2px #10151b, 0 0 0 4px #3fd2c3'), 'usage': 'Keyboard focus on every control: a 2px surface gap, then 2px of solid accent (3:1 or more on every surface).'}]},
    'size': {'note': 'Fixed dimensions of the app shell.', 'tokens': [
        {'name': 'rail-width', 'value': '56px', 'usage': 'Project rail.'},
        {'name': 'sidebar-width', 'value': '272px', 'usage': 'Task and session sidebar (resizable 232–360px).'},
        {'name': 'panel-width', 'value': '440px', 'usage': 'Default side panel (terminal, code, changes, actions, browser); resizable.'},
        {'name': 'chat-max', 'value': '760px', 'usage': 'Max width of the chat column and composer.'},
        {'name': 'row-height', 'value': '32px', 'usage': 'Sidebar session rows and menu items.'},
        {'name': 'control-height', 'value': '30px', 'usage': 'Buttons and inputs (small: 24px).'}]},
    'duration': {'note': 'Motion timing. Enter at the listed time, exit at about two thirds of it; nothing a person waits on runs longer than dur-slow.', 'tokens': [
        {'name': 'dur-instant', 'value': '80ms', 'usage': 'Hover, press, color changes: feedback that must feel immediate.'},
        {'name': 'dur-fast', 'value': '140ms', 'usage': 'Small state changes: toggles, tab and segmented thumbs, chips, icon morphs, tooltips.'},
        {'name': 'dur-base', 'value': '200ms', 'usage': 'Menus and popovers in, rows inserting or expanding, messages appearing, toasts.'},
        {'name': 'dur-slow', 'value': '280ms', 'usage': 'Large moves: side panel open and close, dialogs, view changes between sessions and projects.'},
        {'name': 'dur-glide', 'value': '340ms', 'usage': 'Spring moves (with ease-glide or ease-spring): thumbs, the rail indicator, tabs reflowing, marks popping. Feels done by ~60% of it; never blocks input.'},
        {'name': 'dur-deliberate', 'value': '420ms', 'usage': 'One-off confirmations that never block: a check drawing itself, a ring pulse on a new approval.'}]},
    'ease': {'note': 'Curves. Enter on ease-out, leave on ease-in, glide between places on ease-glide, pop small marks on ease-spring. Springs are linear() curves sampled from a damped spring.', 'tokens': [
        {'name': 'ease-out', 'value': 'cubic-bezier(0.16, 1, 0.3, 1)', 'usage': 'Anything entering: menus, messages, rows, toasts. Fast start, soft landing.'},
        {'name': 'ease-in', 'value': 'cubic-bezier(0.4, 0, 1, 1)', 'usage': 'Anything leaving: menus closing, toasts dismissing, cards collapsing.'},
        {'name': 'ease-in-out', 'value': 'cubic-bezier(0.65, 0, 0.35, 1)', 'usage': 'Things moving from one place to another: thumbs, the rail indicator, panels resizing, rows reordering.'},
        {'name': 'ease-glide', 'value': 'linear(0, 0.054 5%, 0.182 10%, 0.372 16%, 0.589 23%, 0.789 31%, 0.934 40%, 1.014 50%, 1.038 62%, 1.028 76%, 1)', 'usage': 'A real spring with about 4% overshoot (damping 0.72): thumbs, the rail indicator, tabs reflowing, menus scaling in. Lively, never wobbly.'},
        {'name': 'ease-spring', 'value': 'linear(0, 0.061 4%, 0.208 8%, 0.444 13%, 0.722 19%, 0.963 26%, 1.101 34%, 1.122 43%, 1.071 53%, 1.009 65%, 0.984 80%, 1)', 'usage': 'A bouncier spring, about 12% overshoot (damping 0.55), for small marks only: counts, pips, checks, glyph changes, the selected-preset check. Never on surfaces.'}]},
    'blur': {'note': 'Backdrop blur for glass.', 'tokens': [
        {'name': 'blur-glass', 'value': '20px', 'usage': 'backdrop-filter on every `glass` region.'},
        {'name': 'blur-pop', 'value': '28px', 'usage': 'backdrop-filter on menus and popovers.'}]},
}
json.dump(tokens, open(sys.argv[1], 'w'), indent=2, ensure_ascii=False)
