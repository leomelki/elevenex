import json, os, re, sys
PROJ = sys.argv[1]
OUT = sys.argv[2]
only = sys.argv[3].split(',') if len(sys.argv) > 3 and sys.argv[3] else None
width = sys.argv[4] if len(sys.argv) > 4 else '900'
T = json.load(open(os.path.join(PROJ, 'tokens.json')))

def v(x):
    return 'var(--%s)' % x[1:-1] if isinstance(x, str) and x.startswith('{') else x
themes = [t['id'] for t in T['color']['themes']]
css = []
for i, th in enumerate(themes):
    decl = []
    for fam in ('color', 'shadow'):
        for t in T[fam]['tokens']:
            val = t['value']
            if isinstance(val, dict):
                val = val.get(th, val[themes[0]])
            elif i > 0:
                continue
            decl.append('--%s: %s;' % (t['name'], v(val)))
    sel = ':root, [data-theme="%s"]' % th if i == 0 else '[data-theme="%s"]' % th
    css.append('%s { %s }' % (sel, ' '.join(decl)))
root = []
for fam in [k for k, v in T.items() if isinstance(v, dict) and 'tokens' in v and k not in ('color', 'shadow')]:
    for t in T[fam]['tokens']:
        root.append('--%s: %s;' % (t['name'], t['value']))
for k, f in T['type']['families'].items():
    root.append('--font-%s: %s;' % (k, f))
css.append(':root { %s }' % ' '.join(root))
tokens_css = '\n'.join(css)

VENDOR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'vendor')
ref = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'ref', 'artifact-type', 'demo.json')
REACT_CDN = ('https://unpkg.com/react@18.3.1/umd/react.production.min.js', 'https://unpkg.com/react-dom@18.3.1/umd/react-dom.production.min.js')
def react_tags(ref_path):
    """React 18 inline from vendor/ when it's there, else from a CDN (needs network)."""
    if os.path.exists(os.path.join(VENDOR, 'react.production.min.js')):
        return '<script>%s</script><script>%s</script>' % (open(os.path.join(VENDOR, 'react.production.min.js')).read(), open(os.path.join(VENDOR, 'react-dom.production.min.js')).read())
    if os.path.exists(ref_path):
        f = json.load(open(ref_path))['content']['files']
        return '<script>%s</script><script>%s</script>' % (f['components/lib/react.production.min.js'], f['components/lib/react-dom.production.min.js'])
    return '<script src="%s"></script><script src="%s"></script>' % REACT_CDN
rtags = react_tags(ref)
bcss = open(os.path.join(PROJ, 'components/bundle.css')).read()
bjs = open(os.path.join(PROJ, 'components/bundle.js')).read()

comps = sorted(d for d in os.listdir(os.path.join(PROJ, 'components')) if os.path.isdir(os.path.join(PROJ, 'components', d)))
if only: comps = [c for c in comps if c in only]
sections = []; scripts = []; styles = []
n = 0
for c in comps:
    p = os.path.join(PROJ, 'components', c, 'preview.html')
    if not os.path.exists(p): continue
    src = open(p).read()
    m = re.search(r'<script>([\s\S]*?)</script>', src)
    st = re.search(r'<style>([\s\S]*?)</style>', src)
    if st: styles.append(st.group(1).replace('html, body, #root', '.hx-none').replace('body {', '.hx-none {').replace('html, body {', '.hx-none {'))
    cls = re.search(r'<div id="root" class="([^"]*)"', src)
    cls = cls.group(1) if cls else ''
    hm = re.search(r'height=(\d+)', src); hgt = hm.group(1) if hm else '120'
    if not m:
        inner = re.search(r'<body>([\s\S]*?)</body>', src).group(1)
        for th in themes:
            sections.append('<div class="hx-card" data-theme="%s"><div class="hx-lab">%s · %s</div><div style="height:%spx;position:relative;overflow:hidden;background:var(--canvas)">%s</div></div>' % (th, c, th, hgt, inner))
        continue
    body = m.group(1)
    for th in themes:
        n += 1
        rid = 'r%d' % n
        sections.append('<div class="hx-card" data-theme="%s"><div class="hx-lab">%s · %s</div><div id="%s" class="%s" style="height:%spx;box-sizing:border-box;overflow:hidden;background:var(--surface);color:var(--ink)"></div></div>' % (th, c, th, rid, cls, hgt))
        scripts.append('(function(){try{' + body.replace("document.getElementById('root')", "document.getElementById('%s')" % rid) + '}catch(e){document.getElementById("%s").textContent="ERROR "+e.message;}})();' % rid)

html = '''<!doctype html><html><head><meta charset="utf-8"><style>%s
%s
%s
.hx-card{margin:0 0 16px;border:1px solid #888;width:%spx;font-family:var(--font-sans)}.hx-lab{font:11px monospace;padding:2px 6px;background:#ccc;color:#000}
</style></head><body style="margin:8px;background:#999">%s
%s<script>%s</script><script>%s</script></body></html>''' % (
    tokens_css, bcss.split('\n', 1)[1], '\n'.join(styles), width, '\n'.join(sections), rtags, bjs, '\n'.join(scripts))
open(OUT, 'w').write(html)
print('wrote', OUT, n)
