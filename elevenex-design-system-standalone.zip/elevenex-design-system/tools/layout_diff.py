"""Before/after layout check: renders the same previews from two project versions side by side (iframes) and
compares the box of every visible text element, card by card. Reports anything that moved or resized > 1.5px."""
import html, subprocess, sys, os
before, now, out, comps = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
here = os.path.dirname(os.path.abspath(__file__))
pages = []
for i, proj in enumerate((before, now)):
    tmp = '/tmp/ld-%d.html' % i
    subprocess.run(['python3', os.path.join(here, 'harness.py'), proj, tmp, comps, '900'], check=True, capture_output=True)
    s = open(tmp).read().replace('<head>', '<head><script>window.setInterval=function(){return 0};window.setTimeout=function(){return 0};</script>', 1).replace('</style>', '.hx-card[data-theme="dark"]{display:none} *{animation-duration:0s!important;animation-delay:0s!important;transition-duration:0s!important;transition-delay:0s!important}</style>', 1)
    pages.append(s)
doc = '''<!doctype html><html><head><meta charset="utf-8"><style>body{margin:0;background:#222;color:#0f0;font:12px monospace} iframe{width:960px;height:4000px;border:0;background:#fff} #r{position:fixed;inset:0;overflow:auto;background:#111;padding:10px;white-space:pre-wrap;z-index:9}</style></head><body>
<div id="r">comparing…</div>
<iframe id="a" srcdoc="%s"></iframe><iframe id="b" srcdoc="%s"></iframe>
<script>
function boxes(doc){
  var out={};
  doc.querySelectorAll('.hx-card[data-theme="light"]').forEach(function(card){
    var name=card.querySelector('.hx-lab').textContent.split(' ')[0], cr=card.getBoundingClientRect(), list=[];
    var w=doc.createTreeWalker(card,NodeFilter.SHOW_TEXT);
    while(w.nextNode()){ var t=w.currentNode, txt=t.textContent.trim(); if(!txt) continue; var el=t.parentElement; if(!el||el.closest('.hx-lab')||el.closest('[aria-hidden="true"]')||el.closest('[inert]')||el.closest('.is-leave')) continue;
      var cs=doc.defaultView.getComputedStyle(el); if(cs.visibility==='hidden') continue; var op=1,e=el; while(e&&e!==card){ op*=parseFloat(doc.defaultView.getComputedStyle(e).opacity); e=e.parentElement; } if(op<0.05) continue;
      var r=doc.createRange(); r.selectNodeContents(t); var b=r.getBoundingClientRect(); if(b.width<1||b.height<1) continue;
      list.push({t:txt.slice(0,40),x:b.left-cr.left,y:b.top-cr.top,w:b.width,h:b.height}); }
    card.querySelectorAll('input,button,label,.ex-bf-input,.ex-menu,.ex-filechip,.ex-approval,.ex-nt-row,.ex-session,.ex-task-head').forEach(function(el){ if(el.closest('[aria-hidden="true"]')||el.closest('[inert]')||el.closest('.is-leave')) return; var b=el.getBoundingClientRect(); if(b.width<1||b.height<1) return; list.push({t:'<'+el.tagName.toLowerCase()+'.'+String(el.className).split(' ')[0]+'>',x:b.left-cr.left,y:b.top-cr.top,w:b.width,h:b.height}); });
    out[name]=list; });
  return out;
}
function styles(doc){ var out={}; var P=['color','backgroundColor','backgroundImage','boxShadow','borderRadius','borderTopColor','borderTopWidth','fontFamily','fontSize','fontWeight','lineHeight','letterSpacing','opacity','animationName','animationDuration','animationTimingFunction','transitionProperty','transitionDuration','transitionTimingFunction','transform','filter','display','gap','padding','margin','overflow','cursor','textDecorationLine','outlineStyle','webkitMaskImage','zIndex','position','gridTemplateRows','gridTemplateColumns','justifyContent','alignItems','flexDirection','whiteSpace','visibility'];
  doc.querySelectorAll('.hx-card[data-theme]').forEach(function(card){ var name=card.querySelector('.hx-lab').textContent; var list=[]; card.querySelectorAll('*').forEach(function(el){ var cs=doc.defaultView.getComputedStyle(el); list.push(P.map(function(k){return cs[k];}).join('|')); ['::before','::after'].forEach(function(pe){ var c2=doc.defaultView.getComputedStyle(el,pe); if(c2.content&&c2.content!=='none') list.push(pe+P.map(function(k){return c2[k];}).join('|')); }); }); out[name]=list; }); return out; }
setTimeout(function(){
  if(window.__STYLE){ var SA=styles(document.getElementById('a').contentDocument), SB=styles(document.getElementById('b').contentDocument), rs=[]; Object.keys(SA).forEach(function(k){ var a=SA[k], b=SB[k]||[]; if(a.length!==b.length){ rs.push('DOM   '+k+' '+a.length+' vs '+b.length); return; } var n=0, ex=''; for(var i=0;i<a.length;i++) if(a[i]!==b[i]){ n++; if(!ex){ var x=a[i].split('|'), y=b[i].split('|'); for(var j=0;j<x.length;j++) if(x[j]!==y[j]){ ex='prop#'+j+': '+x[j].slice(0,60)+' → '+y[j].slice(0,60); break; } } } rs.push((n?'STYLE ':'same  ')+k+(n?'  '+n+' elements, e.g. '+ex:'')); }); document.getElementById('r').textContent=rs.join('\\n'); return; }
  var A=boxes(document.getElementById('a').contentDocument), B=boxes(document.getElementById('b').contentDocument), rep=[];
  Object.keys(A).forEach(function(k){
    var a=A[k], b=B[k]||[]; var ta=a.map(function(x){return x.t}).join('|'), tb=b.map(function(x){return x.t}).join('|');
    if(ta!==tb){ var i=0; while(i<a.length&&i<b.length&&a[i].t===b[i].t) i++; rep.push('TEXT  '+k+'  differs at #'+i+': before "'+(a[i]||{}).t+'" / now "'+(b[i]||{}).t+'"  ('+a.length+' vs '+b.length+')'); return; }
    var moved=[]; for(var i=0;i<a.length;i++){ var d=[b[i].x-a[i].x,b[i].y-a[i].y,b[i].w-a[i].w,b[i].h-a[i].h]; if(d.some(function(v){return Math.abs(v)>1.5})) moved.push('"'+a[i].t+'" dx '+d[0].toFixed(0)+' dy '+d[1].toFixed(0)+' dw '+d[2].toFixed(0)); }
    rep.push((moved.length?'MOVED ':'same  ')+k+(moved.length?'  '+moved.length+' of '+a.length+': '+moved.slice(0,8).join('; '):'  ('+a.length+' texts)'));
  });
  document.getElementById('r').textContent=rep.join('\\n');
}, 2500);
</script></body></html>'''
if os.environ.get('LD_SPLIT'):
    # smaller page: the two versions go into their own files, loaded by src (for viewers with a size limit)
    base = os.path.splitext(out)[0]
    for k, pg in zip('ab', pages): open(base + '-' + k + '.html', 'w').write(pg)
    doc = doc.replace('<iframe id="a" srcdoc="%s"></iframe><iframe id="b" srcdoc="%s"></iframe>', '<iframe id="a" src="%s"></iframe><iframe id="b" src="%s"></iframe>' % (os.path.basename(base) + '-a.html', os.path.basename(base) + '-b.html'))
else:
    doc = doc % (html.escape(pages[0], quote=True), html.escape(pages[1], quote=True))
doc = doc.replace('<div id="r">', '<script>window.__STYLE=%s</script><div id="r">' % ('true' if (len(sys.argv) > 5 and sys.argv[5] == 'style') else 'false'))
open(out, 'w').write(doc)
print('wrote', out)
