"""Inject a frame probe into a harness page: samples, after each frame renders, the top of a 'watch' element
(content below the animating part) and reports every single-frame shift above a threshold."""
import sys
src, out, watch = sys.argv[1], sys.argv[2], sys.argv[3]
secs = sys.argv[4] if len(sys.argv) > 4 else '15'
s = open(src).read()
probe = r'''<div id="probe" style="position:fixed;top:0;right:0;z-index:99;background:#111;color:#0f0;font:12px monospace;padding:8px;max-width:440px;white-space:pre-wrap">sampling…</div>
<script>(function(){
 var t0=performance.now(), S=[], mc=new MessageChannel();
 function q(){ var card=document.querySelector('.hx-card'); if(!card) return null; var el=(%s)(card); return el?el.getBoundingClientRect().top:null; }
 mc.port1.onmessage=function(){ var v=q(); if(v!=null) S.push({t:performance.now()-t0,y:v}); if(performance.now()-t0<%s*1000) requestAnimationFrame(f); else done(); };
 function f(){ mc.port2.postMessage(0); }
 function done(){ var J=[],m=0; for(var i=1;i<S.length;i++){ var d=S[i].y-S[i-1].y; m=Math.max(m,Math.abs(d)); if(Math.abs(d)>6) J.push((S[i].t/1000).toFixed(2)+'s '+(d>0?'+':'')+d.toFixed(1)+'px'); }
   document.getElementById('probe').textContent='frames '+S.length+'\nmax per-frame shift: '+m.toFixed(1)+'px\nshifts >6px: '+J.length+'\n'+J.slice(0,24).join('\n'); }
 requestAnimationFrame(f);
})();</script>''' % (watch, secs)
open(out, 'w').write(s.replace('</body>', probe + '</body>'))
