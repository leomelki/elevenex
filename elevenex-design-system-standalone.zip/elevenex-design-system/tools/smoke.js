// Smoke test: renders every preview's App with a tiny React stand-in and reports exceptions.
// Usage: node tools/smoke.js project
const fs = require('fs'), path = require('path');
const proj = process.argv[2] || 'project';
const React = {
  Fragment: 'F',
  createElement(type, props, ...children) { return { type, props: props || {}, children }; },
  useState(v) { return [typeof v === 'function' ? v() : v, () => {}]; },
  useEffect() {}, useLayoutEffect() {}, useRef(v) { return { current: v }; }, useMemo(f) { return f(); },
};
function render(node) {
  if (node == null || node === false || node === true) return '';
  if (Array.isArray(node)) return node.map(render).join('');
  if (typeof node !== 'object') return String(node).replace(/</g, '&lt;');
  const { type, props, children } = node;
  if (typeof type === 'function') return render(type(Object.assign({}, props, { children: children.length <= 1 ? children[0] : children })));
  const inner = render(children.length ? children : props.children);
  if (type === 'F') return inner;
  const cls = props.className ? ` class="${props.className}"` : '';
  return `<${type}${cls}>${inner}</${type}>`;
}
global.window = { React };
global.React = React;
require(path.resolve(proj, 'components/bundle.js'));
let fail = 0;
for (const c of fs.readdirSync(path.join(proj, 'components'))) {
  const p = path.join(proj, 'components', c, 'preview.html');
  if (!fs.existsSync(p)) continue;
  const m = /<script>([\s\S]*?)<\/script>/.exec(fs.readFileSync(p, 'utf8'));
  if (!m) continue;
  let out = null;
  const ReactDOM = { createRoot: () => ({ render: (el) => { out = render(el); } }) };
  const document = { getElementById: () => ({}) };
  try {
    new Function('window', 'React', 'ReactDOM', 'document', m[1])(global.window, React, ReactDOM, document);
    console.log('ok  ', c.padEnd(18), (out || '').length, 'chars');
  } catch (e) { fail++; console.log('FAIL', c, e.message); }
}
process.exit(fail ? 1 : 0);
